# 🔄 Livesync Setup - Komplet Guide

> Denne guide sikrer stabil sync mellem Windows, Mac og iPhone.

---

## 📋 Oversigt

| Enhed | Rolle | Plugins |
|-------|-------|---------|
| **Windows** | Primær (desktop) | Alle plugins |
| **Mac** | Sekundær (desktop) | Alle plugins |
| **iPhone** | Capture only | Minimalt (kun sync + capture) |

---

## 🔧 TRIN 1: Windows (Primær enhed)

Din Windows er allerede sat op. Sørg for at alt er synkroniseret:

1. **Åbn Obsidian**
2. **Livesync → Sync now** (eller vent på automatisk sync)
3. **Tjek statusbar** - skal vise ✅

---

## 🍎 TRIN 2: Mac Setup

### 2.1 Installer Obsidian
1. Download fra [obsidian.md](https://obsidian.md)
2. Installer og åbn

### 2.2 Opret vault
1. **Create new vault**
2. Navn: `Christian`
3. Vælg placering (fx `~/Documents/Vaults/Christian`)

### 2.3 Installer Livesync
1. **Settings → Community plugins**
2. **Turn on community plugins**
3. **Browse → Søg "Self-hosted LiveSync"**
4. **Install → Enable**

### 2.4 Konfigurer Livesync
1. **Settings → Self-hosted LiveSync**
2. **Setup wizard → Minimal setup**
3. Indtast dine server-oplysninger:
   - **Remote Database URI:** `https://din-server.dk/couchdb/christian-vault`
   - **Username:** din bruger
   - **Password:** dit password
4. **Test connection** → Skal vise ✅
5. **Apply**

### 2.5 Hent alt fra server
1. **Livesync → Replicate**
2. **Vælg: "Fetch everything from remote"**
3. **Vent** - kan tage et par minutter første gang
4. **Genstart Obsidian**

### 2.6 Aktiver plugin sync
1. **Settings → Livesync → Sync Settings**
2. ✅ **Sync hidden files**
3. ✅ **Sync config folder**
4. ✅ **Plugin synchronization**
5. **Heuristic conflict resolution:** Newer file wins

### 2.7 Hent plugins
1. **Livesync → Plugin and their settings**
2. Klik **"Fetch"** på alle plugins
3. **Genstart Obsidian**
4. Alle plugins og settings skulle nu være der!

---

## 📱 TRIN 3: iPhone Setup (Minimal)

iPhone bruges KUN til quick capture - ikke til læsning eller redigering.

### 3.1 Installer Obsidian
1. **App Store → Obsidian**
2. Installer og åbn

### 3.2 Opret vault
1. **Create new vault**
2. Navn: `Christian`
3. Gem i: **On my iPhone** (ikke iCloud!)

### 3.3 Installer Livesync
1. **Settings → Community plugins**
2. **Turn on community plugins**
3. **Browse → "Self-hosted LiveSync"**
4. **Install → Enable**

### 3.4 Konfigurer Livesync
1. **Settings → Self-hosted LiveSync**
2. **Setup wizard → Minimal setup**
3. Samme server-oplysninger som desktop
4. **Test connection** → ✅
5. **Apply**

### 3.5 Hent vault
1. **Livesync → Replicate**
2. **"Fetch everything from remote"**
3. Vent på sync
4. **Genstart Obsidian**

### 3.6 VIGTIGT: Deaktiver plugins på mobil

iPhone skal KUN have disse plugins:

| Plugin | Status | Hvorfor |
|--------|--------|---------|
| **Self-hosted LiveSync** | ✅ Aktiv | Sync |
| **Templater** | ✅ Aktiv | Inbox template |
| **Periodic Notes** | ❌ Deaktiver | Ikke nødvendig |
| **Meta Bind** | ❌ Deaktiver | Desktop only |
| **Iconize** | ❌ Deaktiver | Unødvendig på mobil |
| **Simple Colored Folder** | ❌ Deaktiver | Unødvendig på mobil |
| **Smart Connections** | ❌ Deaktiver | Desktop only |
| **Calendar** | ❌ Deaktiver | Desktop only |
| **Advanced Tables** | ❌ Deaktiver | Desktop only |
| **Manual Sorting** | ❌ Deaktiver | Desktop only |
| **Double Shift** | ❌ Deaktiver | Virker ikke på mobil |
| **Auto Note Mover** | ❌ Deaktiver | Desktop only |
| **Style Settings** | ❌ Deaktiver | Unødvendig på mobil |

**Sådan deaktiverer du:**
1. **Settings → Community plugins**
2. Slå plugins fra (toggle off)

### 3.7 Stop plugin sync TIL mobil

**VIGTIGT:** Vi vil ikke have at mobil-ændringer overskriver desktop-plugins!

1. **Settings → Livesync → Plugin and their settings**
2. Find **"Synchronization mode"**
3. Sæt til: **"Fetch only"** eller **"Semi-automatic"**
4. Dette betyder: mobil HENTER plugins, men SENDER IKKE ændringer

---

## ⚙️ TRIN 4: Sync-indstillinger (Alle enheder)

### Desktop (Windows + Mac)
```
Livesync Settings:
├── Sync on save: ✅
├── Sync on start: ✅
├── Periodic sync: ✅ (60 sek)
├── Sync hidden files: ✅
├── Plugin sync: ✅ (Full sync)
└── Conflict resolution: Newer wins
```

### Mobil (iPhone)
```
Livesync Settings:
├── Sync on save: ✅
├── Sync on start: ✅
├── Periodic sync: ✅ (60 sek)
├── Sync hidden files: ❌ (ikke nødvendigt)
├── Plugin sync: Fetch only
└── Conflict resolution: Newer wins
```

---

## 📲 TRIN 5: iPhone Widget Setup

### Quick Capture Widget
1. **Hjem → Hold nede → + (tilføj widget)**
2. **Søg "Obsidian"**
3. **Vælg "New note" widget**
4. **Placer på homescreen**

### Widget workflow
1. Tryk widget
2. Skriv hurtig note
3. Gemmes automatisk i Inbox
4. Synker til desktop
5. Kør Smart Process Inbox på desktop (Alt+P)

---

## 🔥 TRIN 6: Troubleshooting

### Sync virker ikke
1. **Tjek netværk** - er du online?
2. **Livesync → Sync now** - manuel sync
3. **Tjek server** - er CouchDB oppe?

### Plugins forsvinder på mobil
- Det er **forventet!** Du har deaktiveret dem.
- De er stadig på desktop.

### Konflikter
1. **Livesync → Show conflicts**
2. Vælg den version du vil beholde
3. Slet den anden

### Styling mangler efter sync
1. **Genstart Obsidian** (force close)
2. Vent 30 sek
3. Genstart igen

### Mobil overskriver desktop-settings
1. **Settings → Livesync → Plugin sync**
2. Sæt til **"Fetch only"** på mobil

---

## 📁 Hvad synker?

| Type | Synker? | Note |
|------|---------|------|
| **Noter** | ✅ | Alle .md filer |
| **Mapper** | ✅ | Inkl. tomme (via _.md) |
| **Attachments** | ✅ | Billeder, PDF, etc. |
| **Templates** | ✅ | |
| **Plugins (desktop)** | ✅ | Fuld sync |
| **Plugins (mobil)** | ⚠️ | Fetch only |
| **Theme** | ✅ | Cupertino |
| **CSS Snippets** | ✅ | |
| **Hotkeys** | ✅ | |

---

## 🎯 Dagligt workflow

### Morgen (Desktop)
1. Åbn Obsidian
2. Livesync synker automatisk
3. Åbn/opret Daily Note
4. Tjek Inbox → Kør Alt+P på nye noter

### I løbet af dagen (iPhone)
1. Tryk widget
2. Skriv hurtig note
3. Done! (synker automatisk)

### Aften (Desktop)
1. Tjek Inbox
2. Kør Alt+P på alle nye noter
3. Shutdown Ritual

---

## ✅ Tjekliste efter setup

### Windows
- [ ] Livesync viser ✅
- [ ] Alle plugins aktive
- [ ] Ikoner og farver virker

### Mac
- [ ] Vault synkroniseret
- [ ] Alle plugins aktive
- [ ] Ikoner og farver virker
- [ ] Samme hotkeys som Windows

### iPhone
- [ ] Vault synkroniseret
- [ ] Kun Livesync + Templater aktive
- [ ] Widget virker
- [ ] Noter synker til desktop

---

## 🔐 Sikkerhed

- ✅ End-to-end kryptering aktiveret
- ✅ Passphrase sat
- ✅ HTTPS til server
- ⚠️ Gem aldrig passphrase i noter!
