# 🧩 Anbefalede Plugins

## Høj Prioritet (installer snart)

### Dataview
> Query dine noter som en database

**Eksempler:**
```dataview
TABLE date, energy, mood
FROM "Daily Notes"
WHERE date >= date(today) - dur(7 days)
SORT date DESC
```

**Use cases:**
- Se alle uafsluttede tasks på tværs af vault
- Lav dashboards med projektoversigt
- Track mønstre i energi/humør over tid

---

### Tasks
> Kraftfuld task management

**Features:**
- Deadlines og recurring tasks
- Prioriteter
- Query tasks fra hele vault

**Perfekt til ADHD:** Se ALT der mangler ét sted.

---

### QuickAdd
> Lynhurtig capture med templates

**Features:**
- Capture til Inbox med ét tryk
- Opretter noter med pre-filled data
- Macros for komplekse workflows

**Perfekt til mobil-workflow.**

---

## Medium Prioritet

### Kanban
> Visuel task board

- Træk noter mellem kolonner
- God til projekt-overblik
- ADHD-venlig visuel struktur

---

### Reminder
> Påmindelser i noter

- Sæt reminders direkte i noter
- Notifikationer på desktop/mobil
- God til "waiting for" items

---

### Rollover Daily Todos
> Automatisk flyt ufærdige tasks

- Tasks der ikke er done flyttes til næste dag
- Perfekt til ADHD - intet går tabt

---

### Daily Notes Editor
> Bedre daily note oplevelse

- Scroll mellem dage
- Se flere dage samtidig

---

## Nice-to-have

### Excalidraw
> Tegn og visualiser

- Mind maps
- Flowcharts
- Brainstorming

---

### Heatmap Calendar
> Visualiser aktivitet

- Se mønstre i din vault-brug
- Motiverende at se streaks

---

### Linter
> Automatisk formatering

- Konsistent markdown
- Fixer whitespace, headings, etc.

---

### Obsidian Git
> Version control

- Automatisk backup til GitHub
- Se historik over ændringer

