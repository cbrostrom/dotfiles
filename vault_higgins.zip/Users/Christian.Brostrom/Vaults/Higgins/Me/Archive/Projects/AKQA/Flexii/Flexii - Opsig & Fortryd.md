---
created: 2024-03-19
type: project
project: Flexii
status: archived
tags:
  - work
  - archived
---

# Flexii - Opsig & Fortryd

> ⚠️ **Arkiveret** - Projekt afsluttet

## Meeting notes

## Todos
- [x] Javascript time - 01 til 30 i stedet ✅ 2024-03-19
- [x] Datoer skal have d. i scriptet ✅ 2024-03-19
- [x] Initial state ✅ 2024-03-19
- [x] Send reel request on close ✅ 2024-03-19

