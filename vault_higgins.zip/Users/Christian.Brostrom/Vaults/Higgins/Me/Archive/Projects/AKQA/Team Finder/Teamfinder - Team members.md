---
created: 2024-01-01
type: reference
project: Teamfinder
status: archived
tags:
  - work
  - archived
---

# Teamfinder - Team members

> ⚠️ **Arkiveret** - Projekt afsluttet

## Developers
- Adam
- Konstantina
- Bjarni
- Freja
- Kingo
- Angelo
- Mads Riise
- Brostrøm

## Testers
- Steffen
- Bruun
- Hylling

