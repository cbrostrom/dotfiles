---
created: 2024-10-28
type: reference
project: Themelio
tags:
  - work
  - work/themelio
---

# Themelio - Moduler

## Udvikler flow
*Fordele / værdi for slutkunde*
- 

## Editor experience
*Fordele / værdi for slutkunde*
- 

## Known issues
- Rollback
- Diagram i forhold til deploy (data loss) ved integration til Shopify

