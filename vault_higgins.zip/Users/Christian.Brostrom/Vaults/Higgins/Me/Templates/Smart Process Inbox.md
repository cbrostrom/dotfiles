<%*
// 🤖 Smart Process Inbox - AI-powered tagging
// Tilføjer tags → Auto Note Mover flytter automatisk!

const OPENAI_API_KEY = "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";

// Hent aktiv fil
const activeFile = app.workspace.getActiveFile();
if (!activeFile) {
    new Notice("⚠️ Ingen aktiv fil!", 3000);
    return;
}

const filePath = activeFile.path;
const fileName = activeFile.basename;

// Tjek om vi er i Inbox
if (!filePath.includes("Inbox")) {
    new Notice("⚠️ Denne note er ikke i Inbox!", 3000);
    return;
}

// Hent fil-indhold
const fileContent = await app.vault.read(activeFile);

new Notice("🤖 Analyserer note med AI...", 2000);

// Byg prompt - AI vælger tags, Auto Note Mover flytter!
const prompt = `Analysér denne note og vælg de BEDSTE tags.

PRIMÆR TAG (vælg ÉN - bestemmer hvor noten flyttes):
- #work/fiskars = Fiskars projekt (Shopify)
- #work/themelio = Themelio projekt (Shopify)  
- #work/akqa = Andet AKQA arbejde
- #grønnebakken = Børnehave/institution (Lily)
- #privat = Andre private projekter
- #home = Hus, bolig, vedligeholdelse
- #family = Familie generelt
- #lily = Lily-relateret (ikke institution)
- #tech = Teknologi, gadgets, software
- #homelab = Homelab, VPS, servere
- #vault = Obsidian vault dokumentation
- #reference = Generel viden/reference
- #archived = Gammelt/færdigt
- #sunday-meeting = Søndagsmøde

SEKUNDÆRE TAGS (vælg 0-2 ekstra):
- #next = Skal gøres snart
- #later = Kan vente
- #idea = Idé til senere
- #waiting = Venter på nogen/noget

NOTE: ${fileName}
INDHOLD: ${fileContent.substring(0, 500)}

Svar KUN med JSON: {"primary": "tag-uden-hashtag", "secondary": ["tag1", "tag2"]}
Eksempel: {"primary": "work/fiskars", "secondary": ["next"]}`;

try {
    const response = await requestUrl({
        url: "https://api.openai.com/v1/chat/completions",
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + OPENAI_API_KEY
        },
        body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
                { role: "user", content: prompt }
            ],
            temperature: 0.2,
            max_tokens: 80
        })
    });

    const data = response.json;
    const aiText = data.choices[0].message.content.trim();
    
    // Parse JSON
    const cleanJson = aiText.replace(/```json\n?|\n?```/g, "").trim();
    const result = JSON.parse(cleanJson);
    
    const primaryTag = result.primary;
    const secondaryTags = result.secondary || [];
    const allTags = [primaryTag, ...secondaryTags];
    
    // Byg synlige tags
    const visibleTags = allTags.map(t => "#" + t).join(" ");
    const tagLines = allTags.map(t => "  - " + t).join("\n");
    let newContent;
    
    if (fileContent.startsWith("---")) {
        // Har frontmatter - indsæt tags
        const parts = fileContent.split("---");
        const existingFM = parts[1] || "";
        let body = parts.slice(2).join("---");
        
        // Tilføj synlige tags efter første overskrift eller i starten
        if (body.includes("\n# ")) {
            body = body.replace(/(\n# .+\n)/, "$1\n" + visibleTags + "\n");
        } else if (body.trim().startsWith("# ")) {
            body = body.replace(/(# .+\n)/, "$1\n" + visibleTags + "\n");
        } else {
            body = "\n" + visibleTags + "\n" + body;
        }
        
        if (existingFM.includes("tags:")) {
            newContent = "---" + existingFM.replace(/tags:[\s\S]*?(?=\n[a-z]|\n---)/i, "tags:\n" + tagLines + "\n") + "---" + body;
        } else {
            newContent = "---" + existingFM + "tags:\n" + tagLines + "\n---" + body;
        }
    } else {
        // Ingen frontmatter
        let body = fileContent;
        
        if (body.includes("\n# ")) {
            body = body.replace(/(\n# .+\n)/, "$1\n" + visibleTags + "\n");
        } else if (body.trim().startsWith("# ")) {
            body = body.replace(/(# .+\n)/, "$1\n" + visibleTags + "\n");
        } else {
            body = visibleTags + "\n\n" + body;
        }
        
        newContent = "---\ntags:\n" + tagLines + "\n---\n" + body;
    }
    
    // Gem ændringer - Auto Note Mover flytter automatisk!
    await app.vault.modify(activeFile, newContent);
    
    new Notice("✅ Tags tilføjet!\n\n" + visibleTags + "\n\n(Auto Note Mover flytter noten)", 4000);

} catch (error) {
    new Notice("❌ Fejl: " + error.message, 5000);
    console.error("Smart Process Inbox:", error);
}
-%>
