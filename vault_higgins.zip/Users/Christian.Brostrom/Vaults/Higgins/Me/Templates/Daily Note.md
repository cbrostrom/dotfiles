---
date: <% tp.file.title %>
type: daily
day: <% moment(tp.file.title, "YYYY-MM-DD").format("dddd") %>
tags:
  - daily
---

# <% tp.file.title %> — <% moment(tp.file.title, "YYYY-MM-DD").format("dddd") %>

<< [[<% moment(tp.file.title, "YYYY-MM-DD").subtract(1, 'days').format("YYYY-MM-DD") %>]] | [[<% moment(tp.file.title, "YYYY-MM-DD").add(1, 'days').format("YYYY-MM-DD") %>]] >>

---

## 🐸 One thing

> The one thing that matters today.

- 

---

## 🧠 Notes & Brain dump

---

## 📥 Inbox check

- [ ] Process inbox
