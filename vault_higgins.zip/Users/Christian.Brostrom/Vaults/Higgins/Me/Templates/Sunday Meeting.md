<%*
// Find næste søndag fra i dag
const today = moment();
const daysUntilSunday = (7 - today.day()) % 7 || 7;
const nextSunday = today.add(daysUntilSunday, 'days');
const dateStr = nextSunday.format("YYYY-MM-DD");
const weekStr = nextSunday.format("YYYY-[W]WW");
const prevSunday = moment(dateStr, "YYYY-MM-DD").subtract(7, 'days').format("YYYY-MM-DD");
const nextNextSunday = moment(dateStr, "YYYY-MM-DD").add(7, 'days').format("YYYY-MM-DD");
-%>
---
date: <% dateStr %>
week: <% weekStr %>
type: sunday-meeting
tags:
  - family
  - sunday-meeting
---

# 💬 Søndags-møde - <% dateStr %>

#family #sunday-meeting

<< [[<% prevSunday %>]] | [[<% nextNextSunday %>]] >>

---

## 🗓️ Næste uge

🟦 Christian | 🟩 Sofie | 👶 Lily | 🟥 Andre

| .             | Man | Tirs | Ons | Tors | Fre | Lør | Søn |
| ------------- | --- | ---- | --- | ---- | --- | --- | --- |
| Afleverer     |     |      |     |      |     |     |     |
| Henter        |     |      |     |      |     |     |     |
| Lang dag      |     |      |     |      |     |     |     |
| Bemærkninger  |     |      |     |      |     |     |     |

### Vigtige datoer & aftaler
- 

---

## 🎯 Fokuspunkter næste uge

> *Hvad skal hver person være opmærksom på?*

**Sofie:** 

**Christian:** 

**Familien:** 

---

## 🌟 Ugens gode bemærkning

> *Noget den anden har gjort som du satte pris på*

#### Sofie til Christian
- 

#### Christian til Sofie
- 

#### Om Lily
- 

---

## 💪 Ugens svære ting

> *Noget der var hårdt - del det, så vi bærer det sammen*

#### Sofie
- 

#### Christian
- 

#### Familien
- 

---

## 🔄 Ugens review

### Hvad nåede vi?
- 

### Hvad blev ikke gjort? (og er det okay?)
- 

### Er der noget vi skal snakke om?
- 

---

## 💡 Idéer & ønsker

> *Ting vi gerne vil, men ikke har planlagt endnu*

- 
