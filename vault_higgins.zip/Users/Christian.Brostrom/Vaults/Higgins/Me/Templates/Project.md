---
title: <% tp.file.title %>
created: <% tp.date.now("YYYY-MM-DD") %>
type: project
status: active
tags:
  - project
---

# 📁 Projekt: <% tp.file.title %>

#project

## 🎯 Purpose
Kort formål / hvorfor

---

## 🐸 Next Actions
- [ ] #next 

---

## 📅 Milestones / Deadlines
- YYYY-MM-DD — Milepæl

---

## 📚 Reference
- Link / noter

---

## 📝 Log
- <% tp.date.now("YYYY-MM-DD") %> - Projekt oprettet
