---
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
type: inbox
---

## <% tp.file.title %>

- [ ] #next 
- [ ] #later 
- [ ] #idea 

### Noter
