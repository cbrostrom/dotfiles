---
created: 2026-06-26
area: dev
type: reference
tags: [claude-code, cheatsheet, agents, delivery]
---

# Claude Code Coworker Cheatsheet

Keep this open while using Claude Code.

The main rule: Claude is strongest when you give it a role, context, constraints, and proof requirements.

## Windows 11 Basics

Use PowerShell in Windows Terminal unless the project team specifically uses another shell.

Open a project:

```powershell
cd C:\Projects\ClientProject
claude
```

Useful checks:

```powershell
git --version
node --version
dotnet --version
```

Create or open the project instruction file:

```powershell
New-Item -Path . -Name "CLAUDE.md" -ItemType File
notepad .\CLAUDE.md
```

Windows tips:

- Keep projects in a short local path like `C:\Projects\...`.
- Avoid OneDrive-synced project folders unless the team already uses them.
- Use backslashes in Windows paths: `C:\Projects\SitecoreClient`.
- If Claude suggests Bash commands, ask it to rewrite them for PowerShell.

## The Basic Formula

Use this shape:

```text
Act as [role].

Context:
[paste ticket, notes, code question, PR summary, or error]

Task:
[what you want]

Rules:
- Separate facts from assumptions.
- Ask questions if the request is unclear.
- Do not invent project behavior.
- Tell me what evidence you used.
```

## Best Everyday Prompts

### Understand A Task

```text
Act as Delivery Analyst.

Read this request and turn it into clear delivery work.

Return:
- Summary
- Facts
- Assumptions
- Risks
- Open questions
- Acceptance criteria
- Suggested next action
```

### Write A Jira Ticket

```text
Act as Ticket Writer.

Turn these notes into a Jira-ready ticket.

Include:
- Problem
- Goal
- Scope
- Out of scope
- Acceptance criteria
- Technical notes
- Dependencies
- Test notes
- Open questions
```

### Challenge A Requirement

```text
Pressure-test this requirement before we commit to it.

Find:
- Ambiguity
- Hidden assumptions
- Edge cases
- Delivery risk
- Missing acceptance criteria
- Questions for the requester
```

### Investigate A Bug

```text
Investigate this bug systematically.

Do not guess the fix first.

Return:
- Symptom
- Reproduction steps
- Evidence gathered
- Most likely causes
- What to inspect next
- Proposed fix only after evidence
```

### Review A Pull Request

```text
Act as Code Reviewer.

Review this PR for bugs, regressions, missing tests, unclear behavior, security issues, and maintainability risk.

Put findings first, ordered by severity.
```

### Prepare A Status Update

```text
Create a short delivery status update.

Use:
- Done
- In progress
- Blocked or at risk
- Decisions needed
- Next step

Be honest and concrete.
```

## Strictness Prompts

Use these when Claude becomes too agreeable.

```text
Be stricter. What could be wrong with this?
```

```text
Separate facts, assumptions, and guesses.
```

```text
What evidence supports that?
```

```text
What are you not sure about?
```

```text
What would you check before changing code?
```

```text
Do not solve yet. First show me the risk.
```

```text
What would prove this is done?
```

## Coding Prompts

### Before Editing

```text
Read the relevant files first.

Then tell me:
- What you found
- What change you recommend
- Which files would change
- What risk exists
- How we would verify it

Do not edit yet.
```

### Small Implementation

```text
Make the smallest safe change for this issue.

Rules:
- Follow existing project patterns.
- Do not refactor unrelated code.
- Keep the diff easy to review.
- Tell me how to verify it.
```

### After Editing

```text
Act as Verification Lead.

Summarize:
- What changed
- What commands were run
- What passed
- What was not tested
- Remaining risk
```

## C# / Sitecore / Umbraco Prompts

```text
Act as Sitecore Umbraco Architect.

Before proposing a solution:
- Identify the CMS/version clues visible in the repo.
- Check existing project patterns.
- Separate content model decisions from code decisions.
- Consider editor workflow, caching, permissions, deployment, and rollback.
- Do not claim platform behavior unless the code or docs support it.
```

```text
Review this CMS change for editor impact.

Look for:
- Template or document type risk
- Content migration needs
- Rendering impact
- Cache invalidation
- Permissions
- Preview/editor workflow
- Rollback plan
```

## Meeting And Notes Prompts

```text
Turn these meeting notes into:
- Decisions
- Actions
- Risks
- Open questions
- Follow-up message
```

```text
Write a concise follow-up message from these notes.

Tone: clear, senior, practical.
Do not add promises that were not agreed.
```

## When Claude Says Something Confident

Ask:

```text
Show me the evidence for that claim.
```

If there is no evidence, ask:

```text
Rewrite your answer with facts and assumptions clearly separated.
```

## When Claude Gets Stuck

Use:

```text
Stop and summarize:
- What we know
- What we tried
- What failed
- The next three useful checks
```

Then pick one check. Do not let it loop.

## Red Flags

Be careful when Claude says:

- "This should work"
- "Typically"
- "Best practice"
- "It is likely"
- "Simply"
- "Just"
- "No tests are needed"

These words are not always wrong, but they often hide missing evidence.

## Good Session Flow

1. Start with context: ticket, PR, error, notes, or goal.
2. Assign a role: Delivery Analyst, Ticket Writer, Code Reviewer, Sitecore Umbraco Architect, or Verification Lead.
3. Demand separation of facts and assumptions.
4. Ask for the smallest safe next step.
5. Approve edits only after the plan makes sense.
6. Ask for verification before accepting the result.

## One-Line Agent Calls

```text
Delivery Analyst: clarify this request and expose risk.
```

```text
Ticket Writer: turn this into a Jira-ready ticket.
```

```text
Code Reviewer: find bugs and missing tests first.
```

```text
Sitecore Umbraco Architect: check CMS architecture and editor impact.
```

```text
Verification Lead: prove what is done and what is not.
```

## The Most Important Habit

Do not ask:

```text
Can you fix this?
```

Ask:

```text
Read the relevant context, explain the issue, show the risk, propose the smallest safe fix, and tell me how we verify it.
```
