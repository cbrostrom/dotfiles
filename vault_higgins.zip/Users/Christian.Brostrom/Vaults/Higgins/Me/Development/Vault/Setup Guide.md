---
created: 2026-06-14
area: [meta, dev]
type: reference
tags: [obsidian, setup, plugins, vault, second-brain, ai-organised]
status: active
---

# Brain Vault — Initial Setup Guide

> Obsidian as **viewer + editor only**. AI handles organising, librarian, structure maintenance. Vault is mostly read by AI; you mostly view.

## Operating mode (read this first)

This vault is in **AI-managed mode**:

- **You** dump thoughts into `Inbox/`, browse `Brains/` + areas to read state, occasionally manually edit
- **AI** (Claude) reads, queries, writes, runs librarian, maintains `Brains/<project>.md`, updates frontmatter, links notes
- **Obsidian** = pretty viewer/editor on top. No automation expected from plugins; AI fills that role.

This changes the plugin posture: **strip aggressively**. Only keep what makes the vault look + feel good, or unlocks a specific human-side action.

---

## Plugins ALREADY configured (community)

Transferred from old vault, ready on enable in Obsidian Settings → Community plugins:

| Plugin | Role | Status |
|---|---|---|
| `obsidian-icon-folder` (Iconize) | Folder + file icons, color cues per area | Config migrated, paths rewritten |
| `flexplorer` | Manual folder/file ordering in file explorer | Config migrated, root order set |

Both have updated `data.json` matching the new vault structure.

---

## Core plugins to enable (built-in, free)

In Obsidian Settings → Core plugins:

| Plugin | Why |
|---|---|
| **File Recovery** | Critical safety. Local snapshots survive plugin/LiveSync conflicts. |
| **Backlink** | Already on. Glanceable backlinks pane. |
| **Outgoing Links** | Already on. Symmetric to backlinks. |
| **Tag Pane** | Inline hashtag navigation. Required by Brain CLAUDE.md taxonomy. |
| **Properties** | Frontmatter editor + queryable fields. Foundation for Bases. |
| **Page Preview** | Hover-preview links. Glanceability for ADHD-brain. |
| **Command Palette** | Already on. |
| **Outline** | Already on. Useful in long notes. |
| **Bookmarks** | Pin Dashboard, current Brain, Inbox. Mental hub. |
| **Workspaces** | Save tab layouts per area (Work / Personal / Dev). |

### Skip these core plugins

| Plugin | Why skip |
|---|---|
| **Daily Notes** | Abandoned. Use Inbox instead. |
| **Templates** (core) | If you keep Templater, this is redundant. |
| **Graph** | Disabled by you. AI doesn't read it. Enable later only if YOU want to glance. |
| **Bases** | Powerful but unused so far. Enable later if you want frontmatter-driven views. Skip for now. |
| **Canvas** | Spatial brainstorm. Not your flow. |
| **Sync** (official) | You use LiveSync. |
| **Slides, Audio Recorder, Markdown Importer, Workspaces (until needed)** | Off until proven needed |

---

## Community plugins to add (optional, by need)

Order by likelihood of value to you. Install one at a time. Stop when satisfied.

### Tier 1 — likely worth installing

| Plugin | Why | Effort |
|---|---|---|
| **Omnisearch** | Better full-text search than core. Worth it the first time you search for something. | 30 sec |
| **Obsidian DoubleShift** | Double-tap shift opens quick switcher. Pure UX win. | 30 sec |
| **Minimize on Close** | Minor UX. Harmless. | 30 sec |
| **Table Editor** | Sane table editing in markdown. | 30 sec |
| **Auto Link Title** | Paste URL → fetches page title. Big win for Inbox dumps of articles. | 1 min |

### Tier 2 — install if a specific friction shows up

| Plugin | Trigger to install |
|---|---|
| **Templater** | If you want to manually create timestamped notes via hotkey. AI doesn't need this — capture flow can be a Claude prompt. |
| **QuickAdd** | If Templater isn't enough — multi-step macros (e.g., capture + tag + route). |
| **Linter** | When AI starts writing frontmatter and you want consistent format on save. |
| **Tag Wrangler** | When hashtag taxonomy drifts and you need vault-wide rename. |
| **Advanced URI** | When you want `obsidian://` deep-links to specific blocks. |
| **Style Settings** | When you want to tweak theme variables. |

### Tier 3 — skip unless you have a specific reason

| Plugin | Why skip |
|---|---|
| **Smart Connections** | AI-semantic search you said you don't actively use. Heavy indexer. Re-evaluate if you start browsing AI-side from Obsidian. |
| **Dataview** | AI queries via grep. You don't write DQL. Bases (core) covers human-side. |
| **Calendar / Periodic Notes** | Daily Notes habit is dead. Don't revive accidentally. |
| **Reminder** | Calendar covers reminders elsewhere. |

---

## Theme + appearance

The "feels good" part. Diva clause from sparring doc applies.

### Recommended starting setup

1. **Theme:** Minimal (`@kepano/obsidian-minimal`) — clean, restrained, well-maintained. Or AnuPpuccin if you want more color.
2. **Font:** Inter (UI), iA Writer Duospace (editor body), JetBrains Mono (code). Set in Appearance → Fonts.
3. **Dark mode default.** Light mode that doesn't look broken.
4. **Sidebar width:** narrow file explorer (200-220px). Editor gets the room.
5. **Reading line width:** 700-800px for comfortable scan.

### Style Settings (only if you install it)

Customize via Settings → Style Settings:
- Tighten accent palette to 1-2 colors
- Reduce icon visual weight if Iconize feels noisy
- Adjust heading sizes for ADHD-friendly hierarchy (avoid huge H1)

---

## Hotkeys to set early

Cmd+K / Ctrl+K = command palette. From there:

| Hotkey | Bind to |
|---|---|
| `Cmd+P` | Command Palette (default) |
| `Cmd+O` | Quick Switcher (default) — opens any note by name |
| `Cmd+Shift+F` | Search (Omnisearch if installed, else core) |
| `Cmd+E` | Toggle Reading / Edit mode |
| `Cmd+Shift+N` | New note in Inbox/ (set manually — points to Inbox folder) |
| `Cmd+Shift+I` | Open Iconize picker for current folder |

Adjust to taste. The Cmd+Shift+N for Inbox dump is the most important — your zero-friction capture path.

---

## Workflow recap (what each piece does)

| Action | How |
|---|---|
| Quick capture | `Cmd+Shift+N` → types thought → saves to `Inbox/` with no frontmatter |
| Browse current state | Open `Brains/<project>.md` directly or via Quick Switcher |
| Find what I know about X | Quick Switcher / Omnisearch / Tag pane / Backlink pane (Obsidian-side) |
| Trigger librarian | Switch to Claude Code at vault root → "run librarian" → confirm-per-file flow |
| Add to a Brain | Tell Claude in code session — auto-appended to `Brains/<slug>.md` |
| Visual cues for navigation | Iconize per-folder colors + icons |
| Folder/file order | Flexplorer manual sort (drag in file explorer) |

---

## What to do RIGHT NOW (first 10 minutes)

1. **Obsidian Settings → Community plugins → Turn on community plugins** (if not already)
2. **Settings → Community plugins → Enable `obsidian-icon-folder` and `flexplorer`** (both already installed by your dotfiles transfer)
3. **Settings → Core plugins → Enable: File Recovery, Bookmarks, Workspaces** (in addition to defaults)
4. **Pin Dashboard.md and CLAUDE.md as bookmarks**
5. **Reload Obsidian** (`Cmd+R` or `Cmd+Q` + reopen) to ensure icons + sort apply
6. **Pick a theme** (Settings → Appearance → Themes → Browse) — Minimal recommended

After that, stop tweaking. Use the vault for a day. Add Tier 1 plugins as friction shows up.

---

## What to do later (when ready)

- **Set up LiveSync on new vault** (you decided to keep current sync). Settings → Self-hosted LiveSync → point at superbro CouchDB. Probably needs same DB name as old or fresh DB — your call.
- **Run librarian on Inbox/** (8 files from old vault waiting)
- **Resolve Fiskars dupe** at `Work/AKQA/Shopify/Fiskars/_dupe-from-Projects-Fiskars/`
- **Delete or archive `~/Vaults/Christian/`** once new flow validated for ~1 week
- **Disable wrap-reminder hook in dotfiles** (from previous sparring — anxiety pump)
- **Rewrite `brain-load.sh` + `brain-save-inject.sh`** to target `~/Vaults/Brain/Brains/<slug>.md`

---

## Reference

- Brain map: `~/Vaults/Brain/CLAUDE.md`
- Sparring summary: `Plans/Active/2026-06-14-vault-second-brain-sparring.md`
- Strategy doc (deeper): `Plans/Active/2026-06-12-knowledge-base-strategy.md`
- Ideas (Vaultkeeper, dropped Terminal Brain): `Ideas/Vaultkeeper/`
- Old vault preserved at: `~/Vaults/Christian/` (plugin configs + Smart Connections embeddings only — no notes left)
- Backup tarball: `~/Backups/vault-pre-restructure-2026-06-14.tar.gz`
