# 🔌 Plugins

## Aktive Plugins

### Core Functionality

| Plugin | Formål |
|--------|--------|
| **Templater** | Avanceret templating med JavaScript. Smart Daily Note vælger Work/Weekend automatisk. |
| **Periodic Notes** | Auto-opret daily notes. Erstatter Core Daily Notes. |
| **Meta Bind** | Interaktive inputs (dropdowns til tracking af søvn, energi, humør, fokus). |

### Visual & Organization

| Plugin | Formål |
|--------|--------|
| **Iconize** | Custom ikoner på filer og mapper (Lucide icons). Automatiske regler baseret på mappe. |
| **Simple Colored Folder** | Baggrundsfarver på mapper. Varmt farveskema. |
| **Style Settings** | Tilpas theme og plugin-indstillinger. |
| **Manual Sorting** | Drag-and-drop sortering af mapper. |
| **Calendar** | Visuel kalender i sidebar. |

### Productivity

| Plugin | Formål |
|--------|--------|
| **Advanced Tables** | Bedre tabel-redigering med Tab-navigation. |
| **Double Shift** | Hurtig command palette med Shift+Shift. |
| **Auto Note Mover** | Flyt noter automatisk baseret på tags. |

### AI

| Plugin | Formål |
|--------|--------|
| **Smart Connections** | AI-powered chat og semantisk søgning. Bruger egen OpenAI API key. |

---

## Plugin Konfiguration

### Templater
- **Templates folder:** `Templates`
- **Folder templates:**
  - `Daily Notes/` → `Daily Note.md`
  - `Inbox/` → `Inbox.md`
  - `Projects/` → `Project.md`
  - `Sunday Meetings/` → `Sunday Meeting.md`

### Periodic Notes
- **Daily format:** `YYYY-MM-DD`
- **Folder:** `Daily Notes`
- **Template:** `Templates/Daily Note`

### Auto Note Mover
Flytter noter automatisk baseret på tags. Se `Tags.md` for komplet liste.

**Workflow:**
1. Smart Process Inbox (Alt+P) tilføjer tags
2. Auto Note Mover flytter automatisk

**Eksempler:**
- `#work/fiskars` → `Projects/AKQA/Shopify/Fiskars/`
- `#grønnebakken` → `Projects/Privat/Grønnebakken Bestyrelse/`
- `#home` → `Reference/Hus/`

---

## Deaktiverede Core Plugins
- Graph view
- Canvas
- Outgoing links
- Note composer
- Bookmarks
- Word count
- Slides
- Audio recorder
- Workspaces
- Sync (bruger Livesync i stedet)

