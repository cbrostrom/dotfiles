# 🎨 Farveskema

## Filosofi
Varmt farveskema i gul/orange/rød/brun spektret. Mørkt og behageligt for øjnene.

---

## Mappefarver

| Mappe | Farve | Hex | Preview |
|-------|-------|-----|---------|
| Inbox | Orange | `#FF9500` | 🟠 |
| Daily Notes | Honey | `#E8A838` | 🟡 |
| Attachments | Yellow | `#FFCC00` | 🟡 |
| Projects | Sand | `#C9A86C` | 🟤 |
| Projects/AKQA | Coral Red | `#E85A5A` | 🔴 |
| Projects/Privat | Warm Brown | `#C9A86C` | 🟤 |
| Sunday Meetings | Rust | `#D2691E` | 🟠 |
| Reference | Caramel | `#CD853F` | 🟤 |
| Archive | Tan | `#B8956E` | 🟤 |
| Templates | Sienna | `#A0522D` | 🟤 |

---

## Fil-ikoner (via Iconize Rules)

| Mappe | Ikon | Farve |
|-------|------|-------|
| Daily Notes/ | `file-check` | Honey |
| Sunday Meetings/ | `file-heart` | Rust |
| Inbox/ | `file-plus` | Orange |
| Projects/AKQA/ | `file-cog` | Red |
| Projects/Privat/ | `file-heart` | Sand |
| Reference/ | `file-text` | Caramel |
| Archive/ | `file-x` | Tan |
| Templates/ | `file-code` | Sienna |
| Attachments/ | `file` | Yellow |

---

## Mappe-ikoner

| Mappe | Ikon |
|-------|------|
| Inbox | `inbox` |
| Daily Notes | `calendar-days` |
| Projects | `folder-kanban` |
| Projects/AKQA | `briefcase` |
| Projects/Privat | `home` |
| Sunday Meetings | `message-circle` |
| Reference | `book-open` |
| Archive | `archive` |
| Attachments | `paperclip` |
| Templates | `file-text` |

---

## Theme
- **Navn:** Cupertino
- **Mode:** Dark
- **CSS Snippet:** `christian-vault.css`

