---
created: 2026-06-15
area: dev
type: reference
tags: [vault, brain, claude, hooks, memory, dotfiles]
---

# Brain System — Quick Reference

How AI memory works across sessions and platforms.

---

## Architecture

```
Session starts
  └─ brain-load.sh (SessionStart hook)
       └─ reads ~/Vaults/Brain/Brains/<slug>.md  ← primary brain
            └─ fallback: .claude/brain.md (legacy repos)

Session ends / .bye / .wrap
  └─ session-wrap skill
       └─ writes ~/Vaults/Brain/Brains/<slug>.md  ← authoritative state
       └─ mem_session_summary → Engram (archive)

/clear or /compact
  └─ brain-save-inject.sh (PreCompact + UserPromptSubmit hook)
       └─ instructs Claude to write Brains/<slug>.md before compacting

Mid-session capture
  └─ .brain / .rem / .store / .mem → append dated entry to Brains/<slug>.md
```

---

## Slug resolution

Both hooks + session-wrap use same logic:
1. In git repo → `basename $(git rev-parse --show-toplevel)`
2. Not in git → `basename $PWD`

Examples: `stellar-shopify` · `dotfiles` · `Brain` · `lommr`

---

## Platform paths

| Platform | Vault root | Brains dir |
|---|---|---|
| macOS | `~/Vaults/Brain` | `~/Vaults/Brain/Brains/` |
| WSL | `/mnt/c/Users/christian/Obsidian/Brain` | `…/Brains/` |

---

## Dot commands

| Command | Action |
|---|---|
| `.brain [text]` / `.rem` / `.store` / `.mem` | Append dated entry to `Brains/<slug>.md` |
| `.bye` / `.wrap` | Full session-wrap: write brain + Engram summary |
| `.recall [query]` | vault grep → Engram `mem_search` |
| `.remember [text]` | `mem_save` to Engram |
| `run librarian` / `triage inbox` | Process `Inbox/` via inbox-librarian skill |

---

## Memory layers

| Layer | What | When to use |
|---|---|---|
| `Brains/<slug>.md` | Per-project current state | Always — loaded automatically |
| Engram | Decisions, bugs, conventions | Write-only by default; `.recall` to query |
| Graphiti | Relational facts | Disabled — enable when relational queries needed |

---

## Files

| File | Purpose |
|---|---|
| `~/dotfiles/.claude/hooks/brain-load.sh` | SessionStart hook |
| `~/dotfiles/.claude/hooks/brain-save-inject.sh` | PreCompact + `/clear` hook |
| `~/dotfiles/.claude/skills/session-wrap/SKILL.md` | `.bye` / `.wrap` skill |
| `~/dotfiles/.claude/skills/inbox-librarian/SKILL.md` | Inbox triage skill |
| `~/dotfiles/.shared-rules/engram-graphiti.md` | Engram/Graphiti routing rules |
| `~/Vaults/Brain/CLAUDE.md` | Vault map for AI |

---

## Brain file format

```md
# Brain: <slug>
_Updated: YYYY-MM-DD HH:MM_

## Current State
- max 3 bullets

## Open Decisions
- max 3 bullets

## Gotchas
- max 3 bullets

## Next Steps
- max 3 bullets

## Git Snapshot
git diff --stat output (omit if not a git repo)
```

session-wrap REPLACES the file (authoritative state).
`.brain` / `.rem` APPENDS a dated section (running log).
