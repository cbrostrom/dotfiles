# ⌨️ Hotkeys

## Generelle

| Hotkey | Funktion |
|--------|----------|
| `Shift+Shift` | Command Palette (via Double Shift) |
| `Ctrl+P` | Command Palette |
| `Ctrl+N` | Ny note |
| `Ctrl+O` | Quick switcher |
| `Ctrl+E` | Toggle edit/preview mode |
| `Ctrl+F` | Søg i note |
| `Ctrl+Shift+F` | Søg i hele vault |

---

## Navigation

| Hotkey | Funktion |
|--------|----------|
| `Ctrl+Click` | Åbn link i ny fane |
| `Alt+←` | Gå tilbage |
| `Alt+→` | Gå frem |
| `Ctrl+Tab` | Skift fane |

---

## Redigering

| Hotkey | Funktion |
|--------|----------|
| `Ctrl+B` | Fed tekst |
| `Ctrl+I` | Kursiv |
| `Ctrl+K` | Indsæt link |
| `Ctrl+]` | Indent |
| `Ctrl+[` | Outdent |
| `Ctrl+Enter` | Toggle checkbox |

---

## Custom (sat op i vault)

| Hotkey | Funktion |
|--------|----------|
| `Alt+P` | Smart Process Inbox (AI tagging) |

---

## Tabeller (Advanced Tables)

| Hotkey | Funktion |
|--------|----------|
| `Tab` | Næste celle |
| `Shift+Tab` | Forrige celle |
| `Enter` | Ny række |

---

## Smart Connections

| Hotkey | Funktion |
|--------|----------|
| `Ctrl+Shift+C` | Åbn Smart Chat |

