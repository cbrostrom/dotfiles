# 📄 Templates

## Oversigt

| Template | Formål | Auto-trigger |
|----------|--------|--------------|
| Daily Note | Router til Work/Weekend | Periodic Notes |
| Daily Note - Work | Hverdage med timebox | Via router |
| Daily Note - Weekend | Afslappet familiestruktur | Via router |
| Sunday Meeting | Ugentlig planlægning | Folder template |
| Inbox | Hurtig capture | Folder template |
| Project | Nyt projekt | Folder template |
| Shutdown Ritual | Afslut arbejdsdag | Manuel |
| Smart Process Inbox | AI-powered tagging | Hotkey (Alt+P) |

---

## Daily Note (Router)

Vælger automatisk Work eller Weekend baseret på ugedag:

```javascript
const dayNum = moment(tp.file.title, "YYYY-MM-DD").day();
const isWeekend = (dayNum === 0 || dayNum === 6);
// Loader korrekt template
```

---

## Daily Note - Work

**Sektioner:**
1. **Morgen tracking** - Søvn, energi, humør, fokus (1-5 skala)
2. **🐸 Frog** - Den ÉNE ting der SKAL gøres
3. **Timebox** - 07:00-20:00 med ikoner (💼/🏠/📞/👶)
4. **Work** - Arbejdsopgaver og møder
5. **Privat** - Private opgaver
6. **Wins** - Hvad gik godt
7. **Reflection** - Hvad nåede jeg, hvad sprang jeg

---

## Daily Note - Weekend

**Sektioner:**
1. **Morgen tracking** - Søvn, energi, humør, fokus
2. **Hvad vil jeg gerne i dag?**
3. **Dagen** - Formiddag/Eftermiddag/Aften
4. **Familie** - Lily og Sofie
5. **Huslige ting**
6. **Wins**
7. **Reflection** - Hvad nød jeg, hvad er jeg taknemmelig for

---

## Sunday Meeting

**Sektioner:**
1. **Ugeplan tabel** - Afleverer/Henter/Lang dag/Bemærkninger
2. **Fokuspunkter** - Hvad skal hver person være opmærksom på
3. **Ugens gode bemærkning** - Positiv feedback
4. **Ugens svære ting** - Del det hårde
5. **Ugens review** - Hvad nåede vi
6. **Idéer & ønsker**

---

## Smart Process Inbox

**Funktion:** AI-powered automatisk tagging og flytning af Inbox-noter.

**Workflow:**
1. Åbn en note i Inbox
2. Tryk `Alt+P` (eller kør via Command Palette)
3. AI analyserer indhold
4. Tilføjer relevante tags
5. Flytter til korrekt mappe

**Kræver:** OpenAI API key (hardcoded i template)

