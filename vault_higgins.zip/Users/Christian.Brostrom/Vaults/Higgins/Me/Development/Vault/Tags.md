# Tag System

> Tags styrer hvor noter flyttes til via Auto Note Mover.

---

## Primære Tags (bestemmer mappe)

### Arbejde
| Tag | Flyttes til |
|-----|-------------|
| `#work/fiskars` | `Projects/AKQA/Shopify/Fiskars/` |
| `#work/akqa` | `Projects/AKQA/` |

### Private projekter
| Tag | Flyttes til |
|-----|-------------|
| `#grønnebakken` | `Projects/Privat/Grønnebakken Bestyrelse/` |
| `#privat` | `Projects/Privat/` |

### Reference
| Tag | Flyttes til |
|-----|-------------|
| `#home` | `Reference/Hus/` |
| `#family` | `Reference/Familie/` |
| `#lily` | `Reference/Lily/` |
| `#tech` | `Reference/Tech/` |
| `#homelab` | `Reference/Homelab & VPS/` |
| `#vault` | `Reference/Vault/` |
| `#reference` | `Reference/` |

### System
| Tag | Flyttes til |
|-----|-------------|
| `#sunday-meeting` | `Sunday Meetings/` |
| `#archived` | `Archive/` |

---

## Sekundære Tags (prioritet/status)

Disse tags flytter IKKE noter, men markerer status:

| Tag | Betydning |
|-----|-----------|
| `#next` | Skal gøres snart/ASAP |
| `#later` | Kan vente, someday/maybe |
| `#idea` | Idé til senere |
| `#waiting` | Venter på nogen/noget |

---

## Sådan virker det

1. **Du tilføjer en note til Inbox**
2. **Kør Smart Process Inbox** (Alt+P)
3. **AI vælger tags** baseret på indhold
4. **Auto Note Mover flytter automatisk** baseret på primær tag

---

## Prioriteringsrækkefølge

Auto Note Mover tjekker tags i denne rækkefølge (første match vinder):

1. `#sunday-meeting`
2. `#work/fiskars`
3. `#work/akqa`
4. `#grønnebakken`
6. `#privat`
7. `#home`
8. `#family`
9. `#lily`
10. `#tech`
11. `#homelab`
12. `#vault`
13. `#archived`
14. `#reference` (fallback)

---

## Tag Farver (CSS)

| Tag | Farve |
|-----|-------|
| `#next` | 🔴 Rød |
| `#later` | 🔵 Blå |
| `#idea` | 🟡 Gul |
| `#waiting` | ⚪ Grå |
| `#work*` | 🟣 Lilla |
| `#home` | 🟢 Grøn |
| `#family`, `#lily` | 💗 Pink |

---

## Eksempler

### Note om Fiskars projekt
```
Tags: #work/fiskars #next
→ Flyttes til: Projects/AKQA/Shopify/Fiskars/
```

### Idé til homelab
```
Tags: #homelab #idea
→ Flyttes til: Reference/Homelab & VPS/
```

### Noget om Lily i institution
```
Tags: #grønnebakken
→ Flyttes til: Projects/Privat/Grønnebakken Bestyrelse/
```

### Generel familienote
```
Tags: #family
→ Flyttes til: Reference/Familie/
```
