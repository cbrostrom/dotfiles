# 📱 Multi-Device Setup

> Forskellige themes og plugins per enhed - men samme noter!

---

## 🎯 Koncept

| Enhed | Config Folder | Theme | Plugins |
|-------|---------------|-------|---------|
| **Desktop** | `.obsidian` | Cupertino | Alle |
| **iPhone** | `.obsidian-mobile` | Minimal | Kun essentials |

**Noter synker** - men **settings er separate!**

---

## 🔧 TRIN 1: Desktop Setup (Windows/Mac)

Desktop bruger standard `.obsidian` mappen - ingen ændringer nødvendige.

---

## 📱 TRIN 2: iPhone Setup

### 2.1 Opret separat config
1. **Settings → About**
2. Find **"Override config folder"**
3. Skriv: `.obsidian-mobile`
4. **Genstart Obsidian**

> ⚠️ Efter genstart er vault "tom" - ingen plugins/theme. Det er normalt!

### 2.2 Aktiver Community Plugins
1. **Settings → Community plugins**
2. **Turn on community plugins**

### 2.3 Installer kun nødvendige plugins

| Plugin | Installer? | Hvorfor |
|--------|------------|---------|
| **Self-hosted LiveSync** | ✅ JA | Sync! |
| **Templater** | ✅ JA | Inbox template |
| **Periodic Notes** | ⚠️ Valgfrit | Hvis du vil oprette daily notes på mobil |
| Alle andre | ❌ NEJ | Desktop only |

### 2.4 Installer Minimal Theme
1. **Settings → Appearance → Manage**
2. Søg: **"Minimal"**
3. **Install and use**

### 2.5 Installer Minimal Theme Settings (valgfrit)
1. **Settings → Community plugins → Browse**
2. Søg: **"Minimal Theme Settings"**
3. **Install → Enable**

### 2.6 Konfigurer Minimal for mobil
1. **Settings → Minimal Theme Settings**
2. Anbefalede indstillinger:
   - **Color scheme:** Dark (eller Light)
   - **Text font:** System font (hurtigere)
   - **Line width:** Wide (bedre på mobil)
   - **Focus mode:** Off
   - **Image grids:** Off

### 2.7 Konfigurer Livesync
1. **Settings → Self-hosted LiveSync**
2. Indtast samme server-info som desktop
3. **Sync → Replicate**
4. Vent på noter synker

---

## 🔄 TRIN 3: Livesync Indstillinger

### På Desktop
Sync ALT inklusiv `.obsidian`:
```
Settings → Livesync:
├── Sync hidden files: ✅
├── Sync config folder: ✅
└── Ignore patterns: .obsidian-mobile/
```

### På iPhone
Sync KUN noter, IKKE config:
```
Settings → Livesync:
├── Sync hidden files: ❌
├── Sync config folder: ❌
└── (eller ignorer .obsidian/)
```

**Alternativt:** Tilføj til ignore pattern på begge:
- Desktop ignorerer: `.obsidian-mobile/`
- Mobil ignorerer: `.obsidian/`

---

## 📁 Mappestruktur efter setup

```
Christian/
├── .obsidian/              ← Desktop config (synker IKKE til mobil)
│   ├── plugins/
│   ├── themes/
│   └── snippets/
├── .obsidian-mobile/       ← Mobil config (synker IKKE til desktop)
│   ├── plugins/
│   └── themes/
├── Daily Notes/            ← Synker ✅
├── Inbox/                  ← Synker ✅
├── Projects/               ← Synker ✅
└── ...
```

---

## 🎨 Anbefalede Mobile Themes

### 1. Minimal (Anbefalet)
- ✅ Meget mobil-venlig
- ✅ Hurtig og let
- ✅ God læseoplevelse
- ✅ Customizable via plugin
- [GitHub](https://github.com/kepano/obsidian-minimal)

### 2. Things
- ✅ Clean og simpel
- ✅ God til tasks
- ✅ Inspireret af Things app

### 3. Prism
- ✅ Moderne og farverigt
- ✅ God kontrast
- ✅ Mobil-optimeret

### 4. California Coast
- ✅ Warm colors
- ✅ God læsbarhed
- ✅ Mobil-venlig

---

## 📲 Mobil Workflow

### Quick Capture (Widget)
1. Tryk Obsidian widget
2. Skriv note
3. Gem → Synker automatisk

### Læse noter
1. Åbn Obsidian
2. Vent på sync (få sekunder)
3. Læs noter i Minimal theme

### Oprette Daily Note (valgfrit)
1. Åbn Obsidian
2. Command palette → "Open today's daily note"
3. Udfyld (uden Meta Bind - bare tekst)

---

## ⚠️ Vigtige noter

### Meta Bind virker ikke på mobil
Daily notes har Meta Bind selectors (`INPUT[...]`). På mobil vises de som rå tekst.

**Løsning:** Brug bare tal direkte i frontmatter:
```yaml
sleep: 4
energy: 3
mood: 4
focus: 2
```

### Auto Note Mover kører ikke på mobil
Noter i Inbox flyttes IKKE automatisk på mobil.

**Løsning:** Lad dem ligge i Inbox. Kør Smart Process Inbox på desktop.

### Ikoner og farver
Iconize og Simple Colored Folder er kun på desktop. Mobil viser standard Obsidian UI.

---

## ✅ Tjekliste

### Desktop
- [ ] `.obsidian/` er standard config
- [ ] Cupertino theme
- [ ] Alle plugins aktive
- [ ] Livesync ignorerer `.obsidian-mobile/`

### iPhone
- [ ] Override config: `.obsidian-mobile`
- [ ] Minimal theme installeret
- [ ] Kun Livesync + Templater aktive
- [ ] Livesync ignorerer `.obsidian/`
- [ ] Widget virker

---

## 🔥 Troubleshooting

### "Vault er tom efter override"
Det er normalt! Du har oprettet en ny config. Installer plugins og theme igen.

### "Noter synker ikke"
Tjek at Livesync er konfigureret i `.obsidian-mobile/plugins/`.

### "Theme ser mærkeligt ud"
Genstart Obsidian efter theme-installation.

### "Plugins fra desktop dukker op"
Tjek at du har sat ignore pattern korrekt i Livesync.

