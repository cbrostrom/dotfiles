# Vault Oversigt

> Min Obsidian vault til ADHD-venlig produktivitet og daglig planlægning.

---

## Dokumentation

| Fil | Indhold |
|-----|---------|
| [[Mappestruktur]] | Hvordan vault er organiseret |
| [[Plugins]] | Alle plugins og hvad de gør |
| [[Farveskema]] | Farver og ikoner |
| [[Templates]] | Alle templates og deres formål |
| [[Tags]] | Tag-system og kategorier |
| [[Hotkeys]] | Genvejstaster |
| [[Anbefalede Plugins]] | Plugins til fremtiden |
| [[Livesync Setup]] | Synkronisering på tværs af enheder |

---

## Filosofi

- **Barebone by design** - Simplicitet reducerer friktion
- **Inbox-first workflow** - Capture hurtigt, processer senere
- **ADHD-venlig** - Visuelle cues, minimale beslutninger
- **Timeboxing** - Struktur kompenserer for tidsblindhed
- **Varmt farveskema** - Gul/orange/rød/brun palette

---

## Naming Convention

- **Mapper:** Uden numre, uden emojis (Iconize håndterer ikoner)
- **Filer:** Beskrivende navne, ingen præfikser
- **Rækkefølge:** Manual Sorting plugin håndterer orden

---

## Hurtige links

- [[Daily Note]] - Dagens note
- [[Inbox]] - Hurtig capture
- [[Sunday Meeting]] - Ugentlig planlægning

---

*Sidst opdateret: 2025-11-29*
