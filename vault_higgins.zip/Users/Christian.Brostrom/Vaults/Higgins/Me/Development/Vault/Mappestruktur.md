# 📁 Mappestruktur

## Oversigt

```
Christian/
├── Inbox/           # Hurtig capture, usorterede noter
├── Daily Notes/     # Daglig planlægning & reflection
├── Projects/        # Aktive projekter
│   ├── AKQA/        # Arbejdsprojekter (rød tema)
│   └── Privat/      # Private projekter (varm brun)
├── Sunday Meetings/ # Ugentlig planlægning med Sofie
├── Reference/       # Vidensbase
│   ├── Familie/
│   ├── Homelab/
│   ├── Hus/
│   ├── Lily/
│   ├── Tech/
│   ├── Vault/       # Denne dokumentation
│   └── VPS/
├── Archive/         # Afsluttede/inaktive ting
├── Attachments/     # Billeder, PDFs, filer
└── Templates/       # Note templates
```

---

## Mappeformål

### 📥 Inbox
- **Formål:** Hurtig capture af tanker, idéer, tasks
- **Workflow:** Dump alt her → processer senere med AI eller manuelt
- **Template:** `Inbox.md`

### 📅 Daily Notes
- **Formål:** Daglig planlægning, timeboxing, tracking
- **Workflow:** Oprettes automatisk via Periodic Notes
- **Template:** `Daily Note.md` (router til Work/Weekend)

### 📁 Projects
- **Formål:** Aktive projekter med konkrete mål
- **Undermapper:**
  - `AKQA/` - Arbejdsprojekter (Shopify, Fiskars, etc.)
  - `Privat/` - Private projekter (Grønnebakken, etc.)
- **Template:** `Project.md`

### 💬 Sunday Meetings
- **Formål:** Ugentlig planlægning med Sofie
- **Workflow:** Oprettes hver søndag
- **Template:** `Sunday Meeting.md`

### 📚 Reference
- **Formål:** Permanent viden, dokumentation
- **Undermapper:** Familie, Homelab, Hus, Lily, Tech, Vault, VPS

### 🗄️ Archive
- **Formål:** Afsluttede projekter, gamle noter
- **Workflow:** Flyt hertil når noget er done

### 📎 Attachments
- **Formål:** Billeder, PDFs, andre filer
- **Workflow:** Obsidian gemmer automatisk her

### 📄 Templates
- **Formål:** Note templates til Templater
- **Workflow:** Bruges automatisk via folder templates

