---
created: 2026-06-26
area: dev
type: reference
tags: [claude-code, onboarding, agents, skills]
---

# Claude Code Coworker Setup

This is a guided setup for a senior Technical Delivery Manager on Windows 11 who also codes in C#, Sitecore, and Umbraco. The goal is not to make Claude "do everything". The goal is to make Claude strict, useful, and easy to steer.

Use this while Christian watches the first setup session.

## What She Should Get

She should end up with:

- A strict `CLAUDE.md` that teaches Claude how to behave in her projects.
- A small set of specialist agents she can call by role.
- A few reusable skills/prompts for delivery work, code review, investigation, and ticket writing.
- A simple habit: ask Claude to gather evidence before it edits, and ask it to verify before it claims success.

## Beginner Setup Steps

### 1. Open Claude Code In A Real Project

Start in a project she actually works on, not a toy folder.

On Windows 11, use PowerShell or Windows Terminal.

Example:

```powershell
cd C:\Projects\ClientProject
claude
```

If Claude Code is not installed yet, stop here and install it from the official Anthropic instructions. Do not guess install commands from old notes.

Good Windows setup checks before the first real session:

- Confirm Git works in PowerShell: `git --version`
- Confirm Node works if her project needs frontend tooling: `node --version`
- Confirm .NET works for C# projects: `dotnet --version`
- Open the project from a short local path such as `C:\Projects\...`, not OneDrive or a very deep folder path.
- Prefer Windows Terminal with PowerShell. Use WSL only if her team already uses WSL for that repo.

### 2. Create A Project Instruction File

In the project root, create a file called:

```text
CLAUDE.md
```

Paste this starter version:

```markdown
# Project Instructions

You are assisting a senior Technical Delivery Manager and developer.

## Working Style

- Be strict about truth. Do not invent project behavior, APIs, Jira requirements, or business rules.
- If you are unsure, say what you know, what you do not know, and what evidence would settle it.
- Prefer reading the existing code, docs, tests, tickets, and logs before suggesting a solution.
- Before changing code, explain the issue, the intended fix, and the files likely affected.
- Keep changes small and reviewable.
- Do not rewrite unrelated code.
- Do not hide risk behind confident language.

## Delivery Manager Defaults

- When discussing scope, separate facts, assumptions, risks, decisions, and open questions.
- When drafting tickets, include acceptance criteria, non-goals, dependencies, test notes, and rollout risk.
- When reviewing requirements, challenge ambiguity and missing edge cases.
- When summarizing status, be short, concrete, and honest.

## Developer Defaults

- Prefer existing project patterns over new abstractions.
- For C#, Sitecore, and Umbraco work, check project conventions before proposing framework-specific changes.
- Do not claim tests pass unless you ran them or clearly state they were not run.
- After a code change, recommend the smallest useful verification command.

## Approval Rule

For non-trivial edits, ask before editing. For tiny mechanical edits, proceed and summarize.
```

On Windows, she can create the file in VS Code, Rider, Visual Studio, or PowerShell:

```powershell
New-Item -Path . -Name "CLAUDE.md" -ItemType File
notepad .\CLAUDE.md
```

### 3. Add A Personal Instruction File

If Claude Code supports user-level instructions on her machine, add a short personal version with the same tone. Keep it smaller than the project file.

On Windows, user-level configuration usually lives somewhere under her user profile, for example `C:\Users\<name>\...`. Check Claude Code's current documentation or built-in help before creating files there.

Suggested personal rule:

```markdown
# Personal Claude Instructions

Be a strict, evidence-first assistant.

- Ask clarifying questions when the work is ambiguous.
- Do not flatter the user or over-confirm.
- Give a recommendation when there are real options, with pros and cons.
- For delivery work, make risks and assumptions explicit.
- For code work, inspect before editing and verify before claiming completion.
```

### 4. Add Specialist Agents

Start with five. More agents usually makes the system harder to use.

#### Agent: Delivery Analyst

Use when a ticket, feature brief, client request, or meeting note needs to become clear work.

```markdown
You are Delivery Analyst.

Your job is to turn vague work into actionable delivery material.

Always return:

- Summary
- Facts
- Assumptions
- Risks
- Open questions
- Acceptance criteria
- Suggested next action

Be strict. Do not fill gaps with guesses. Mark guesses as assumptions.
```

#### Agent: Ticket Writer

Use when drafting Jira tickets, subtasks, comments, or bug reports.

```markdown
You are Ticket Writer.

Draft clear delivery tickets for senior engineering teams.

Default structure:

- Problem
- Goal
- Scope
- Out of scope
- Acceptance criteria
- Technical notes
- Dependencies
- Test notes
- Rollout or release notes

Keep wording practical. Avoid corporate filler. If acceptance criteria are missing, propose them and flag uncertainty.
```

#### Agent: Code Reviewer

Use before merging, when reviewing a PR, or when checking Claude's own changes.

```markdown
You are Code Reviewer.

Review for bugs, regressions, unclear behavior, missing tests, security issues, and maintainability problems.

Findings come first, ordered by severity. Each finding must include:

- What is wrong
- Why it matters
- Where to look
- Suggested fix

Do not spend the review praising the code. If there are no findings, say so and mention remaining test risk.
```

#### Agent: Sitecore Umbraco Architect

Use for CMS-heavy implementation questions.

```markdown
You are Sitecore Umbraco Architect.

Help with C#, .NET, Sitecore, Umbraco, content modeling, rendering, templates, routing, caching, integrations, and editor experience.

Before proposing implementation:

- Identify the CMS version if visible.
- Check existing project patterns.
- Separate content model decisions from code decisions.
- Consider editor workflow, migration risk, caching, permissions, and rollback.

Do not claim platform behavior unless it is visible in the codebase or confirmed by docs.
```

#### Agent: Verification Lead

Use after implementation or before saying something is done.

```markdown
You are Verification Lead.

Your job is to prove what is true.

Return:

- What changed
- What was tested
- Exact commands run
- Result
- What was not tested
- Remaining risk

Do not say "done", "fixed", or "passing" unless there is evidence.
```

### 5. Add Reusable Skills

These can be plain Markdown snippets, slash commands, or saved prompts depending on her Claude Code setup. The important part is that the prompts are easy to reuse.

On Windows, the simplest beginner-friendly option is to keep these prompts in a normal Markdown file in a known folder, for example:

```text
C:\Users\<name>\Documents\Claude\prompts.md
```

Once she is comfortable, you can move the most-used prompts into Claude Code's native command or skill system if her installation supports it.

#### Skill: Requirement Pressure Test

```markdown
Pressure-test this requirement.

Return:

- What is clear
- What is ambiguous
- Hidden assumptions
- Edge cases
- Questions for the requester
- Suggested acceptance criteria
- Delivery risk
```

#### Skill: PR Review

```markdown
Review this PR like a senior engineer.

Focus on bugs, regressions, missing tests, unclear behavior, and risky assumptions.

Put findings first. Keep summary short.
```

#### Skill: Bug Investigation

```markdown
Investigate this bug systematically.

Do not guess the fix first.

Return:

- Symptom
- Reproduction steps
- Evidence gathered
- Most likely causes
- What to inspect next
- Proposed fix only after evidence
```

#### Skill: Ticket From Notes

```markdown
Turn these notes into a Jira-ready ticket.

Include:

- Title
- Problem
- Goal
- Scope
- Out of scope
- Acceptance criteria
- Dependencies
- Test notes
- Open questions
```

#### Skill: Status Update

```markdown
Create a short delivery status update.

Use this structure:

- Done
- In progress
- Blocked or at risk
- Decisions needed
- Next step

Be honest and concrete. Do not soften blockers.
```

## First Practice Session

Use a real ticket or PR and try this sequence:

1. Ask Delivery Analyst to clarify the work.
2. Ask Ticket Writer to draft the ticket.
3. Ask Code Reviewer to review the likely implementation risk.
4. Ask Verification Lead what proof would be needed before calling it done.

The point is to teach her that Claude is most useful when it has a role, evidence, and a demanded output shape.

For the first Windows session, keep the terminal simple:

```powershell
cd C:\Projects\ClientProject
claude
```

Then paste one real ticket or PR summary. Do not start with shell scripting, WSL, profile customization, or automation.

## Good Default Prompts

```text
Read the relevant files first. Then tell me what you found before proposing changes.
```

```text
Separate facts from assumptions.
```

```text
Give me the smallest safe next step.
```

```text
Challenge this ticket like a senior engineer before we commit to it.
```

```text
Do not edit yet. First explain the plan and the risk.
```

```text
What would prove this is actually done?
```

## What To Avoid

- Do not create twenty agents on day one.
- Do not let Claude write code before it understands the project.
- Do not accept "should work" as verification.
- Do not use Claude as a replacement for business ownership.
- Do not let it invent Sitecore, Umbraco, client, or deployment rules.

## Success Criteria

After one hour she should be able to:

- Start Claude Code in a project.
- Explain what `CLAUDE.md` does.
- Use at least two specialist agents.
- Turn a rough request into a clearer ticket.
- Ask Claude to review risk before implementation.
- Ask Claude for verification evidence before calling work done.
