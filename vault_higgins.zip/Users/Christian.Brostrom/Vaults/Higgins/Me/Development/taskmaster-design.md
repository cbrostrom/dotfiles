---
created: 2026-06-15
type: spec
status: approved
tags: [claude, skills, taskmaster, planning, vault]
---

# Taskmaster — Design Spec

Vault-native project task state machine. Replaces `planning-with-files` for all big plans. No external tools installed.

## Problem

Multi-session projects had no persistent task state. planning-with-files created ephemeral scratch files in the project repo — no dependency graph, no `next` logic, no cross-session continuity. Task Master (external tool) solves this but adds MCP overhead, API keys, and context cost.

## Solution

A Claude skill that reads/writes structured `.md` files in `~/Vaults/Brain/`. Claude is the runtime. Vault is the database. Obsidian is the UI.

---

## Data Model

Location: `~/Vaults/Brain/Projects/<slug>/tasks.md`

```markdown
---
project: my-project
created: 2026-06-15
---

## setup-auth
- status: done
- deps: []
- priority: high
- notes: Uses JWT, see [[auth-decisions]]

## user-dashboard
- status: in-progress
- deps: [setup-auth]
- priority: high
- notes:

## payment-flow
- status: pending
- deps: [user-dashboard]
- priority: medium
- notes:
```

**Status values:** `pending` / `in-progress` / `done` / `blocked`

**IDs:** kebab-case slugs — human-readable, dep refs self-documenting, no implied sequence.

**Deps:** comma-separated slug list `[slug-a, slug-b]`. Empty `[]` = no deps.

**Notes:** free text, supports Obsidian `[[wikilinks]]` to brain notes.

---

## Subcommands

```
.task help                          — show all subcommands
.task init [slug]                   — create Projects/<slug>/tasks.md (slug defaults to basename $PWD)
.task add <slug> [deps:a,b] [priority:high|medium|low]
.task next                          — return first unblocked pending task
.task done <slug>                   — mark done, print newly unblocked tasks
.task block <slug> [reason]         — mark blocked with reason
.task expand <slug>                 — AI decompose into subtasks
.task status                        — full board: grouped by status
```

---

## Parse Logic

All ops use native Read + Write tools. No external parsers.

- Tasks = `## <slug>` headers
- Fields = `- key: value` lines under each header
- Deps = `[slug-a, slug-b]` → split on comma, trim whitespace

---

## `.task next` Algorithm

1. Read tasks.md
2. Collect all slugs where `status: done` → done-set
3. Filter tasks where `status: pending` AND every dep in done-set
4. Sort: `high` priority first
5. Return top result with title + notes

---

## `.task expand <slug>`

1. Read task slug + notes
2. Claude generates 3–6 subtasks
3. Written as nested `  - [ ] subtask` lines under the task section
4. tasks.md updated in place

---

## `.task init` Side Effects

- Creates `~/Vaults/Brain/Projects/<slug>/tasks.md` with frontmatter
- Creates `~/Vaults/Brain/Development/taskmaster.md` (tool reference) if not exists
- Appends entry to relevant brain file

---

## CLAUDE.md Changes

### Scope routing (replaces planning-with-files for big plans)

| Scope | Tool |
|---|---|
| ≤2 files, single fix | Direct edit |
| Mid: 2–3 files | `EnterPlanMode` → plannotator |
| Big plan (any session length) | `.task init` → vault tasks.md |
| Component invariants | `cavekit` SPEC.md |

### Memory routing

| Signal | Action |
|---|---|
| "remember/save/note/brain/don't forget" | Write to relevant `~/Vaults/Brain/` note |
| "capture/inbox" | New file `~/Vaults/Brain/Inbox/YYYY-MM-DD-HH-MM-<slug>.md` |
| "save to engram" | `mem_save` — explicit only |
| `.recall` | vault grep → `mem_context` fallback |

### Dot-command addition

```
| `.task <cmd>` | taskmaster skill — vault-native task state machine |
```

### Deprecated

`planning-with-files` — remove from trigger routing. Plugin stays installed but no longer routed to.

---

## Effort Classifier Change

`deep` tier hint addition: if no `Projects/<slug>/tasks.md` exists for current project → inject suggestion to `.task init`.

---

## Obsidian Integration

Dataview query for cross-project board:
```
TABLE status, deps, priority FROM "Projects" WHERE contains(file.name, "tasks")
```

Slugs support `[[wikilinks]]` in notes field — tasks link naturally to brain notes, decisions, context.

---

## Out of Scope

- No sync to external issue trackers
- No git integration (tasks stay in vault, not repo)
- No multi-user / team features
- Engram integration — dormant until explicit use case found
