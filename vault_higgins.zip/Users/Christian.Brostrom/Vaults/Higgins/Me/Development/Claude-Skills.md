# Claude Code Skills

> Skills live in `~/dotfiles/.claude/skills/` (symlinked to `~/.claude/skills/`).
> Add new skills there — they auto-register via symlink.
> Last updated: 2026-06-12

---

## Session / Context

| Skill | Trigger | What it does |
|---|---|---|
| `session-wrap` | `.bye` / `.wrap` | End-of-session: writes brain.md, saves to Engram + Graphiti, git anchor |
| `switch` | `.switch` | session-wrap + `/clear` — saves everything, loads nothing, fresh context |

## Planning & Execution

| Skill | Trigger | What it does |
|---|---|---|
| `paseo` | `/paseo` | Reference for managing agents and worktrees |
| `paseo-epic` | `/paseo-epic` | Heavy orchestration for big work — research, plan, adversarial review, phased impl |
| `paseo-loop` | `/paseo-loop` | Agent loop until exit condition met |
| `paseo-advisor` | `/paseo-advisor` | Single agent as second opinion — outside take without delegating |
| `paseo-committee` | `/paseo-committee` | Two high-reasoning agents for root cause analysis + plan |
| `paseo-handoff` | `/paseo-handoff` | Hand off current task to another agent with full context |
| `plannotator-setup-goal` | `/plannotator-setup-goal` | Turn idea into goal package — interviews user, fact sheet, execution plan |

## Review & Annotation

| Skill | Trigger | What it does |
|---|---|---|
| `plannotator-review` | `.review` / `/plannotator-review` | Browser-based code review UI for worktree or PR URL |
| `plannotator-annotate` | `/plannotator-annotate <file>` | Annotation UI for markdown file, HTML, URL, or folder |
| `plannotator-last` | `/plannotator-last` | Annotate last rendered assistant message |

## Development

| Skill | Trigger | What it does |
|---|---|---|
| `graphify` | `/graphify` | Any input → knowledge graph. Also auto-queries graphify-out/ if it exists |
| `mcp-doctor` | `/mcp-doctor` | MCP server diagnostics |
| `sparring` | `/sparring` | Adversarial reasoning partner |
| `writing` | `.write` / `/writing` | Prose drafting — blog, docs, marketing, emails, UI text |

## Infrastructure / Dotfiles

| Skill | Trigger | What it does |
|---|---|---|
| `dotfiles-update` | `.dotfiles` / `/dotfiles` | Update dotfiles locally + propagate to LinuxBro/SuperBro |
| `use-spark` | `/use-spark` | (description not set) |

---

## Adding a New Skill

```
mkdir ~/dotfiles/.claude/skills/<name>
# write SKILL.md with frontmatter: name, description, trigger, group
# update this file
```

Frontmatter format:
```yaml
---
name: skill-name
description: "One-line description shown in skill list"
trigger: /skill-name
group: productivity
---
```
