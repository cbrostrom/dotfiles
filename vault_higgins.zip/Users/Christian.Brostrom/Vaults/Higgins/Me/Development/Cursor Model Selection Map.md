---
created: 2026-06-26
area: development
type: reference
tags: [cursor, ai-models, model-selection, agents, token-budget]
status: active
topic: cursor-model-routing
---

# Cursor model selection map

Use this when recommending a Cursor model from a spec. It is a practical routing guide, not a price sheet. "Token pressure" means expected token consumption and cost pressure relative to the other available models.

## Default rule

Start with the cheapest model that can safely handle the task. Escalate only when the task needs deeper reasoning, broader context, stronger coding judgement, or higher reliability.

| Task shape | Default model | Escalate when |
|---|---|---|
| Quick edits, obvious fixes, simple scripts | **GPT-5.4 Mini**, **Haiku 4.5**, **Gemini 3 Flash** | The change touches architecture, state, auth, data, or production risk |
| Normal coding tasks | **Sonnet 4.6**, **Codex 5.3**, **GPT-5.5** | Debugging is subtle, spec is ambiguous, or multiple systems are involved |
| Complex implementation from a spec | **GPT-5.5**, **Opus 4.8**, **Codex 5.3** | Need original architecture, root-cause reasoning, or high-stakes review |
| Large-context research or synthesis | **Gemini 3.1 Pro**, **Opus 4.8**, **GPT-5.5** | Need exact source-grounded reasoning, not just breadth |
| Fast exploration, summaries, triage | **Gemini 3.5 Flash**, **Gemini 3 Flash**, **GPT-5.4 Mini** | The output will drive irreversible work |
| Code review, security review, risky refactors | **Opus 4.8**, **GPT-5.5**, **Sonnet 4.6** | Always prefer stronger models for hidden-regression hunting |

## Capability tiers

| Tier | Models | Token pressure | Best for | Avoid for |
|---|---|---:|---|---|
| Premium judgement | **Opus 4.8**, **GPT-5.5**, **Opus 4.7** | Very high | Ambiguous specs, architecture, subtle bugs, review, trade-off analysis, high-risk edits | Bulk mechanical work, trivial summaries |
| Senior coding default | **Sonnet 4.6**, **Codex 5.3**, **GPT-5.4**, **Opus 4.6** | High | Most real implementation, refactors, tests, debugging, PR cleanup | Very large cheap sweeps where speed/cost matters more |
| Reliable mid-tier | **Sonnet 4.5**, **GPT-5.2**, **Codex 5.2**, **Gemini 3.1 Pro**, **Opus 4.5** | Medium-high | Feature work with clear specs, broad context reads, test generation, docs from code | Mission-critical reasoning without review |
| Economical coding | **GPT-5.4 Mini**, **Codex 5.1 Max**, **GPT-5.1**, **Haiku 4.5**, **Grok Build 0.1** | Medium | Small features, scoped edits, lint/test fixes, common framework patterns | Architecture, security, hard debugging |
| Cheap/fast utility | **GPT-5.4 Nano**, **Codex 5.1 Mini**, **GPT-5 Mini**, **Gemini 3.5 Flash**, **Gemini 3 Flash**, **Gemini 2.5 Flash**, **Grok 4.3**, **Kimi K2.5**, **GLM 5.2** | Low | Summaries, classification, search guidance, simple transforms, draft outlines, low-risk boilerplate | Anything where correctness is hard to verify |

## Model notes

| Model | Use when | Token posture |
|---|---|---|
| **Composer 2.5** | Cursor-native multi-file composition, agentic editing, fast iteration inside the IDE | Medium-high; good when edit throughput matters |
| **Opus 4.8** | Best available reasoning/review choice; use for hard specs, architecture, bug hunts, and final judgement | Expensive; reserve for high-stakes or ambiguous work |
| **GPT-5.5** | Strong generalist for specs, coding, planning, and implementation | Expensive; good default when quality matters |
| **Sonnet 4.6** | Balanced senior-engineer model for day-to-day coding | High but efficient for real code work |
| **Codex 5.3** | Code-heavy implementation, refactors, test repair, repository work | High; efficient when the task is mostly code |
| **Gemini 3.1 Pro** | Large-context reading, broad synthesis, comparing many files or docs | Medium-high; good for breadth |
| **GPT-5.4 Mini / Nano** | Cheap scoped edits, transformations, summaries, initial triage | Low to medium; use before escalating |
| **Haiku 4.5 / Gemini Flash models** | Very fast summaries, extraction, classification, mechanical tasks | Low; do not trust for subtle reasoning without verification |
| **Grok / Kimi / GLM** | Secondary opinions, loose ideation, simple low-risk tasks | Usually low to medium; verify important outputs |

## Recommendation format

When recommending from a spec, use this pattern:

```yaml
model_recommendation:
  primary: "Sonnet 4.6"
  fallback: "GPT-5.5"
  budget_tier: "high"
  why: "Enough coding judgement for a multi-file feature without paying Opus rates."
  escalate_if:
    - "requirements are ambiguous"
    - "security/auth/data integrity is involved"
    - "tests reveal non-obvious failures"
```

## Escalation ladder

For most tasks:

1. **Triage cheaply:** Gemini Flash / GPT Mini / Haiku.
2. **Implement normally:** Sonnet 4.6 / Codex 5.3 / GPT-5.5.
3. **Review or unblock hard problems:** Opus 4.8 / GPT-5.5.

For token-heavy tasks:

1. Use **Gemini 3.1 Pro** or a Flash model to summarize and cluster context.
2. Feed the distilled context to **Sonnet 4.6**, **GPT-5.5**, or **Opus 4.8** for the actual decision.
3. Use a cheap model again for mechanical follow-up only after the decision is made.

