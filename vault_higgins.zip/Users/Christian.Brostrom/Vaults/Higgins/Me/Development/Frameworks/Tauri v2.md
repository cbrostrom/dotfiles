# Tauri v2

Quick reference only. Do not auto-load into agent context.

Official docs: https://v2.tauri.app/start/

## When to reference

Use this when a project has `src-tauri/`, `tauri.conf.json`, `@tauri-apps/*`,
Rust commands for a desktop shell, or user mentions Tauri.

## Agent rule

Open this note only when relevant. Prefer the official docs link over copying
docs into chat. If docs changed while using them, update this note with a
one-line link/note and `Last checked`; never paste large docs.

Last checked: 2026-06-19
