# Fallow

Codebase intelligence for JavaScript/TypeScript: dead code, duplication, complexity, circular deps, architecture boundaries, PR risk. Static, zero-config, sub-second. Repo: https://github.com/fallow-rs/fallow · Docs: https://docs.fallow.tools

## Invocation: use npx (not installed globally)

The `fallow` binary is NOT on PATH on this machine. Always run via npx:

```bash
npx --yes fallow <command> [flags]
```

First run downloads the prebuilt binary (~10s); subsequent runs are cached and fast.

## Agent rules (always)

1. Always use `--format json --quiet 2>/dev/null` for machine-readable output. `2>/dev/null` keeps progress/warnings off stdout so JSON stays clean. Never `2>&1`.
2. Always append `|| true` — exit code 1 means "issues found" (normal), not an error. Only exit 2 is a real error (bad config / parse failure). Without `|| true` the shell treats exit 1 as failure.
3. The earlier `|| true` masking bug: if `fallow` is not installed, `fallow ... || true` silently returns empty and looks like "no issues". Always invoke as `npx --yes fallow` and sanity-check the binary resolves (`npx --yes fallow --version`).

## Common commands

```bash
# Full analysis (dead code + duplication + health)
npx --yes fallow --format json --quiet 2>/dev/null || true

# Dead code only (unused files/exports/types/deps + circular deps)
npx --yes fallow dead-code --format json --quiet 2>/dev/null || true
npx --yes fallow dead-code --format json --quiet --unused-exports 2>/dev/null || true

# PR risk: only issues introduced vs a base ref (pass/warn/fail verdict)
npx --yes fallow audit --base main --format json --quiet 2>/dev/null || true

# Duplication (modes: strict | mild(default) | weak | semantic)
npx --yes fallow dupes --format json --quiet --mode semantic 2>/dev/null || true

# Complexity hotspots, owners, refactor targets (needs git repo)
npx --yes fallow health --format json --quiet --hotspots --targets 2>/dev/null || true

# Trace before deleting a "unused" export / file / dependency
npx --yes fallow dead-code --format json --quiet --trace src/utils.ts:myFn 2>/dev/null || true
npx --yes fallow dead-code --format json --quiet --trace-dependency lodash 2>/dev/null || true

# Auto-fix unused exports/deps — ALWAYS dry-run first, then apply
npx --yes fallow fix --dry-run --format json --quiet 2>/dev/null || true
npx --yes fallow fix --yes --format json --quiet 2>/dev/null || true   # --yes required in non-TTY

# Feature flags / security candidates (unverified — must verify before acting)
npx --yes fallow flags --format json --quiet 2>/dev/null || true
npx --yes fallow security --format json --quiet 2>/dev/null || true
```

## Config file

fallow requires `.fallowrc.json` (or `.fallowrc.jsonc` / `fallow.toml`). **`fallow.config.json` is NOT discovered** — use `npx fallow config` to verify it loads. Key options:

```json
{
  "ignoreDependencies": ["pkg-name"],
  "ignoreExports": ["src/file.ts:exportName"],
  "ignorePatterns": ["**/generated/**"]
}
```

## Notes

- Monorepo scoping: `--workspace '<glob>'` (e.g. `apps/*,!apps/legacy`) or `--changed-workspaces <ref>` for CI.
- Scope to files (lint-staged): `--file path/a.ts --file path/b.ts`.
- Production-only (excludes tests/stories/specs): `--production`.
- `--explain` adds metric definitions to JSON; `fallow explain <issue-type>` explains a rule without running.
- Suppress: `// fallow-ignore-next-line <issue-type>` or `// fallow-ignore-file <issue-type>`.
- Never run `fallow watch` (interactive, never exits). Never enable telemetry on the user's behalf.
- Full skill reference lives at `~/.claude/skills/fallow/SKILL.md`.

## laesr usage

For the laesr repo (Bun monorepo): `npx --yes fallow audit --base main --format json --quiet 2>/dev/null || true` after each feature/stream to catch dead code + complexity regressions before commit.
