# SolidJS

Quick reference only. Do not auto-load into agent context.

Official docs: https://docs.solidjs.com/

## When to reference

Use this when a project has `solid-js`, SolidStart, `vite-plugin-solid`,
`*.tsx` Solid components, or user mentions SolidJS.

## Agent rule

Open this note only when relevant. Prefer the official docs link over copying
docs into chat. If docs changed while using them, update this note with a
one-line link/note and `Last checked`; never paste large docs.

Last checked: 2026-06-19
