---
created: 2026-06-21
area: dev
type: reference
tags: [raycast, extensions, react, typescript, node]
---

# Raycast Extensions

Quick reference only. Open this when working on Raycast extensions.

Official docs:

- Dev docs: `https://developers.raycast.com/`
- Manual overview: `https://manual.raycast.com/extensions#create-your-own`
- Docs index: `https://developers.raycast.com/llms.txt`

## When to reference

Use this when you want to scaffold a new Raycast extension, remember how the
manifest maps to files, or query the official docs quickly without browsing.

## Fastest start

1. In Raycast, run `Create Extension`.
2. Pick a template. `Detail` is a safe starter; `List` is a good default for
   search/results flows.
3. Choose the parent folder and generate the extension.
4. In the new extension directory, run `npm install && npm run dev`.
5. Open Raycast and launch the command from Root Search.
6. Edit the entry file under `src/` and save. `npm run dev` handles hot reload.

## Prereqs

- Raycast installed
- Signed in to Raycast
- Node.js 22.14+
- npm 7+
- Basic TypeScript and React comfort

## Mental model

- `package.json` is the manifest and the npm package file.
- `src/` holds command entry files.
- A command `name` maps to `src/<name>.ts` or `src/<name>.tsx`.
- Use `tsx` for UI commands and `ts` for simpler non-UI commands.
- Preferences are declared in the manifest and show up in Raycast Preferences >
  Extensions.

## First pages to revisit

- Getting Started:
  `https://developers.raycast.com/basics/getting-started`
- Create Your First Extension:
  `https://developers.raycast.com/basics/create-your-first-extension`
- Manifest:
  `https://developers.raycast.com/information/manifest`
- File Structure:
  `https://developers.raycast.com/information/file-structure`

## Query the docs fast

Raycast's docs are unusually agent-friendly:

- Append `.md` to a docs page to get Markdown.
- Append `?ask=<question>` to ask that page a focused question.

Examples:

- `https://developers.raycast.com/readme.md?ask=What should I read first to build a small local extension?`
- `https://developers.raycast.com/information/manifest.md?ask=How do extension preferences and command preferences relate?`
- `https://developers.raycast.com/information/file-structure.md?ask=How does command name map to files in src?`

## Good first extension shapes

- A search shortcut that opens a site or internal tool
- A command that reads one API and renders a list/detail view
- A clipboard formatter or text transformer
- A personal capture command that sends input to a file or endpoint

## Agent rule

Prefer the official docs links over copying large chunks into notes. If the docs
change in a meaningful way, update this note with the new link or rule and bump
`Last checked`.

Last checked: 2026-06-21
