---
created: 2026-06-29
area: dev
type: reference
tags: [email, infrastructure, domains, migration, mxroute]
status: active
---

# Email Inventory — christianbrostrom.com + .dk

Snapshot from MXroute DirectAdmin panel, 2026-06-29. Source for migration planning.

Host: **mxrouting.net** (not cPanel).
Related: [[Domain Consolidation Strategy]]

---

## How routing works

All routing is visible in the forwarder screenshots — **no hidden external forwards**. The flow is:

```
service alias (forwarder only) → hub mailbox on MXroute → read via IMAP/client
```

The forward icon on mailboxes means **"receives forwarded mail from aliases"**, not outbound forwarding. Mail accumulates in the hub mailboxes listed below.

---

## Summary

| Domain | Mailboxes | Forwarders | Total stored |
|---|---:|---:|---:|
| `christianbrostrom.com` | 6 | 29 | ~5.0 GB |
| `christianbrostrom.dk` | 7 | 7 | ~1.77 GB |

**Pattern:** `.com` = many service aliases → two hubs (`signup@`, `mail@`). `.dk` = fewer aliases → hubs (`post@`, `me@`, `signup@`, `subscriptions@`, `legacy@`, `notify@`).

---

## christianbrostrom.com

### Mailboxes (6) — terminal destinations

| Address | Storage | Role |
|---|---:|---|
| `signup@` | 2.52 GB | Service registrations / throwaway signups |
| `mail@` | 954 MB | Personal / important mail |
| `legacy@` | 914 MB | **Active fallback** — catches unclassified mail; needs tighter control |
| `akqa@` | 495 MB | Work (AKQA) |
| `adj@` | 162 MB | **Aleks Deejay** (legacy DJ identity) — migrate to `aleksdeejay.dk` |
| `notify@` | 35 MB | Notifications |

### Forwarders (29)

#### → `signup@christianbrostrom.com` (21)

arc, centered, db, ea, lily, logseq, morgan, netdata, newsletter, notify, nzb, obsidian, ok, plex, ps, screeps, shopping, steam, streamdeck, techland, travel

#### → `mail@christianbrostrom.com` (6)

banking, forsikring, jagskalgiftesmedsofia, lunan, parkering, work

#### Other (2)

| Alias | Destination | Status |
|---|---|---|
| `no-reply@` | `notry@christianbrostrom.com` | Leftover — unused, safe to remove |
| `sofie@` | `post@christianbrostrom.dk` + `sofieaa@hotmail.com` | **Unused** — candidate for removal (see verify steps below) |

---

## christianbrostrom.dk

### Mailboxes (7) — terminal destinations

| Address | Storage | Role |
|---|---:|---|
| `post@` | 1.77 GB | Primary personal inbox |
| `signup@` | 2.56 MB | Service signups |
| `me@` | 234 KB | Personal routing hub |
| `bank@` | 267 KB | Banking |
| `subscriptions@` | 33 KB | Paid subscriptions |
| `legacy@` | 0 B | Forward sink — `privat@` lands here |
| `notify@` | 0 B | Forward sink — `git@` lands here |

### Forwarders (7)

| Alias | Destination |
|---|---|
| `fagforening@` | `me@` |
| `git@` | `notify@` |
| `iptv@` | `signup@` + `subscriptions@` |
| `lunan@` | `me@` |
| `netflix@` | `signup@` + `subscriptions@` |
| `nzb@` | `signup@` |
| `privat@` | `legacy@` |

---

## Overlap & inconsistencies

| Issue | Detail |
|---|---|
| Duplicate alias | `lunan@` — `.com` → `mail@`, `.dk` → `me@` |
| Duplicate alias | `nzb@` — both domains →各自的 `signup@` |
| Alias/mailbox clash | `notify@` on `.com` is both a mailbox (35 MB) AND an alias → `signup@` |
| Hub sprawl | Personal mail split across `mail@`, `me@`, `post@` |
| Legacy dual role | `.com` legacy@ = 914 MB active fallback; `.dk` legacy@ = empty forward sink |
| DJ mail on wrong domain | `adj@` (162 MB) should live on `aleksdeejay.dk` |
| Dead forwarders | `no-reply@` → `notry@`, `sofie@` → `.dk` + Hotmail |

---

## Recommendations

### Target architecture

```
christianbrostrom.dk (MXroute)
├── post@           primary personal inbox
├── signup@         all service registrations
├── subscriptions@  recurring (netflix, iptv)
├── notify@         automated alerts (git, monitoring) — forward-only, no mailbox needed
├── bank@           financial
└── aliases         forwarders only

christianbrostrom.com
└── catch-all → post@christianbrostrom.dk   (retire 29 individual forwarders over time)

aleksdeejay.dk
└── own mailbox     migrate adj@ content here, then delete adj@
```

### Cleanup actions

1. **Imapsync `.com` mailboxes** (~5 GB) — forwarders don't move existing mail. Order: signup → legacy → mail → akqa → adj → notify.

2. **Collapse personal hubs** — `mail@`, `me@`, `post@` → one inbox (`post@christianbrostrom.dk`).

3. **Replace `legacy@` fallback with catch-all** — instead of a 914 MB dumping ground, use `.com` catch-all → `post@.dk` with client-side filters. Export legacy mail to local archive first.

4. **Migrate `adj@` → `aleksdeejay.dk`** — imapsync 162 MB, update any remaining DJ/service logins, delete mailbox.

5. **Remove dead forwarders** — `no-reply@` → `notry@`, `sofie@` (after verify), `jagskalgiftesmedsofia@`.

6. **Consolidate duplicates** — one domain for `lunan@` and `nzb@`.

7. **Retire stale service aliases** — screeps, techland, ea, etc. if accounts are gone.

8. **Update logins gradually** via password manager as discovered.

### How to verify `sofie@` is unused

1. Search password manager for `sofie@christianbrostrom.com`
2. In MXroute DirectAdmin → **E-Mail Delivery Logs** — filter recipient `sofie@`, check last 90 days
3. Search existing mailboxes (post@, mail@) for `To: sofie@` or `Cc: sofie@`
4. If all clear: delete forwarder, wait 30 days, confirm no bounces/missed mail

### Migration checklist

- [ ] Imapsync all 6 `.com` mailboxes → `.dk` targets
- [ ] Imapsync `adj@` → `aleksdeejay.dk`
- [ ] Export `legacy@christianbrostrom.com` to local mbox archive
- [ ] Set `.com` catch-all → `post@christianbrostrom.dk`
- [ ] Delete dead forwarders: `no-reply@`, `sofie@`, `jagskalgiftesmedsofia@`
- [ ] Consolidate duplicate aliases (lunan, nzb)
- [ ] Update password manager entries
- [ ] After 90-day soak: delete drained `.com` mailboxes

---

## Step-by-step cleanup guide

Work in order. Each phase is safe to pause between. Total active work: ~2–3 hours spread over a few weeks.

### Phase 0 — Prep (30 min)

1. Log into **MXroute DirectAdmin** — note your IMAP server hostname (E-Mail Accounts → connect info). Usually `* .mxrouting.net`, port **993**, SSL.
2. Install **imapsync** locally if you don't have it:
   ```bash
   brew install imapsync   # macOS
   ```
3. Create a local archive folder: `~/MailArchive/christianbrostrom-migration/`
4. Open password manager — you'll update entries as you go, not all at once.

### Phase 1 — Kill dead weight (15 min)

No mail moves yet. Just remove forwarders you're sure about.

1. DirectAdmin → **E-Mail Forwarders** → `christianbrostrom.com`
2. Verify `sofie@` is unused (delivery logs + password manager search)
3. Delete these forwarders:
   - `no-reply@` → `notry@`
   - `sofie@` → post@ + Hotmail
   - `jagskalgiftesmedsofia@` → mail@
4. Scan the signup@ alias list — delete any for services you no longer use (screeps, techland, ea, etc.)

### Phase 2 — Archive legacy mail (30 min)

`legacy@christianbrostrom.com` is 914 MB of fallback mail. Export before you restructure.

1. Add `legacy@christianbrostrom.com` to your mail client (Apple Mail, Thunderbird, etc.)
2. Select all → **Export mailbox** / save as `.mbox`
3. Store in `~/MailArchive/christianbrostrom-migration/legacy-com.mbox`
4. Leave the mailbox on MXroute for now — you'll drain it in Phase 3.

### Phase 3 — Move mail to `.dk` (1–2 hours, mostly waiting)

Imapsync copies mail between mailboxes on the same server. Same host for both sides, different user names.

**Target mapping:**

| Source (.com) | Destination (.dk) | Size |
|---|---|---|
| `mail@` | `post@` | 954 MB |
| `signup@` | `signup@` | 2.52 GB |
| `legacy@` | `post@` (or keep archived locally only) | 914 MB |
| `akqa@` | `post@` or keep separate | 495 MB |
| `notify@` | `notify@` | 35 MB |

Run one mailbox at a time. Example for `mail@` → `post@`:

```bash
imapsync \
  --host1 YOUR_IMAP_HOST --user1 mail@christianbrostrom.com --password1 'PASS' --ssl1 \
  --host2 YOUR_IMAP_HOST --user2 post@christianbrostrom.dk   --password2 'PASS' --ssl2 \
  --automap --useheader 'Message-Id'
```

Tips:
- Replace `YOUR_IMAP_HOST` with your server from DirectAdmin
- `--automap` merges folders sensibly (Inbox → Inbox, etc.)
- For `signup@` (2.52 GB), run overnight — add `--nofoldersizes` to speed up start
- Verify in mail client: spot-check a few old messages in the destination mailbox

**Separate task — Aleks Deejay:**

```bash
imapsync \
  --host1 YOUR_IMAP_HOST --user1 adj@christianbrostrom.com --password1 'PASS' --ssl1 \
  --host2 YOUR_IMAP_HOST --user2 YOU@aleksdeejay.dk         --password2 'PASS' --ssl2 \
  --automap
```

Create the `aleksdeejay.dk` mailbox first if it doesn't exist.

### Phase 4 — Collapse personal hubs (15 min)

Once mail@ and me@ content is in post@:

1. DirectAdmin → **E-Mail Forwarders** → `christianbrostrom.dk`
2. Confirm `fagforening@` and `lunan@` still route to `me@`
3. Change those forwarders: `fagforening@` → `post@`, `lunan@` → `post@`
4. On `.com`: change the 6 mail@ aliases (banking, forsikring, etc.) → `post@christianbrostrom.dk` instead of `mail@christianbrostrom.com`
5. Remove duplicate `lunan@` and `nzb@` forwarders on `.com` (keep the `.dk` versions)

### Phase 5 — Catch-all on `.com` (10 min)

Replaces the old legacy@ fallback with something controlled.

1. DirectAdmin → **E-Mail** → **Default Address** → `christianbrostrom.com`
2. Set to forward to `post@christianbrostrom.dk`
3. Now any mail to `random@christianbrostrom.com` with no explicit forwarder still reaches you
4. You can now delete individual `.com` forwarders over time — catch-all covers stragglers

### Phase 6 — Client-side filters (20 min)

In your mail client on `post@christianbrostrom.dk`, create rules so migrated chaos is sortable:

| Rule | Action |
|---|---|
| To contains `signup@` or service alias | Move to folder "Signups" |
| To contains `bank` or `forsikring` | Move to folder "Finance" |
| To contains `akqa` or `work@` | Move to folder "Work" |
| To contains `notify@` or `git@` | Move to folder "Alerts" |

Adjust to taste. Goal: one inbox, organised by alias.

### Phase 7 — Update logins (ongoing, 5 min/week)

Don't big-bang this. As you use services:

1. Search password manager for `@christianbrostrom.com`
2. Change email to the new alias on `.dk` (or keep `.com` — catch-all still works)
3. Mark entry as updated

Priority: banking, work, anything security-sensitive first.

### Phase 8 — Drain and delete (after 90 days)

Only after you've lived with the new setup and confirmed nothing is missing.

1. Confirm `.com` mailboxes show no new mail (check dates on latest messages)
2. Delete drained mailboxes on `.com`:
   - `mail@`, `signup@`, `legacy@`, `adj@`, `notify@`
   - Keep or delete `akqa@` depending on work preference
3. Delete empty `.dk` mailboxes if fully merged: `me@`
4. Remove remaining individual `.com` forwarders — catch-all handles stragglers
5. Optional: reduce `.com` to **zero mailboxes**, catch-all only (domain kept for legacy addresses)

### Rollback

If something breaks mid-migration:
- Forwarders are cheap — re-add any deleted alias in DirectAdmin
- imapsync is copy-only — source mailboxes stay intact until you delete them
- Don't delete source mailboxes until Phase 8

---

## Resolved

| Question | Answer |
|---|---|
| Where does mail land? | Hub mailboxes on MXroute — read via IMAP. Forwarder screenshots are complete. |
| What is `adj@`? | Aleks Deejay — migrate to `aleksdeejay.dk` |
| What is `notry@`? | Leftover no-reply, unused — remove |
| What is `legacy@`? | Active fallback on `.com` (914 MB) — replace with controlled catch-all |
| Host? | mxrouting.net (DirectAdmin) |
| Is `sofie@` needed? | No — verify via logs/password manager, then delete |
