#!/usr/bin/env bash
# Install new Obsidian community plugins into vault
# Run from anywhere — edit VAULT_DIR if needed

set -euo pipefail

VAULT_DIR="${1:-$HOME/Vaults/Christian}"
PLUGIN_DIR="$VAULT_DIR/.obsidian/plugins"

declare -A PLUGINS=(
  ["obsidian-local-rest-api"]="coddingtonbear/obsidian-local-rest-api"
  ["omnisearch"]="scambier/obsidian-omnisearch"
  ["obsidian-reminder-plugin"]="uphy/obsidian-reminder"
  ["quickadd"]="chhoumann/quickadd"
  ["obsidian-kanban"]="mgmeyers/obsidian-kanban"
  ["smart-connections"]="brianpetro/obsidian-smart-connections"
  ["highlightr-plugin"]="chetachiezikeuzor/Highlightr-Plugin"
)

mkdir -p "$PLUGIN_DIR"

for plugin_id in "${!PLUGINS[@]}"; do
  repo="${PLUGINS[$plugin_id]}"
  dir="$PLUGIN_DIR/$plugin_id"
  mkdir -p "$dir"

  echo "→ $plugin_id ($repo)"

  tag=$(curl -sf "https://api.github.com/repos/$repo/releases/latest" \
    | grep '"tag_name"' | head -1 | sed 's/.*"tag_name": "\(.*\)".*/\1/')

  if [ -z "$tag" ]; then
    echo "  ✗ Could not fetch release tag — skipping"
    continue
  fi

  base="https://github.com/$repo/releases/download/$tag"

  curl -sfL "$base/main.js"       -o "$dir/main.js"       || echo "  ⚠ main.js missing"
  curl -sfL "$base/manifest.json" -o "$dir/manifest.json" || echo "  ⚠ manifest.json missing"
  curl -sfL "$base/styles.css"    -o "$dir/styles.css"    2>/dev/null || true

  if [ -s "$dir/manifest.json" ]; then
    name=$(grep '"name"' "$dir/manifest.json" | head -1 | sed 's/.*"name": "\(.*\)".*/\1/')
    echo "  ✓ $name @ $tag"
  else
    echo "  ✗ Failed"
  fi
done

echo ""
echo "Done. Restart Obsidian — plugins appear in Settings → Community plugins."
echo "LiveSync will sync plugin files to all other devices automatically."
