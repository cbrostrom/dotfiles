# MonsterBro — Hardware Audit

**Date:** 2026-07-14
**Role:** Windows gaming rig + WSL dev server

## Specs

| Component | Details |
|---|---|
| **CPU** | AMD Ryzen 7 5800X (8-core / 16-thread, 3.8 GHz) |
| **RAM** | 32 GB |
| **GPU** | NVIDIA GeForce RTX 2070 SUPER (8 GB VRAM) |
| **Motherboard** | ASUS TUF GAMING X570-PLUS |
| **OS** | Windows 11 Pro (Build 26200) |
| **WiFi** | Intel Wi-Fi 6 AX200 160MHz (1.2 Gbps) |
| **Ethernet** | Realtek Gaming GbE (1 Gbps) |

## Storage

| Drive | Size | Free |
|---|---|---|
| C: | 930 GB | 642 GB |
| D: | 466 GB | 405 GB |
| E: | 7,452 GB | 4,944 GB |
| F: | 1,863 GB | 108 GB |
| G: | 1,863 GB | 176 GB |
| H: | 932 GB | 157 GB |

**Total:** ~13.5 TB across 6 drives

## WSL

| Component | Details |
|---|---|
| **Distro** | Debian 13 (Trixie) |
| **Kernel** | 6.6.114.1-microsoft-standard-WSL2 |
| **Disk** | 1 TB (899 GB free) |
| **SSH** | Port 27789, key: `superbro_ed25519` |

## Notes

- GPU is passthrough from Windows to WSL (not visible from Linux side)
- Tailscale IP: `100.100.1.255`
- Hostname (Tailscale): `monsterbro`
- WSL user: `christian`
