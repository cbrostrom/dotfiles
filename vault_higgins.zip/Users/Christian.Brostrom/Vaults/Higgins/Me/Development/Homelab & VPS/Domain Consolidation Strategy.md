---
tags: [infrastructure, domains, identity, strategy]
created: 2026-05-31
status: decided
---

# Domain Consolidation Strategy

## Final Domain Roles

| Domain | Role | Status |
|---|---|---|
| `christianbrostrom.dk` | Identity — personal site, portfolio, contact, primary email | Active |
| `superbro.dk` | Platform — all services, tools, homelab, VPS, experiments | Active |
| `christianbrostrom.com` | Legacy email insurance — catch-all forwarding only | Retain, no migration |
| `cloudbro.dk` | Deprecated — retire at next renewal | Retiring |

## Subdomain Strategy on superbro.dk

```
service.lab.superbro.dk   → homelab (linuxbro) — replaces *.cloudbro.dk
service.vps.superbro.dk   → VPS ops/internal tooling
service.superbro.dk       → public-facing / identity-neutral
```

Max 2–3 levels. Segments: `lab` / `vps` / `public` / `internal`.

### Example targets

```
docker.lab.superbro.dk    Portainer/Dockhand on homelab
plex.lab.superbro.dk
grafana.lab.superbro.dk

docker.vps.superbro.dk    Portainer/Dockhand on VPS
grafana.vps.superbro.dk

auth.superbro.dk          public
status.superbro.dk        public
git.superbro.dk           public
```

## Email Strategy

Migrate all `.com` mail (~5 GB across 6 mailboxes) to `.dk` primary. See full inventory: [[Email Inventory — christianbrostrom.com + .dk]].

Target: `.com` becomes catch-all forward to `post@christianbrostrom.dk` only. Collapse hub mailboxes (`mail@`, `me@`, `post@`) into one. Update service logins gradually via password manager.

## Why superbro.dk Wins

- Already in active use
- Flexible — not tied to infra semantics (unlike `cloudbro`)
- Memorable, extensible across all project types
- Slight playfulness acceptable

## Why cloudbro.dk is Expendable

Too semantically narrow (cloud/infrastructure concept). Weak for general-purpose tools or SaaS-style projects. Legacy separation that no longer serves a purpose.

## Related

- [[cloudbro.dk Migration Plan]]
