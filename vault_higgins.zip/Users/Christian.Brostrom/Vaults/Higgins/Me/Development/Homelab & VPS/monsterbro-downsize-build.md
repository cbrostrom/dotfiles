# MonsterBro — Downsized Build Guide

**Date:** 2026-07-14
**Goal:** Shrink tower to compact mATX, upgrade GPU

## Parts List

| Component | Product | Price (DKK) | Source |
|---|---|---|---|
| **GPU** | ASUS RX 9070 XT Prime OC 16GB | 4,899 | Proshop |
| **Motherboard** | ASUS TUF B550M-PLUS WiFi II (mATX, AM4, WiFi 6) | 1,045 | Avxperten |
| **Case** | Lian Li A3-mATX (26.3L, mesh) | 551 | Kelkoo |
| **External dock** | LC Power LC-DOCK-U3-4B (4-bay USB 3.2) | 649 | Avxperten |
| | **Total** | **7,144** | |

### Cheaper GPU alternatives
| Product | Price (DKK) |
|---|---|
| Gigabyte RX 9070 XT Gaming OC | 5,099 |
| Sapphire RX 9070 XT Pulse | 5,721 (Elgiganten) |
| Sapphire RX 9070 XT Nitro+ | 5,999 |

## What carries over from current build

- AMD Ryzen 7 5800X (AM4 socket — compatible with B550)
- 32 GB DDR4 RAM (B550M supports up to 128 GB)
- All 6 storage drives

## Storage layout

### Internal (case supports 2× SSD + 1× HDD)
| Slot | Drive | Purpose |
|---|---|---|
| M.2 or SATA | OS SSD (C:) | Windows + WSL |
| 2.5" bay | Data SSD (D:) | Games / active projects |
| 3.5" bay | Primary HDD | Frequently accessed data |

### External dock (USB 3.2, hot-swap)
| Drive | Size | Purpose |
|---|---|---|
| E: | 7,452 GB | Bulk storage / archives |
| F: | 1,863 GB | Media / backups |
| G: | 1,863 GB | Media / backups |

**Note:** H: (932 GB) — decide if it stays internal or moves to dock. Dock has 4 bays, only 3 used.

## Build checklist

- [ ] Order parts
- [ ] Back up critical data (just in case)
- [ ] Remove old GPU (RTX 2070 SUPER)
- [ ] Remove old motherboard (X570-PLUS ATX)
- [ ] Install B550M-PLUS WiFi II
- [ ] Transfer CPU (5800X) + cooler + RAM
- [ ] Install RX 9070 XT
- [ ] Route 3× HDD to external dock
- [ ] Cable management (A3-mATX is tight — plan routes)
- [ ] Boot Windows, install AMD drivers
- [ ] Verify WSL still works
- [ ] Run gaming benchmark to confirm improvement
- [ ] Sell old parts (X570-PLUS + RTX 2070 SUPER)

## WSL caveat

RDNA 4 has a [known bug](https://github.com/microsoft/WSL/issues/14144) where GPU compute (OpenCL/ROCm) isn't detected in WSL2. Gaming on Windows is unaffected. General dev in WSL is unaffected. Only matters if you ever need GPU compute from WSL.

## Case specs (Lian Li A3-mATX)

- Volume: 26.3L (vs current tower ~50L+)
- Dimensions: 443 × 194 × 321 mm
- GPU clearance: 415mm (RX 9070 XT is ~300mm — fits easily)
- CPU cooler clearance: 165mm
- PSU: ATX/SFX (keep your current PSU if it fits, else SFX)
- Fans: supports up to 10× 120mm

## Motherboard specs (B550M-PLUS WiFi II)

- Socket: AM4 (compatible with 5800X)
- Form factor: mATX
- RAM: 4× DDR4, up to 128 GB
- M.2: 2× slots
- WiFi 6 + Bluetooth 5.2
- USB: 4× USB 3.2 Gen 1, 1× USB Type-C
- Ethernet: 2.5 Gb
- PCIe 4.0 support

## Resale value (old parts)

| Part | Estimated resale (DKK) |
|---|---|
| RTX 2070 SUPER | 1,500-2,000 |
| X570-PLUS ATX | 500-800 |
| **Total** | **2,000-2,800** |

**Net cost after resale: ~4,300-5,100 DKK**
