---
type: reference
tags:
  - homelab
  - vault
updated: 2026-05-28
---

# LiveSync Setup Guide

> Self-hosted CouchDB on superbro → Obsidian LiveSync on all devices.
> One-time setup per device. After that, plugins + notes sync automatically.

---

## 1. Deploy CouchDB on superbro

### Copy config file to host
```bash
mkdir -p ~/.config/couchdb/config
cp couchdb-local.ini ~/.config/couchdb/config/local.ini
```

### Create stack.env
```bash
cat > stack.env << EOF
TZ=Europe/Copenhagen
COUCHDB_USER=christian
COUCHDB_PASSWORD=<strong-password-here>
EOF
```

### Deploy via Dockhand
1. Open Dockhand → Stacks → New stack
2. Name: `couchdb`
3. Paste `couchdb-livesync-compose.yml`
4. Add env vars from stack.env
5. Deploy

### Create database
```bash
# After deploy — create the vault database
curl -X PUT https://sync.superbro.dk/christian-vault \
  -u christian:<password>
```

### Verify
```
https://sync.superbro.dk/_utils
```
Log in with your credentials. Database `christian-vault` should exist.

---

## 2. LiveSync settings (desktop — Win/Mac/Linux)

Settings → Self-hosted LiveSync:

```
Remote Database URI: https://sync.superbro.dk/christian-vault
Username: christian
Password: <your password>
End-to-end encryption: ON
Passphrase: <separate passphrase — save in Vaultwarden>

Sync on save: ON
Sync on start: ON
Periodic sync: ON (60s)
Sync hidden files: ON
Plugin synchronization: Full
Conflict resolution: Newer wins

Files to ignore:
.obsidian/workspace
.obsidian/workspace.json
.obsidian/workspace-mobile.json
.obsidian/cache
.trash/
```

### First-time sync (new machine)
1. Install Obsidian → create empty vault named `Christian`
2. Install Self-hosted LiveSync (only this plugin manually)
3. Configure as above
4. Replicate → "Fetch everything from remote"
5. Restart Obsidian → all plugins + notes appear
6. Done. Never set up manually again.

---

## 3. Mobile (iPhone + iPad)

Same LiveSync config as desktop BUT:

```
Sync hidden files: OFF
Plugin synchronization: Fetch only  ← never push from mobile
```

Active plugins on mobile (disable everything else):
- obsidian-livesync
- templater-obsidian
- periodic-notes
- quickadd

---

## 4. Install new plugins (once, on desktop)

Run install script (downloads from GitHub, LiveSync propagates to all devices):

```bash
chmod +x "Reference/Homelab & VPS/install-obsidian-plugins.sh"
bash "Reference/Homelab & VPS/install-obsidian-plugins.sh"
```

Then restart Obsidian → enable in Settings → Community plugins.

---

## 5. Plugin list

### Desktop (all devices)
| Plugin | Purpose |
|---|---|
| templater-obsidian | Smart templates, Work/Weekend routing |
| periodic-notes | Auto daily note creation |
| dataview | Dashboard queries |
| obsidian-meta-bind-plugin | Energy/mood/sleep/focus inputs |
| auto-note-mover | Tag → folder automation |
| calendar | Sidebar calendar |
| obsidian-doubleshift | Fast command palette |
| table-editor-obsidian | Tab nav in tables |
| obsidian-icon-folder | Visual folder icons |
| simple-colored-folder | Coloured folders |
| obsidian-style-settings | Theme tweaks |
| minimize-on-close | QoL |
| **obsidian-local-rest-api** | HTTP API → Claude Code can read/write vault |
| **omnisearch** | Fuzzy full-text vault search |
| **obsidian-reminder-plugin** | Date-based reminders inside notes |
| **quickadd** | Single hotkey → capture to Inbox |
| **obsidian-kanban** | Visual board for project tracking |
| **smart-connections** | Semantic search + AI chat over vault |
| **highlightr-plugin** | Colour highlights, visual memory aid |

### Mobile only (disable rest)
| Plugin | Keep |
|---|---|
| obsidian-livesync | ✅ |
| templater-obsidian | ✅ |
| periodic-notes | ✅ |
| quickadd | ✅ |

---

## 6. Local REST API → Claude Code integration

After installing obsidian-local-rest-api:
1. Settings → Local REST API → Generate API key → copy it
2. Add to `~/.claude/settings.json` MCP servers section (or ask Claude Code to do it)
3. Claude Code can now: read notes, create notes, search vault — from any terminal session

---

## Troubleshooting

**Sync not working:** Livesync → Check sync status. Verify `sync.superbro.dk` reachable on Tailscale.

**Plugins missing on new device:** Livesync → Plugin sync → Fetch all.

**Workspace keeps reverting:** Confirm `workspace.json` is in ignore list.

**Mobile overwrites desktop plugins:** Set plugin sync to "Fetch only" on mobile.
