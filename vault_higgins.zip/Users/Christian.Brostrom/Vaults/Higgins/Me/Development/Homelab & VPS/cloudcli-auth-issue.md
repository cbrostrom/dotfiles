---
created: 2026-06-15
area: dev
type: note
tags: [cloudcli, auth, caddy, superbro, parked]
status: parked
---

# CloudCLI Auth Issue (Parked)

## Problem
CloudCLI at `ai.local:8443` (Caddy → localhost:8686) shows Claude as **Not authenticated** even though `claude auth status` returns `loggedIn: true`.

## Root Cause
cloudcli's auth check reads `~/.claude/.credentials.json`. Newer Claude Code (current version) stores OAuth tokens in **macOS Keychain** — `.credentials.json` doesn't exist. cloudcli is blind to Keychain auth.

## Symptoms
- Provider card shows "Not authenticated" for Claude
- Falls back to Cursor subscription instead
- `claude auth login` inside cloudcli terminal shows success → UI still shows unauthenticated
- JWT errors in pm2 logs (`expiredAt: 2026-05-19`) = stale browser session token, separate issue

## Fix (when ready)
Need one of:
1. **API key** → `echo "ANTHROPIC_API_KEY=sk-ant-..." > /opt/homebrew/lib/node_modules/@cloudcli-ai/cloudcli/.env && pm2 restart cloudcli-ui`
2. **File cloudcli issue** → they need Keychain support in `claude-auth.provider.ts`

## Blocker
Enterprise AKQA subscription — no personal API key available via console.anthropic.com.

## SuperBro
Don't install cloudcli there until Mac auth resolved. Same fix applies cross-machine (API key in `.env`).

## Stale browser JWT
If cloudcli UI acts up: clear localStorage at `https://ai.local:8443` → re-login with username/password.
