# Brain: Brain
_Updated: 2026-06-21_

## Current State

## Conventions

- For Cursor model recommendations from specs, use `Development/Cursor Model Selection Map.md` as the reference for ability vs token-budget routing.

