# Next: dotfiles

- Seed Keychain + enable pinentry-touchid (manual: `rbw unlock` in Terminal → "Save in Keychain" → `rbw config set pinentry pinentry-touchid`).
- Bootstrap MonsterBro (`dotfiles --update` end-to-end on WSL host — `mcp-servers.wsl.list` exists but full bootstrap loop unverified).
- Test `.task init` on real project.
- Restart CC after MCP cull — confirm context drop. [done: 2026-06-17]
- Phase 2: wire ~/.cursor/hooks.json SessionStart → brain-load.sh (auto brain in Cursor) [done: 2026-06-17]
- Phase 4: remove lean-ctx + headroom entries from .claude/mcp-servers.list and mcp-servers.macos.list [done: 2026-06-17]
- Commit all Phase 0-1 changes (ask user first) [done: 2026-06-17]
- Implement agnostic consolidation spec — Plans/Active/2026-06-21-agnostic-consolidation-spec.md (phases 1-5, Zed rules already done)
- Execute dotfiles cleanup phases A+B+D — plan at ~/Vaults/Brain/Brains/dotfiles/cleanup-plan-2026-06-25.md
- Review + build subagent ideas from ~/Vaults/Brain/Brains/dotfiles/subagent-ideas-2026-06-25.md — start with standup, morning-brief, dot-doctor
