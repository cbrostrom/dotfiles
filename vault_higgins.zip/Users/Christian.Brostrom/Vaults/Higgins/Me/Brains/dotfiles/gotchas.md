# Gotchas: dotfiles

- **`~/.claude.json` mcpServers** bypasses dotfiles overlay system. Manual `claude mcp add` writes here. Audit periodically.
- **pfctl rule order**: `rdr-anchor` must precede `anchor` in `/etc/pf.conf`. macOS updates reset → re-run `sudo scripts/system/pf-caddy.sh`.
- **pm2 after node upgrade**: delete + recreate entry with current `$(which node)`, then `npm rebuild better-sqlite3 --prefix <pkg>`.
- **pinentry-touchid setup**: needs `pinentry-touchid -fix` once to redirect fallback symlink to `pinentry-mac`.
- **cloudcli-update**: must use `npm update -g --prefix /opt/homebrew` — homebrew prefix required or wrong binary updates. `$(which cloudcli)` in new shell may resolve to `/opt/homebrew/bin/cloudcli` (homebrew PATH precedes fnm).
- **cloudcli auth shim**: synthetic `~/.claude/.credentials.json` with placeholder `accessToken` lets cloudcli show "connected" under enterprise Keychain auth. Breaks if cloudcli ever validates token against API.
- **git worktree prune** only works from inside owning repo. Running in dotfiles doesn't clean external project worktrees.
- **CLAUDEMD editing**: blocked by auto-mode self-modification guard. Edit source at `~/dotfiles/.claude/CLAUDE.md` (symlink target).
- **Zed ACP zombies**: `Zed → acp → node → claude SDK` chain leaks sessions on task complete. No Zed config to fix. Kill manually if accumulating.
- **Parallel agents**: token-multiplicative — quality usually same as sequential for solo workflow. Use only for 10+ file migrations or adversarial review.
- **Brain skill removed**: `.claude/skills/brain/` gone. Replaced by `brain` CLI. Memory = markdown files, no MCP, no skill overhead.
- **brain CLI shell expansion**: avoid `**` in shell args — zsh expands globs. Use plain text or single quotes.
- **zsh ** expansion**: shell expands ** before Python receives it. Use single quotes or no ** braindirectly in brain CLI args.
- Plans go to ~/Vaults/Brain/Plans/Active/ — never to .planning/ in the repo. All agents must use the vault path. AGENTS.md brain section already documents the vault location.
