# Dotfiles Cleanup Plan — 2026-06-25

Audit performed by Cursor agent. Repo: `~/dotfiles`. All phases ordered by risk/impact.

---

## Phase A — Safe deletions (archive/docs)
_Zero runtime risk. Do anytime._

- [ ] `docs/superpowers/` — 7 historical planning/spec files. Git history preserves them.
- [ ] `.planning/` — completed audit + clean-slate plan. Git history preserves them.
- [ ] `.claude/skills/.disabled-2026-05-15/` — 5 disabled skill trees (plannotator-*, vite)
- [ ] `.claude/skills/.disabled-2026-06-16-using-superpowers/` — disabled superpowers adapter
- [ ] `.fallow/` at repo root — local audit cache, not in .gitignore (add to gitignore)
- [ ] Update `brainstorming` + `writing-plans` skills: remove refs to `docs/superpowers/` paths → retarget to vault paths
- [ ] `modules/claude-settings/README.md` L44-45 — remove stale spec/plan doc references

---

## Phase B — Fix broken wiring (bugs)
_Real issues. High priority._

- [ ] `.zshrc` L90: references `09-cmux.zsh` but `09-herdr.zsh` exists — **breaks herdr load**
- [ ] `.zshrc` L108: stale comment about `07-zellij.zsh` (removed)
- [ ] `zsh/08-workflow.zsh` L15: `claude-sync` hardcodes `~/.config/dotfiles/...` — wrong path when repo is `~/dotfiles`
- [ ] `scripts/claude/install-claude-config.sh` L128-129: links `entroly-start.sh` + `claude-session-check.sh` — files don't exist
- [ ] `scripts/doctor.sh` L174-188: health checks for missing hooks (entroly, claude-session-check)
- [ ] `.claude/settings.local.example.json`: SessionStart hooks reference missing files
- [ ] Root `CLAUDE.md` hook table: documents `wrap-reminder.sh` + `engram-sync-start/stop.sh` — both missing. Update to match reality.
- [ ] `modules/claude-settings/README.md` L25: claims `claude-settings-merge.sh` runs on SessionStart — **not wired in any settings JSON**. Either wire it or delete hook + fix README.
- [ ] `.agents/skills/dotfiles/SKILL.md` L28: lists `rtk-rewrite.sh` as active Claude hook — should be `rtk hook claude`

---

## Phase C — lean-ctx excision
_Policy says removed. Still installed in several places._

- [ ] `modules/rust-tools/install.sh` — remove lean-ctx cargo install
- [ ] `modules/rust-tools/module.sh` — update description
- [ ] `modules/rust-tools/status.sh` — remove lean-ctx health check
- [ ] `scripts/install/bootstrap-server.sh` L79-94 — remove lean-ctx install
- [ ] `README.md` L72-77 — remove lean-ctx troubleshooting (Danish)
- [ ] `.gitignore` L69-70 — remove `.lean-ctx/` cache entry
- [ ] Decide: disable `rust-tools` in `modules.conf` if lean-ctx was its only purpose (check what else it installs)

---

## Phase D — Hook cleanup
_Clean up superseded/orphan hooks._

- [ ] `.claude/hooks/rtk-rewrite.sh` — superseded by `rtk hook claude` native hook. Delete.
- [ ] `claude-settings-merge.sh` — wire into SessionStart in `settings.base.json` OR delete hook and update README claim
- [ ] Verify `engram-sync-start/stop.sh` — if engram uses systemd/launchd, remove from CLAUDE.md docs

---

## Phase E — Test/doc alignment
_Fixtures and docs drifting from reality._

- [ ] `modules/claude-settings/tests/fixtures/e2e/expected-{linux,darwin}.json` — contain `superpowers@...` true + `entroly-start.sh` — drift from live `settings.base.json`
- [ ] `AGENTS.md` L193 — references `.aislop/config.yml` which doesn't exist. Either add config file or remove reference.
- [ ] `.claude/devices/MonsterBro.json` — capital M; hostname-s convention is lowercase. Rename to `monsterbro.json`.
- [ ] `settings.local.example.json` statusLine — points to caveman plugin cache path; should use `statusline.sh` like darwin settings.
- [ ] `mcp-servers.wsl.list` — WSL list may still have pruned MCPs (mcp-mermaid, tailwindcss, google-calendar). Align with policy.
- [ ] `README.md` — references `modules/vscodium/` which doesn't exist. Update.

---

## Phase F — Orphan scripts
_Wire or delete._

- [ ] `.claude/scripts/homeassistant-mcp.sh` — not referenced in any `mcp-servers*.list`. Wire to list or delete.
- [ ] `scripts/brain-pick.sh` — `.claude/CLAUDE.md` uses `brain pick` CLI; check if this wrapper adds value or is dead.
- [ ] `scripts/brain-migrate.sh` — one-off migration script. Confirm all brains migrated; then delete.
- [ ] `.zshrc` L123 — hardcodes `/home/christian/.opencode/bin` on all platforms. Guard with platform check.

---

## Phase G — Zellij residue
_Module disabled; config still being synced._

- [ ] `modules/symlinks/install.sh` — still symlinks `.config/zellij` even though `!zellij` in modules.conf. Remove symlink logic or guard with module check.

---

## Priority order

1. **B** (bugs first — cmux/herdr is a real shell startup bug)
2. **A** (quick wins, pure cleanup)
3. **D** (hook clarity)
4. **C** (lean-ctx excision)
5. **E** (fixture/doc alignment)
6. **F** + **G** (minor orphans)

---

_Estimated sessions to complete: 2-3. Safe to run phases A+B+D in one session._
