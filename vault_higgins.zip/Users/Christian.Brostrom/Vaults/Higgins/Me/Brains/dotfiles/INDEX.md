# Brain index: dotfiles
- current.md (7L) — - **brain CLI**: bare brain → status dashboard. brain load →
- gotchas.md (16L) — - **`~/.claude.json` mcpServers** bypasses dotfiles overlay 
- next.md (12L) — - Seed Keychain + enable pinentry-touchid (manual: `rbw unlo
- history/ — 10 session(s), last 2026-06-17-0145
- archive/ — 1 monthly file(s)
