## Context Bridge — dotfiles — 2026-06-28 14:58

### What we were doing
Editing Cursor keybindings to improve usability — primarily trying to get shortcuts working in the Cursor agent panel, and remapping cmd+p/f/u to better mnemonics.

### Decisions made
- **Removed `editorTextFocus` guard from `shift+cmd+h`** (format document): broadened to fire whenever a formatter is available, not just when editor textarea has focus. Kept `editorHasDocumentFormattingProvider && !editorReadonly`.
- **Removed `editorFocus` guard from `ctrl+shift+h`** (HookyQR.beautify): now fires globally.
- **Remapped cmd+p → command palette** (`workbench.action.showCommands`): was Quick Open (file-scoped). User wanted "all options" panel.
- **Remapped cmd+f → Quick Open** (`workbench.action.quickOpen`): freed up from Find (which doesn't work in agent mode anyway). F = Files mnemonic.
- **Remapped cmd+u → Find** (`actions.find`): Find moved here to free up cmd+f.

### Files touched
- `~/Library/Application Support/Cursor/User/keybindings.json` — all the above keybinding changes

### Open questions
- None — user accepted the outcome.

### Dead ends (don't repeat)
- **Cursor agent panel keybindings are NOT fixable via keybindings.json**: the agent panel is a webview that swallows all key events before they reach VS Code's keybinding layer. Only keys Cursor explicitly wires through work (cmd+p was one, cmd+f/u are not).
- **Double-tap chords (alt alt, shift shift, ctrl ctrl) don't work in agent panel**: same webview isolation issue. Chord detection never fires. No when-clause fix exists.
- **Broadening `when` guards on existing bindings does not help for agent panel**: confirmed by user testing.

### Exact next step
No follow-up needed — session was self-contained. If agent panel keybinding support improves in a future Cursor release, revisit.

### Context to reload
- Brain: `brain load` in dotfiles dir
- Key files: `~/Library/Application Support/Cursor/User/keybindings.json`
