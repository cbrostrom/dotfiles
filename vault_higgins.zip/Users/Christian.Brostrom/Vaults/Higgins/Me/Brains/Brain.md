---
created: 2026-06-15
area: meta
type: brain
tags: [vault, brain-system, hooks, memory]
repo: Brain
---

# Brain: Brain
_Updated: 2026-06-15_

## Current State
- Engram auto-hooks killed (sync-start, sync-stop, on-prompt, on-stop). Vault = sole memory.
- Hooks: 7 active (brain-load, effort-classifier, fast-mode-guard, brain-save-inject, git-push-guard, rtk-rewrite, statusline).
- Save commands: `.brain` only. Always append timestamped section. Slug resolution: explicit arg > active plan `repo:` > loaded brain > git basename > PWD.
- Skills: ~13 custom retained. ~15 cut (paseo×6, plannotator extras×3, session-wrap, switch, skills-lists×3, mcp-doctor, use-spark).

## Open Decisions
- WSL vault path unverified (`/mnt/c/Users/christian/Obsidian/Brain`) — confirm on next Windows session
- Sync mechanism still parked (LiveSync vs Syncthing)

## 2026-06-15 — Inbox fallback rule established

- Found rogue `Notes/` folder created by brainless session (brain hook misfired).
- Moved `cloudcli-auth-issue.md` → `Development/Homelab & VPS/`, added missing `area: dev` + `type: note` frontmatter. Removed empty `Notes/` dir.
- Rule locked: **all uncategorized content → `Inbox/`**. Never create new top-level folders.
- Gotcha added to Brain.md. CLAUDE.md "What NOT to do" updated with Inbox fallback rule.

## Gotchas
- Brain slug ≠ PWD. Always resolve to conceptual project. Ask when ambiguous (multiple plausible candidates).
- `brain-save-inject.sh` still needs Brains/ dir to exist — already true.
- Append is canonical for all brain writes. session-wrap removed — no replace vs append confusion.
- **No brain loaded = no vault map.** Session without brain hook misfiring will create rogue folders (e.g. `Notes/`). Rule: all uncategorized content goes to `Inbox/` — never create new top-level folders.

## Next Steps
- Verify new session: only brain-load fires at SessionStart (no engram output)
- settings.darwin.json: 2 manual edits still pending (Stop block + engram-on-prompt in UPS)
- settings.linux.json: SessionStart manual cleanup pending
- Skill dir deletions pending (HARD BLOCK — run manually)
- Fiskars dupe cleanup (15 min manual, `Work/AKQA/Shopify/Fiskars/_dupe-from-Projects-Fiskars/`)

---

## 2026-06-30 — Zero-token session capture pipeline built

- `vault-save.sh` (stop hook) now: reads stdin event JSON, extracts `workspace_roots[0]` for slug (was broken — used `$PWD` = `.cursor`), stores `transcript_path`, writes timestamped Inbox entry per stop.
- `summarizer.py` — recall's TF-IDF + TextRank vendored verbatim at `~/.cursor/hooks/`
- `parse_cursor_transcript.py` — Cursor JSONL adapter (role/message.content, Shell tool, thinking block skip)
- `session-summarize` — CLI + hook target. Replaces summary on each stop (not appends) so final transcript always wins. Called automatically from stop hook in background.
- `session-check` — inspect last event JSON + today's Inbox logs
- **Flow:** stop fires → Inbox marker + TF-IDF summary written (0 tokens) → librarian routes to Brains/ on demand (tokens, manual)
- **Gotcha:** stop fires per agent turn, not per conversation. Summary is always from latest (fullest) transcript — overwrite pattern fixes the stale-summary problem.
- **Open:** Obsidian vs pure git vault — reconsidering viewer layer (see Next Steps)

## Next Steps (updated 2026-06-30)
- Test `session-summarize` output quality after this session
- Decision pending: drop Obsidian as primary viewer in favour of pure git + any markdown viewer
- Verify WSL vault path (still pending from 2026-06-15)
- Fiskars dupe cleanup still pending

---

## 2026-06-15 — Hooks + skills streamline executed

- All 11 plan tasks done. 4 engram auto-hooks killed, 9 dead hook files deleted, ~14 dead skills removed.
- HARD BLOCK encountered mid-session: `settings*.json` and `.claude/skills/` protected by classifier. User completed those edits manually.
- CLAUDE.md updated: `.brain` slug resolution, dropped `.rem/.store/.mem/.bye/.wrap`, Engram = manual only.
- Two commits pushed: `f341247` + `7ee7518` on `cbrostrom/dotfiles master`.
- **Gotcha:** Self-Modification HARD BLOCK in auto mode blocks writes to `settings*.json` and `.claude/skills/`. Plan around it: give user exact commands, continue with unblocked tasks.

---

## 2026-06-15 — Brain confirm style + dot-command clarity

- `.brain` confirm now renders as `> 🧠 **Brain updated** → \`Brains/<slug>.md\`` — blockquote + bold pops in terminal.
- Dot-commands beat skills for simple triggers: no token overhead, no skill load. Brain append = 2 lines of CLAUDE.md, not a skill.
- Inbox drop alias still an option for out-of-Claude capture: `echo "thought" >> ~/Vaults/Brain/Inbox/$(date +%Y-%m-%d-%H%M).md`

---

## 2026-06-15 — Brain confirm flow finalised

- Pre-write: `> 🧠 **Brain updating** → \`Brains/<slug>.md\``
- Post-write: `> ✅ **Saved**`
- Note: both appear together (Claude renders after tool calls complete — no live animation)
- Dot-command beats skill for this use case — zero token overhead

---

## 2026-06-15 — Hook + skill streamline brainstorm

Brainstormed full audit of hooks + skills. Plan written: `Plans/Active/2026-06-15-hooks-skills-streamline.md`. Handing off to sonnet for execution.

**Decisions locked:**
- Engram auto-hooks killed (sync-start/stop, on-prompt, on-stop). Vault = sole memory. `mem_save`/`mem_search` remain manual tools.
- Save commands: `.brain` only. Always append timestamped section. Model sizes content from context. Kills `.rem` `.store` `.mem` `.bye` `.wrap` `.switch` + `session-wrap` + `switch` skills.
- Hooks: 13 → 7. Cut entroly-start, claude-settings-merge (SessionStart), all 4 engram hooks. Delete dead files (wrap-reminder, tuna-notify, claude-session-check, engram-clear + backup).
- Skills cut: paseo×6, plannotator extras×3 (keep review/annotate/last), session-wrap, switch, find-skills, skills.*.list×3, mcp-doctor, use-spark. ~15 total.
- SessionStart settings-merge handled by `dotfiles --update`, not needed per-session.

**Resulting hook map:** brain-load (SessionStart), effort-classifier + fast-mode-guard + brain-save-inject (UserPromptSubmit), git-push-guard + rtk-rewrite (PreToolUse:Bash), brain-save-inject (PreCompact).

**Gotcha update:** `session-wrap REPLACES, .brain APPENDS` distinction goes away once session-wrap deleted. Append is canonical for both mid-session and end-of-session.

**Next steps after exec:**
- Sonnet runs plan tasks 1-10
- Verify new session = only brain-load fires
- Commit dotfiles + Brain.md
- Update CLAUDE.md dot-command + memory-routing tables per plan task 6

## 2026-06-12 — stellar-shopify / Wedgwood audit

- Wedgwood.com videos self-hosted on Shopify CDN (`cdn/shop/videos/`) — no functional cookie consent needed for playback; confirmed via canvas pixel check
- RC `external-video.liquid` renders YouTube/Vimeo iframes unconditionally (no consent check); NAV11 "replace with message" behavior depends on OneTrust auto-blocking config, NOT theme code
- WCAG AA failures on wedgwood.com/en-int: "Poised Precision" h2 (2.63:1, needs 3:1) and "Read the story" 14px link (2.90:1, needs 4.5:1) — both in Helia/media-banner section with light gray image + 20% black overlay
