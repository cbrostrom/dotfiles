# Brain index: raycast-extensions
- current.md — fastest path to create and iterate on local Raycast extensions
- next.md — first extension checklist and high-value doc lookups
- gotchas.md — prerequisites, dev-loop, and permissions reminders
- history/ — session notes
- archive/ — older brain files
