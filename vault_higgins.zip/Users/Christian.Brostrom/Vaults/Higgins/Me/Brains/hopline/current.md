# Brain: hopline
_Updated: 2026-06-20_

## Current State

**Last commit:** `d9a6f72` (main) — HoldDragSensor innermost-wins fix + follow-up polish
**Build:** Tauri 2 + SolidJS + TypeScript + SQLite (tauri-plugin-sql)
**Quality:** aislop 92/100 · fallow 0 issues · tsc 0 errors

### What works
- Sidebar autohide + multi-monitor (cursor follows active monitor, Option locks cursor)
- Settings window (standalone modal, gear → `open_settings`)
- App icon mode: dock / status bar / both / neither
- Spaces (SpaceNav)
- **Persistent Tabs** (Phase 5a–5d complete):
  - Saved tabs with reset URL, dimming when closed, reopen on click
  - Folders (2-level nesting, CRUD, colors deferred), collapse state
  - Global pins + space pins (PinRow)
  - Drag-and-drop via `@thisbeyond/solid-dnd` + custom `HoldDragSensor`
    - Root reorder (tabs + folders)
    - Tab → folder (drop into)
    - Tab ← folder (drag out, innermost-wins sensor fix)
    - Folder highlight (`bg-accent/15 ring-1 ring-accent/40`) only for tab drags
  - Saved tabs hidden from Open Tabs list
  - Instant reactivity: `createMemo` + stable string primitive keys for `<For>`
  - `InlineInput` committed-guard prevents double-commit
  - `jiggle_cursor` Tauri command fixes WKWebView hover after drag
  - Click suppressor in sensor prevents accidental tab focus on drop
  - Ghost: `opacity-90 ring-2 ring-accent/60 shadow-xl z-50 rounded-md`
  - `tabAwareCollision`: tabs sort only vs tabs; folders don't shift during tab drags

### Architecture notes
- `persistentTabsState` (createStore) – tabs, folders, globalPins
- Stable `<For>` keys: "f-{id}" / "t-{id}" strings via `savedSectionKeys` createMemo
- Folder-child tabs use `createDraggable("it-{id}")` — NOT in SortableProvider
- `HoldDragSensor` guard: `if (holdTimer !== null) return` prevents outer draggable
  from overwriting inner drag when event bubbles (innermost wins)
- `jiggle_cursor` exposed as Tauri command; called from `handleSavedDragEnd`

## Conventions
- No `.unwrap()` in Rust — use `.expect("reason")` or `?`
- No magic numbers — constants or dynamic detection
- aislop >= 90, fallow 0 issues before commit
- Rust: `cargo clippy -- -D warnings` must pass
