# Next: hopline
_Updated: 2026-06-20_

## Candidate phases (priority order, discuss before starting)

### Phase 6 — Command Palette polish
- Already exists (`CommandPanelApp`), but needs to search persistent tabs + folders
- Quick-open a saved tab from keyboard
- Assign keyboard shortcut (currently hardcoded?)

### Phase 7 — Folder colours
- UI: colour swatch in folder context menu (rename → colour picker inline)
- Persist to `folders.color` (column already exists in DB schema)
- Apply tinted left border or folder icon tint in `FolderRow`

### Phase 8 — Onboarding / First-run polish
- Currently a basic `<Onboarding>` screen
- Step-by-step guide: install extension → create first space → save first tab
- Consider showing sample content so the sidebar doesn't look empty on first open

### Phase 9 — Tab metadata sync
- Title / favicon updates when Chrome tab navigates (currently only set on save)
- `TAB_UPDATED` message from extension → update `persistentTabsState.tabs` title/favicon

### Phase 10 — Keyboard navigation
- Arrow keys to move between items in the sidebar
- Enter to open; Delete/Backspace to remove
- Focus ring visible

### Phase 11 — Spaces management UI
- Rename, reorder, delete spaces from sidebar (right-click SpaceNav)
- Space colour / emoji icon

### Phase 12 — Export / Import
- Export spaces + tabs as JSON
- Import to restore (useful for backup or moving between machines)

---
## Deferred / won't do soon
- Profile support (deferred by user)
- Deep folder nesting (max 2 levels enforced, revisit if needed)
- Folder drag-and-drop reorder (folders reorder via context menu for now)
