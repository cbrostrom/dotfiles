# Brain: huskr
_Updated: 2026-06-30_

## Current State

**P0 complete. P1 complete. P2 (sync indicator) done. P3 next.**

Branch: `main`. All work merged and pushed.

### What's done (P0–P2)

- Notes fully excised, Butler lazy-mode, WAL pragmas, `SERVE_WEB=false`
- **Tauri shell complete** — tray, hotkey, hide-to-tray, quick-capture
- **Sidecar complete** — Rust spawns sidecar, reads `HUSKR_READY`, stores `{port, token}` in managed state, exposes via `get_sidecar_config` command
- **Custom migration runner** — `sidecar-migrate.ts` bundles all 31 SQL files, uses `sqlite.exec()` for multi-statement support
- **Frontend wired** — `platform.ts` auto-inits sidecar at module load, `onSidecarReady()` callback, `api.ts`/`websocket.ts` use sidecar URL + launch-token header
- **Connection status** — `connectionStatus` signal (online/offline/connecting), dot indicator in Tauri title bar
- **Settings → Connection** — shows active mode (Local sidecar / Remote / Dev proxy)
- **Login fix** — `showServerSetup` re-evaluates after sidecar init settles

### Next: P3 — Sync Engine

Plan: `p3-sync-plan.md` — 5 chunks (3a→3b+3c→3d→3e), ~60k tokens total.
Sidecar encryption key (Step 5 from old plan) deferred to after sync works.

### Key decisions logged in gotchas.md

- Supabase rejected as sync layer (too heavy, wrong fit)
- SQLCipher passphrase loss is destructive

## Conventions

- Conventional Commits, lowercase, no period, verb-first. See `.cursorrules`.
- Notes feature removed. `archive/huskr-with-notes` branch is frozen.
- Local-first by default; cloud sync (P2) is opt-in. Server is arbiter when online, LWW per field.
- Sidecar IPC: TCP localhost + `X-Huskr-Launch-Token` header (per-launch UUID from Rust).
- Auto-update: stable channel only.
- Multi-user per instance: confirmed via spaces + memberships.
- Butler lazy-mode: on-demand only, never always-on.
- Personal tool, possibly OSS later. No billing.
- P3 progress: 3a (schema) + 3b/3c (sync endpoints) complete. Migration 0031_add_sync_columns.sql adds synced_at/sync_origin to todos/lists/folders/tags + sync_config table. GET/POST /sync mounted at /sync and /api/sync. 3d (sidecar sync engine) is next — push loop (unsynced rows → POST /sync remote), pull loop (GET /sync remote → LWW apply), triggers on startup/WS reconnect/30s interval.
