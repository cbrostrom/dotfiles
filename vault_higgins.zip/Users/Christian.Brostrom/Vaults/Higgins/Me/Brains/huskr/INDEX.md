# Brain index: huskr
- current.md (41L) — _Updated: 2026-06-30_
- gotchas.md (31L) — - **Bun does not run on iOS.** Tauri iOS (P3) cannot use the
- next.md (51L) — All items complete. See `current.md`.
- history/ — 2 session(s), last 2026-06-30-14-03
