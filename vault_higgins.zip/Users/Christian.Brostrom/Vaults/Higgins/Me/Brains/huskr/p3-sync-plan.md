# P3 — Sync Engine Plan

_Created: 2026-06-30_

## Architecture

Server-authoritative, LWW on `updated_at`, server is tiebreaker on equal timestamps.
Sidecar is a local SQLite replica — pushes writes, pulls deltas. PWA goes direct to server.
Soft deletes (`deleted_at`) already exist — tombstones propagate for free.

## Chunks (execute in order)

### 3a — Schema migration (~8k tokens)

**Files:** `packages/db/src/schema.ts`, `apps/api/src/lib/sidecar-migrate.ts`

Add to `todos`, `folders`, `lists`, `tags` tables:
- `synced_at` INTEGER (epoch ms, nullable) — NULL means unsynced
- `sync_origin` TEXT (nullable) — device ID that last wrote the row

New table `sync_config`:
- `id` TEXT PRIMARY KEY
- `last_sync_ts` INTEGER NOT NULL DEFAULT 0 — global pull watermark
- `remote_url` TEXT — stored remote server URL
- `remote_api_key` TEXT — stored API key for sidecar→remote auth

After schema edit: `bun run db:generate`, then update `sidecar-migrate.ts` to import the new `.sql` file.

**Done when:** `bun run typecheck` passes, migration applies on fresh DB.

---

### 3b — GET /sync endpoint (~12k tokens)

**Files:** `apps/api/src/routes/sync.ts` (new), `apps/api/src/index.ts` (mount router)

`GET /sync?since=<epoch_ms>&types=todos,lists,folders,tags&limit=500`

Returns:
```json
{
  "changes": [
    { "type": "todo", "id": "...", "data": {...}, "updated_at": 1234, "deleted_at": null },
    ...
  ],
  "cursor": "next_updated_at_value_or_null",
  "has_more": false
}
```

Query: `WHERE updated_at > ? OR deleted_at > ?` across requested types. Order by `updated_at ASC`, paginate via cursor.

Auth: standard session middleware (existing `authMiddleware`).

**Done when:** `curl` returns correct deltas from a seeded DB.

---

### 3c — POST /sync endpoint (~15k tokens)

**Files:** `apps/api/src/routes/sync.ts` (extend)

`POST /sync` body:
```json
{
  "changes": [
    { "type": "todo", "action": "upsert", "id": "...", "data": {...}, "updated_at": 1234 },
    { "type": "todo", "action": "delete", "id": "...", "updated_at": 1234 }
  ],
  "origin": "device_id"
}
```

Per row: if incoming `updated_at` > existing `updated_at`, apply. Otherwise skip.
Set `sync_origin` to the incoming `origin`.
Fire WebSocket broadcast for each applied change (reuse existing broadcast helpers).

Returns:
```json
{
  "results": [
    { "id": "...", "status": "applied" },
    { "id": "...", "status": "rejected", "server_updated_at": 1235 }
  ]
}
```

**Done when:** POST with mixed old/new timestamps correctly applies only newer ones.

---

### 3d — Sidecar sync engine (~18k tokens)

**Files:** `apps/api/src/lib/sync-engine.ts` (new), `apps/api/src/index.ts` (start engine if sidecar)

Module: `SyncEngine` class or functional module.

Config: reads `remote_url` and `remote_api_key` from local `sync_config` table.

**Push loop:**
1. Query local DB: rows where `synced_at IS NULL` (across all entity tables)
2. `POST /sync` to remote with those rows
3. On success: set `synced_at = Date.now()` for applied rows
4. On network error: skip, retry next cycle

**Pull loop:**
1. Read `last_sync_ts` from `sync_config`
2. `GET /sync?since=<last_sync_ts>` from remote (paginate if `has_more`)
3. For each incoming row: LWW against local — apply if incoming `updated_at` > local
4. Update `last_sync_ts` to highest seen `updated_at`

**Triggers:** on startup, on WS reconnect, every 30s interval.

**Done when:** two instances (sidecar + remote) stay in sync after creates/edits/deletes on both sides.

---

### 3e — Frontend sync UX (~6k tokens)

**Files:** `apps/web/src/lib/appContext.tsx`, `apps/web/src/components/layout/AppLayout.tsx`

- Extend `connectionStatus` to include `"syncing"` state
- Show "Syncing…" with pulsing dot during active push/pull
- "Pulling data from server…" banner on first remote connection (initial sync)
- Suppress error toasts when `connectionStatus === "offline"` — queue silently
- After sync completes, show brief "Synced" confirmation then hide

**Done when:** status dot reflects all 4 states correctly in Tauri app.

## Dependencies

```
3a → 3b + 3c (parallel) → 3d → 3e
```

## Key files for context

Before starting any chunk, read:
- `packages/db/src/schema.ts` — current schema
- `apps/api/src/index.ts` — router mounts + sidecar mode
- `apps/api/src/lib/websocket.ts` — broadcast helpers
- `apps/web/src/lib/platform.ts` — sidecar config getters
- `apps/web/src/lib/appContext.tsx` — connectionStatus signal (lines 130-145)
