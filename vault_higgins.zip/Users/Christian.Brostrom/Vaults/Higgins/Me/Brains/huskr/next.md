# Next: huskr

## P0 ✅ — Notes excision + backend slim + Butler lazy-mode

All items complete. See `current.md`.

---

## P1 — Tauri desktop shell (in progress)

### Done
- [x] Tauri scaffolded, `bun run dev` starts everything
- [x] Connected mode: Settings → Connection, first-run server URL gate on login
- [x] Tray icon + hide-to-tray
- [x] Global hotkey `⌘⇧Space` + quick-capture floating window
- [x] Sidecar step 1: API sidecar-ready (HUSKR_SIDECAR, HUSKR_LAUNCH_TOKEN, HUSKR_READY signal)
- [x] Sidecar step 2: `bun run build:sidecar` → `src-tauri/binaries/huskr-api-<triple>`

### Remaining (paused at step 3 — meaty, token-expensive)
- [ ] **Step 3** — Rust: spawn sidecar, read port from stdout, expose `get_sidecar_config` command
  - Add `tauri-plugin-shell` to Cargo.toml + capabilities
  - Register `SidecarState { port: u16, token: String }` in app state
  - In `setup()`: generate UUID token → spawn with env vars → read stdout until `HUSKR_READY port=N`
  - Kill child on `RunEvent::Exit`
  - Expose `#[tauri::command] get_sidecar_config() → { url, token }`
- [ ] **Step 4** — Frontend: mode awareness
  - `platform.ts`: `getSidecarConfig()` calls `invoke("get_sidecar_config")`
  - `api.ts`: if sidecar → use `http://127.0.0.1:{port}`, inject `X-Huskr-Launch-Token` header
  - `websocket.ts`: if sidecar → use `ws://127.0.0.1:{port}`
  - Settings → Connection: Local / Remote toggle (store in `huskr_mode` localStorage)
- [ ] **Step 5** — Encryption key persistence
  - Rust: check `app_data_dir()/.huskr_enc_key`; if missing, generate 32 random bytes → hex → write
  - Pass to sidecar as `ENCRYPTION_KEY` env var

### Other P1 items
- [ ] Auto-update (stable channel only) — `tauri-plugin-updater`
- [ ] Code-signing stubs (macOS notarization, Windows Authenticode)
- [ ] GitHub Actions build + release workflow

---

## P2 — Sync delta + connectors + grocery beachhead

Full spec: `pivot-tauri.md`.

---

## P3 — Mobile + calendar

Full spec: `pivot-tauri.md`.
- P3 chunk 3d: write apps/api/src/lib/sync-engine.ts — SyncEngine class with push loop (unsynced rows → POST /sync remote), pull loop (GET /sync remote → LWW local upsert via Drizzle), reads sync_config table for remote_url + remote_api_key, triggers on startup + WS reconnect + 30s interval. Gate on HUSKR_SIDECAR=true.
