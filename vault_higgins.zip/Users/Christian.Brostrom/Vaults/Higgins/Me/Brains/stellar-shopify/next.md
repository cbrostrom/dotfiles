# Next: stellar-shopify

## Fix schema alias imports (repo: stellar-shopify) — DONE by coworker, pending package bump

> stellar-shopify migration is complete and verified. Only blocker: bump to @akqa-denmark/shopify-theme-build@0.1.1 once published.

## Fix schema alias imports (repo: stellar-shopify) — archive

**Context**: `@akqa-denmark/shopify-theme-build` v0.1.x is extracted and published.
When `shopify-build prepare` runs, the orchestrator loads schema files via `jiti`
but Node can't resolve `@/` and `@shared/` tsconfig aliases at runtime.

**Fix**: migrate all schema files from alias imports to relative imports.
Do NOT patch the package — fix the consumer (stellar-shopify).

### Steps

1. **In `akqa-denmark-shopify-theme-build` repo** (do first):
   - Add `export { snakifyString } from './utils/strings.js';` to `src/index.ts`
   - Rebuild and publish a new patch (`npm run release`)

2. **Write codemod** `scripts/migrate-aliases.ts` in the build package repo:
   - Globs `stores/*/src/schemas/**/*.ts` given a `--root` arg
   - `@/schemas/*` → relative path (all schema files live under `<store>/src/schemas/`)
   - `@shared/scripts/utils/snakifyString` → `@akqa-denmark/shopify-theme-build`
   - Runs in-place, prints summary

3. **In stellar-shopify**:
   - Run `npx tsx <path>/scripts/migrate-aliases.ts --root .`
   - Run `shopify-build prepare` to verify
   - Commit: `chore: replace alias imports with relative paths in schema files`

### Scope
~1,347 files across 8 stores. Distinct alias patterns:
- `@/schemas/settings` (barrel)
- `@/schemas/settings/paragraph`
- `@/schemas/section-blocks` (barrel)
- `@/schemas/section-blocks/collection-teaser`
- `@/schemas/section-blocks/teaser-card`
- `@/schemas/types/schemaTypes` (type-only, convert anyway)
- `@shared/scripts/utils/snakifyString` → package import

### Risk
`import type` from `@/schemas/types/schemaTypes` don't break at runtime (esbuild strips them)
but convert for consistency. Barrel imports require `index.ts` to exist — pre-existing requirement.

_Captured: 2026-06-23_

**Full plan**: `alias-to-relative-migration.plan.md` (same folder)

