---
created: 2024-01-01
type: reference
project: Grønnebakken
tags:
  - family
  - lily
---

# Grønnebakken Bestyrelse 2024-25

| Navn | Telefon | Barn |
|------|---------|------|
| Helle Rosendahl | 22409540 | Mor til Carl på **Sommerfuglestuen 0-3 år** |
| Signe Ammitzbøll Bæch Frandsen | 51946249 | Mor til Knud på **Påfuglestuen 3-6 år** |
| Christian Kjærulff Brostrøm | 31212209 | Far til Lily fra **Uglestuen 0-3 år** |
| Jesper Frimodt | 30160307 | Far til Theodor på **Påfuglestuen 3-6 år** |
| Anne Kirstine Eriksen | 27286213 | Mor til Martha på **Svalerne 3-6 år** |
| Martin Madsen | 22326979 | Far til Leo fra **Nattergalestuen 3-6 år** |
| Heidrun Filtenborg | 20205667 | Mor til Ragnar på **Sommerfuglestuen 0-3 år** |
| Louise Susan Wendt Arafa | 20409872 | Mor til Caroline Mathilde på **Sommerfuglestuen 0-3 år** |
