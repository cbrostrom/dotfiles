---
created: 2024-06-25
type: journal
tags:
  - family
  - lily
---

# Barselsdagbog - Lily 👶

## 25. juni 2024

Vi havde første barsels-dag og hyggede os rigtigt meget i løbet af dagen. Mor fik lov at sove lidt mere i dag og det var tiltrængt 🙂

Dagen gik relativt hurtigt og vi fik leget en masse og da mor var med var ALT bare lidt sjovere 🙂

Mor og dig faldt i søvn sammen kl. 19:30 og det var bare super hyggeligt. Far fik lov at spille lidt computer.

---

## 26. juni 2024

Vi hyggede med en god masse leg imens mor fik sig en god efter-nat skraber 🙂 Du er en vildbasse om natten og det koster søvn - men det ændrer ikke på at dit smil om morgenen er fantastisk. 

Også selvom det nogen gange føles som om du gør det med vilje og siger "jeg har bare mere energi end jer... lala la la la laalaa" 🙂

Du ligger og sover imens jeg skriver det her lige nu - det er okay solrigt - men ikke helt varmt endnu.

---

*Klar til Barsel #2* 🤞

