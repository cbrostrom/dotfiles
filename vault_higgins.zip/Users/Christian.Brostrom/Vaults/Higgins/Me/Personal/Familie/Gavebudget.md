---
created: 2024-01-01
type: reference
tags:
  - family
  - reference
---

# Gavebudget - Stark Brostrøm

## Regler

### Voksne (søskende)
- Fødselsdagsgaver: **Kun hvis man er inviteret til noget** (budget 200 kr.)
- Julegaver: **Ingen** - ligemeget om vi holder sammen eller ej

### Børn
- Fødselsdagsgaver: **Kun hvis de holder fødselsdag og man er inviteret** (200 kr.)
- Julegaver: **Ja, hvert år** (200 kr.)

