---
created: 2024-01-01
type: reference
tags:
  - family
  - reference
---

# Huskeliste - Far

## Bleer

### 2. hylde fra døren
- [ ] #recurring Husk at fylde op når der er under 6 tilbage

