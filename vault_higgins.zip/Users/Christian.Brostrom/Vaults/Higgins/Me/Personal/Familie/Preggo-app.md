Lav en app som viser størrelse osv - er hyggeligt. #family 
/date