---
tags: [gave, smykke, halskæde, fødselsdagsdag]
type: idea
created: 2026-06-27
---

# Halskæde Pendant — Fødselsdagsgave

## Koncept: "Celestial Four"

Et åbent cirkel-pendant i 18k gult guld — ingen bagplade, ingen fylde. Formen opstår af selve cirklen og de fine indre linjer, der holder de fire stjernetegn på plads. Resultatet er luftigt, delikat og feminint.

---

## Design

### Form
- **Ydre ring:** Åben cirkel i 18k guld, ~18 mm i diameter — nogenlunde på størrelse med en stor skjorteknap
- **Ingen bagplade:** Pendanten består udelukkende af ringen og fine indre guldtråde (~0,6–0,8 mm) der forbinder de fire symboler
- **Indre linjer:** Tynde guldtråde danner en svagt roteret firkant inde i cirklen og skaber geometrisk struktur uden bulk — som et stjernekort eller en astronomisk tegning

### Stjernetegn
De fire symboler er placeret som kompasspunkter inden i cirklen, forbundet af de indre linjer:

| Position | Tegn | Diamant |
|----------|------|---------|
| 12 o'clock | ♌ Leo | ✦ Én diamant |
| 3 o'clock | ♋ Cancer | ✦ Én diamant |
| 6 o'clock | ♍ Virgo | — |
| 9 o'clock | ♌ Leo | — |

Symbolerne er udført som miniature linjeindgravering direkte i guldtråden — enkle og raffinerede.

### Diamanter
- **2 stk.** brilliantslibede diamanter, hver ca. 2 mm / 0,03 ct (G-farve, VS klarhed)
- Monteret i fine bezels (kram-fatninger) langs linjerne lige ved siden af henholdsvis **Leo (12 o'clock)** og **Cancer (3 o'clock)**
- De to diamanter sidder i øverste højre kvadrant af pendanten — tæt på hinanden — og giver et subtilt glimmer der samler lyset

### Resultat
Intet fylder, intet overvejer. De to diamanter sidder som to stjerner der "hører til" Leo og Cancer, mens Virgo og den anden Leo er præsent men ubesmykket — en bevidst balance.

---

## Materialer

| Element | Spec |
|---------|------|
| Metal | 18k gult guld |
| Diamanter | 2x brilliantslibede, ~0,03 ct / 2 mm, G/VS |
| Fatning | Bezel (kram-fatning) |
| Kæde | Delikat 18k guld boks- eller ankerkæde, 40–45 cm |
| Pendant størrelse | ~18 mm diameter |

---

## Produktion

Dette design kræver en guldsmed med erfaring i **filigraneteknik** eller wire-work smykker. Nøgleord til guldsmed:

- Åbent wire-pendant (ingen bagplade)
- Fint geometrisk indre framework
- Micro-bezel diamantfattninger
- Stjernetegn som linjeindgravering eller øverst lag wire

### Mulige ruter
- **Skræddersyet guldsmed** — bed om et CAD-udkast (3D-model) før produktion for at godkende proportioneringen
- **Etsy / Artisan smykkemager** — søg: "custom zodiac wire pendant 18k" eller "constellation circle necklace gold"
- **Lokal guldsmede** med CAD-kapacitet (anbefalet for kontrol over finish)

---

## Noter
- Pendanten bæres bedst på en meget tynd kæde — den fine karakter drukner på en tung kæde
- Overvej at bede guldsmeden om et voks- eller harpiks-print til godkendelse af størrelse, inden der støbes i guld
- Designet er skalerbart: 16 mm = meget diskret, 20 mm = lidt mere present

![[Pasted image 20260627132024.png]]