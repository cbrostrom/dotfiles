---
created: 2024-01-01
type: reference
tags:
  - home
  - reference
---

# Græsplæne vedligehold

## Årlig vedligeholdelse

1. Klip plænen helt kort
2. Skab luft i bunden - med en græsrive (eller plænelufter - kan lejes i havecenter)
3. Luft plænen på langs og på tværs
4. Fjern ALT løst materiale fra plænen - der er mere end du tror
5. Efterså med frø på langs og på tværs
6. Spred gødning

---

> 💡 **Husk:** Efterså og gød én gang om året

