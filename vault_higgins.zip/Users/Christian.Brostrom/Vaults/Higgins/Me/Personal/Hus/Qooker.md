---
created: 2024-01-01
type: reference
tags:
  - home
  - reference
---

# Qooker

## Produktinfo

| Serienummer | Købsdato | Garanti udløb |
|-------------|----------|---------------|
| | | |

## Vedligeholdelse

- [ ] #recurring Afkalk filter hver 3. måned

