---
created: 2024-01-01
type: reference
tags:
  - home
  - reference
---

# Støvsuger

## Produktinfo

| Serienummer | Købsdato | Garanti udløb |
|-------------|----------|---------------|
| | | |

## Vedligeholdelse

- [ ] #recurring Rens filter månedligt
- [ ] #recurring Tøm beholder efter brug

