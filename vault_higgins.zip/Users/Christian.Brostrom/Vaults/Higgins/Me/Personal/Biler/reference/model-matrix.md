---
created: 2026-06-21
area: personal
type: reference
tags: [bil, elbil, vw, skoda, audi, volvo, model-matrix]
status: active
topic: ev-car-purchase
---

# EV model matrix — VW, Skoda, Audi, Volvo

For trip: **Dyssegård → Boes (~300 km), no charging, any weather.**

WLTP thresholds: **≥ 580 km** safe · **≥ 550 km** minimum (RWD large battery).

## Verdict legend

| Verdict | Meaning for this trip |
|---|---|
| ✅ **Buy** | Comfortable margin in worst-case planning |
| ⚠️ **Borderline** | Usually works; tight on extreme frost + 130 km/t + degraded battery |
| ❌ **Skip** | Insufficient for stated requirement from Dyssegård |

---

## Volkswagen

| Model | Variant / battery | WLTP (typical) | Verdict | Notes |
|---|---|---|---|---|
| **ID.7** | Pro / Pro S / Tourer | 584–690 km | ✅ | Best VW choice for this requirement |
| **ID.7 Tourer** | Large battery RWD | 584–689 km | ✅ | Extra boot; same range class |
| ID.4 | 77 kWh RWD (Style/Move/GTX) | 525–558 km | ⚠️ | Max ID.4; OK most days, not "any condition" guaranteed |
| ID.4 | Pure / 62 kWh | ~431 km | ❌ | |
| ID.5 | Same platform as ID.4 | Same as ID.4 equiv. | ⚠️/❌ | Match to ID.4 battery size |
| ID.3 | Long range | ~420–550 km | ⚠️/❌ | Usually too short unless highest WLTP + RWD |

**VW rule:** Prefer **ID.7** if hard no-charge requirement. ID.4 77 kWh only if accepting occasional winter anxiety.

---

## Skoda

| Model | Variant / battery | WLTP (typical) | Verdict | Notes |
|---|---|---|---|---|
| **Enyaq 85** | RWD | 570–575 km | ⚠️ | Best Skoda value; Mobilsiden winter est. ~403 km real |
| Enyaq 85 Sportline | RWD | ~570 km | ⚠️ | Same range class |
| Enyaq 85x | AWD | ~538–542 km | ❌/⚠️ | AWD costs range; below safe threshold |
| Enyaq 60 | 62 kWh | ~413–430 km | ❌ | |
| Enyaq Coupé | Match battery to above | Same logic | ⚠️/❌ | Slightly different aero; check WLTP in ad |

**Skoda rule:** **Enyaq 85 RWD only.** Skip 60 and AWD 85x for this trip requirement.

---

## Audi

| Model | Variant / battery | WLTP (typical) | Verdict | Notes |
|---|---|---|---|---|
| **Q6 e-tron** | RWD / long range | 600–668 km | ✅ | PPE platform; best Audi for distance |
| Q6 e-tron | quattro / SQ6 | 535–560 km | ⚠️/❌ | Check exact WLTP — many quattro trims too short |
| Q4 e-tron | 55 / Sportback 55 | 550–592 km | ⚠️ | Top of Q4 range; borderline for "any condition" |
| Q4 e-tron | 40 / 45 | ~440–520 km | ❌ | |
| Q8 e-tron | Large battery | Often 500+ km | ⚠️/✅ | Check variant; heavy car |
| e-tron GT | — | Varies | ⚠️ | Sport saloon; verify WLTP per car |

**Audi rule:** **Q6 e-tron RWD** for safety. Q4 55 is ceiling of borderline tier.

---

## Volvo

| Model | Variant / battery | WLTP (typical) | Verdict | Notes |
|---|---|---|---|---|
| **EX90** | Large battery | ~610 km | ✅ | Overkill on range; large/expensive |
| EX40 / EC40 | Single Motor Extended Range | 570–576 km | ⚠️ | RWD extended only |
| EX40 / EC40 | Twin Motor AWD | Lower | ❌ | |
| **EX30** | All variants | 339–475 km | ❌ | Too short |
| XC40 Recharge | Older short-range | ~418–426 km | ❌ | |
| XC40 Recharge | Extended range | ~576 km | ⚠️ | Same as EX40 class |

**Volvo rule:** **EX90** for comfort margin; **EX40/EC40 Extended Range RWD** as value borderline option. Skip EX30.

---

## Cross-brand shopping priority

For **hard no-charge / any weather** from Dyssegård:

1. VW ID.7 / ID.7 Tourer
2. Audi Q6 e-tron (RWD, long range)
3. Volvo EX90

For **best value, usually works**:

4. Skoda Enyaq 85 RWD
5. VW ID.4 77 kWh RWD
6. Audi Q4 55
7. Volvo EX40 Extended Range RWD

---

## Agent: evaluating a specific listing

```yaml
checklist:
  - wltp_km: ">= 580 preferred, >= 550 absolute minimum"
  - drivetrain: "RWD preferred"
  - battery: "largest pack in model line"
  - brands_allowed: [VW, Skoda, Audi, Volvo]
  - verdict: "lookup model-matrix by model + variant"
  - if_borderline: "flag winter risk; suggest ID.7/Q6/EX90 if budget allows"
  - if_used: "request or infer SoH; downgrade effective range if < 95%"
```
