---
created: 2026-06-21
area: personal
type: reference
tags: [bil, elbil, agent-bootstrap, ev-car-purchase]
status: active
topic: ev-car-purchase
---

# EV car purchase — agent index

> **Bootstrap order for any session or agent:** read files in this order, then act.

| # | File | Purpose |
|---|---|---|
| 1 | [[current]] | Live requirements, decisions, open questions |
| 2 | [[reference/range-requirements]] | Trip math, WLTP filters, worst-case rules |
| 3 | [[reference/model-matrix]] | VW / Skoda / Audi / Volvo — buy / borderline / skip |

## One-line context

Christian & Sofie are shopping for a **used EV**. Hard requirement: drive **Dyssegård → Boes (Jutland)** on one charge in **any weather**, no en-route charging. Preferred brands: **VW, Skoda, Audi, Volvo**.

## Agent instructions

When helping with this topic:

1. **Load context** — read `current.md` first; it overrides stale chat assumptions.
2. **Apply filters** — use locked numbers from `reference/range-requirements.md`; do not re-derive from scratch unless inputs change.
3. **Brand scope** — only recommend models in `reference/model-matrix.md` unless user expands brands.
4. **Listing field** — in Danish ads, filter on **Rækkevidde (WLTP)**, not trim names like "Long Range".
5. **Cite vault** — surface facts with path, e.g. `Personal/Biler/reference/range-requirements.md`.
6. **Update state** — after new decisions or shortlists, append to `current.md` with dated section; do not overwrite locked requirements without explicit user confirmation.

## Related (future)

- [[../../Ideas/Car Buyer Agent/README|Car Buyer Agent]] — planned helper agent spec

## Grep hooks

```
topic: ev-car-purchase
agent_entry: Personal/Biler/INDEX.md
tags: bil, elbil, vw, skoda, audi, volvo
```
