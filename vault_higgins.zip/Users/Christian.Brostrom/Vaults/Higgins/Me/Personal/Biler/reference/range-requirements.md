---
created: 2026-06-21
area: personal
type: reference
tags: [bil, elbil, range, wltp, boes, dyssegaard]
status: active
topic: ev-car-purchase
---

# EV range requirements — Dyssegård → Boes

Durable reference for trip planning and listing filters. **Do not guess these numbers in future sessions — use this file.**

## Trip

| Point | Detail |
|---|---|
| Origin | Dyssegårdsvej 59A, 2870 Dyssegård |
| Destination | Boes, Dover sogn, Skanderborg kommune (near Alken, ~20 min from Aarhus) |
| Typical route | Motorvej via E45 / Storebælt corridor → Skanderborg → local roads to Boes |
| One-way distance | **~300 km** (289 km to Skanderborg + ~10–15 km last leg) |
| Driving profile | Mostly motorway 110–130 km/t |

## What "reach" means in ads

Danish used-car sites list **Rækkevidde (WLTP)** — not "reach" as a separate metric.

| In ad | Meaning |
|---|---|
| Rækkevidde / WLTP | Official lab range — **the number to filter on** |
| "Long Range" / "85" / "77 kWh" | Trim or battery hint — **always verify WLTP number** |
| Real range / sommer / vinter | Sometimes dealer estimate — treat as guidance, not filter |

## WLTP vs real world

WLTP = mixed driving, ~23 °C, ~46.5 km/t average. Motorway winter is much worse.

| Condition | Usable range vs WLTP | WLTP needed for 300 km |
|---|---|---|
| Summer motorway | ~70% | ~430 km |
| Normal winter motorway | ~60–65% | ~460–500 km |
| **Worst case (user requirement)** | ~50–55% | **~550–600 km** |

### Conservative formulas

```
WLTP_min = trip_km × 2          # "any condition" one-way, with buffer
WLTP_min = trip_km ÷ 0.55       # alternative, slightly less conservative
```

For **300 km one-way**:

| Rule | WLTP filter |
|---|---|
| **Default (recommended)** | **≥ 580 km** |
| Absolute minimum | **≥ 550 km** (RWD + large battery only) |

For **round trip without charging** (~600 km usable in worst case):

```
WLTP_min ≈ 600 ÷ 0.55 ≈ 1090 km   # effectively impractical on used market
```

→ Plan to **charge at destination** or buy ID.7 / Q6 / EX90 class and still treat round-trip as tight in extreme frost.

## Used-car adjustments

| Factor | Impact |
|---|---|
| Battery SoH 90% | Effective WLTP × 0.90 |
| AWD vs RWD | Typically −30 to −50 km WLTP |
| No varmepumpe | Worse winter range |
| Start at 100% | Assume yes when leaving home |
| Arrival buffer | Do not plan to arrive at 0% — filters above include margin |

## External benchmarks (2026)

- Mobilsiden / Danish guides: winter often **25–40%** below WLTP on motorway
- FDM / NAF extreme winter test (2026): average **~38%** below WLTP; some models **~46%**
- Skoda Enyaq 85 example (Mobilsiden): 575 km WLTP → ~403 km estimated winter effective (still > 300 km, but less buffer than ID.7)

## Listing search checklist

1. Filter **Rækkevidde ≥ 580 km** (relax to 550 if needed)
2. Confirm **RWD** unless AWD required
3. Confirm **largest battery** variant (Enyaq 85, ID.4 77 kWh, Q4 55, etc.)
4. Check **varmepumpe** on older Volvo/Audi if possible
5. Ask seller / get report for **battery SoH** on used cars
6. Ignore trim marketing — trust the **WLTP integer in the ad**

## Sources

- Session research 2026-06-21 (Cursor)
- afstande.com Gentofte–Skanderborg (~289 km)
- Mobilsiden.dk, FDM, Hvilkenbil.dk winter range guidance
- skanderborgleksikon.dk — Boes location
