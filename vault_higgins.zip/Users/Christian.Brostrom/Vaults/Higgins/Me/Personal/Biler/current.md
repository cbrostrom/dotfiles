---
created: 2026-06-21
area: personal
type: brain
tags: [bil, elbil, ev-car-purchase]
status: active
topic: ev-car-purchase
---

# EV car purchase — current state
_Updated: 2026-06-21_

## Status

**Phase:** Research complete → ready to search listings / evaluate specific cars.

## Locked requirements

| Key | Value |
|---|---|
| Home base | Dyssegårdsvej 59A, 2870 Dyssegård (Gentofte area) |
| Destination | Boes, Skanderborg kommune (near Alken, Søhøjlandet) |
| Trip type | One-way, no en-route charging |
| Weather | Must work in **any** condition (incl. winter motorway) |
| Car type | Used **electric** (not PHEV unless user changes mind) |
| Brands | VW, Skoda, Audi, Volvo only |

## Locked filters (Bilbasen / Biltorvet)

| Filter | Value |
|---|---|
| **Rækkevidde (WLTP) — default** | **≥ 580 km** |
| **Rækkevidde (WLTP) — minimum** | **≥ 550 km** (RWD + large battery only; accept small winter risk) |
| Drivetrain preference | RWD over AWD (range) unless 4WD needed |
| Battery | Largest pack in model line |

## Trip distance (locked)

| Leg | km |
|---|---|
| Dyssegård → Skanderborg (motorvej) | ~289 |
| Skanderborg → Boes / Alken | ~10–15 |
| **Total one-way** | **~300 km** |
| Round trip without charging | ~600 km usable (very few used EVs; plan to charge at destination or accept ID.7-class car) |

## Shortlist tier (by range safety)

See [[reference/model-matrix]] for full table.

- **Safe:** VW ID.7 / ID.7 Tourer, Audi Q6 e-tron (RWD long range), Volvo EX90
- **Usually OK:** Skoda Enyaq 85 RWD, VW ID.4 77 kWh RWD, Audi Q4 55, Volvo EX40 Extended Range RWD
- **Skip:** Enyaq 60, ID.4 Pure, Q4 40/45, EX30, old XC40 short-range

## Open decisions

- [ ] Budget ceiling (DKK)
- [ ] Need AWD / anhængertræk?
- [ ] Round-trip same day without charging, or OK to charge at Boes?
- [ ] Max age / km on used market
- [ ] Build Car Buyer Agent? (see [[../../Ideas/Car Buyer Agent/README]])

## Next steps

1. Search Bilbasen with WLTP ≥ 580 km + brand filter
2. If too few results, relax to 550 km and restrict to RWD large-battery variants only
3. On specific listings: verify exact WLTP in ad, battery kWh, RWD vs AWD, varmepumpe, SoH if available

---

## 2026-06-21 — Initial research session

Research captured from Cursor chat. Requirements and range math stored in `reference/`. User clarified Boes is a village near Alken (not a dealership). Home address confirmed as Dyssegård.
