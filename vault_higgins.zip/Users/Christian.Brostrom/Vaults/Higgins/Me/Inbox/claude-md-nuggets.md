---
created: 2026-06-15
updated: 2026-06-15
area: dev
type: inbox
tags: [claude, claude-md, nuggets, optimisation]
status: active
---

# CLAUDE.md improvement nuggets

Running list. Tiny ideas, bi-thoughts, convention proposals. Picked up on next CLAUDE.md optimisation pass. Append timestamped — never rewrite.

## How to use
- Drop any idea here, no matter how small
- Add date prefix `### YYYY-MM-DD —`
- On next pass: review all unresolved → decide accept/reject/defer per nugget
- After integration into CLAUDE.md: strikethrough or move to `Archive/`

---

### 2026-06-15 — Plans vs Brain routing
**Idea:** Multi-phase actionable plans should live in `$VAULT/Plans/Active/YYYY-MM-DD-<slug>.md`, not brain append. Brain = state. Plans = actionable work. Currently `.plan` big-scope routes to `.task init` (vault tasks.md) but ad-hoc multi-phase plans (like Claude prune plan stored 2026-06-15) ended up appended to brain.

**Proposed change:** Add explicit rule to CLAUDE.md memory routing or `.brain` definition: if appended content has "Phase 1 / Phase 2 / Phase N" structure → suggest moving to `Plans/Active/` instead.

**Why:** Easier to find later. Brain grows unbounded with stale plans. Plans/Active is the natural home.

---

### 2026-06-15 — Nuggets file convention itself
**Idea:** This file. Establish habit of capturing tiny CLAUDE.md improvement thoughts here as they arise. Memory routing already covers "capture/inbox" — but specifically for CLAUDE.md optimisation thoughts, dedicated file beats scattered Inbox entries.

**Proposed change:** Add to CLAUDE.md keyword dispatch:
| Signal | Action |
|---|---|
| "nugget/idea for claude.md/improve claude config" | append timestamped section to `$VAULT/Inbox/claude-md-nuggets.md` |

**Why:** Habit-forming. Cheap to capture. Compound effect over weeks.
