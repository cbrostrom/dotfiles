---
created: 2026-05-31 11:32
type: inbox
---
Dør ind til altan :
Indvendig til høj på fortrin : 198cm høj - 77cm bred

Udvendig:
205cm høj - 84cm bred

--- dør ind til store rum
84cm bred


--- dør ind til lange rum
79cm bred

