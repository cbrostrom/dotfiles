---
created: 2026-06-02 11:52
type: inbox
---
NPM package

- Schema generation
- Quick build
- 