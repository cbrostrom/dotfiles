# Claude Code context bloat reduction

_Captured: 2026-06-15_

## Problem
21% context after 1 Engram call. Root cause: 15 MCPs loaded globally, several with 100-200 tools each (fires full deferred tool list every turn).

## Current MCPs (user-scope)
```
mcp-dockhand           ~200 tools  HTTP (superbro)
plugin:atlassian       ~140 tools  HTTP
engram-personal        agent tools ✓
engram-work            agent tools ✓ (duplicate)
engram                 script      ✗ DEAD - remove
obsidian               bunx        ✓
serena                 uvx         ✓
lean-ctx               lean-ctx    ✓
graphiti               HTTP        ✓
github                 npx         ✓
mcp-mermaid            npx         ✓
tailwindcss            npx         ✓
google-calendar        script      ✓
apple-mcp              bunx        ✓
headroom               headroom    ✓
```

## Plan

### Step 1 — Remove dead entry
```bash
claude mcp remove engram --scope user
```

### Step 2 — Remove heavy globals
```bash
claude mcp remove mcp-dockhand --scope user
claude mcp remove plugin:atlassian:atlassian --scope user
claude mcp remove serena --scope user
claude mcp remove obsidian --scope user
claude mcp remove engram-work --scope user
```

### Step 3 — Add project-level replacements

**Infra sessions** — add to project `.claude/settings.json`:
```json
{
  "mcpServers": {
    "mcp-dockhand": { "type": "http", "url": "http://100.100.1.50:8080/mcp" }
  }
}
```

**AKQA/Fiskars work** — already handled by `project-mcp add akqa` / `project-mcp add fiskars`

**Obsidian** — add per vault-session:
```bash
claude mcp add --scope project obsidian -- bunx obsidian-mcp ~/Vaults/Christian
```

**Serena** — add per large-codebase project:
```bash
claude mcp add --scope project serena -- uvx --from git+https://github.com/oraios/serena serena start-mcp-server --project-from-cwd --context claude-code
```

**engram-work** — add to `~/Work/` project `.claude/settings.json`:
```json
{
  "mcpServers": {
    "engram-work": { "type": "stdio", "command": "/opt/homebrew/bin/engram", "args": ["mcp", "--tools=agent"] }
  }
}
```

### Step 4 — Check list files for stale entries
```bash
grep -E 'dockhand|atlassian|serena|obsidian|engram-work' \
  ~/dotfiles/.claude/mcp-servers.list \
  ~/dotfiles/.claude/mcp-servers.developer.list \
  ~/dotfiles/.claude/mcp-servers.work.list
```
Remove any hits so reinstall doesn't re-add them.

### Step 5 — Verify
Start fresh session, check context% after 1 message. Target: <10% baseline.

## Expected impact
5 MCPs removed → ~340 tool definitions gone from deferred list. Estimate 50-60% baseline reduction.

## Keep global
engram-personal, graphiti, lean-ctx, github, apple-mcp, google-calendar, mcp-mermaid, headroom, tailwindcss
