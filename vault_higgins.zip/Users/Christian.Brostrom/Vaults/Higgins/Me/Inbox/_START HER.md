---
created: 2025-11-30
type: placeholder
---

# 📥 Inbox

> Alt starter her - dump dine tanker!

## Workflow

1. **Skriv** - Dump alt her (widget, quick note)
2. **Sync** - Venter automatisk på desktop
3. **Process** - Kør `Alt+P` på desktop → AI tagger og flytter

## Tips

- Brug denne mappe til ALLE hurtige noter
- Lad være med at sortere manuelt - lad AI gøre det
- Tjek inbox dagligt på desktop

---

*Denne fil holder mappen synkroniseret*

