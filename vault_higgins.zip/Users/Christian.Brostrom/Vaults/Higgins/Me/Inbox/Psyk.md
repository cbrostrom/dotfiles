ADHD #christian

Hvad er det vigtige?

Rytmer og gentagelser

Timeboxing er godt

ADHD på jobbet - bog

Der skal være en plan for at understøtte rytme

Skal ikke tage det personligt - både Sofie og jeg

Jeg er IKKE ligeglad

Træffe beslutninger kan være rigtig svært 

Skal betragtes som et handikap - man ber ikke en blind om at se - for det kan de ikke 

Læs opgaven nu - OHIO (Only handle it once)
Hellig zone (uden kritik) (20:30 hver dag) - skal prøves

Kernen = kærlighed

Headspace eller podcast om ADHD er klogt

Tie stille - fysisk kontakt

Manu Saraeen podcast

Aften ritual - hold om hinanden 90 sekunder uden ord

Christian er mere end ADHD
