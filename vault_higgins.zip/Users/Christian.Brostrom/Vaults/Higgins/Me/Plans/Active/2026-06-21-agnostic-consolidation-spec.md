---
created: 2026-06-21
area: [meta, dev]
type: spec
status: draft
tags: [dotfiles, agnostic, cursor, claude-code, raycast, skills, hooks, consolidation]
repo: dotfiles
supersedes: Plans/Active/2026-06-16-lean-agent-stack-alignment.md
---

# Spec: Agnostic Consolidation & Optimisation

Actionable implementation spec for any agent. Consolidates the clean-slate plan
(2026-06-16), the third-party import analysis (Cursor session 2026-06-21), and
the hooks parity audit into one document.

## Goal

One agent stack. Same rhythm (policy → memory → capabilities → enforcement)
across Claude Code, Cursor, Raycast, Codex, Gemini, Zed, OpenCode, and any
future harness. Dotfiles repo is the single source. Per-tool adapters are thin.
Skills live in one canonical tree. A new `fleet.json` file travels with the
repo and auto-updates per machine.

---

## Fleet — machines running these dotfiles

### Current fleet

| Host | Canonical | OS | Arch | Profile | Workflow | Agent stack |
|---|---|---|---|---|---|---|
| GY-M-WHKK2PF6N7 | Mac | macOS | arm64 | desktop-full | developer,work | CC, Cursor, Raycast, Zed (disabled) |
| linuxbro | Server | linux | amd64 | server-headless | server | CC |
| superbro | Server | linux | amd64 | server-headless | server | CC |
| MonsterBro | WSL | linux/wsl | x86_64 | wsl | wsl | CC |

### Device snapshots vs fleet.json

`.claude/devices/<host>.json` exists but is Claude-centric: it tracks plugins,
CC MCP servers, and CC settings state. The new `fleet.json` is agent-agnostic.

#### New: `fleet.json` (repo root, git-tracked)

Auto-updated by `dotfiles --update` and by the pre-commit hook. Any agent can
read it to understand the fleet without parsing per-device JSON.

```json
{
  "$schema": "fleet-schema.json",
  "updated": "2026-06-21T09:00:00Z",
  "machines": {
    "gy-m-whkk2pf6n7": {
      "hostname": "GY-M-WHKK2PF6N7",
      "os": "macos",
      "arch": "arm64",
      "profile": "desktop-full",
      "dotfiles_workflows": ["developer", "work"],
      "agents": ["claude-code", "cursor", "raycast"],
      "shell": "zsh",
      "node": "22.x",
      "python": "3.12.x",
      "tailscale": true,
      "last_updated": "2026-06-21T09:00:00Z"
    },
    "linuxbro": {
      "hostname": "linuxbro",
      "os": "linux",
      "arch": "amd64",
      "profile": "server-headless",
      "dotfiles_workflows": ["server"],
      "agents": ["claude-code"],
      "shell": "zsh",
      "node": "22.x",
      "python": "3.12.x",
      "tailscale": true,
      "last_updated": "2026-06-09T00:00:00Z"
    },
    "superbro": {
      "hostname": "superbro",
      "os": "linux",
      "arch": "amd64",
      "profile": "server-headless",
      "dotfiles_workflows": ["server"],
      "agents": ["claude-code"],
      "shell": "zsh",
      "node": "22.x",
      "python": "3.12.x",
      "tailscale": true,
      "last_updated": "2026-06-09T00:00:00Z"
    },
    "monsterbro": {
      "hostname": "MonsterBro",
      "os": "wsl",
      "arch": "x86_64",
      "profile": "wsl",
      "dotfiles_workflows": ["wsl"],
      "agents": ["claude-code"],
      "shell": "zsh",
      "node": "22.x",
      "python": "3.12.x",
      "tailscale": true,
      "last_updated": "2026-06-12T19:07:05Z"
    }
  }
}
```

Implementation:

1. Create `scripts/fleet-snapshot.sh` — reads hostname, uname, versions, DOTFILES_WORKFLOWS,
   installed agent binaries, and merges into `fleet.json` keyed by lowercase hostname.
2. Wire into pre-commit hook alongside device-snapshot.sh.
3. Wire into `dotfiles --update` (bootstrap.sh post-step).
4. Each machine updates only its own key; other keys are left intact.
5. Schema file `fleet-schema.json` at repo root for optional validation.

Relationship to `.claude/devices/`:

`fleet.json` supersedes `.claude/devices/`. The device snapshot system was
CC-centric (tracks plugins, CC settings state, CC MCP servers) and tied to
Anthropic's ecosystem. `fleet.json` is the agnostic replacement.

Migration path:
1. `fleet.json` goes live first (Phase 1).
2. Any CC-specific fields still needed (enabled_plugins, CC MCP servers)
   get folded into `fleet.json` under a `claude_code` key per machine —
   keeping it as one file but with optional tool-specific sections.
3. Once `fleet.json` carries all data, remove `device-snapshot.sh`,
   `.claude/devices/*.json`, and the pre-commit hook call to device-snapshot.
4. Update `CLAUDE.md` and `AGENTS.md` to reference `fleet.json` only.

Target `fleet.json` machine entry (with optional CC section):

```json
{
  "hostname": "GY-M-WHKK2PF6N7",
  "os": "macos",
  "arch": "arm64",
  "profile": "desktop-full",
  "dotfiles_workflows": ["developer", "work"],
  "agents": ["claude-code", "cursor", "raycast"],
  "shell": "zsh",
  "node": "22.x",
  "python": "3.12.x",
  "tailscale": true,
  "last_updated": "2026-06-21T09:00:00Z",
  "claude_code": {
    "enabled_plugins": ["atlassian@claude-plugins-official", "..."],
    "mcp_servers": ["github", "engram"]
  }
}
```

---

## Architecture: four layers

```
┌─────────────────────────────────────────────────────┐
│  Layer 1: POLICY (AGENTS.md)                        │
│  Advisor stance, language, approval gate, push guard │
│  brain memory protocol, tool routing, code quality   │
├─────────────────────────────────────────────────────┤
│  Layer 2: ADAPTERS (thin, per-harness)              │
│  CC: CLAUDE.md  Cursor: core.mdc  Zed: rules       │
│  Raycast: agent-policy skill  Codex/Gemini: AGENTS  │
├─────────────────────────────────────────────────────┤
│  Layer 3: SKILLS (capabilities)                     │
│  Universal: ~/.agents/skills/   CC-only: ~/.claude/ │
│  Cursor-managed: ~/.cursor/skills-cursor/           │
├─────────────────────────────────────────────────────┤
│  Layer 4: RUNTIME (hooks, MCP, model, memory)       │
│  agent-core.json, hooks, mcp-servers.list, brain    │
│  fleet.json                                          │
└─────────────────────────────────────────────────────┘
```

---

## Layer 1: Policy — AGENTS.md

**Status: DONE.** No changes needed. Already the source of truth.

Current AGENTS.md covers: advisor stance, language, brain protocol, tool
routing (RTK), token awareness, approval gate, coding principles, push guard,
planning thresholds, code quality (aislop + fallow), infrastructure dispatch.

All adapters point here. Every harness reads this file.

---

## Layer 2: Adapters

### 2a. Claude Code — `.claude/CLAUDE.md`

**Status: DONE.** Thin adapter. `@../AGENTS.md` import + CC-only sections
(dot-commands, hooks, settings-arch, Plannotator, project detection).

No changes needed.

### 2b. Cursor — `.cursor/rules/core.mdc`

**Status: DONE.** alwaysApply, 36 lines, points at AGENTS.md, mentions brain
load, RTK, aislop, fallow.

No changes needed.

### 2c. Zed — `.config/zed/rules`

**Status: STALE AND CONTRADICTORY.**

Current content is a standalone ruleset that contradicts AGENTS.md on multiple
points:

| Current Zed rules | AGENTS.md | Delta |
|---|---|---|
| "Danish default" | English default | Wrong |
| "Caveman mode: ALWAYS ON" | Available on request, not default | Wrong |
| "lean-ctx MCP" | lean-ctx removed | Obsolete |
| "Memory: Engram" (mem_save/mem_search) | Brain CLI (`brain load`) | Outdated |
| "Forbidden: test execution" | Not forbidden in AGENTS.md | Over-restrictive |
| Approval: "patch + DK explanation" | Outline + EN | Wrong language |
| Commit msgs: English "regardless" | Same, but Zed says explain in Danish | Contradicts |

**Note:** Zed module is disabled in `modules.conf` (`!zed`) so this file is
inert on machines using the TUI update flow. But it's still git-tracked and
would be active if Zed is re-enabled.

**Action:**

Replace entire `.config/zed/rules` content with an AGENTS.md pointer:

```markdown
# Global Agent Rules

Read AGENTS.md in the workspace root before acting. It is the source of truth
for advisor stance, brain memory protocol, approval gate, tool routing, push
guard, and planning thresholds.

Brain: run `brain load` at the start of each session.
Language: English default.
```

If Zed supports file imports, use that instead. Otherwise keep it as a
≤10-line summary matching `core.mdc` style.

### 2d. Raycast — `~/.agents/skills/agent-policy/SKILL.md`

**Status: MISSING.**

Raycast has no AGENTS.md reader. It discovers skills from `~/.agents/skills/`
and `~/.claude/skills/`. Policy must be injected as a skill.

**Action:** Create `dotfiles/.agents/skills/agent-policy/SKILL.md`:

```markdown
---
name: agent-policy
description: >-
  Core working policy. Use at the start of any conversation involving code,
  projects, dotfiles, servers, or technical decisions. Covers approval gate,
  language, memory protocol, and code quality expectations.
---

# Agent Policy

(Condensed AGENTS.md — advisor stance, English default, approval gate,
brain protocol summary, push guard summary, aislop/fallow pointers.)
```

Body should be ≤600 tokens (Raycast loads full body when triggered). Extract
the behavioral essentials from AGENTS.md; skip dispatch tables and signal
matrices. Raycast doesn't have shell hooks so push guard is advisory only.

### 2e. Codex / Gemini / OpenCode

**Status: ADEQUATE.** These agents read `AGENTS.md` natively. `brain setup
--write --agent=codex` (or all) scaffolds the brain block. No adapter file
needed beyond AGENTS.md itself.

**Action:** None unless specific adapters are wanted later.

### 2f. Copilot — `.github/copilot-instructions.md`

**Status: NOT USED.** Exists in `brain` AGENT_FILES map but no file is
generated. Low priority.

**Action:** None. Generate via `brain setup` when needed per-project.

---

## Layer 3: Skills — the big reorganisation

### Problem

With Cursor "Include third-party Plugins, Skills, and other configs" ON,
Cursor scans ALL of these:

- `~/.agents/skills/` (1 skill: fallow)
- `~/.claude/skills/` (15+ skills, including disabled dirs)
- `~/.codex/skills/` (empty)
- `~/.cursor/skills-cursor/` (Cursor-managed: ~10 built-in skills)

Result: catalog bloat. Disabled skills in `.claude/skills/.disabled-*` dirs
get scanned. Duplicate names between `.claude/` and `.agents/` get
silently deduplicated (first wins). Raycast scans `~/.claude/skills/` too
but only one level deep (misses nested disabled dirs — this is fine).

### Target state

Three buckets, clear ownership:

| Bucket | Path (dotfiles) | Symlinked to | Scanned by | Purpose |
|---|---|---|---|---|
| **Universal** | `.agents/skills/<name>/` | `~/.agents/skills/` | CC, Cursor, Raycast, Codex | Cross-tool capabilities |
| **CC-only** | `.claude/skills/<name>/` | `~/.claude/skills/` | CC (and Cursor/Raycast but CC-specific content) | Hook-dependent, dot-command, CC-specific |
| **Cursor-managed** | (not in dotfiles) | `~/.cursor/skills-cursor/` | Cursor only | Cursor built-in skills |

### Skill classification

Audit every active SKILL.md under `.claude/skills/` and `.agents/skills/`.
Classification criteria:

- **Universal:** No dependency on CC hooks, slash commands, or CC-specific tool names.
  Works in any agent with shell access.
- **CC-only:** Uses `.plan`/`.task`/`.review`/`.mem` dot-commands, references
  CC hook events (PreCompact, ExitPlanMode), or depends on CC plugin features.
- **Retire:** Disabled dirs, superseded skills, unused skills.

| Skill | Current location | Classification | Action |
|---|---|---|---|
| `fallow` | `.agents/skills/` | Universal | Stay (already correct) |
| `agent-policy` | (new) | Universal | Create in `.agents/skills/` |
| `systematic-debugging` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `verification-before-completion` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `writing` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `writing-plans` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `brainstorming` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `sparring` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `dotfiles-update` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `inbox-librarian` | `.claude/skills/` | Universal | Promote to `.agents/skills/` |
| `graphify` | `.claude/skills/` | CC-only (slash cmd) | Stay in `.claude/skills/` |
| `taskmaster` | `.claude/skills/` | CC-only (`.task` routing) | Stay in `.claude/skills/` |
| `plannotator-annotate` | `.claude/skills/` | CC-only (hooks) | Stay in `.claude/skills/` |
| `plannotator-last` | `.claude/skills/` | CC-only (hooks) | Stay in `.claude/skills/` |
| `plannotator-review` | `.claude/skills/` | CC-only (hooks) | Stay in `.claude/skills/` |
| `.disabled-2026-05-15/*` | `.claude/skills/` | Retire | Move to `~/.agents/.retired/` |
| `.disabled-2026-06-16-*/*` | `.claude/skills/` | Retire | Move to `~/.agents/.retired/` |

### Frontmatter hygiene

Every promoted skill must have compliant frontmatter (Agent Skills standard):

```yaml
---
name: skill-name          # must match folder name, kebab-case
description: >-
  When to use this skill and what it does.
  Lead with trigger conditions.
disable-model-invocation: false   # true for heavy/rare skills
paths: "**/*.ts"                  # optional file scoping (Cursor only)
---
```

Raycast requires `name` and `description`. Cursor uses all fields.
`disable-model-invocation: true` prevents auto-injection for expensive skills.

Candidates for `disable-model-invocation: true`:
- `writing` (large reference files)
- `brainstorming` (heavy procedure)
- `fallow` (large CLI reference)

### Retired skills — move out of scan paths

```bash
mkdir -p ~/.agents/.retired
mv dotfiles/.claude/skills/.disabled-2026-05-15 ~/.agents/.retired/
mv dotfiles/.claude/skills/.disabled-2026-06-16-using-superpowers ~/.agents/.retired/
```

These MUST leave the `.claude/skills/` tree entirely. Cursor and Raycast scan
hidden dirs inside skill roots. A `.disabled-*` dir containing SKILL.md files
will pollute the catalog.

### Symlink structure after promotion

```
dotfiles/
├── .agents/skills/
│   ├── agent-policy/SKILL.md           (NEW)
│   ├── brainstorming/SKILL.md          (MOVED from .claude/skills/)
│   ├── dotfiles-update/SKILL.md        (MOVED)
│   ├── fallow/SKILL.md                 (EXISTING)
│   ├── inbox-librarian/SKILL.md        (MOVED)
│   ├── sparring/SKILL.md               (MOVED)
│   ├── systematic-debugging/SKILL.md   (MOVED)
│   ├── verification-before-completion/SKILL.md (MOVED)
│   ├── writing/SKILL.md                (MOVED)
│   └── writing-plans/SKILL.md          (MOVED)
├── .claude/skills/
│   ├── graphify/SKILL.md               (STAYS)
│   ├── taskmaster/SKILL.md             (STAYS)
│   ├── plannotator-annotate/SKILL.md   (STAYS)
│   ├── plannotator-last/SKILL.md       (STAYS)
│   ├── plannotator-review/SKILL.md     (STAYS)
│   ├── skills.list                     (STAYS — external installs)
│   └── .gitignore                      (STAYS)
└── .cursor/
    ├── rules/core.mdc                  (STAYS)
    └── hooks/brain-load.sh             (STAYS)

~/.agents/skills/  → dotfiles/.agents/skills/     (symlink, existing)
~/.claude/skills/  → dotfiles/.claude/skills/      (symlink, existing)
~/.agents/.retired/                                (NOT scanned, NOT symlinked)
```

### Name collision check

After promotion, verify no duplicate `name` values across:
- `~/.agents/skills/`
- `~/.claude/skills/`
- `~/.cursor/skills-cursor/`

Cursor keeps first match and silently drops the rest. Add a doctor check.

---

## Layer 4: Runtime wiring

### 4a. Hooks — parity matrix

#### Claude Code hooks (settings.darwin.json)

| Hook script | CC event | Purpose |
|---|---|---|
| `brain-load.sh` | SessionStart | Vault context injection |
| `brain-optimise-cheap.sh` | SessionStart | Cheap vault maintenance |
| `brain-save-inject.sh` | PreCompact, UserPromptSubmit | Brain save before compaction |
| `git-push-guard.sh` | PreToolUse (Bash) | Block push outside whitelist |
| `rtk hook claude` | PreToolUse (Bash) | Token-compressed shell output |
| `effort-classifier.sh` | UserPromptSubmit | Tier prompt complexity |
| `fast-mode-guard.sh` | UserPromptSubmit | Guard against fast mode misuse |
| `statusline.sh` | StatusLine | CC terminal status bar |
| `claude-settings-merge.sh` | (build-time) | Settings layer merge |

#### Cursor hooks (live ~/.cursor/hooks.json)

| Hook | Cursor event | Source | Status |
|---|---|---|---|
| `brain-load.sh` | sessionStart | Dotfiles | OK |
| `herdr-agent-state.sh` | sessionStart | Herdr (local) | Personal, keep |
| `rtk hook cursor` | preToolUse (Shell) | Dotfiles | OK |
| `aislop hook cursor` | afterFileEdit | Dotfiles | OK |
| `codeisland-bridge` × 10 | various | CodeIsland (local) | Personal, keep |
| `git-push-guard.sh` | — | — | **MISSING** |

#### Recommended Cursor hooks changes

**Add git-push-guard to Cursor preToolUse:**

The push-guard script (`~/.claude/hooks/git-push-guard.sh`) reads JSON from
stdin with `.tool_input.command` and `.cwd`. Cursor's preToolUse for Shell
provides the same shape. The script is already cross-compatible.

Add to `scripts/cursor/install-cursor-config.sh` hooks.json patcher:

```python
# git-push-guard: preToolUse Shell
guard_entry = {
    "command": "bash '$HOME/.claude/hooks/git-push-guard.sh'",
    "type": "command",
    "matcher": "Shell",
    "timeout": 5000,
}
# Add to preToolUse alongside rtk, dedup by command string
```

Update live `~/.cursor/hooks.json` preToolUse to include the guard.

**Do NOT port to Cursor** (CC-only, no equivalent event):

- `effort-classifier.sh` — Cursor `beforeSubmitPrompt` exists but payload
  format is undocumented. Defer until Cursor documents it.
- `brain-save-inject.sh` — no PreCompact event in Cursor.
- `brain-optimise-cheap.sh` — low-value for Cursor; brain load is sufficient.
- `fast-mode-guard.sh` — CC-specific mode concept.
- `statusline.sh` — CC terminal UI.

**Do NOT port (personal tooling):**

- `herdr-agent-state.sh` — Herdr-managed, not in dotfiles
- `codeisland-bridge` × 10 — CodeIsland-managed, not in dotfiles

Both are fine as local overlays in `~/.cursor/hooks.json`. The
`install-cursor-config.sh` patcher already handles coexistence (it patches
idempotently without clobbering existing entries).

#### Hooks manifest (new: for doctor.sh)

Create `dotfiles/.cursor/hooks.manifest.json` — reference-only, not copied
to `~/.cursor/`. Used by `doctor.sh` to verify required hooks are present.

```json
{
  "required": {
    "sessionStart": [{"command_contains": "brain-load"}],
    "preToolUse": [
      {"command_contains": "rtk hook cursor"},
      {"command_contains": "git-push-guard"}
    ],
    "afterFileEdit": [{"command_contains": "aislop hook cursor"}]
  },
  "optional_local": [
    "codeisland-bridge",
    "herdr-agent-state"
  ]
}
```

### 4b. MCP — agent-core-sync

**Status: WORKING.** `agent-core.json` → `agent-core-sync.sh` → Cursor
`~/.cursor/mcp.json` + `~/.cursor/cli-config.json`.

Syncs: model ID, display name, aliases, language, approval mode, sandbox
settings, MCP servers from merged list files.

No changes needed. The agnostic piece is that MCP servers are defined in
`.list` files (pipe-delimited), workflow overlays are `DOTFILES_WORKFLOWS`,
and `agent-core-sync.sh` translates to Cursor's format.

Raycast and Codex have their own MCP configs — not synced from dotfiles.
That's intentional: MCP is tool-specific, skills are the shared layer.

### 4c. Brain — memory protocol

**Status: WORKING ACROSS CC AND CURSOR.**

- CC: `brain-load.sh` hook on SessionStart (auto).
- Cursor: `brain-load.sh` in `hooks.json` sessionStart (auto).
- Raycast: `agent-policy` skill mentions brain protocol (manual).
- Codex/Gemini/Zed: AGENTS.md says "run `brain load`" (manual).

`scripts/brain` AGENT_FILES map is correct:

```python
AGENT_FILES = {
    "claude": "CLAUDE.md",
    "cursor": "AGENTS.md",
    "copilot": ".github/copilot-instructions.md",
    "windsurf": ".windsurfrules",
    "codeium": ".codeiumrules",
}
```

No changes needed to the brain CLI.

---

## Stale / contradictory items to clean up

### Device snapshots: stale data on servers

LinuxBro and SuperBro snapshots show `last_synced: 2026-06-09`, enabled
plugins that were pruned on Mac (caveman, planning-with-files, superpowers),
and no skills. These snapshots are from before the clean-slate prune.

**Action:** Next `dotfiles --update` on each server will refresh via
`device-snapshot.sh write`. After that, the plugin lists will reflect actual
installed state. No manual fix needed, but note that the snapshot might still
show old plugins until someone runs CC on those servers.

### MonsterBro device snapshot: casing

`MonsterBro.json` uses mixed case hostname. CLAUDE.md says canonical is
lowercase. The `hostname -s` output on WSL determines this. If WSL returns
`MonsterBro`, the file is correct for that machine. But gotchas.md already
warns about this. Verify `hostname -s` output on MonsterBro.

### Zed module disabled but config tracked

`modules.conf` has `!zed` but `.config/zed/` is still fully git-tracked
(settings, keymap, tasks, rules, themes, install script). This is fine for
portability (re-enable later), but the rules file actively contradicts
AGENTS.md. Fix the rules content even though the module is disabled.

### Unused MCP overlay files

Some overlay files are empty or contain only comments:
- `mcp-servers.developer.list` — empty slot after pruning
- `mcp-servers.macos.list` — empty after moves to apple/infra overlays

These are harmless (no-op on merge) but could be pruned for clarity. Low
priority.

### CC plugins drift

Mac snapshot shows plugins that don't match `plugins.list` + overlays:
- `plugins.list`: claude-md-management, plannotator
- `plugins.developer.list`: frontend-design, code-simplifier
- `plugins.work.list`: shopify, liquid-skills, liquid-lsp, atlassian

Mac snapshot `enabled_plugins` includes atlassian, claude-md-management,
frontend-design, liquid-skills, plannotator. Missing: code-simplifier,
shopify, liquid-lsp. Either these were disabled manually or the install
script didn't run after the last edit. `modules/claude-settings/doctor.sh`
should catch this.

---

## Execution phases

### Phase 1: fleet.json (new file, zero risk)

1. Create `scripts/fleet-snapshot.sh`
   - Reads: hostname, uname -s, uname -m, shell version, node version,
     python version, DOTFILES_WORKFLOWS, installed agent binaries
     (claude, cursor, raycast, codex, opencode, zed)
   - Merges into `fleet.json` at repo root (upsert own key only)
   - Tailscale detection: `tailscale status --json 2>/dev/null`
   - CC-specific state (enabled_plugins, CC MCP servers) folded into
     optional `claude_code` sub-key per machine — replaces device-snapshot
2. Create `fleet.json` with Mac data (initial seed)
3. Wire into pre-commit hook (replaces device-snapshot.sh call)
4. Wire into `dotfiles --update` / bootstrap.sh
5. Deprecate `scripts/claude/device-snapshot.sh` — remove pre-commit call,
   keep script temporarily for `device-snapshot.sh list` back-compat
6. Remove `.claude/devices/*.json` from git tracking after fleet.json
   carries the same data
7. Document in CLAUDE.md / AGENTS.md under a "Fleet" section

### Phase 2: Skill reorganisation (highest impact)

1. Create `dotfiles/.agents/skills/agent-policy/SKILL.md`
2. Move universal skills from `.claude/skills/` → `.agents/skills/`:
   - systematic-debugging, verification-before-completion, writing,
     writing-plans, brainstorming, sparring, dotfiles-update, inbox-librarian
   - Each move: `git mv .claude/skills/<name> .agents/skills/<name>`
   - Update any cross-references in CLAUDE.md / AGENTS.md
3. Remove `.claude/skills/.disabled-*` from git tracking:
   - `mkdir -p ~/.agents/.retired`
   - `git rm -r --cached .claude/skills/.disabled-2026-05-15`
   - `git rm -r --cached .claude/skills/.disabled-2026-06-16-using-superpowers`
   - Move content to `~/.agents/.retired/` (outside repo)
   - Add `.claude/skills/.disabled-*` to `.gitignore`
4. Audit frontmatter on all remaining skills:
   - `name` matches folder name
   - `description` present and ≤1024 chars, starts with "Use when..."
   - `disable-model-invocation: true` on heavy skills
5. Verify: no duplicate `name` across `.agents/skills/`, `.claude/skills/`,
   `.cursor/skills-cursor/`

### Phase 3: Stale adapter fixes

1. ~~Replace `.config/zed/rules` content with AGENTS.md pointer (≤10 lines)~~ — DONE (2026-06-21, Cursor session)
2. No other adapter changes needed (CC, Cursor already correct)

### Phase 4: Cursor hooks — push guard

1. Add git-push-guard to `scripts/cursor/install-cursor-config.sh`
   preToolUse patcher
2. Create `.cursor/hooks.manifest.json` for doctor verification
3. Run `bash scripts/cursor/install-cursor-config.sh` to patch live hooks.json
4. Verify: in Cursor, attempt `git push` in a non-whitelisted repo → blocked

### Phase 5: Doctor extensions

Extend `scripts/doctor.sh` with new checks:

1. **fleet.json exists** and current host has an entry
2. **fleet.json freshness** — warn if `last_updated` > 7 days
3. **Skill name collisions** — scan `~/.agents/skills/`, `~/.claude/skills/`,
   `~/.cursor/skills-cursor/` for duplicate `name` values
4. **Retired skills leak** — no `SKILL.md` under `.claude/skills/.disabled-*`
5. **Cursor hooks manifest** — if `~/.cursor/hooks.json` exists, verify all
   `required` entries from `.cursor/hooks.manifest.json` are present
6. **Zed rules drift** — if `.config/zed/rules` exists, warn if it contains
   "Danish" or "lean-ctx" or "Engram" (contradicts AGENTS.md)
7. **Frontmatter compliance** — scan all `SKILL.md` files in
   `~/.agents/skills/` for missing `name` or `description`

### Phase 6: Documentation

1. Update `CLAUDE.md` (repo root) — add Fleet section, update Skills section
   to reflect two-bucket structure
2. Update `AGENTS.md` — add Fleet reference, update skill paths
3. Mark `Plans/Active/2026-06-16-lean-agent-stack-alignment.md` as superseded

---

## Files touched (summary)

### New files

| File | Purpose |
|---|---|
| `fleet.json` | Agnostic fleet manifest (git-tracked, auto-updated) |
| `fleet-schema.json` | Optional JSON schema for fleet.json |
| `scripts/fleet-snapshot.sh` | Fleet snapshot generator |
| `.agents/skills/agent-policy/SKILL.md` | Raycast/universal policy skill |
| `.cursor/hooks.manifest.json` | Doctor reference for required Cursor hooks |

### Modified files

| File | Change |
|---|---|
| `.config/zed/rules` | Replace stale rules with AGENTS.md pointer |
| `scripts/cursor/install-cursor-config.sh` | Add git-push-guard to preToolUse patcher |
| `hooks/pre-commit` | Add fleet-snapshot.sh call |
| `scripts/doctor.sh` | Add fleet, skill collision, hooks, Zed drift checks |
| `CLAUDE.md` | Add Fleet section, update skill paths |
| `AGENTS.md` | Add Fleet reference |
| `.gitignore` (or `.claude/skills/.gitignore`) | Exclude `.disabled-*` |

### Moved files (git mv)

| From | To |
|---|---|
| `.claude/skills/systematic-debugging/` | `.agents/skills/systematic-debugging/` |
| `.claude/skills/verification-before-completion/` | `.agents/skills/verification-before-completion/` |
| `.claude/skills/writing/` | `.agents/skills/writing/` |
| `.claude/skills/writing-plans/` | `.agents/skills/writing-plans/` |
| `.claude/skills/brainstorming/` | `.agents/skills/brainstorming/` |
| `.claude/skills/sparring/` | `.agents/skills/sparring/` |
| `.claude/skills/dotfiles-update/` | `.agents/skills/dotfiles-update/` |
| `.claude/skills/inbox-librarian/` | `.agents/skills/inbox-librarian/` |

### Removed from git tracking

| Path | Reason |
|---|---|
| `.claude/skills/.disabled-2026-05-15/` | Retired, leaks into Cursor/Raycast scans |
| `.claude/skills/.disabled-2026-06-16-using-superpowers/` | Retired, obsolete |
| `.claude/devices/*.json` | Superseded by `fleet.json` |

### Deprecated

| File | Replacement |
|---|---|
| `scripts/claude/device-snapshot.sh` | `scripts/fleet-snapshot.sh` |

---

## Verification checklist

After all phases, verify:

### Policy rhythm (every harness)

- [ ] New CC session: brain context appears, advisor stance active
- [ ] New Cursor session: brain context appears, AGENTS.md followed
- [ ] Raycast AI Chat: `agent-policy` skill discovered, English default
- [ ] Zed (if re-enabled): rules point at AGENTS.md, no Danish default

### Skills

- [ ] Cursor Settings → Rules → Skills: catalog shows universal + CC skills,
      no `.disabled-*` entries, no duplicates
- [ ] Raycast Settings → AI → Skills: lists agent-policy, fallow, writing,
      brainstorming, systematic-debugging, etc.
- [ ] `~/.agents/skills/` contains 10 skill dirs (9 promoted + fallow)
- [ ] `~/.claude/skills/` contains 5 skill dirs (graphify, taskmaster,
      plannotator-annotate, plannotator-last, plannotator-review)
- [ ] No SKILL.md files anywhere under `.claude/skills/.disabled-*`

### Hooks

- [ ] Cursor `git push` in non-whitelisted repo → blocked
- [ ] CC `git push` in non-whitelisted repo → blocked (already working)
- [ ] RTK compression active in both CC and Cursor
- [ ] aislop fires on file edit in Cursor
- [ ] CodeIsland/Herdr hooks still fire (local, unchanged)

### Fleet

- [ ] `fleet.json` exists at repo root with current host entry
- [ ] `git commit` in dotfiles refreshes fleet.json entry
- [ ] `dotfiles --update` refreshes fleet.json entry
- [ ] Other machine entries preserved (not overwritten)

### Doctor

- [ ] `scripts/doctor.sh` reports no warnings on Mac
- [ ] Doctor catches: missing fleet.json, skill name collision, stale Zed
      rules, missing Cursor hooks, retired skill leaks

---

## Risks

| Risk | Likelihood | Mitigation |
|---|---|---|
| Skill move breaks CC skill resolution | Low | Symlinks resolve; CC scans both trees |
| Raycast ignores nested skill files | Expected | Raycast only reads top-level SKILL.md; references/ loaded on demand by model |
| Cursor catalog bloat from ~/.claude/skills/ | Medium | Promote to .agents/; use disable-model-invocation |
| fleet.json merge conflict on multi-machine push | Low | Each machine writes own key only; JSON merge is key-level |
| git-push-guard payload mismatch in Cursor | Low | Script already handles missing fields gracefully |
| Retired skills lost | None | Moved to ~/.agents/.retired/, not deleted |

---

## Out of scope

- Custom Cursor subagents / modes
- Plugin reinstallation on servers (wait until next server session)
- RTK for Raycast (no hook system)
- MCP sync for Raycast/Codex (tool-specific, not agnostic)
- WSL bootstrap end-to-end verification (separate task in brain next.md)
- Cursor CLI skill parity (documented upstream gap, no fix available)

---

## Pickup prompt

> Implement the agnostic consolidation spec at
> `~/Vaults/Brain/Plans/Active/2026-06-21-agnostic-consolidation-spec.md`.
> Execute phases 1–5 in order. Phase 6 (docs) can be done inline.
> Skip manual verification steps — leave those for the user.
> The spec supersedes the 2026-06-16 clean-slate plan.
