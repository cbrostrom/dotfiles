---
date: 2026-06-12
tags: [tech, plan, knowledge-base, ai, claude]
status: draft
---

# Knowledge Base Strategy — Karpathy pattern vs Engram/Graphiti

> Honest read on the Claude CoWork Knowledge Base Kit, where it overlaps with what you already run, and what a pragmatic hybrid looks like cross-machine.

## TL;DR (read this first)

**Challenge to your framing.** You phrased this as *"pivot to using the growing knowledgebase / brain approach"*. That frame is wrong. The kit and your current setup are **not competitors**. They do three different jobs:

| Layer | What it is | What it stores | Authored by |
|---|---|---|---|
| **Karpathy KB (the kit)** | Curated external knowledge | Articles, papers, transcripts you collected → distilled wiki + dated query reports | *You*, with Claude as librarian |
| **Engram** | Session memory | Decisions, bug fixes, conventions, project state Claude noticed while working with you | *Claude*, about your work |
| **Graphiti** | Relational layer | Entities + edges with temporal validity (who decided what, when, supersedes what) | *Claude*, structured |
| **brain.md** | Per-repo working state | Current state, open decisions, gotchas, next steps for one repo | *Claude*, ephemeral per repo |
| **Obsidian vault** | Your own writing | Daily notes, plans, references, ideas | *You*, manually |

The kit fills a **real gap** in your stack: nothing you currently run is good at *"I read 20 PDFs about ADHD parenting / Shopify themes / housing-board law — distill them into a citable wiki I can interrogate."* Engram and Graphiti are observation layers, not corpus layers.

**`[Likely]` Recommendation:** Adopt the kit as a fourth layer **inside the vault** (`KNOWLEDGE/`), so it gets LiveSync cross-machine for free. Do **not** retire Engram or Graphiti — they serve different needs. brain.md stays per-repo.

The uncomfortable truth: your complaint that Engram/Graphiti "run in a separate universe" is partially correct, but the fix isn't to replace them. The fix is (a) accept they're opaque by design (Claude's notes to itself), and (b) build a *visible* knowledge layer next to them where you can actually browse files.

---

## What the kit actually is (one paragraph)

Andrej Karpathy's pattern: separate three folders so provenance survives. `RAW/` is verbatim sources, never edited. `Wiki/` is Claude-distilled cross-linked articles where every claim cites a RAW file. `Outputs/` is dated query reports with citations. Each topic gets its own `KNOWLEDGE/[topic]_kb/` folder with `CLAUDE.md` instructions. A monthly health-check skill audits drift. That's the whole thing. The kit is a `KNOWLEDGE/` folder template plus one skill — four files total. It is **agnostic to where you put it**; the "CoWork" branding is just Anthropic's hosted product, but the pattern works in any Claude Code workspace.

The genuinely good idea: **verbatim RAW + sourced wiki claims**. That's the discipline that prevents AI knowledge bases from rotting into summaries-of-summaries with no traceable backing.

---

## Honest assessment against your current setup

### Where the kit wins over what you have today

1. **External-corpus distillation.** Engram doesn't store articles you read. Graphiti doesn't either. Your Obsidian vault has `Reference/` but no enforced source-provenance discipline. The kit explicitly solves *"I read this paper / podcast / book — make it part of my queryable knowledge."*

2. **Browsable artifacts.** Every wiki article and query report is a markdown file you can read in Obsidian. Engram/Graphiti are opaque — you can't open them in Finder and skim. Your "separate universe" complaint dies the moment knowledge lives as `.md` files.

3. **Citation discipline.** Wiki articles **must** trace claims to a `RAW/` file. Engram has no such rule. This matters when you re-read a claim six months later and want to know if it's something you observed or something an article said.

4. **Compounding outputs.** Every question becomes a dated report. Engram has `mem_session_summary` but you rarely open those. Reports as files in Obsidian = browsable, searchable via Omnisearch, indexable by Smart Connections.

### Where the kit is *worse* than what you have

1. **Manual ingest.** You have to drop files into `RAW/` and say "compile". Engram captures automatically via `mem_save` during work. The kit will not replace ambient observation.

2. **No code-anchored memory.** brain.md remembers *"pre-commit stash loop fixed via `GIT_REFLOG_ACTION` guard"*. The kit has no equivalent — it's for *external* knowledge, not *your work*.

3. **No temporal supersession.** Graphiti tracks "this decision invalidates that prior decision". The kit's wiki has no built-in mechanism for *"v2 of this article supersedes v1"* — drift detection is monthly via the health-check skill.

4. **Designed for "CoWork" hosted product.** The kit assumes Anthropic's CoWork desktop app with a `schedule` skill and clickable `computer://` links. Two issues in your Claude Code setup:
   - `computer://` links **don't render clickable** in Claude Code terminal — `obsidian://` URIs do.
   - The bundled `.skill` file is a zip — needs extraction, and the monthly cron should run via your existing `schedule` skill (which exists — confirmed in available skills) or launchd on Mac.

### Where the kit and Engram/Graphiti are doing the same job (real overlap)

Almost nowhere. The only meaningful overlap is **synthesis across past content**:
- Engram: "what decisions have I made about X?" → fast, opaque, code-flavored
- Karpathy KB: "what do my sources say about X?" → file-backed, citation-disciplined, external-flavored

These are complements, not competitors. Keep both.

---

## Cross-machine story

You already have the substrate. You just haven't been using it for this.

### Current sync mechanisms (confirmed)

| Layer | Sync mechanism | Cross-machine? |
|---|---|---|
| Obsidian vault (`~/Vaults/Christian`) | **Self-hosted LiveSync via CouchDB on superbro** | ✅ Mac, WSL/MonsterBro, iPhone |
| Dotfiles | Git + `dotfiles --update` skill | ✅ Mac, LinuxBro, SuperBro, MonsterBro |
| Engram | `~/.claude/scripts/engram.sh` wrapper, SessionStart/Stop sync hooks | ⚠️ Partial — needs hook deployment per host (see vault CLAUDE.md "Next steps") |
| Graphiti | HTTP MCP on `superbro:8000` over Tailscale | ✅ Any machine on tailnet |
| brain.md | Per-repo, committed to git | ✅ Travels with repo |

**Key insight:** if `KNOWLEDGE/` lives **inside the vault** (`~/Vaults/Christian/KNOWLEDGE/`), it sync's automatically to every device you use Obsidian on, including iPhone. No new infrastructure needed. The kit doesn't care where it lives — it's just a folder with markdown.

This also kills your "limited to per git repo" complaint. KBs in the vault are **cross-project by definition** — `shopify_themes_kb` is useful from any client's repo, `parenting_kb` is useful from nowhere code-related at all.

### The decision: where does `KNOWLEDGE/` live?

| Option | Pros | Cons | Verdict |
|---|---|---|---|
| **A. Inside vault** (`~/Vaults/Christian/KNOWLEDGE/`) | Free LiveSync to all devices incl. iPhone. Browsable in Obsidian. Backlinks integrate with existing `[[wiki-links]]`. | Vault becomes larger (RAW PDFs/transcripts can be heavy). LiveSync isn't built for large binary blobs. | **`[Likely]` Best for prose/markdown KBs.** |
| **B. Separate git repo** (`~/knowledge`, gitignored vault) | Clean separation. Git history for KBs. No vault bloat. | Need new sync (clone/pull on each machine). No iPhone. Outside Obsidian search. | Worse than A for your use case. |
| **C. Dotfiles repo** | Already syncs everywhere. | Wrong tool — dotfiles is for config, not knowledge corpus. Will pollute commits. | No. |
| **D. iCloud Drive** | Built-in Apple sync. | No Linux/WSL. Not version-controlled. | No. |

**Recommendation: A.** Put `KNOWLEDGE/` at vault root. Use `.obsidian-livesync` exclusion for any `RAW/*.pdf` files larger than ~10MB if vault bloat becomes real (Smart Connections can also be told to skip RAW/). Markdown-heavy KBs (ADHD parenting, theatre, business systems) will be tiny.

For the rare KB that's PDF-heavy (e.g. legal docs for housing board), keep PDFs out of LiveSync — link to them in Reference/Attachments/ or store them on superbro and reference via path.

---

## What this looks like assembled (mental model)

```
~/Vaults/Christian/                    ← LiveSync, all devices
├── Daily Notes/                       ← your manual notes
├── Inbox/                             ← capture
├── Projects/                          ← your project notes (AKQA/Fiskars, Privat)
├── Reference/                         ← your reference notes
├── KNOWLEDGE/                         ← NEW: Karpathy KBs (the kit)
│   ├── CLAUDE.md                     ← top-level librarian rules
│   ├── shopify_themes_kb/            ← external knowledge re. Shopify dev
│   ├── adhd_parenting_kb/            ← books, papers, podcasts on ADHD
│   ├── housing_board_kb/             ← Grønnebakken docs, vedtægter, laws
│   └── ai_tooling_kb/                ← Claude Code, MCP, agent patterns
│
~/.claude/                             ← dotfiles-managed, all devices
├── hooks/                             ← Engram SessionStart/Stop sync
└── projects/<repo>/memory/MEMORY.md   ← Engram local index per repo

dotfiles/.claude/brain.md              ← per-repo working state, in repo
each-code-repo/.claude/brain.md        ← per-repo working state, in repo

Engram MCP (engram-personal, engram-work)
Graphiti MCP (superbro:8000)
```

Four layers, distinct roles:
- **Vault notes** = you write
- **KNOWLEDGE/** = Claude distills external sources you collect
- **brain.md / Engram / Graphiti** = Claude remembers work it did with you
- **Code** = the actual artifacts

---

## What to keep, what to retire, what to add

### Keep as-is

- **Engram personal + work** — session memory, code-anchored. Not redundant with KBs. Don't break this.
- **Graphiti** — temporal/relational. Already cross-machine via Tailscale. Best for *"how do these decisions relate over time"*.
- **brain.md** — per-repo state. Stays in each repo. Don't try to fold this into the vault.
- **Obsidian vault structure** — your existing Projects/Reference/Daily Notes is fine.

### Retire or de-emphasize

- **`Reference/Tech/` as ad-hoc dumping ground for articles you read.** Move those into the right `_kb/RAW/`. Keep Reference/ for your own structured notes (Hus, Familie, Lily, etc.) — the kit is for *external corpora*, not personal life logistics.

### Add

1. `KNOWLEDGE/` folder at vault root, populated from the kit.
2. Health-check skill installed in `~/.claude/skills/knowledge-base-health-check/` (extracted from the `.skill` zip).
3. One scheduled task: monthly health check via the `schedule` skill.
4. One adapter rule in `~/.claude/CLAUDE.md` (or vault `CLAUDE.md`): *"When user references a topic that has a `_kb`, query the KB first before answering."*

---

## Required adaptations for *your* setup (not the kit's defaults)

The kit assumes Anthropic's CoWork product. You're on Claude Code + dotfiles + LiveSync. Concrete fixes:

| Kit assumes | You need instead |
|---|---|
| `computer:///path/to/file.md` clickable links | `obsidian://open?vault=Christian&file=KNOWLEDGE/<kb>/Outputs/<file>` URIs — these *do* open in Obsidian on click. |
| CoWork's `schedule` skill | You have a `schedule` skill in Claude Code (confirmed). Use it. Fallback: launchd plist on Mac, cron on Linux. |
| `knowledge-base-health-check-skill.skill` (binary zip) | Extract `SKILL.md` to `~/.claude/skills/knowledge-base-health-check/SKILL.md` so it's pickable by Claude Code's skill system. |
| Single-machine workspace | All `_kb` folders in vault root → free LiveSync. |
| English-only | Your vault is bilingual (Danish for personal, English for work) — kit's writing rules need a tweak: language per KB, not global. |
| One global writing-rules file at `ABOUT ME/writing-rules.md` | You have writing rules at `~/.claude/agent-style/`. Either symlink or point the kit's `CLAUDE.md` at agent-style. |

---

## Implementation plan (incremental, low-risk)

Don't do this all at once. Six steps, each independently valuable.

### Step 1 — Drop the kit into the vault (10 min, reversible)

```bash
cd ~/Vaults/Christian
mkdir -p KNOWLEDGE
cp ~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/KNOWLEDGE/CLAUDE.md KNOWLEDGE/
cp ~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/KNOWLEDGE/_KB_CLAUDE_TEMPLATE.md KNOWLEDGE/
cp ~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/KNOWLEDGE/_SCHEDULED_TASK_TEMPLATE.md KNOWLEDGE/
```

Edit `KNOWLEDGE/CLAUDE.md`:
- Replace `computer://` link convention with `obsidian://` URI scheme.
- Point writing rules at `~/.claude/agent-style/RULES.md` instead of `ABOUT ME/writing-rules.md`.
- Add a note: "Personal-topic KBs are Danish; work-topic KBs are English."

### Step 2 — Install the health-check skill (5 min)

```bash
cd /tmp
unzip ~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/KNOWLEDGE/knowledge-base-health-check-skill.skill
mkdir -p ~/.claude/skills/knowledge-base-health-check
cp knowledge-base-health-check-skill/SKILL.md ~/.claude/skills/knowledge-base-health-check/
```

Then add to `dotfiles/modules/skills/` so it sync's to LinuxBro/SuperBro/MonsterBro on next `dotfiles --update`.

### Step 3 — Spin up *one* real KB to validate the pattern (30 min)

Pick a topic you've actually been collecting on. **Recommended first KB:** `ai_tooling_kb` — you have lots of MCP/Claude Code/agent-pattern material already scattered across `Reference/Tech/`, Inbox, screenshots, and downloads.

Tell Claude: *"Spin up a knowledge base for AI tooling — focus areas: MCP servers, Claude Code workflows, agent patterns, knowledge management."*

Drop 3-5 sources into `KNOWLEDGE/ai_tooling_kb/RAW/`. Say "compile". Inspect the resulting wiki and outputs. If it feels good, continue. If not, you've spent 30 min — kill it.

### Step 4 — Set up the monthly health check (5 min, one-time)

After Step 3 succeeds, ask Claude: *"Set up the knowledge base monthly health check."* It will use the existing `schedule` skill. Cron: `0 9 1 * *`.

### Step 5 — Migrate accumulated articles (ongoing, low-pressure)

You have material in `Reference/Tech/`, downloads, screenshots, and Inbox that belongs in `_kb/RAW/`. Don't do this in one pass — move things over **as you encounter them**. The kit will compile them on next "compile" call.

### Step 6 — Wire the KB pointer into your global CLAUDE.md (5 min)

Add to `~/.claude/CLAUDE.md` keyword dispatch table:

```markdown
| Signal | Action |
|---|---|
| "what do my sources say about X" / "compile" / "ingest this article" | Check `~/Vaults/Christian/KNOWLEDGE/` for relevant `_kb`, follow KB protocol |
```

That's it. Once `KNOWLEDGE/CLAUDE.md` exists in the vault, *any* Claude Code session at vault root or in a subdir will pick it up via the existing `@` import mechanism if you reference it.

---

## Open questions you should answer before committing

1. **Are you actually collecting external sources, or is most of your "knowledge" code/work-anchored?** If 90% of what you want to remember is "decisions I made while building X", the KB pattern adds overhead for low return. Engram + brain.md may be enough. Be honest about this — the kit shines when you read books/papers/podcasts, not when you ship code.

2. **How many KBs do you realistically maintain?** 1-3 is fine. 10+ becomes a maintenance burden even with the health-check skill. Resist the temptation to spin up `_kb` folders for every passing interest.

3. **Are you willing to do the "compile" prompt regularly?** The kit is not zero-touch. Sources don't process themselves. If you don't say "compile" weekly, RAW grows and Wiki goes stale. This is the discipline cost.

4. **Do you want claims auto-promoted into the Wiki, or only on your approval?** The kit's default is "active librarian, leaning aggressive". You can dial this down per-KB. For sensitive topics (housing board law, parenting decisions), make the librarian conservative.

---

## What I'd do if I were you

`[Likely]` Do Steps 1-3 today. Sink 30 minutes into `ai_tooling_kb` with 3-5 sources you already have. Validate the loop end-to-end: drop → compile → query → read the report → trace a claim back to RAW. If that loop *feels* better than asking Engram, the pattern is worth keeping. If it feels like ceremony, kill it.

`[Likely]` Do **not** retire Engram or Graphiti. Your real complaint about them — opacity, repo-scoping — is mostly a UX problem solved by also having a layer with browsable files. Once `KNOWLEDGE/` exists, Engram becomes "the auto-captured layer" and the KB becomes "the curated layer" and they stop feeling redundant.

`[Guessing]` In 3 months you'll have 2-4 active KBs (ai_tooling, parenting, housing_board, maybe theatre or hus). You'll touch each one weekly-ish. The monthly health check will do most of the maintenance. The query reports in `Outputs/` will become the most-read part of your vault.

---

## References

- Kit source: `~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/`
- Karpathy original: x.com/karpathy/status/2039805659525644595
- Walkthrough video: youtu.be/ib74sLgjIBM
- Your vault CLAUDE.md: `~/Vaults/Christian/CLAUDE.md`
- Engram routing: `~/.claude/CLAUDE.md` (memory routing section)
- Graphiti config: `~/.dotfiles/.claude/mcp-servers.list`

## Health-check skill — what it actually does

Read the unzipped `SKILL.md`. Useful bits worth pulling out:

- **Skip-if-no-changes precondition.** If top `CHANGELOG.md` entry is itself a health check, skill writes "skipped" and exits. Zero token waste when nothing happened. Good.
- **Delta vs full audit.** Default = delta (only articles modified since last check + 3 random samples). Quarterly (Jan/Apr/Jul/Oct 1st) = full audit of every article. Scales as KBs grow.
- **Auto-fixes in place** — writing-rules swaps, broken backlinks, RAW registration of orphan files (only if frontmatter valid + topic fits Focus Areas), `emerging → established` promotion when ≥2 independent sources back a claim, contradiction cross-references (does NOT reconcile — embraces both positions, logs to QUESTIONS.md under "Held tensions"). Em-dash bullet `**Term** —` rewritten to `**Term:**` — useful agent-style fix.
- **Auto-drafts up to 3 new articles per run** from three streams: orphan refs mentioned in ≥3 articles, output syntheses not yet in wiki, held tensions worth own treatment. Default Status `emerging`. Cites RAW. Skips if evidence thin (logs "candidate held" — refuses to fabricate). Direct hit on your "knowledge propagate naturally" wish.
- **Flag-only bucket** (never auto-actioned) — out-of-scope RAW, output→wiki promotion candidates, stale rewrites that'd change voice, banned-word swaps where right replacement is non-obvious. Logged to CHANGELOG pending bucket.
- **Scheduled task pattern** — one parent agent reads `KNOWLEDGE/`, lists active KBs (any subfolder with `CLAUDE.md`), spawns one general-purpose sub-agent per KB **in parallel**, each in its own context window. Token use scales linearly per KB, not quadratically. Cron `0 9 1 * *`. Each sub-agent returns one-line summary; parent prints aggregate report.
- **"Action the latest health check" trigger** — re-reads top CHANGELOG entry's pending bucket and walks user through numbered options. Uses plain numbered list, not `AskUserQuestion` (cross-platform).

**Adapt for your setup:**
- Replace `general-purpose` sub-agent type with `Explore` for read-heavy passes, `claude` for the write step. Cheaper.
- Use your `schedule` skill (confirmed present) to install the cron. Fallback: launchd plist on Mac at `~/Library/LaunchAgents/com.user.kb-health-check.plist`.
- Skill triggers `obsidian://` URI for any CHANGELOG/Outputs links (your env, not CoWork's `computer://`).
- WSL/MonsterBro: same cron, same vault path (LiveSync). Don't run on multiple machines simultaneously — pick one (Mac) as canonical scheduler or you'll race-condition the CHANGELOG.

---

## Automation — kill the .wrap OCD

This is the more important problem. You called it: pseudo-OCD wrapping, anxiety that knowledge will be lost if you don't ritualize. Let me be direct.

### Root cause (uncomfortable truth)

`~/.claude/hooks/wrap-reminder.sh` is the trigger. Every 25 turns it prints *"run .wrap to save context before it bloats"* as a system message. That hook is **manufacturing** the OCD loop. You see the nudge, you wrap, you feel safe for 25 turns, you see the nudge again. The hook trained you into the ritual.

`[Certain]` Disable it. Hooks should reduce anxiety, not generate it.

```bash
# Either delete the wrap-reminder block from settings.{darwin,linux,wsl}.json,
# or rename the script so it's never invoked:
mv ~/dotfiles/.claude/hooks/wrap-reminder.sh ~/dotfiles/.claude/hooks/wrap-reminder.sh.disabled
```

### What's already automatic (you may not realize)

You already have a passive-capture pipeline. The pieces:

| Hook | When it fires | What it does |
|---|---|---|
| `engram-on-prompt.sh` | UserPromptSubmit | Injects pending-commit queue into context, **tells Claude to mem_save BEFORE handling new prompt** |
| `engram-on-stop.sh` | Stop (end of every turn) | Scans for new commits since last stop, appends to pending queue |
| `engram-sync-start.sh` | SessionStart | Pull Engram state from canonical host |
| `engram-sync-stop.sh` | Stop | Push Engram state to canonical host |
| `brain-load.sh` | SessionStart | Read repo's `brain.md` into context |
| `brain-save-inject.sh` | PreCompact | Re-write `brain.md` before harness compacts conversation |

`[Certain]` Memory captures itself when you commit. Sync runs every session. brain.md re-writes before compaction. `.wrap` is **already redundant** for the 90% case. You just don't trust it because the wrap-reminder hook is gaslighting you.

### What's missing — fill these gaps, then stop wrapping manually

Three real gaps. Each is a small hook.

**Gap 1 — Engram passive save on every Stop, not just commits.**
`engram-on-stop.sh` currently triggers only when commits land. Significant non-commit work (long debugging session, design discussion, no file changes) gets lost. Fix: extend Stop hook to call `mem_capture_passive` with the turn's transcript when conversation depth > N turns AND no commit fired. Engram's `mem_capture_passive` is the right tool — it exists, it's listed in available tools.

**Gap 2 — KB auto-compile trigger.**
Right now you have to say "compile". Add a hook (UserPromptSubmit or a SessionStart check) that:
- Scans `~/Vaults/Christian/KNOWLEDGE/*/RAW/` for files newer than each KB's last `CHANGELOG.md` entry.
- If any found AND user's prompt mentions a KB topic, prepend system message: *"Unprocessed sources in `<kb_name>/RAW/`. Compile before answering?"*
- One-line decision, not a wrap ritual.

**Gap 3 — Cross-machine knowledge handoff.**
You worry knowledge dies between machines. It mostly doesn't (Engram sync hooks, LiveSync vault, Graphiti on Tailscale). But: brain.md is **per-repo, per-machine** — if you work on dotfiles on Mac then MonsterBro, brain.md is current only if you committed and pulled. Solution: existing pre-commit hook already snapshots devices. Trust it. If you really want, add a Stop hook that auto-commits `.claude/brain.md` when it changed.

### The OCD-killing principle

Pick **one** save trigger per type of knowledge. More is anxiety, not redundancy.

| Knowledge type | Single canonical trigger | Manual fallback |
|---|---|---|
| Repo state | `brain-save-inject.sh` on PreCompact | none — trust the hook |
| Decisions/bugs/conventions | `mem_save` during work (model proactive-save rule) | `.remember` if model misses something obvious |
| External corpus | `compile` when you drop new RAW | health-check skill monthly |
| Session summary | Engram Stop hook + LiveSync vault | none — let it accumulate, you don't re-read most of them |

**Stop wrapping manually.** The hooks are doing the work. If you ever lose knowledge despite the hooks, that's a hook bug worth fixing — not a reason to ritualize.

### Realistic automation roadmap (3 hooks, ~1 hour total)

1. **Disable `wrap-reminder.sh`** — 1 min. Single biggest anxiety reducer.
2. **Extend `engram-on-stop.sh`** to call `mem_capture_passive` on long no-commit turns — 20 min. Closes the "lost in chat" failure mode.
3. **Add `kb-compile-nudge.sh`** UserPromptSubmit hook — 30 min. Watches `KNOWLEDGE/*/RAW/`, prepends one-line nudge when stale sources match the active prompt's topic. Soft trigger, not a system message every 25 turns.

After those three, you should not need `.wrap` for normal work. Reserve `.bye` only for end-of-day cleanup if you genuinely want a written summary in the vault — and only because *you want it*, not because Claude needs it.

### What I'd cut from your current setup

- `wrap-reminder.sh` — anxiety pump. Kill.
- `.bye` / `.wrap` as default flow — keep the skill, demote to opt-in.
- Manual `.remember` after every decision — you have the proactive-save rule in Engram's system prompt. Trust it. Only intervene when Claude visibly misses.

---

## Updated reference list

- Kit source: `~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/`
- Extracted skill: `~/Downloads/Claude-CoWork-Knowledge-Base-Kit_v1/KNOWLEDGE/knowledge-base-health-check-skill/SKILL.md`
- Karpathy original: x.com/karpathy/status/2039805659525644595
- Walkthrough video: youtu.be/ib74sLgjIBM
- Your vault CLAUDE.md: `~/Vaults/Christian/CLAUDE.md`
- Engram routing: `~/.claude/CLAUDE.md` (memory routing section)
- Existing hooks: `~/dotfiles/.claude/hooks/`
- Wrap-reminder (anxiety source — disable): `~/dotfiles/.claude/hooks/wrap-reminder.sh`

---

## Alternative — vault as cross-project brain (your preferred shape)

You said the part that matters: light on RAW, heavy on **fast lookup + cross-project awareness**. Karpathy KB is overbuilt for that. Here's the lean version.

### Idea

`brain.md` stops being per-repo. Move it into the vault as one file per project under `Brains/`. LiveSync handles cross-machine. Vault becomes the single brain — Engram stays as Claude's auto-capture layer behind it.

### Shape

```
~/Vaults/Christian/Brains/
├── INDEX.md                 ← one-line summary per project, grep target
├── dotfiles.md              ← current state, open decisions, gotchas, next steps
├── fiskars.md               ← Shopify client work
├── grønnebakken.md          ← housing board
├── stellar-shopify.md
├── homelab.md               ← superbro / linuxbro stacks
├── monsterbro.md            ← WSL setup state
└── _shared/
    ├── conventions.md       ← cross-project (commit style, naming, hooks)
    ├── infrastructure.md    ← Tailscale, MCPs, sync mechanisms
    └── people.md            ← Sofie, Lily, colleagues, stakeholders
```

Each brain file = same shape as current `brain.md`. Frontmatter + sections: Current State / Open Decisions / Gotchas / Next Steps. Capped ~200 lines per file. Old state → Archive/.

### Why this beats per-repo brain.md

- **Cross-project lookup** — "what did I decide on dotfiles when I worked on Fiskars?" → grep `~/Vaults/Christian/Brains/`. One command, all projects.
- **No git ceremony** — brain doesn't sit in the code repo. Committing/pulling code doesn't entangle brain updates. LiveSync pushes within seconds.
- **iPhone access** — see project state from phone via Obsidian mobile. Per-repo brain.md can't do that.
- **Token-cheap reads** — `grep -l` then targeted Read. Engram returns prose, vault returns exact lines. For "what did I write about X" lookups, vault wins.
- **No infrastructure** — no Neo4j, no CouchDB pivot, no new MCP. Files + LiveSync (already running).

### How it works in practice

**SessionStart hook** (replace `brain-load.sh`): detect project from `$PWD`, look up `Brains/<project>.md` + `Brains/_shared/*.md`, inject into context. Cap at ~3k tokens — caveman compress if larger.

**Stop hook** (extend `brain-save-inject.sh`): write back to `Brains/<project>.md` instead of repo-local `.claude/brain.md`. Project name resolution: `$PWD` → known mapping (you have ~6 projects, hardcode the table).

**Cross-project query trigger** — when user says *"how does X relate to Y"*, *"compare projects"*, *"what's running where"* → `grep -l "<term>" ~/Vaults/Christian/Brains/` then Read matching files. Already in your CLAUDE.md routing table ("what do I have on X" → grep vault). Just point it at `Brains/`.

**INDEX.md** — one-line summary per project, manually maintained or auto-refreshed weekly. Acts as the "what projects exist" map. Cheap to read every session start.

### Where Engram and Karpathy KB still earn their keep

- **Engram** = the auto-capture layer. Vault brain is what Claude *writes intentionally*; Engram is what Claude *notices passively*. When Engram has more than vault brain on a topic, Stop hook can suggest promoting it.
- **Karpathy KB** (`KNOWLEDGE/`) = only for genuine external corpora. If you ever want to ingest a stack of papers on ADHD or housing law, that pattern stays available. Until then, don't build it. Drop the kit folder *without* spinning up KBs. Cost: zero.

### Migration (minimal)

1. `mkdir ~/Vaults/Christian/Brains` + create `INDEX.md` and `_shared/` subfolder.
2. Copy current `dotfiles/.claude/brain.md` → `Brains/dotfiles.md`. Add frontmatter.
3. Rewrite `brain-load.sh`:
   - Map `$PWD` → project slug via a small case statement.
   - Read `~/Vaults/Christian/Brains/<slug>.md` + every file in `Brains/_shared/`.
   - Output as additionalContext.
4. Rewrite `brain-save-inject.sh` to target vault path, not repo path.
5. Delete repo-local `.claude/brain.md` files. They'll regenerate empty if hook misfires.
6. Add to vault `CLAUDE.md`:
   ```
   ## Brains
   ~/Vaults/Christian/Brains/<project>.md — one per project, plus _shared/ for cross-cutting.
   Grep here for "what do I know about X across projects".
   ```

### Tradeoffs (the honest part)

| Win | Cost |
|---|---|
| Cross-project grep | Brain no longer travels with repo clone — new dev cloning your dotfiles doesn't get the brain. (Likely fine: brain is *for you*, not collaborators.) |
| LiveSync cross-machine | Vault must be present + synced before Claude session starts. If LiveSync paused/broken, brain is stale. Engram backup mitigates. |
| iPhone access | Brain edits from phone could conflict with hook writes. Mitigation: hook checks mtime, prompts before overwriting if vault is newer. |
| Single grep target | Sensitive client info now in personal vault (already true for vault notes — just keep doing what you do). |

### Recommendation

`[Likely]` This shape matches your stated preference better than the Karpathy KB. Do this as Track B' instead of pure automation:

- **Track A — KB layer** — optional. Defer until you have a real external-corpus need. Just drop the kit folder ready to spin up later.
- **Track B' — Vault brain** — today, 30 min. Migrate dotfiles brain first, prove the loop, then migrate others as you touch them.
- **Track C — Disable wrap-reminder** — 1 min, do alongside B'.

The Karpathy KB stays available but unbuilt until you actually have papers to ingest.

---

## Grilling the vault-brain idea

I'd ship it. But here's where it cracks under stress:

### Real failure modes

1. **LiveSync conflict-on-write.** Hook writes `Brains/dotfiles.md` on Mac at same second phone edits it via Obsidian mobile. CouchDB resolves with last-write-wins per field — silent data loss possible. **Mitigation:** Stop hook reads vault mtime first; if newer than session start, write `Brains/dotfiles.conflict-YYYYMMDD-HHMM.md` instead and surface to user next session.

2. **No project boundary = leakage.** Single grep target means client-confidential bits (Fiskars passwords, AKQA internal links) sit next to personal stuff. Vault is already on superbro CouchDB — fine for you, **not fine if work asks where notes live**. Mitigation: don't put client secrets in vault brain, keep those in `_shared/infrastructure.md` with explicit *"local-only, do not sync to mobile"* tag (LiveSync per-file exclude).

3. **`$PWD` → project resolution breaks.** Run Claude from `~`, from a tmpfile dir, from a worktree — no project match → wrong brain or none. Mitigation: explicit `.claude/project-slug` file at repo root as override; fall back to `$PWD` mapping; final fallback = read INDEX + ask.

4. **Brain file rot.** `Brains/dotfiles.md` will balloon over months. No compaction trigger. Mitigation: cap at 200 lines via PreCompact hook — anything older moves to `Brains/archive/dotfiles-YYYY-Q.md` (still grep-reachable).

5. **Engram drift vs vault truth.** Two writers, same topic, no reconciliation. Engram says X, vault brain says Y, you trust vault, Engram still returns X to next session. Mitigation: weekly cron — `mem_search` per project topic, diff vs `Brains/<project>.md`, flag divergence in INDEX.md "Drift" section. Cheap.

6. **Cross-machine `_shared/` is dangerous.** Edit `_shared/conventions.md` on Mac while WSL session has it open → conflict. Worse than per-project conflicts because every session reads `_shared/`. Mitigation: treat `_shared/` as **read-mostly**. Hook never writes there automatically. You curate manually.

### What I'd cut from the proposal

- **`Brains/_shared/people.md`** — overkill. Already in Engram. Don't double-store soft data.
- **INDEX.md auto-refresh weekly cron** — premature. Keep manual until vault has >10 brain files.

---

## Vault audit + improvement plan

Scanned vault. Findings, ranked by impact.

### Hard truths

| Finding | Evidence | Why it matters |
|---|---|---|
| **Graph view is dead** | 94 files, 28 total `[[links]]` → **0.3 links/file avg**. Most files isolated. | Obsidian graph = noise without backlinks. Brains/ won't fix this unless every brain links to related project/reference notes. |
| **Daily notes abandoned** | Last Daily Note `2025-12-04`. Today = `2026-06-12`. 6-month gap. | Periodic Notes plugin doing nothing for you. Either kill the habit or fix the friction. Half-running is worst case. |
| **Duplicate Fiskars folders** | `Projects/Fiskars/` AND `Projects/AKQA/Shopify/Fiskars/` both exist. | Two-folder drift = which is canonical? Pick one before Brains/fiskars.md points at the wrong path. |
| **Tag frontmatter sparse** | Only ~5 unique `tags:` lines across vault. | Tag → folder routing in `CLAUDE.md` is unused. Either enforce or remove the routing table. |
| **Reference/Vault and Reference/Homelab look like project state** | They describe systems, not durable knowledge. | These belong in `Brains/` once you build it. |

### Improvement plan (small, high-leverage)

**1. Backlink hygiene — the graph fix.**
Every brain file links to at least 2 related notes. Every project note links to its brain. Add agent-rule to `CLAUDE.md`: *"When writing/editing any vault file, add `[[backlinks]]` to ≥1 related note where one exists."* Cheap, compounding.

**2. Resolve Fiskars duplication.**
Canonical = `Projects/AKQA/Shopify/Fiskars/`. Move/merge `Projects/Fiskars/` contents in. Add redirect note at old path: `→ moved to [[Projects/AKQA/Shopify/Fiskars/index]]`. Same audit for other near-duplicates.

**3. Daily Notes — decide.**
Either: (a) kill it, remove from Periodic Notes plugin, accept Brain/Inbox as capture; or (b) reduce template to **1 line** (top of brain dump) so friction → zero. The current abandoned half-state is the worst.

**4. Move project-state notes out of Reference/.**
`Reference/Homelab & VPS/*` and `Reference/Vault/*` describe *current state* → move to `Brains/homelab.md` and `Brains/vault-itself.md`. Reference/ stays for **durable** knowledge (Hus papers, Lily school info, Familie contacts).

**5. Add MOCs (Maps of Content), not more folders.**
Three index files at vault root:
- `MOC-Projects.md` — links to every active project's brain + key notes
- `MOC-Reference.md` — links into Reference/ subtree
- `MOC-Ideas.md` — links to every Ideas/ subfolder

MOCs are the spine the graph view actually shows. Folders ≠ graph; links = graph.

**6. Templates folder hygiene.**
Audit `Templates/`. Anything not used in last 90 days → archive. Templates that don't auto-populate via Templater = friction.

**7. Inbox triage rule.**
8 files in Inbox is fine now. Set ceiling: 15. When exceeded, auto-prompt at session start to triage. Hook: `inbox-cap.sh` UserPromptSubmit, prints one-line nudge when `ls Inbox/ | wc -l > 15`.

**8. Two-letter folder naming convention (optional).**
You're not there yet, but worth knowing: PARA-style numeric prefixes (`1-Projects/`, `2-Areas/`, `3-Resources/`, `4-Archive/`) keep top-level stable as vault grows. Your structure is already PARA-shaped, just unprefixed. Skip unless you hit 200+ files.

### Anti-jungle rules (paste into vault `CLAUDE.md`)

```markdown
## Vault hygiene rules

1. No new top-level folders without explicit ask.
2. Every new note has frontmatter: date, tags (≥1), and ≥1 [[backlink]] where applicable.
3. Brains/ = current state. Reference/ = durable knowledge. Don't mix.
4. Project state notes live in Brains/, NOT Reference/.
5. Before creating a note, grep first — append to existing if same topic.
6. MOC files (`MOC-*.md`) at vault root are the navigation spine. Update when adding major notes.
7. Inbox cap = 15 files. Triage before adding more.
8. Daily Notes are optional. If template > 5 lines, it's wrong.
```

### Recommended action order

| Order | Task | Time |
|---|---|---|
| 1 | Resolve Fiskars duplication | 5 min |
| 2 | Decide Daily Notes fate (kill or simplify) | 2 min |
| 3 | Migrate dotfiles brain to `Brains/dotfiles.md` (Track B' from above) | 20 min |
| 4 | Move Reference/Homelab + Reference/Vault → Brains/ | 5 min |
| 5 | Create 3 MOCs at vault root | 10 min |
| 6 | Add hygiene rules to vault CLAUDE.md | 2 min |
| 7 | Backlink hygiene — retroactive, do as you touch files | ongoing |

Total today: ~45 min. Vault stops being a jungle before it becomes one. 94 files is the right time — at 500 files this is twice the work.

---

## Inbox + AI librarian (borrowing from RAW)

Strong idea. Different from Karpathy RAW — your own notes, not external sources. Closer to **GTD inbox + LLM triage**.

### Shape

```
~/Vaults/Christian/Notes/        ← rename Inbox? See below.
├── 2026-06-12-13-22-random-thought.md
├── 2026-06-12-14-05-meeting-grab.md
└── ...
```

Drop notes free-form. Frontmatter optional. No worrying about routing, tags, backlinks. **Friction = zero**, which is the whole point.

Librarian pass — AI reads each note and:
1. Adds frontmatter (date, tags, type guess)
2. Extracts entities → adds `[[backlinks]]` to existing notes that match
3. Routes to correct folder per your tag-routing table (`#work/fiskars` → `Projects/AKQA/Shopify/Fiskars/`, etc.)
4. Promotes durable knowledge to `Reference/` or `Brains/` if pattern clear
5. Logs everything to `Notes/_LIBRARIAN.md` so you audit

### Naming — `Inbox/` vs `Notes/`

Keep **`Inbox/`**. Already exists. Name signals *"transient, will be processed"* — `Notes/` is ambiguous (could mean permanent). Don't rename a working folder for cosmetic reasons.

### Trigger options

| Option | When | Cost | Best for |
|---|---|---|---|
| **Manual via Claude Code** — say "librarian pass" at vault session | When you remember | Free, uses your Claude tokens | Daily/weekly batches |
| **Local Ollama cron** — nightly script processes Inbox/ via ollama (qwen2.5:7b or similar) | 3am daily | Free, slow, lower quality routing | Hands-off, OK with imperfect tags |
| **Huskr** (you said you have this) | Whatever Huskr does | Already built | If it works, use it |

`[Likely]` Hybrid: **Ollama nightly for frontmatter + tag suggestion** (cheap, mechanical), **manual Claude pass for routing decisions** (judgement calls). Don't auto-route via Ollama — small models will misfile. Suggesting tags is safe; moving files is risky.

### Librarian skill (new)

Tiny skill, ~50 lines:

```markdown
# inbox-librarian skill

For each file in $VAULT/Inbox/ older than 24h:
1. Read file.
2. Suggest: tags, type, target folder per CLAUDE.md routing table.
3. Extract entities, grep $VAULT for matches → propose backlinks.
4. Show user: "filename — tags [X,Y] → move to <folder>? (y/n/skip)"
5. On y: rewrite with frontmatter, add backlinks, move file. Log to _LIBRARIAN.md.
6. Never delete. Never edit body text. Never auto-route without confirm.
```

Boundaries: librarian touches frontmatter + filename + location. Never edits body. Friction stays at zero for capture.

### How this differs from your existing Huskr

`[Guessing]` (haven't seen Huskr code) — if Huskr is one-shot "process this note now", librarian is "batch-process Inbox/ with sit-back-and-confirm flow". Different ergonomics. Both can coexist — Huskr for inline, librarian for backlog.

### Cron caution

If you wire Ollama cron, **dry-run mode only for first 2 weeks**. Write suggestions to `Inbox/_SUGGESTIONS.md`, don't mutate notes. Trust the model after you've audited 50+ suggestions.

---

## Single vault vs multiple

Quick answer: **stay single**. Don't split.

### Why split is tempting (and wrong for you)

- Mixed Danish/English looks messy in graph search results
- Work-vs-private compliance worry
- Mental clean-separation appeal

### Why single wins for your setup

1. **Brains/ design depends on single grep target.** "How does X relate across projects" breaks if half projects live in another vault.
2. **94 files is too small to split.** Split overhead (two LiveSync configs, two CLAUDE.md, two MCP setups, two hook configs) outweighs any benefit until ~500+ files.
3. **Bilingual is a non-problem in Obsidian.** Search handles it. Tags handle it. Folder-based language routing (already in your vault CLAUDE.md) is enough.
4. **Cross-context value is the killer feature.** Realizing your Shopify Liquid pattern applies to Grønnebakken's web setup, or that the homelab DNS bug mirrors a Fiskars cache issue — only happens in a single graph.
5. **Hook config doubles.** `brain-load.sh` needs to know which vault per project. Per-machine `$VAULT` resolution gets messier.

### When to reconsider

Split off a **dedicated work vault** only when:
- AKQA/client legal explicitly requires it (NDA, GDPR, data-residency)
- Vault crosses ~500 files AND ≥60% is work
- LiveSync performance degrades (irrelevant at your scale)

None of those hold now. Single vault, bilingual, with strong tag discipline.

### Optimization without splitting

If you want sharper separation **inside one vault**:

```
~/Vaults/Christian/
├── Work/                ← move Projects/AKQA into here (EN)
│   └── Fiskars, AKQA-internal, …
├── Privat/              ← move Projects/Privat, Daily Notes (DA)
│   └── Grønnebakken, family, hus, lily
├── Brains/              ← cross-project state (mixed lang per file)
├── Reference/           ← durable knowledge (mixed lang per topic)
├── Inbox/               ← capture (any lang)
└── …
```

Two top-level folders signal context cleanly. Graph still single. Hook config single. Grep still works across both. **`[Likely]` recommended optimization** — fold `Projects/` into `Work/` + `Privat/` as part of the Track B' migration. 10 minutes extra.

---

## Next step

Three parallel tracks:

**Track B' — Vault brain (today, 30 min, RECOMMENDED FIRST):** Create `~/Vaults/Christian/Brains/`, migrate `dotfiles/.claude/brain.md` → `Brains/dotfiles.md`, rewrite `brain-load.sh` + `brain-save-inject.sh` to target vault. Closest match to how you actually work.

**Track C — Disable wrap-reminder (today, 1 min):** Single biggest anxiety cut. `mv ~/dotfiles/.claude/hooks/wrap-reminder.sh{,.disabled}`.

**Track A — KB layer (deferred):** Drop `KNOWLEDGE/` folder in vault ready to use, but don't spin up KBs until a real external-corpus need lands. Optional.

All reversible.
