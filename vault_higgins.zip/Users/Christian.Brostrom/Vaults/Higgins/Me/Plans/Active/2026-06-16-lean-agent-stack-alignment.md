---
created: 2026-06-16
area: [meta, dev]
type: plan
status: active
tags: [dotfiles, cursor, claude-code, brain, lean-ctx, rtk, context, models, mcp]
repo: dotfiles
---

# Plan: Lean Agent Stack + Cursor/CC Alignment

_Picked up from Cursor session 2026-06-16. User approved direction; execution deferred until Cursor aligned first._

## Goal

Strip context bloat. Lock Brain AI OS as the continuity layer. Remove lean-ctx + headroom. Standardise on **RTK + native tools + caveman + vault brain**. Bring Cursor in line with Claude Code. Slim `CLAUDE.md` and clarify model switching.

## Why now

- Context fills before meaningful work — lean-ctx MCP instructions, auto-checkpoints, stale cross-project session state, Cursor project MCP cache (17 servers), massive skills injection.
- Three compression layers overlap: **RTK** (shell hook), **lean-ctx** (MCP + shell aliases in `.zshrc`), **headroom** (unused MCP).
- Rules drift: CC `CLAUDE.md` says native Read default; lean-ctx MCP says ALWAYS use `ctx_*`; Cursor User Rules (cloud) still reference lean-ctx.
- `CLAUDE.md` is ~157 lines core + 4 `@` imports — heavy SessionStart payload on top of brain-load (~4k chars for dotfiles).
- Mid-fix MCP cull uncommitted; `settings.local.json` drift (`herdr-agent-state`, model mismatch).

## Locked decisions

| Topic | Decision |
|---|---|
| Continuity | Vault `Brains/<slug>/` + hooks (`brain-load`, `brain-optimise-cheap`, `brain-save-inject`) |
| Shell compression | **RTK** via `rtk-rewrite.sh` (CC only today) |
| Prose compression | **Caveman** (rules + plugin) |
| File reads / search | **Native Read, Grep, Bash** — no MCP replacement |
| lean-ctx MCP | **Remove** from `mcp-servers.list` + Cursor |
| lean-ctx shell hook | **Remove** from `.zshrc` (auto-on in agent sessions duplicates RTK) |
| headroom MCP | **Remove** — not used, adds MCP surface |
| Core MCP (always) | `github` only |
| Overlays | Opt-in via `DOTFILES_WORKFLOWS` (apple, memory, infra, work, developer) |
| Cursor rules source of truth | New `dotfiles/.cursor/rules/agent-stack.mdc` + slim cloud User Rules |
| CLAUDE.md | Slim core + load-on-demand dispatch files (Phase 3) |

## Rules map — who reads what

| Layer | Location | Git? | Tool | Notes |
|---|---|---|---|---|
| CC project memory | `dotfiles/.claude/CLAUDE.md` + `@` imports | Yes | Claude Code | Symlinked `~/.claude/CLAUDE.md` |
| CC hooks | `dotfiles/.claude/hooks/` | Yes | Claude Code | brain-load, RTK, effort-classifier, … |
| CC settings | `settings.base.json` → platform → override | Yes | Claude Code | `doctor.sh --fix` regenerates local |
| CC model | `settings.base.json` `"model"` | Yes | Claude Code | Currently `claude-sonnet-4-6` |
| Cursor model | `dotfiles/.claude/agent-core.json` | Yes | Cursor | Synced via `agent-core-sync.sh` → `cli-config.json` |
| Cursor MCP | `mcp-servers.list` → `~/.cursor/mcp.json` | Partial | Cursor | UI can re-enable removed servers |
| Cursor workspace | `dotfiles/.cursorrules` | Yes | Cursor | No-docs rule only today |
| Cursor User Rules | Settings → Rules UI | **Cloud** | Cursor | Caveman, lean-ctx block — edit manually |
| Vault brain | `Brains/<slug>/` | Yes (vault) | Both (CC hook; Cursor manual/skill) | Primary state |
| Zed | `.config/zed/rules` | Yes | Zed | Still has lean-ctx section — remove |

**Gap:** Cursor does not read `CLAUDE.md`, `RTK.md`, or CC hooks. Alignment requires `.cursor/rules/*.mdc` + MCP sync + User Rules edit.

---

## Phase 0 — Cursor alignment first (before dotfiles commit)

Do this in Cursor **before** running dotfiles changes, so the agent executing Phase 1 isn't fighting stale rules.

### 0.1 Cursor User Rules (Settings → Rules)

Remove entire `## lean-ctx MCP` section. Replace with:

```markdown
## Tool routing (Brain OS)
Default: native Read, Grep, Shell.
Never use lean-ctx or headroom — removed from stack.
CC: RTK compresses shell via hook. Cursor: native tools.
Continuity: vault Brains/<slug>/ — ask to load brain or use .brain show.
Prose: caveman mode (Danish default).
Code changes: outline first, wait for approval.
```

### 0.2 Cursor MCP (Settings → MCP)

Disable and remove: **lean-ctx**, **headroom**.

Optional cleanup: disable stale project MCPs not in current workflow (engram, graphiti, dockhand, tailwind, mermaid, apple-mcp, …) — match CC core = github only unless overlay active.

### 0.3 Restart Cursor

New chat in dotfiles repo. Confirm context meter lower at message 1.

### 0.4 Verify

- [ ] No `mcp__lean-ctx__*` or `mcp__headroom__*` tools in agent tool list
- [ ] Agent uses native Read/Shell, not ctx_*
- [ ] User Rules no longer mention lean-ctx

---

## Phase 1 — Dotfiles: remove bloat MCP + shell hook

### Files to edit

| File | Action |
|---|---|
| `.claude/mcp-servers.list` | Remove `lean-ctx` entry |
| `.claude/mcp-servers.macos.list` | Remove `headroom` block |
| `.claude/mcp-servers.server.list` | Update comment (no lean-ctx in base) |
| `.claude/CLAUDE.md` | Replace lean-ctx Read routing → RTK + native (see Phase 3 stub) |
| `.zshrc` | Remove lines 119–160 (lean-ctx shell hook + auto-on) |
| `.config/zed/rules` | Remove `## lean-ctx MCP` section |
| `.gitignore` | Remove `.lean-ctx/` entry |
| `modules/rust-tools/install.sh` | Remove lean-ctx install (or deprecate whole module) |
| `modules/rust-tools/module.sh` | Update description |
| `modules/rust-tools/status.sh` | Remove or repurpose |
| `scripts/install/bootstrap-server.sh` | Remove lean-ctx install step |
| `README.md` | Remove lean-ctx shell workaround section (or point to RTK) |

### New file

| File | Purpose |
|---|---|
| `dotfiles/.cursor/rules/agent-stack.mdc` | Versioned Cursor rule: Brain OS stack, native tools, no lean-ctx/headroom |

Suggested `agent-stack.mdc` frontmatter:

```yaml
---
description: Brain AI OS agent stack — RTK, native tools, vault brain. No lean-ctx/headroom.
alwaysApply: true
---
```

Body: 15–20 lines max — tool routing, brain continuity, caveman, approval workflow pointer.

### Commands after edit

```bash
cd ~/dotfiles
./modules/claude-settings/doctor.sh --fix
./scripts/agent-core-sync.sh
claude mcp remove lean-ctx --scope user 2>/dev/null || true
claude mcp remove headroom --scope user 2>/dev/null || true
./modules/mcp-servers/install.sh
```

### Verify

- [ ] `~/.claude.json` mcpServers keys = `["github"]` (plus any explicit overlays you keep)
- [ ] `~/.cursor/mcp.json` = github only (disable stragglers in UI if Cursor re-adds)
- [ ] `claude mcp list` matches lists
- [ ] New CC session: no lean-ctx MCP; RTK hook still rewrites git/grep
- [ ] `lean-ctx-status` → command not found or N/A (acceptable)

### Brain update

`.brain current` append to `Brains/dotfiles/current.md`:

- MCP core = github only
- lean-ctx + headroom removed
- Stack locked: RTK + native + caveman + vault brain

---

## Phase 2 — Finish interrupted MCP cull + settings drift

Uncommitted work from 2026-06-15 still open:

| File | State |
|---|---|
| `mcp-servers.developer.list` | Emptied (mermaid, tailwind, google-calendar removed) |
| `mcp-servers.apple.list` | google-calendar moved here |

### Tasks

- [ ] Commit developer + apple list changes with Phase 1
- [ ] Run `doctor.sh --fix` — resolve `herdr-agent-state.sh` SessionStart drift in `settings.local.json`
- [ ] Confirm merged SessionStart hooks: `brain-optimise-cheap` + `brain-load` (both intentional per modular brain)
- [ ] Restart CC — confirm context drop vs pre-cull baseline
- [ ] Update `Brains/dotfiles/next.md` — mark "Restart CC after MCP cull" done

---

## Phase 3 — Slim CLAUDE.md (model + context cost)

### Problem

`CLAUDE.md` loads every CC session:

```
@RTK.md
@agent-style/claude-code.md   ← index OK; full RULES.md load-on-demand
@coding-principles.md
@tools.macos.md
+ 157 lines tables (dispatch, memory, infra, planning, lean-ctx section)
+ brain-load injection (~30–60 lines modular)
```

Total SessionStart can exceed 8–12k tokens before first user message.

### Target architecture

```
.claude/CLAUDE.md          ← slim core (~40 lines): stance, caveman, push guard, pointers
.claude/dispatch/
  dot-commands.md          ← table only
  memory-routing.md        ← vault + engram rules
  infra-signals.md         ← dockhand, docker hosts
  tool-routing.md          ← RTK + native (locked)
@RTK.md                    ← keep (small)
@coding-principles.md      ← keep (small)
@tools.macos.md            ← platform-only via conditional? or keep
```

`CLAUDE.md` references dispatch files with `@dispatch/tool-routing.md` etc. — CC resolves `@` at load **unless** we move to load-on-demand via skill pointer (trade-off: model must Read when needed).

### Preferred slim core (keep in CLAUDE.md)

1. Advisor stance (7 bullets) — behavioural, high value
2. Caveman default + `.normal` escape
3. Push/publish whitelist (security)
4. Session start: brain hook + `.pick` fallback (3 lines)
5. Pointers: `@dispatch/*`, `@RTK.md`, settings-arch path
6. **No** infra tables, **no** project detection tables in core

### CLAUDE.md replacement for tool routing (locked text)

```markdown
# Tool routing (Brain OS — locked)
- Read / Grep / Glob / Shell: native tools always.
- CC shell: RTK via PreToolUse hook (automatic). Do not wrap manually.
- Cursor: native shell (no RTK hook today).
- Never use lean-ctx or headroom.
- Large files: Read with limit/offset; grep with head_limit.
- Vault: native Read on $VAULT paths; `ob open` only for Obsidian UI.
```

Remove entire `# Read tool routing (overrides lean-ctx default)` section.

### Acceptance

- [ ] SessionStart token estimate drops ≥30% (measure via CC verbose or `rtk gain` baseline)
- [ ] No lost behaviour: dot-commands still reachable via `@dispatch/dot-commands.md` or skill triggers
- [ ] Brain-load unchanged

Related vault note: [[Inbox/claude-md-nuggets]] — batch small CLAUDE tweaks there first.

---

## Phase 4 — Model switching (CC + Cursor)

### Current state (2026-06-16 audit)

| Surface | Config | Value | Drift |
|---|---|---|---|
| CC tracked | `settings.base.json` | `claude-sonnet-4-6` | — |
| CC generated | `settings.local.json` | `sonnet` | ⚠ doctor flags |
| Cursor synced | `agent-core.json` | `claude-4.6-sonnet-medium-thinking` | — |
| Cursor runtime | `~/.cursor/cli-config.json` | synced from agent-core | OK after sync |

### Principle: one canonical file per tool

| Tool | Canonical model config | Sync mechanism |
|---|---|---|
| Claude Code | `settings.base.json` → `"model"` | `doctor.sh --fix`; `/model` writes override — avoid |
| Cursor | `dotfiles/.claude/agent-core.json` → `model.cursor_model_id` | `agent-core-sync.sh` on merge + manual |

### Model switch procedure

**Claude Code:**

```bash
# 1. Edit tracked layer (not settings.local.json)
vim ~/dotfiles/.claude/settings.base.json   # "model" key
# 2. Regenerate
~/dotfiles/modules/claude-settings/doctor.sh --fix
# 3. New CC session
```

**Cursor:**

```bash
# 1. Edit canonical
vim ~/dotfiles/.claude/agent-core.json      # model.cursor_model_id + display_name
# 2. Sync
~/dotfiles/scripts/agent-core-sync.sh
# 3. Restart Cursor / new chat
```

**Both at once:** edit both files in one commit → doctor + agent-core-sync → restart both.

### Future improvement (optional)

- Add `agent-core.json` `"model": { "claude_code": "...", "cursor": "..." }` single struct
- `doctor.sh` reads CC model from agent-core OR documents explicit dual-edit
- Statusline hook shows active model + workflow overlays

Do **not** use `/model` in CC for permanent changes — writes ephemeral override that fights dotfiles.

---

## Phase 5 — Cursor brain parity (after stack stable)

CC auto-loads brain; Cursor does not.

Options (pick one when executing):

| Option | Effort | Fidelity |
|---|---|---|
| A. Manual: "load dotfiles brain" / `.brain show` | Zero | Low friction OK for now |
| B. `.cursor/rules/brain-session.mdc` — "on first message, Read Brains/<slug>/current+next" | Low | Medium |
| C. Cursor hook running `brain-load.sh` output | Medium | High — matches CC |

Recommendation: **B** for Phase 5 unless Cursor hooks mature — rule can invoke bash brain-load pattern without full hook infra.

---

## Execution order (when ready)

```
Phase 0  Cursor User Rules + MCP disable + restart     ← YOU, in UI
Phase 1  Dotfiles remove lean-ctx/headroom + .mdc rule ← agent / you
Phase 2  Commit MCP cull + doctor --fix                  ← same session
Phase 3  Slim CLAUDE.md + dispatch split               ← separate session
Phase 4  Model switch doc test (both tools)            ← verify procedure
Phase 5  Cursor brain parity rule                      ← optional
```

## Out of scope

- Re-installing culled MCPs (engram, graphiti, dockhand) — opt-in overlays only
- RTK hook for Cursor — future; native tools sufficient for now
- WSL vault path verification
- Plugin pruning (superpowers, compound-engineering) — separate plan

## Rollback

```bash
cd ~/dotfiles && git revert HEAD
./modules/claude-settings/doctor.sh --fix
./scripts/agent-core-sync.sh
# Re-enable lean-ctx in Cursor UI if needed
```

## Cross-references

- Modular brain: [[Plans/Active/2026-06-15-modular-brain]]
- Hooks/skills streamline: [[Plans/Active/2026-06-15-hooks-skills-streamline]]
- Brain state: [[Brains/dotfiles/current]]
- Vault routing: [[Development/Vault/Brain-System]]
- CLAUDE nuggets: [[Inbox/claude-md-nuggets]]

## Pickup prompt

When ready, open this plan in Obsidian and tell Cursor/CC:

> Execute Phase 0 (I'll do UI steps) then Phase 1 from [[Plans/Active/2026-06-16-lean-agent-stack-alignment]].
