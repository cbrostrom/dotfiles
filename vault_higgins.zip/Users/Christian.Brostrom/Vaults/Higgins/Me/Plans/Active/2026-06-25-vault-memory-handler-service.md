---
created: 2026-06-25
area: [meta, dev]
type: plan
status: active
tags: [vault, memory, knowledgebase, tauri, local-ai, byok, sync, automation, inbox, librarian]
---

# Plan: Vault Memory Handler Service

## Short Answer

Build this, but do not start with a full Tauri product.

The right architecture is a small local-first memory service with a CLI, daemon, and plain-markdown vault adapter first. Tauri becomes the desktop control surface once the capture and cleanup loops prove useful. That keeps the system efficient for personal use, while still leaving a path to a polished service with local AI, BYOK providers, sync, and optional agent adapters.

Tauri is not overkill for the long-term product. It is overkill for the first cut if it owns the core logic. The core should work headlessly from Cursor, shell hooks, cron/launchd, Raycast, Shortcuts, Obsidian, or mobile shares. Tauri should sit on top of that core, not become the core.

## Goal

Create a cross-platform memory handler for the vault, now referred to as the "vault", "brain", or "KB", that captures useful information automatically, stores it with provenance, and periodically organizes it into the existing vault structure.

The system should reduce the need to remember commands like `.mem`, `.brain`, or manual dotfile-specific capture commands. It should notice relevant context, capture it cheaply, and let a cleanup pass promote useful material into durable notes.

## Problem

Cursor and CLI agents obscure context. Useful decisions, gotchas, snippets, command results, and project state often exist only inside a chat transcript or terminal scrollback. Manual capture works only when the user remembers to run it, which is the exact failure mode the system should prevent.

Current vault direction already has the right principles:

- Single vault at `~/Vaults/Brain`.
- `Inbox/` as zero-friction capture.
- AI-managed notes with the human mostly as viewer.
- Confirm-before-move librarian flow.
- `Brains/<slug>/` for per-project current state.
- Plain markdown, not plugin-dependent rendering.

What is missing is the automatic bridge from work context into the vault.

## Product Shape

Working name: **Memory Handler**.

Possible product names later:

- Memory Handler
- Vault Memory
- KB Agent
- Recall Sink
- Local Memory Service

The product should feel like a quiet local daemon with a visible control panel. It captures things, classifies them, and asks for confirmation only when a decision actually matters.

## Recommendation

Build in four layers:

1. **Core library**
   - Owns capture records, classification, routing, dedupe, provider selection, and vault writes.
   - No UI assumptions.
   - Testable without Tauri.

2. **CLI**
   - Gives immediate utility.
   - Supports commands like `mem capture`, `mem inbox`, `mem cleanup`, `mem promote`, `mem doctor`.
   - Easy to call from Cursor hooks, shell aliases, Raycast, launchd, cron, Git hooks, and agent workflows.

3. **Daemon**
   - Runs locally.
   - Watches configured sources.
   - Queues captures.
   - Runs cheap cleanup automatically.
   - Defers semantic cleanup to scheduled or manual runs.

4. **Tauri app**
   - Provides tray icon, review queue, provider settings, sync status, source toggles, and cleanup approvals.
   - Should be added after the CLI/daemon prove the model.

This sequence keeps the product honest: if the core memory loop is valuable, Tauri makes it pleasant. If the loop is weak, a nice app would only hide that.

## Is Tauri Overkill?

For MVP: yes, if it is the starting point.

For the service: no. Tauri is a good fit once the system needs:

- Cross-platform desktop packaging.
- Tray/menu-bar capture.
- Background daemon management.
- Provider settings for local AI and BYOK.
- A review UI for proposed note moves.
- Secure key storage through OS keychains.
- Deep links into Obsidian/Cursor/files.
- Local file permissions with a native shell.

The main risk is letting Tauri drive the architecture. The app should be replaceable. The memory system should still work from a terminal on a headless Linux box.

## Architecture

### 1. Capture Sources

Start narrow. Add sources only when they are reliable.

MVP sources:

- Manual CLI capture: `mem capture "text"`.
- Stdin capture: `some-command | mem capture --source terminal`.
- File capture: `mem capture --file path/to/file.md`.
- Cursor/session capture through explicit hook integration.
- Clipboard capture only on manual trigger, not continuous monitoring.

V1 sources:

- Watch `Inbox/` for new raw notes.
- Browser share target or extension.
- Raycast/Alfred/Shortcuts integration.
- Obsidian command URI integration.
- Terminal session summaries.
- Git commit and PR summaries.

Later sources:

- OCR screenshots.
- Audio/voice notes.
- Calendar/meeting notes.
- Slack/Teams/email imports, only with explicit user opt-in.
- Agent transcript import.

### 2. Raw Capture Store

Every capture first becomes a raw event. Raw events should be append-only and safe to sync.

Recommended location:

```text
~/Vaults/Brain/.memory/
  queue/
    2026-06-25T1447-<id>.json
  processed/
    2026-06/
  state.sqlite
  logs/
```

Raw event shape:

```json
{
  "id": "ulid-or-uuid",
  "created": "2026-06-25T14:47:00+02:00",
  "source": "cursor|terminal|manual|clipboard|browser|obsidian|voice",
  "device": "macbook",
  "workspace": "/Users/Christian.Brostrom/Vaults/Brain",
  "repo": null,
  "title": "optional title",
  "body": "raw captured text",
  "metadata": {
    "command": null,
    "url": null,
    "app": null,
    "cwd": null
  },
  "status": "queued"
}
```

Why this matters:

- It preserves provenance.
- It makes cleanup idempotent.
- It prevents sync conflicts because devices append new files instead of editing the same file.
- It allows reprocessing if classification improves later.

### 3. Inbox Bridge

The vault already treats `Inbox/` as raw, no-frontmatter capture. Keep that contract.

The memory service should support two raw lanes:

- `.memory/queue/` for machine-readable event records.
- `Inbox/` for human-visible raw notes.

Rules:

- Do not add frontmatter to notes while they are in `Inbox/`.
- Do not auto-route human-visible notes without confirmation.
- Machine captures can be classified automatically, but durable note writes should remain reviewable until confidence is high.

### 4. Classification

Classification should be staged:

1. **Cheap deterministic pass**
   - Source, path, repo, hashtags, file names, and known project slugs.
   - No AI call.
   - Runs immediately.

2. **Small local model pass**
   - Local summarization and routing hints.
   - Good for privacy-sensitive notes.
   - Should be optional and provider-configurable.

3. **BYOK provider pass**
   - User-provided OpenAI, Anthropic, Gemini, OpenRouter, Groq, etc.
   - Used for higher quality cleanup, dedupe, and synthesis.
   - Never required for basic capture.

Classification output:

```json
{
  "area": "dev",
  "type": "plan",
  "tags": ["vault", "memory", "tauri"],
  "confidence": 0.82,
  "suggested_destination": "Plans/Active/2026-06-25-vault-memory-handler-service.md",
  "suggested_backlinks": ["Plans/Active/2026-06-14-vault-second-brain-sparring.md"],
  "summary": "Plan for automatic capture and cleanup around the vault."
}
```

### 5. Cleanup Modes

There should be two cleanup modes.

#### Cheap Cleanup

Runs frequently. No AI required.

Actions:

- Move processed queue files into monthly buckets.
- Regenerate indexes.
- Detect exact duplicates by hash.
- Detect near-obvious duplicates by normalized title/body hash.
- Mark stale suggestions.
- Keep logs small.

This can run on session start, app launch, or every few hours.

#### Semantic Cleanup

Runs manually or on schedule. Uses local AI or BYOK provider.

Actions:

- Summarize raw captures.
- Merge related captures.
- Propose vault destinations.
- Propose backlinks.
- Promote repeated gotchas into `Brains/<slug>/gotchas.md`.
- Promote stable facts into `Brains/<slug>/current.md`.
- Add actionable items to `Brains/<slug>/next.md`.
- Create or update plans.
- Identify obsolete or contradictory notes.

Semantic cleanup should show a review batch before writes:

```text
Capture: 2026-06-25T1447 memory handler idea
Proposed action: create plan
Destination: Plans/Active/2026-06-25-vault-memory-handler-service.md
Backlinks:
- Plans/Active/2026-06-14-vault-second-brain-sparring.md
- Plans/Active/2026-06-15-modular-brain.md
Confidence: 0.87
Approve? yes / edit / skip
```

### 6. Vault Writes

Durable writes must respect the existing vault contract:

- New AI-written notes get frontmatter.
- Inbox files get no frontmatter.
- Plans go to `Plans/Active/YYYY-MM-DD-<topic>.md`.
- Project state goes to `Brains/<slug>/`.
- Existing notes should be appended or patched surgically, not rewritten wholesale.
- The system should cite source files when surfacing facts from the vault.

For `Brains/<slug>/`, use the modular shape:

```text
Brains/<slug>/
  INDEX.md
  current.md
  gotchas.md
  next.md
  history/
  archive/
```

Memory handler should not flood `current.md`. Default path for uncertain material is `history/` or `Inbox/`.

## AI Provider Strategy

The service should support three provider classes.

### Local AI

Purpose:

- Private classification.
- Small summaries.
- Tag suggestions.
- Dedupe hints.
- Low-cost background work.

Possible backends:

- Ollama.
- LM Studio.
- llama.cpp server.
- Jan or other local OpenAI-compatible servers.

Recommended interface:

- Treat local providers as OpenAI-compatible where possible.
- Keep provider adapters thin.
- Store model capabilities: context length, JSON reliability, embedding support, cost estimate, privacy level.

### BYOK Hosted AI

Purpose:

- Higher quality semantic cleanup.
- Long-context synthesis.
- Better cross-note routing.
- Optional embeddings.

Providers:

- Anthropic.
- OpenAI.
- Google Gemini.
- OpenRouter.
- Groq.
- Mistral.
- Any OpenAI-compatible endpoint.

Rules:

- Keys live in OS keychain, not config files.
- The app shows exactly what content will be sent.
- Provider use is opt-in by task class.
- Sensitive folders can be local-only.

### CLI Agent Adapters

This is attractive but needs caution.

Useful integration:

- User-configured command adapter: run a command with a prompt and capture stdout.
- Example: `mem provider add-command my-agent -- "some-cli --prompt-file {prompt}"`
- Good for local tools, custom agents, or paid CLIs that expose a legitimate command interface.

Avoid:

- Screen scraping Cursor or other subscription apps.
- Automating products in ways that bypass their intended API.
- Assuming a desktop subscription includes programmable background usage.

Cursor specifically:

- Cursor IDE is excellent as an editing surface and agent environment.
- A standalone app should not assume it can use the user's Cursor subscription as a generic background model provider.
- If Cursor exposes official SDK/API routes suitable for this use case, support them as a provider adapter later.
- Until then, integrate with Cursor through files, hooks, commands, and explicit user-triggered capture.

## Embeddings And Search

Embeddings are useful, but should not be the source of truth.

Source of truth:

- Markdown files in the vault.
- Raw event records in `.memory/queue` and `.memory/processed`.

Optional indexes:

- SQLite FTS for fast keyword search.
- Vector index for semantic search.
- Entity index for people, projects, repos, clients, and topics.

Recommended local index:

```text
.memory/state.sqlite
  captures
  suggestions
  processed_files
  providers
  embeddings_index_metadata
  entities
```

Do not sync SQLite blindly between devices unless there is a clear locking story. Prefer rebuilding indexes from markdown and raw events per device.

## Cross-Platform Sync

Use plain files as the sync contract.

Recommended split:

- Vault markdown: synced by the user's chosen vault sync tool.
- Raw capture events: append-only JSON files inside `.memory/queue` and `.memory/processed`.
- Local indexes: per-device SQLite, rebuildable.
- Secrets: per-device keychain.
- App config: small TOML/JSON file, optionally synced if it has no secrets.

Sync options:

### Option A: Obsidian Sync or LiveSync

Best if the vault is already stable there.

Pros:

- Works with Obsidian.
- Cross-device.
- No new mental model.

Cons:

- Binary-heavy raw inputs can bloat sync.
- Conflict behavior depends on the sync layer.

Use for:

- Markdown.
- Small JSON capture records.

Avoid for:

- Large audio.
- Large video.
- Huge PDFs.
- Embedding databases.

### Option B: Syncthing

Best for local-first power-user sync across Mac, Linux, and home servers.

Pros:

- Good cross-platform story.
- Local-first.
- Works well with append-only files.

Cons:

- Mobile story is weaker on iOS.
- Needs setup and monitoring.

### Option C: Git Snapshots

Best as history and rollback, not live sync.

Pros:

- Great audit trail.
- Good for nightly snapshots.
- Easy rollback.

Cons:

- Bad for real-time capture conflicts.
- Bad for non-technical mobile capture.

Recommended approach:

- Use file sync for active vault sync.
- Add scheduled git snapshots for backup/history.
- Keep `.memory/state.sqlite`, logs, and large transient files out of git.

## Security And Privacy

The product must be conservative by default.

Requirements:

- Local-first storage.
- No cloud account required.
- No telemetry by default.
- Provider keys stored in OS keychain.
- Per-folder privacy rules.
- Preview before sending content to hosted providers.
- Redaction hooks for obvious secrets.
- Audit log of provider calls.
- Easy export and delete.

Suggested privacy modes:

- **Local only:** no network AI calls.
- **BYOK ask first:** user approves hosted calls.
- **BYOK automatic for allowed folders:** hosted calls allowed only for configured areas.
- **Team/work restricted:** never send `Work/` unless explicitly enabled.

## UI Shape For Tauri

Tauri app surfaces the system; it should not be required for automation.

Main screens:

- **Inbox Queue:** raw captures, suggested summaries, confidence, source.
- **Review Batch:** approve/edit/skip proposed writes.
- **Vault Map:** detected folders, brains, open plans, stale items.
- **Providers:** local AI, BYOK keys, model selection, privacy rules.
- **Sources:** clipboard trigger, browser share, Cursor hook, terminal, voice, screenshots.
- **Sync:** last sync seen, conflicts, device list, excluded paths.
- **Audit:** what was captured, what was sent to AI, what was written.

Tray/menu actions:

- Capture clipboard.
- Capture selected text.
- Quick note to Inbox.
- Run cheap cleanup.
- Run semantic cleanup.
- Open review queue.
- Pause capture.

## CLI Shape

Commands:

```text
mem init
mem capture "text"
mem capture --stdin --source terminal
mem capture --file ./note.md
mem inbox
mem suggest
mem review
mem cleanup --cheap
mem cleanup --semantic
mem promote <capture-id>
mem providers list
mem providers add-openai-compatible
mem doctor
mem sync-status
```

Useful aliases:

```text
kb capture
kb cleanup
brain capture
brain cleanup
```

The CLI should make "vault", "brain", and "KB" equivalent user-facing language.

## Cursor Integration

Do not rely on the user remembering manual capture.

Possible integrations:

- Cursor hook at session end: summarize decisions, files touched, commands, blockers, and next steps into a raw capture.
- Explicit command: `.kb` or `.brain` triggers capture into queue.
- Workspace root detection: map repo path to `Brains/<slug>/`.
- Agent transcript importer: process recent chat transcripts into raw captures.
- Pull request helper: capture PR title, summary, test results, review comments.

Guardrails:

- Avoid capturing every token of every conversation.
- Prefer summaries plus source references.
- Keep raw transcript import opt-in.
- Do not write durable project state without review until confidence is high.

## Data Flow

1. Source emits content.
2. Capture adapter writes append-only event into `.memory/queue`.
3. Cheap classifier adds deterministic metadata.
4. Optional AI classifier adds summary, tags, and route suggestion.
5. Suggestion appears in CLI/Tauri review queue.
6. User approves, edits, or skips.
7. Vault writer creates or patches markdown.
8. Event moves to `.memory/processed/YYYY-MM/`.
9. Index rebuilds locally.

## MVP Scope

Build only what proves the loop.

MVP includes:

- CLI.
- Vault path detection.
- Append-only capture queue.
- Manual capture and stdin capture.
- Cheap classification from hashtags, repo path, and file path.
- Semantic cleanup with one provider adapter.
- Review queue in terminal.
- Writes to `Inbox/`, `Plans/Active/`, and `Brains/<slug>/history/`.
- Basic dedupe by hash.
- `mem doctor`.

MVP excludes:

- Tauri UI.
- Continuous clipboard watcher.
- Browser extension.
- Voice/OCR.
- Mobile app.
- Multi-user/team features.
- Automatic hosted provider calls.

Expected build effort:

- Prototype: 1-3 days.
- Solid personal MVP: 1-2 weeks.
- Tauri v1: 3-6 additional weeks.
- Product-grade service: 2-4 months.

## V1 Scope

Add:

- Tauri tray app.
- Review UI.
- OS keychain storage.
- Local AI provider adapter.
- OpenAI-compatible BYOK adapter.
- Configurable privacy rules.
- Scheduled cleanup.
- Raycast/Shortcuts integration.
- Obsidian URI integration.
- Local SQLite search/index.

## V2 Scope

Add:

- Browser extension/share target.
- OCR and voice capture.
- More provider adapters.
- Agent transcript importer.
- Entity graph.
- Conflict UI.
- Team/shared vault mode.
- Plugin ecosystem for capture sources.

## Implementation Stack

Recommended:

- Rust core if Tauri is likely and file safety matters.
- TypeScript bindings or a thin TS CLI only if faster iteration wins.
- SQLite for local state.
- Markdown parser for frontmatter and note edits.
- OpenAI-compatible provider interface for local and hosted models.
- Tauri for desktop UI once core is stable.

Alternative:

- TypeScript-first core with Node CLI and later Tauri sidecar.
- Faster MVP, but packaging and native OS integration may get messier.

Recommendation:

- If this is personal tooling only, TypeScript-first is fine.
- If this might become a service/product, use Rust core + Tauri from the start, but still build CLI first.

## File Layout For Product Repo

```text
memory-handler/
  crates/
    memory-core/
    memory-cli/
    memory-daemon/
    memory-tauri/
  apps/
    desktop/
  docs/
  fixtures/
  tests/
```

Vault runtime layout:

```text
~/Vaults/Brain/
  Inbox/
  Plans/
  Brains/
  .memory/
    config.toml
    queue/
    processed/
    state.sqlite
    logs/
```

## Open Decisions

- Product repo location.
- Rust-first vs TypeScript-first.
- Whether `.memory/queue` should live inside the vault or in an app data directory with only approved captures written to the vault.
- Preferred sync substrate: LiveSync, Syncthing, or hybrid.
- Initial AI provider: local Ollama, OpenAI-compatible endpoint, or Anthropic BYOK.
- Whether semantic cleanup can auto-write low-risk destinations, or must always review.
- Naming: memory, brain, KB, or vault.

## Suggested First Milestone

Build a CLI-only proof:

1. `mem init --vault ~/Vaults/Brain`.
2. `mem capture --stdin --source cursor`.
3. `mem suggest` generates route suggestions.
4. `mem review` approves one write into `Plans/Active` or `Brains/<slug>/history`.
5. `mem cleanup --cheap` archives processed captures and rebuilds a tiny index.

Success criterion:

- After one real Cursor work session, useful state lands in the vault without relying on the user remembering a custom memory command.

## Risks

- Automatic capture can become noisy.
- AI cleanup can over-organize and create busywork.
- Sync conflicts can corrupt state if shared mutable files are edited across devices.
- Hosted AI can leak sensitive work notes if privacy defaults are loose.
- A Tauri UI can make the project feel finished before the memory loop is reliable.
- "Use my Cursor subscription as a model provider" may not be possible or appropriate without an official API.

## Strong Defaults

- Capture append-only.
- Organize later.
- Keep raw provenance.
- Never depend on an Obsidian plugin.
- Keep markdown as source of truth.
- Keep indexes rebuildable.
- Review before durable writes until the user trusts the system.
- Local AI first for private material.
- BYOK for high-quality cleanup when explicitly allowed.
- Tauri as UI, not architecture.

## Next Actions

1. Decide product repo location.
2. Pick Rust-first or TypeScript-first.
3. Define the raw capture JSON schema.
4. Implement `mem init`, `mem capture`, and `mem inbox`.
5. Add cheap classification from path, hashtags, and repo slug.
6. Implement terminal review.
7. Add one AI provider adapter.
8. Run it against real Cursor session captures for a week before building Tauri UI.
