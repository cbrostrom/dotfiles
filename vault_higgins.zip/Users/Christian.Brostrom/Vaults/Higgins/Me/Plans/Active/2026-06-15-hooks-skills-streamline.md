---
created: 2026-06-15
area: [meta, dev]
type: plan
status: active
tags: [hooks, skills, claude-code, dotfiles, brain]
repo: dotfiles
---

# Plan: Streamline Claude Code Hooks + Skills

_Brainstormed: 2026-06-15. Execution target: sonnet._

## Goal

Cut Claude Code config surface to match actual workflow: vault-first brain, no Engram auto-sync, one save command, lean skill set. Outcome: 13→7 hooks, ~25→13 skills, 7→1 save commands.

## Why

Current state (per Brain.md and live audit):
- Brain.md states "Engram demoted, write-only, no auto session-start calls" — but 5 Engram hooks fire automatically. Mismatch between stated intent and reality.
- Save commands sprawl: `.brain` `.rem` `.store` `.mem` `.bye` `.wrap` `.switch` + `session-wrap` + `switch` skills = 7+ entry points to ≈same action.
- 3 hooks present but unwired (wrap-reminder, tuna-notify, claude-session-check) + engram-clear backup = cruft.
- Paseo stack (6 skills) and half of Plannotator stack unused.

Vault grep is cheaper than Engram search per CLAUDE.md routing rules. Hooks should match.

## Decisions (locked in brainstorm)

| Topic | Decision |
|---|---|
| Engram auto hooks | Kill all 4 (sync-start, sync-stop, on-prompt, on-stop). `mem_save`/`mem_search` remain as manual tools. |
| Save commands | One `.brain` only. Always **append** timestamped section to `Brains/<slug>.md`. Model picks length from context. |
| Paseo skills | Cut all 6. Cavecrew + Agent tool cover the use cases. |
| Plannotator | Keep `review`, `annotate`, `last`. Cut `setup-goal`, `compound`, `visual-explainer`. |
| Dead hooks | Delete files (wrap-reminder, tuna-notify, claude-session-check, engram-clear + backup). |
| SessionStart stack | Keep `brain-load` only. Drop `entroly-start` and `claude-settings-merge` (dotfiles update handles merge). |
| UserPromptSubmit | Keep `effort-classifier` + `fast-mode-guard`. |
| Skill cuts (custom) | `find-skills`, `skills.list`, `skills.developer.list`, `skills.server-headless.list`, `mcp-doctor`, `use-spark`. |
| Skills retained | writing, sparring, graphify, inbox-librarian, dotfiles-update, agent-browser, worklog, plannotator-{review,annotate,last}. |

## Final hook map

| Event | Hook | Purpose |
|---|---|---|
| SessionStart | `brain-load.sh` | inject `Brains/<slug>.md` |
| UserPromptSubmit | `effort-classifier.sh` | `[eff:X]` tag |
| UserPromptSubmit | `fast-mode-guard.sh` | guard fast-mode misuse |
| UserPromptSubmit | `brain-save-inject.sh` | trigger brain write on `/compact`, `/clear` |
| PreToolUse:Bash | `git-push-guard.sh` | push whitelist |
| PreToolUse:Bash | `rtk-rewrite.sh` | RTK proxy |
| PreCompact | `brain-save-inject.sh` | write brain before compact |

`statusline.sh` retained (statusLine config, not a hook).

## Execution tasks

### Task 1 — Edit `~/dotfiles/.claude/settings.base.json`
- Remove `SessionStart` hook block (engram-sync-start).
- Remove `Stop` hook block (engram-sync-stop).

### Task 2 — Edit `~/dotfiles/.claude/settings.darwin.json`
Strip these blocks from `hooks`:
- `SessionStart` → drop entroly-start entry and claude-settings-merge entry. Keep brain-load entry.
- `Stop` → drop engram-on-stop entry. Result: no `Stop` hooks (drop the key entirely).
- `UserPromptSubmit` → drop engram-on-prompt entry. Keep effort-classifier, fast-mode-guard, brain-save-inject.

### Task 3 — Mirror task 2 in `settings.linux.json` and `settings.wsl.json`
Same deletions if present.

### Task 4 — Delete hook files
```bash
cd ~/dotfiles/.claude/hooks
rm -f engram-sync-start.sh engram-sync-stop.sh engram-on-prompt.sh engram-on-stop.sh \
      engram-clear.sh engram-clear.sh.backup.* \
      entroly-start.sh \
      wrap-reminder.sh tuna-notify.sh claude-session-check.sh
```
Then in `~/.claude/hooks/` remove matching symlinks:
```bash
cd ~/.claude/hooks
rm -f engram-sync-start.sh engram-sync-stop.sh engram-on-prompt.sh engram-on-stop.sh \
      engram-clear.sh engram-clear.sh.backup.* \
      entroly-start.sh \
      wrap-reminder.sh tuna-notify.sh claude-session-check.sh
```

**NOTE:** `claude-settings-merge.sh` file stays on disk — still used by `dotfiles --update`. Only the SessionStart wiring goes.

### Task 5 — Delete custom skill dirs
From `~/dotfiles/.claude/skills/`:
```bash
rm -rf paseo paseo-advisor paseo-committee paseo-handoff paseo-loop \
       plannotator-setup-goal plannotator-compound plannotator-visual-explainer \
       session-wrap switch \
       find-skills skills.list skills.developer.list skills.server-headless.list \
       mcp-doctor use-spark
```
Mirror in `~/.claude/skills/` (likely symlinks).

### Task 6 — Update `~/.claude/CLAUDE.md`
Dot-command table:
- Drop rows: `.remember`, `.recall`, `.rem`, `.store`, `.mem`, `.bye`, `.wrap`.
- Update `.brain` row: `Append dated section to $VAULT/Brains/<slug>.md. Model sizes content from context. If text provided, use it; else synthesize. One-line confirm.`

Memory routing table:
- Drop rows: "remember/save this/note that/don't forget" (auto mem_save), "we're done/wrapping up/end of session" (session-wrap).
- Rewrite Engram line: `Engram = manual only (no auto hooks). Use mem_save/mem_search when invoked explicitly. Graphiti = disabled until needed at scale.`

### Task 7 — Update `~/Vaults/Brain/Brains/Brain.md`
Replace **Current State** section with:
```
- Engram auto-hooks killed (sync-start, sync-stop, on-prompt, on-stop). Vault = sole memory.
- Hooks: 7 active (brain-load, effort-classifier, fast-mode-guard, brain-save-inject, git-push-guard, rtk-rewrite, statusline).
- Save commands: `.brain` only. Always append timestamped section.
- Skills: 13 custom retained. ~15 cut (paseo×6, plannotator extras×3, session-wrap, switch, skills lists×4, mcp-doctor, use-spark).
```

### Task 8 — Run `dotfiles --claude-doctor --fix` (or merge script)
Regenerates `~/.claude/settings.local.json`. Verify only the 7 declared hooks remain in merged output.

### Task 9 — Verify
- New session: confirm only `brain-load` fires at SessionStart (no engram sync output).
- Trigger `/clear`: brain-save-inject still fires.
- Trigger `git push` from non-whitelisted dir: guard still blocks.
- `.brain test` (in any repo): appends to `Brains/<slug>.md`.

### Task 10 — Commit
- Commit `~/dotfiles` changes. Message:
  ```
  feat(claude): streamline hooks + skills

  - Kill 4 engram auto hooks (vault primary)
  - Drop 6 dead hook files + 15 unused skills
  - Consolidate save commands to single .brain
  - Update CLAUDE.md routing rules
  ```
- Commit Brain.md update separately in vault.

### Task 11 — Fix brain slug resolution (per-project, not per-PWD)

**Problem:** `brain-save-inject.sh` uses `git toplevel basename` else `PWD basename`. Breaks when:
- Working across multiple projects in one session (PWD changes mid-flight)
- Conceptual project ≠ cwd (e.g. notes about Fiskars while sitting in dotfiles repo)
- Vault subfolder work where PWD basename is meaningless (e.g. `Inbox/`)

**New behavior:**
1. Resolve candidate slugs in this priority:
   - Explicit arg: `.brain <slug>` — use as-is
   - Active plan front-matter `repo:` field (if recently read)
   - Loaded brain file from SessionStart (`Brains/<slug>.md` injected by brain-load)
   - Git repo basename
   - PWD basename
2. If multiple candidates differ → model **must** ask user via `AskUserQuestion` before writing. Options = candidate list + "new slug".
3. If single candidate and confidence high → write directly, one-line confirm including slug used.

**Implementation:**
- Hook stays shell (still injects "write brain now" instruction on `/compact`,`/clear`).
- Slug resolution moves to **model side** — driven by CLAUDE.md `.brain` rule, not hook.
- Update CLAUDE.md `.brain` row:
  ```
  `.brain [slug] [text]` | Resolve target slug (explicit arg > active plan repo > loaded brain > git basename > PWD). If multiple plausible candidates differ, ask via AskUserQuestion before writing. Append timestamped section to `$VAULT/Brains/<slug>.md`. Confirm: `Brain updated → Brains/<slug>.md`.
  ```

**Gotcha to capture in Brain.md after exec:** brain slug != PWD. Always resolve to conceptual project. Ask when ambiguous.

## Out of scope

- WSL vault path verification (parked, next Windows session)
- Fiskars dupe folder cleanup (parked, 15min manual)
- Engram MCP server itself (stays installed, just not auto-invoked)

## Rollback

```bash
cd ~/dotfiles && git revert HEAD
./modules/claude-settings/doctor.sh --fix
```

All deletions recoverable from git history. Engram data on disk untouched (`~/.engram/personal/`).
