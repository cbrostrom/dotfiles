---
tags: [infrastructure, domains, traefik, migration, superbro]
created: 2026-05-31
status: planned
---

# cloudbro.dk → superbro.dk Migration Plan

**Goal:** Retire `cloudbro.dk`, move all homelab services to `*.lab.superbro.dk`.

**Stack:** Both servers run Traefik. DNS on Cloudflare → wildcard cert via DNS challenge available.

## Phases

### Phase 1 — Inventory
- [ ] List all DNS records on cloudbro.dk at Cloudflare
- [ ] List all services on linuxbro accessed via cloudbro.dk subdomains
- [ ] Note where Traefik configs / compose files live on linuxbro

### Phase 2 — DNS scaffolding
Add on Cloudflare:
```
*.lab.superbro.dk  → homelab IP
*.vps.superbro.dk  → VPS IP  (if not already present)
```
Use wildcard — cleaner than per-service records.

### Phase 3 — Traefik dual-route (homelab)
For each `service.cloudbro.dk`, add new label alongside old — both live during transition:

```yaml
labels:
  # keep old temporarily
  - "traefik.http.routers.plex-old.rule=Host(`plex.cloudbro.dk`)"
  - "traefik.http.routers.plex-old.tls.certresolver=letsencrypt"
  # new
  - "traefik.http.routers.plex.rule=Host(`plex.lab.superbro.dk`)"
  - "traefik.http.routers.plex.tls.certresolver=letsencrypt"
```

### Phase 4 — VPS formalization (optional)
Decide: keep flat `service.superbro.dk` or migrate ops to `service.vps.superbro.dk`.
Recommendation: `.vps.` for internal ops, flat for public-facing.

### Phase 5 — Validate + update references
- [ ] Test all new URLs
- [ ] Update password manager entries
- [ ] Update bookmarks
- [ ] Check for hardcoded domain refs in service configs

### Phase 6 — Soft cutover
- [ ] 301 redirects: `*.cloudbro.dk` → `*.lab.superbro.dk`
- [ ] Notify any external integrations

### Phase 7 — Cleanup
- [ ] Remove cloudbro.dk parallel Traefik vhosts
- [ ] Let domain expire at next renewal — do not renew

## Key Detail

Cloudflare DNS challenge → wildcard `*.lab.superbro.dk` cert in Traefik. No per-service HTTP challenge needed.

## Related

- [[Domain Consolidation Strategy]]
