---
created: 2026-06-14
area: meta
type: plan
tags: [vault, second-brain, sparring, restructure, sync, obsidian, joplin, logseq, ai-tooling]
status: active
---

# Vault as Second Brain — Sparring Summary

> Two-session sparring (2026-06-12 strategy doc + 2026-06-14 restructure session) crystallized into a single reference. Read this when picking up the thread or onboarding a new session.

## Original framing (what you brought in)

- Vault feels overengineered. You don't use graph, Bases, Smart Connections — Obsidian's headline features.
- LiveSync is a recurring pain.
- ADHD-brain wants a friction-free dump-anywhere capture loop, then a librarian to triage later.
- "Brain for the AI" and "extra brain for mind-dumping" felt like two needs.
- Sub-question: is multi-vault worth it (Personal vs Work vs Dev separation)?

## Uncomfortable truths surfaced

1. **The "AI graph" pitch is half-marketing.** Obsidian's graph view is a *human* UI affordance. Claude cannot consume the rendered graph. Wiki-links via grep are just text references — useful but not magical. True graph-for-AI is Graphiti (separate system, already running on `superbro:8000`).
2. **You've been paying Obsidian's complexity tax for features you don't use.** Graph, Bases, Smart Connections — all human-superpower features. AI's real wins come from disk-level structure (frontmatter, taxonomy, flat Brains/), not Obsidian plugins.
3. **Obsidian doesn't become a viewer if AI edits files.** Both Claude and Obsidian write to the same `.md` substrate. Obsidian = human UX; Claude = mutator. They stack, they don't compete.
4. **The wrap-reminder hook was manufacturing OCD.** Disabling it is the biggest single anxiety reduction available. Already noted last session; still pending action.
5. **You don't actually need a unified vault to feel organized.** Split-brain (human note app + flat-file AI brain) is a viable architecture. But it has its own costs.

---

## Decisions LOCKED in this sparring

### Structure

- **Single vault, NOT multi-vault.** 94 files is too small to justify split overhead. Cross-context value (Shopify pattern applies to Grønnebakken web setup) only emerges with one graph.
- **Three life-area folders inside one vault:** `Personal/`, `Work/`, `Development/`.
- **Flat `Brains/` at vault root** — one file per project, cross-project grep stays single-target.
- **`Reference/` at root** — small, only truly cross-cutting content. Area-specific reference lives inside its area folder.
- **No numeric prefixes** — manual sort plugin (Flexplorer) + Iconize handle ordering and visual hierarchy.
- **Vault folder name** = `Brain` (not `Christian`, not prefixed).

### Capture + librarian

- **Inbox = zero friction.** Body only, no frontmatter required at capture.
- **Hashtag hints + inferred fallback (I2)** — natural for you (you tag by habit). Librarian reads inline hashtags; falls back to inference if absent.
- **Confirm-before-move always.** Librarian never auto-routes. You veto with one keystroke.
- **Brains APPEND, not replace** — new content joins existing `Brains/<slug>.md` as dated sections.

### Frontmatter contract

```yaml
---
created: YYYY-MM-DD
area: personal | work | dev | idea | meta   # string OR array, first = primary
type: brain | project | reference | note | meeting | plan | idea
tags: []
---
```

- `area` can be string or array. **First element = primary** = drives file location.
- Secondary areas → auto-backlink, not duplicate file.
- Inbox files have NO frontmatter (pre-librarian state).

### Hashtag taxonomy

| Hashtag | Becomes |
|---|---|
| `#personal #work #dev #idea #meta` | `area:` (first = primary, multiple = array) |
| `#brain #ref #project #meeting #plan #note` | `type:` |
| `#work/fiskars #dev/dotfiles` (2-level max) | area + project hint |
| Any other | `tags:` array |

Hashtags stay in body. Librarian copies to frontmatter on promotion.

### Routing

| Type | Destination |
|---|---|
| brain | `Brains/<slug>.md` flat |
| project | `<area>/<project>/` |
| reference | `<area>/Reference/` or root `Reference/` if cross-cutting |
| idea | `Ideas/<name>/` |
| note, meeting | `<area>/<context>/` |
| plan | `Plans/Active/YYYY-MM-DD-<topic>.md` |

### Plugin posture

- **Enabled, will use:** Templater, Calendar, Periodic Notes (under review), Doubleshift, Table Editor, Style Settings, Iconize, LiveSync (under review), Dataview (demoted), Minimize-on-Close, Omnisearch, Reminder, QuickAdd, Smart Connections (sidebar only), Flexplorer.
- **Newly enabled this session:** File Recovery (critical), Bases.
- **Future enable when re-opening in Obsidian:** Graph (with caveat that it's for human eyes, not AI), Bookmarks, Workspaces.
- **Demote:** Dataview → only legacy queries; write new views as Bases.
- **Worth installing later:** Auto Link Title, Advanced URI, Linter, Tag Wrangler.

### Pre-migration safety

- Backup of old vault stored at `~/Backups/vault-pre-restructure-2026-06-14.tar.gz` (14.1MB, 470 entries, verified).
- LiveSync paused before restructure.
- Other Obsidian clients closed.

---

## Decisions DEFERRED (still open)

1. **Sync mechanism.** LiveSync vs Syncthing vs git-snapshot. Decision parked. Restructure happened decoupled from sync choice.
   - Suggested hybrid for future: real-time sync (whatever choice) + nightly git snapshot for history.
   - User insight: **"viewer / editor / sync handled decoupled"** is the right mental model. Apps and sync mechanisms don't have to be the same vendor.
2. **Obsidian as primary editor vs alternatives** (Joplin, Logseq, plain MD + VSCode).
   - Joplin = SQLite-backed, not flat-file. Not compatible with AI direct-file editing model. Strong mobile + own-server, but wrong substrate.
   - Logseq = flat MD, similar to Obsidian. User experience says its sync is also bad.
   - Decision: stay flat-file (currently Obsidian-compatible). Editor choice can change later without restructuring the files.
3. **What happens to old vault** (`~/Vaults/Christian/`).
   - Plugin config (`.obsidian/`, `.obsidian-mobile/`) and Smart Connections embeddings (`.smart-env/`) still live there.
   - Empty content folders remain. User can `rmdir` later or delete the whole `Christian/` directory once new flow is validated.
4. **Per-project Brains/ hook rewrite.**
   - Current hooks (`brain-load.sh`, `brain-save-inject.sh`) target repo-local `.claude/brain.md`.
   - Future rewrite: `$PWD → slug → ~/Vaults/Brain/Brains/<slug>.md` resolution.
   - Slug table not yet populated. Project list needs collection.
5. **Librarian skill implementation.**
   - Spec drafted in this conversation; not yet written as `~/.claude/skills/inbox-librarian/SKILL.md` or vault-level skill.
6. **Daily Notes fate.**
   - Abandoned since 2025-12-04. Options: kill, simplify to 1-line, leave as-is.
   - Currently moved to `Archive/Daily Notes 2025/` — effectively retired.
7. **Fiskars duplication.**
   - Two source folders found: `Projects/Fiskars/` + `Projects/AKQA/Shopify/Fiskars/`.
   - Staged at `Work/AKQA/Shopify/Fiskars/_dupe-from-Projects-Fiskars/` — needs manual review to merge.
8. **Bases views to ship.**
   - Listed (Inbox triage, Work space, Personal space, Dev space, Brains overview, Stale brains, Open plans, Orphan notes) but not built yet.
9. **QuickAdd capture macros.**
   - Planned: `Inbox dump`, `Inbox dump + voice`, `Promote note`. Not built.
10. **Workspaces.**
    - Planned: `Work`, `Personal`, `Dev` saved layouts. Not built.

---

## What got moved (2026-06-14)

Old vault `~/Vaults/Christian/` → New vault `~/Vaults/Brain/`.

| From | To |
|---|---|
| `Inbox/` | `Inbox/` |
| `Daily Notes/` | `Archive/Daily Notes 2025/` |
| `Plans/` | `Plans/` |
| `Sunday Meetings/` | `Personal/Sunday Meetings/` |
| `Templates/` | `Templates/` |
| `Attachments/` | `Attachments/` |
| `Archive/Daily Notes/` | `Archive/Daily Notes (archived 2024)/` |
| `Archive/Projects/`, `Archive/Vault-Docs/` | `Archive/...` (unchanged) |
| `Ideas/*` | `Ideas/*` |
| `Projects/AKQA/Meetings/` | `Work/AKQA/Meetings/` |
| `Projects/AKQA/Shopify/Fiskars/` | `Work/AKQA/Shopify/Fiskars/` |
| `Projects/AKQA/Shopify/Themelio/` | `Work/AKQA/Shopify/Themelio/` |
| `Projects/Fiskars/` (dupe) | `Work/AKQA/Shopify/Fiskars/_dupe-from-Projects-Fiskars/` |
| `Projects/Privat/Grønnebakken Bestyrelse/` | `Personal/Grønnebakken Bestyrelse/` |
| `Reference/Familie/` | `Personal/Familie/` |
| `Reference/Hus/` | `Personal/Hus/` |
| `Reference/Lily/` | `Personal/Lily/` |
| `Reference/Homelab & VPS/` | `Development/Homelab & VPS/` |
| `Reference/Tech/` | `Development/Tech/` |
| `Reference/Vault/` | `Development/Vault/` |
| Loose: `Projects/Tessera Descent - Item Synergy Chart.md` | `Ideas/Tessera Descent/` |
| Loose: `Projects/AKQA/Shopify-Headless-Landscape.md` | `Work/AKQA/` |
| Loose: `Projects/AKQA/Check-in 2024-11-15.md` | `Work/AKQA/Meetings/` |
| Loose: `Projects/AKQA/Flight To Orbit.md` | `Work/AKQA/` |
| Loose: `Reference/Claude-Skills.md` | `Development/` |
| `Dashboard.md` | `Dashboard.md` (root) |
| `CLAUDE.md` (old) | `CLAUDE.md.old` (preserved for reference) |

Final counts: 94 `.md` files in old vault → 93 `.md` + `CLAUDE.md.old` in new vault. Zero leftovers in old vault (excluding plugin config dirs).

New `Brains/` is **empty by design** — populates as project-context conversations land and AI writes to it.

---

## Sync deep-dive (parked but recorded)

### LiveSync (current)
- Pro: sub-second sync, native iPhone, already running.
- Con: CouchDB infra on superbro, plugin-coupled, silent field-level merges, can lose data in conflicts.

### Syncthing
- Pro: filesystem-native (any writer works), free versioning (staggered/simple), visible conflict files, no central server.
- Con: $15 one-time for Möbius Sync on iPhone, slightly slower (filesystem watcher latency ~1-10s).

### Git
- Pro: full history, branchable, cheap private GitHub repo.
- Con: NOT real-time, kills capture loop if used as primary sync, iPhone is painful.
- Best fit: **layer git on top** of whichever real-time sync you pick. Nightly cron `git -C ~/Vaults/Brain add -A && git commit -m "snapshot $(date -I)"` for history/audit.

### Recommendation
- `[Likely]` Syncthing + Möbius on iPhone + nightly git snapshot. Visible conflicts, free versioning, $15 lifetime.
- `[Acceptable]` Keep LiveSync if no actual data loss has occurred + add nightly git snapshot anyway.

---

## Alternative note apps (parked, recorded for future reference)

| App | Storage | iPhone | Free? | AI direct-file? | Verdict |
|---|---|---|---|---|---|
| **Obsidian** (current) | Flat MD | ✅ native | ✅ ($) for paid sync | ✅ trivial | Stay if sync solvable |
| **Joplin + self-host on superbro** | SQLite DB | ✅ native | ✅ | ❌ API only | Strong mobile, wrong substrate for AI |
| **Logseq** | Flat MD (blocks) | ✅ native | ✅ | ✅ trivial | Same paradigm, also has sync pain |
| **Notion (free tier)** | Cloud DB | ✅ | ✅ for solo | ❌ MCP only | Beautiful, but data hostage |
| **AnyType** | Local-first P2P | ✅ | ✅ | ❌ object model | Wrong substrate |
| **Apple Notes** | iCloud | ✅ | ✅ | ❌ AppleScript | Loses Linux/WSL |
| **Plain MD + VSCode + Syncthing** | Flat MD | ⚠️ (Working Copy) | ✅ | ✅ | Cleanest, worst mobile |

**Conclusion:** flat-file substrate is the only viable option given Claude-as-first-class-writer. Stay flat-file. Editor choice (Obsidian vs Logseq vs plain) is secondary; can change later without restructuring files.

---

## The split-brain idea (considered but not adopted)

Proposed shape:
```
HUMAN BRAIN: Joplin or Notion or Apple Notes — mind-dump, organize, browse, mobile
AI BRAIN: ~/Vaults/Brain/Brains/*.md flat — Claude reads/writes directly
```

Rejected for now: introduces two systems to maintain, two sync mechanisms, drift risk. Current restructure unifies into one Brain vault that AI and human both edit. Could revisit if the unified vault proves clunky.

---

## The viewer/editor/sync decoupling insight

User insight that emerged near the end:

> "Thinking in terms of viewer / editor and sync being handled decoupled would be amazing."

This reframes the problem cleanly:
- **Substrate:** flat `.md` files on disk (locked in)
- **Sync:** orthogonal — LiveSync, Syncthing, git, iCloud — pick one (deferred)
- **Editor:** orthogonal — Obsidian, Logseq, VSCode, Claude, anything — can have multiple
- **Viewer:** orthogonal — Obsidian (graph/Bases), Marksman, GitHub web, mobile share sheet — pick what you want for each context

These four layers don't have to be the same product. Mistake we've been making: treating Obsidian as all four. It only needs to be editor+viewer for humans; Claude is editor; filesystem is substrate; sync is whatever you wire up.

---

## Open action items (next time)

| Item | Effort | Status |
|---|---|---|
| Disable wrap-reminder hook | 1 min | TODO |
| Resolve Fiskars dupe (`_dupe-from-Projects-Fiskars/`) | 15 min manual | TODO |
| Decide sync mechanism (LiveSync vs Syncthing vs hybrid) | decision + setup | DEFERRED |
| Rewrite `brain-load.sh` + `brain-save-inject.sh` to target `~/Vaults/Brain/Brains/<slug>.md` | 30 min | TODO |
| Populate `$PWD → slug` table for hook resolution | 5 min once project list collected | TODO |
| Write Librarian skill (`~/.claude/skills/inbox-librarian/SKILL.md`) | 30 min | TODO |
| Build Bases views (Inbox triage, area spaces, brains overview, stale brains, open plans, orphans) | 30 min when Obsidian re-opened | TODO |
| Build QuickAdd capture macros | 15 min | TODO |
| Save Obsidian Workspaces (Work / Personal / Dev) | 5 min | TODO |
| Add nightly git snapshot cron | 10 min | TODO |
| Decide fate of `~/Vaults/Christian/` (old vault, plugin config) | 5 min | TODO |

---

## File ownership cheat sheet for this restructure session

| File | Role |
|---|---|
| `~/Vaults/Brain/CLAUDE.md` | Live AI map for the new vault (Karpathy-inspired) |
| `~/Vaults/Brain/CLAUDE.md.old` | Previous vault root CLAUDE.md, preserved |
| `~/Vaults/Brain/Plans/Active/2026-06-14-vault-second-brain-sparring.md` | THIS file |
| `~/Vaults/Brain/Plans/Active/2026-06-12-knowledge-base-strategy.md` | Previous strategy doc (deeper, longer; this summary supersedes for active reference) |
| `~/Backups/vault-pre-restructure-2026-06-14.tar.gz` | Safety net for the restructure |

---

## How to use this doc

Open this when:
- Resuming the second-brain thread cold
- Onboarding a new Claude session at vault root
- Reviewing what was decided vs what's still open
- Justifying a deviation: read the locked decisions first; if you change one, update this doc with the date and reason.
