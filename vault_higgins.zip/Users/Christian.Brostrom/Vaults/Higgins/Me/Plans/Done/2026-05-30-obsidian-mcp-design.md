# Obsidian MCP Integration — Design Spec
_2026-05-30_

## Goal

Connect Claude Code to the Obsidian vault via MCP so Claude can search notes, capture to Inbox, update daily notes, and route notes to correct folders — using the Local REST API plugin already running.

---

## Architecture

```
Obsidian (must be open)
  └─ Local REST API plugin → https://127.0.0.1:27124
                                    ↑
                             mcp-obsidian (npx, per-session)
                                    ↑
                          ~/.claude/settings.json
                                    ↑
                             Claude Code session
```

No new Obsidian plugins. No daemon. `mcp-obsidian` starts via `npx -y mcp-obsidian` each session. Vault syncs cross-device via LiveSync → CouchDB on superbro.

---

## MCP Server Config

Add to `~/.claude/settings.json` under `mcpServers`:

```json
"obsidian": {
  "command": "npx",
  "args": ["-y", "mcp-obsidian"],
  "env": {
    "OBSIDIAN_API_KEY": "<api-key-from-plugin-data.json>",
    "OBSIDIAN_PROTOCOL": "https",
    "OBSIDIAN_HOST": "127.0.0.1",
    "OBSIDIAN_PORT": "27124"
  }
}
```

### Available tools

| Tool | Workflow |
|---|---|
| `obsidian_search` | Search & read notes |
| `obsidian_get_file_contents` | Read any note |
| `obsidian_create_or_update_file` | Capture to Inbox, update daily note, route notes |
| `obsidian_list_files_in_vault` | Browse structure |
| `obsidian_get_recent_changes` | What changed recently |
| `obsidian_open_file_in_obsidian` | Open note in app |

---

## CLAUDE.md Additions (vault root)

Add section to `/Users/Christian.Brostrom/Vaults/Christian/CLAUDE.md`:

```markdown
## Obsidian MCP

Tools only available when Obsidian app is open on this Mac.

### Capture
- New notes → `Inbox/YYYY-MM-DD HH-MM Title.md`
- Always include frontmatter: `date`, `tags`

### Daily notes
- Path: `Daily Notes/YYYY-MM-DD.md`
- Append tasks/wins/notes — never overwrite full file

### Note routing (when filing from Inbox)
Follow existing tag → folder rules (see ## Tag → Folder routing above).

### Language
- Personal notes: Danish
- Work notes (AKQA, Fiskars): English
```

---

## Memory Routing Rules

Add to `~/.claude/CLAUDE.md` (global routing table):

| Signal | Action |
|---|---|
| "what do I have on X / find my notes on X" | `obsidian_search` |
| "what did we do / remember X about me" | Engram `mem_search` |
| "capture this / add to inbox" | `obsidian_create_or_update_file` → Inbox/ |
| "remember this / don't forget" | Engram `mem_save` |

### Engram vs Obsidian — not redundant

| | Engram | Obsidian |
|---|---|---|
| What's stored | Claude's observations about user (patterns, preferences, decisions) | User's own notes (thoughts, projects, daily logs) |
| Who writes | Claude, autonomously | User (+ Claude via MCP) |
| Travels cross-device | No | Yes (LiveSync) |
| Purpose | Claude's working memory | User's second brain |

---

## Out of Scope

- Custom MCP server / vault-specific tools (not needed — reasoning + context covers routing)
- In-Obsidian AI beyond Smart Connections (already installed)
- Smart Connections API key upgrade (separate decision)
