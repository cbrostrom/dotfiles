# Spec: The Higgins Pipeline (Global Memory & Synthesis)

**Purpose**
Transform a distributed set of machines (Mac, MonsterBro, SuperBro) into a unified, high-fidelity knowledge engine. It utilizes a "capture-sync-synthesize" loop to ensure zero-cost data entry, a "dump-and-forget" workflow, and surgical, token-efficient retrieval via an MCP-driven "Digital Twin."

---

## Architecture: The Three Pillars

### 1. The Capture Layer (Zero-Cost / Append-Only)
*   **Active Capture (`mem`):** A CLI tool that anchors a manual thought to its environment (CWD, Git Repo, Last Commit). 
*   **Passive Capture (The "Exhaust"):** 
    - **Session Snapshots:** A "dump" mechanism (e.g., `/save` or `/end` skill) that writes the raw, unsummarized chat transcript to the Inbox.
    - **Activity Evidence:** Git diffs and terminal logs that provide the "factual" record of work performed.
*   **Storage:** All capture events are stored as raw, append-only Markdown/Text files in `~/Vaults/Higgins/Inbox`.
*   **Sync:** Syncthing (Workstations $\rightarrow$ SuperBro) using a "Send Only" $\rightarrow$ "Receive Only" one-way valve to prevent conflicts.

### 2. The Synthesis Layer (The "Janitor" on SuperBro)
*   **Runtime:** Daily cron job (04:00) on the always-on SuperBro VPS.
*   **Engine:** Local LLM via Ollama (Llama-3-8B).
*   **The Synthesis Process:**
    1. **Preprocessing (Heuristics):** Non-AI scripts strip "LLM filler," deduplicate code blocks, and chunk massive transcripts to prevent context bloat.
    2. **Intelligence Phase:** The local model analyzes the cleaned scraps and session dumps to extract "Gold" (learnings, decisions, and technical fixes).
    3. **Vault Integration:** Updates structured "Brain" files and the Global Concept Map within the `~/Vaults/Higgins` hierarchy.
    4. **Purge:** Clears the `Inbox` once processed.

### 3. The Retrieval Layer (The "Librarian" MCP)
*   **Mechanism:** A local MCP server hosted on SuperBro.
*   **Anti-Bloat Strategy:** Instead of prompt-injection, agents use the MCP to surgically query the Vault:
    - `search_higgins(query)`: Returns a high-precision snippet of synthesized knowledge.
    - `get_project_context(slug)`: Fetches the "Current State" of a specific project.
*   **The Result:** A "Digital Twin" that provides the correct knowledge only when it makes sense, keeping token usage minimal.

---

## Operational Flow
`Action/Thought/Chat` $\rightarrow$ `Raw Dump (Workstation)` $\rightarrow$ `Syncthing` $\rightarrow$ `SuperBro` $\rightarrow$ `Ollama Synthesis` $\rightarrow$ `Structured Vault` $\rightarrow$ `Surgical MCP Query` $\rightarrow$ `Agent Answer`

## Performance & Cost
| Component | Cost | Resource Impact |
|----------|------|-------------------|
| **Capture** | $0 | Negligible (Text I/O) |
| **Sync** | $0 | Low (Background) |
| **Synthesis**| $0 | Burst CPU/RAM on SuperBro (15m/day) |
| **Retrieval**| Low | Minimal (Surgical snippet tokens) |

## Memory Hierarchy
- **Raw Inbox:** High-noise, high-fidelity, transient.
- **Daily Digest:** Medium-noise, processed summary.
- **Core Vault (The Brain):** Zero-noise, highly structured, permanent knowledge.

---

## Next Steps
1. **Unify Vaults:** Merge `AI` and `Me` into `~/Vaults/Higgins/`.
2. **Sync Setup:** Configure Syncthing for the `Higgins/Inbox` folder $\rightarrow$ SuperBro.
3. **Build the Janitor:** Implement the TypeScript/Bun synthesis script on SuperBro.
4. **Surgical Retrieval:** Build the Librarian MCP to expose the `Higgins` vault.
