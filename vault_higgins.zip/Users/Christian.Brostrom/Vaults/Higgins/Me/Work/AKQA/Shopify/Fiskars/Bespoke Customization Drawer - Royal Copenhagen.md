---
tags: [shopify, fiskars, royal-copenhagen, easify, bespoke, dev-notes]
created: 2026-06-16
updated: 2026-06-17
status: in-review
---

# Bespoke Customization Drawer — Royal Copenhagen

> Dev notes from STLR-5932. The drawer integrates our bespoke name validation/population with Easify Product Options.

## What was built

A consolidated `CustomizationDrawer` class that:
- Detects Easify DOM changes via `MutationObserver` (active only while drawer is open)
- Hydrates bespoke name inputs with autocomplete (`<datalist>`) or `<select>` options
- Wires hydrated inputs to the correct product form via `properties[Name]` keys
- Validates on save/submit, blocking ATC if required or invalid
- Shows a grace-period loader (80ms grace, 1500ms max) to avoid flash-of-loading for fast renders

## Key files

> ⚠️ `customization-drawer.ts` was split into a module folder on 2026-06-17 (aislop refactor). The single file no longer exists.

| File | Purpose |
|------|---------|
| `src/assets/scripts/ui/customization-drawer/index.ts` | Main orchestrator — lifecycle, loader, mutation observer |
| `src/assets/scripts/ui/customization-drawer/constants.ts` | All selectors, timing constants, shared types |
| `src/assets/scripts/ui/customization-drawer/dom-helpers.ts` | Pure DOM helpers — `isVisuallyShown`, `isOptionRootFilled`, `hasActiveCustomizationSelection`, `syncSelectionState` |
| `src/assets/scripts/ui/customization-drawer/bespoke-hydrator.ts` | `BespokeHydrator` class — datalist/select hydration, form wiring |
| `src/assets/scripts/ui/customization-drawer/drawer-validator.ts` | `DrawerValidator` class — validation, error display, event binding |
| `src/assets/scripts/ui/bespoke-names-utils.ts` | Pure helpers: parse metafield, build lookup map, locate controls, generate property keys |
| `theme/blocks/_customization-drawer.liquid` | HTML structure, always loads module, emits JSON data blob |
| `src/assets/styles/utilities/utility-drawer.css` | CSS: hides Easify's native errors until a selection is active |

Import path is **unchanged** — `'../ui/customization-drawer'` resolves to `index.ts` automatically.

## Architecture decisions

### Non-destructive Easify integration
Easify manages its own React-rendered DOM. We must never remove or reorder its nodes.
- Errors from Easify (`.po-field-error`) are **hidden via CSS**, never removed.
- The CSS rule is scoped to `[data-customization-drawer-content]` — a `data-*` attribute stamped on `contentEl` by `CustomizationDrawer` at init. This prevents the rule from accidentally hiding `.po-field-error` elements in **other** drawers on the page:

```css
[data-app-drawer-content][data-customization-drawer-content]:not([data-has-customization-selection])
  .po-field-error:not([data-bespoke-field-error]) {
  @apply hidden;
}
```

- `<datalist>` elements are kept in a hidden sibling container **outside** Easify's tree — inserting them inside caused corruption on Easify re-renders.

### Timing / debouncing
Easify re-renders on every interaction. We debounce with `SETTLE_MS = 200ms` before acting on mutation events. This prevents race conditions where our hydration code runs while Easify is mid-render.

### Form wiring
Shopify's product form lives outside the drawer's DOM. We locate it lazily (on each hydration attempt) via `input[name^="properties["][form^="product-form-"]` which Easify injects. This is intentional — at construction time, Easify hasn't rendered yet.

## Property key naming

The `getBespokePropertyKey` function in `bespoke-names-utils.ts` generates the `name` attribute for form submission:
- **1 control** → `properties[Name]`
- **N controls** → `properties[Name 1]`, `properties[Name 2]`, etc.

### To customise (e.g. "Name cup 1" / "Name cup 2")

Add `data-bespoke-property="properties[Name cup 1]"` to the **same** element that has `data-bespoke-names` in Easify's custom HTML field.

**Critical:** `data-bespoke-names` is the marker that makes the input discoverable. `data-bespoke-property` is an optional override for the form key. **Both must be present** on the same element.

```html
<!-- In Easify custom HTML — correct way -->
<input data-bespoke-names data-bespoke-property="properties[Name cup 1]" />
```

```html
<!-- Wrong — removes the discovery marker -->
<input data-bespoke-property="properties[Name cup 1]" />
```

### Module always registers
The module **must not** be gated on `has_bespoke_names` in the Liquid `data-module` attribute. Even without bespoke names, the module handles:
- Easify required-field validation
- Submit interception
- Loader/error UI state

If the module doesn't load, the save button falls back to `DialogControls`' close behaviour — no validation runs.

```liquid
{{- /* ✅ Always register */ -}}
data-module="app-drawer-observer customization-drawer"

{{- /* ❌ Old conditional — breaks validation when no bespoke names */ -}}
data-module="app-drawer-observer{% if has_bespoke_names %} customization-drawer{% endif %}"
```

### DialogControls — never call `dialog.close()` directly
Always let button clicks propagate to `DialogControls.handleClose()`. Calling `dialog.close()` directly bypasses:
- `scrollLock.unlock()`
- `aria-expanded` reset on the trigger
- Focus restore

In the "no active selection" save path: just clear errors and `return` — `DialogControls` closes the dialog correctly from there.

## Known issues / pre-PR fixes applied (2026-06-16)

| Issue | Fix |
|-------|-----|
| Form lookup at construction time fails (Easify not rendered yet) | Changed `this.form` to a lazy getter that queries on each use |
| Dead `locateBespokeControl` (singular) export | Removed |
| Empty `bespoke_names` array `[]` would still emit the script tag | Added `has_bespoke_names` flag with explicit `.size > 0` guard in Liquid |
| `data-bespoke-property="Name cup 1"` produced `name="Name cup 1"` (no `properties[...]` wrapper) — Shopify silently ignores it, order receives no property | `getBespokePropertyKey` now auto-wraps: bare values get `properties[${value}]`, already-wrapped values pass through unchanged |

## Remaining / deferred

- **Bespoke label i18n** — `getBespokePropertyKey` hardcodes `Name` / `Name 1`. For per-store naming ("Name cup 1"), a Liquid setting `bespoke_label` could be passed via `data-bespoke-label` and read in JS. No work done yet — `data-bespoke-property` is the current escape hatch.
- **Multi-store reuse** — The Liquid block and TS class are store-specific. To promote to shared:
  1. Move the block to `shared/theme/blocks/_customization-drawer.liquid`
  2. Move `bespoke-names-utils.ts` to `shared/scripts/ui/`
  3. Each store's `entrypoints/index.ts` registers `CustomizationDrawer`
  4. The metafield key (`custom.bespoke_names`) could be made configurable via a block setting

## How to test

1. Product with bespoke metafield set (`shop.metafields.custom.bespoke_names`)
2. Open customization drawer → select a variant with Easify options
3. Verify: bespoke inputs appear, autocomplete works, wrong names show validation error
4. Verify: selecting → deselecting → re-selecting another option does not clear content
5. Verify: ATC is blocked when required fields are empty; allowed when valid

## Locale strings — correct location

The storefront locale strings (`general.accessibility.easify.*`) live in **`en.default.json`** — NOT `en.default.schema.json`.

| File | Purpose |
|------|---------|
| `theme/locales/en.default.json` | ✅ Storefront strings — used by Liquid `\| t` filter. Add new theme-facing strings here. |
| `theme/locales/en.default.schema.json` | ❌ Auto-generated by build from TS schema files — admin/section-editor labels only. Never add `t`-filter strings here. |

`sync-translations` merges FROM Shopify with `shopifyPrecedence: true`. Keys added locally that don't yet exist on Shopify are **preserved** — they are not overwritten. Copilot's "auto-generated" warning on `en.default.json` is a **false positive** for this project.

## aislop — code quality gate

```bash
# Scan
aislop scan stores/royal-copenhagen

# Auto-fix (unused imports, dead comments, etc.)
aislop fix stores/royal-copenhagen

# Full duplicate block details
aislop scan stores/royal-copenhagen -d
```

Score on this branch: **63 → 84** (after `aislop fix`) → **100/100** (after manual refactor).

Requires running outside the Cursor sandbox (`required_permissions: ["all"]`).

## Copilot review — recurring false positive

Copilot repeatedly flags `en.default.json` as "auto-generated, edits may be lost". This is incorrect — see locale section above. Safe to dismiss.

## Branch

`feature/STLR-5932-Bespoke-fixes`  
PR: https://github.com/Vita-Stellar/stellar-shopify/pull/1266
