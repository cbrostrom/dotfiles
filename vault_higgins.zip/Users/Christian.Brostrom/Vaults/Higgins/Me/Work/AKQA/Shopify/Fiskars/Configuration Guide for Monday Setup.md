---
tags:
  - next
  - work/fiskars
---
#next #work/fiskars

Create configuration guide to send Monday — full overview of everything that needs to be set up
