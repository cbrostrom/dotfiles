# Enterprise Shopify Framework — Extraction Plan

**Date:** 2026-06-02
**Context:** stellar-shopify (Fiskars) as the origin codebase. Framework extraction deferred until Foundation Reset completes on `feature/theme-optimisation-framework-foundation-fix`.

## Goal

Extract the reusable multi-store Shopify theme platform into a maintained upstream repo. New clients fork from it. Framework improvements flow upstream and clients pull via `git merge upstream/main`.

## Audit findings (stellar-shopify)

**~65% portable framework, ~35% Fiskars-specific**

### Framework-generic (moves to new repo)
- Build orchestrator (`build/`, `vite.config.ts`, store discovery)
- Schema pipeline (TS→JSON compilation, `shared/`, snakify utils)
- Dev tooling (tsconfig, eslint, TailwindCSS v4, Prettier)
- CI primitives (`validate-pr.yml`, all `*-job.yml` reusables — 100% parametric)
- `stores/base/` (after scrubbing 4 Fiskars refs)
- Docs (schema dev, contributing, dev workflow, commit convention)

### Fiskars-specific (stays in client repo)
- `version.json` (8-store registry)
- `stores/{7 brands}/` (all brand content)
- `push-theme-to-{dev,test,prod}.yml` (7 brand names + 21 secrets hardcoded)
- `.env` Shopify tokens
- `docs/foundation-reset/` (migration-specific)

### 4 scrub points in `stores/base/`
| File | Issue |
|---|---|
| `stores/base/src/schemas/configs/theme-info.ts:5` | Hardcodes `/fiskars/stellar-shopify` GitHub URL |
| `package.json` | Name: `akqa-dk-shopify-theme` → `stellar-shopify-framework` |
| `.github/workflows/push-theme-to-foundation.yml` | Branch name hardcoded |
| `.github/workflows/sync-docs-to-wiki.yml` | References `Vita-Stellar/stellar-shopify-theme-base` |

## Architecture: Fork + upstream remote

```
stellar-shopify-framework  (upstream, maintained by framework team)
  stores/base/             ← framework team owns
  build/
  shared/
  vite.config.ts
  .github/workflows/*-job.yml   ← reusable CI primitives
  validate-pr.yml
  version.json.template
  scripts/init-client.ts        ← generates version.json + deploy workflows

fiskars/stellar-shopify    (too far gone — stays as-is, add upstream remote)
stellar-shopify-<client2>  (new clients fork at day 0)
  stores/base/             ← merged from upstream
  stores/{brand}/          ← client owns, never touched by upstream
  version.json             ← client owns
```

**Key invariant:** Clients never modify `stores/base/` or `build/`. All brand work in `stores/{brand}/`. This keeps `git merge upstream/main` conflict-free.

## Update flow

```
upstream fix → client: git fetch upstream && git merge upstream/main
Conflicts only if client touched stores/base/ — enforced by convention + CI guard
```

## Enforcement

1. **Base-drift CI check** — diffs `stores/base/` against `upstream/main:stores/base/` on PR, fails if diverged without documented reason
2. **Contributing.md convention** — "never commit to `stores/base/` in a client repo"

## Extraction scope (~3-5 days)

| Task | Effort |
|---|---|
| New GitHub org/repo `stellar-shopify-framework` | Trivial |
| Copy `stores/base/`, `build/`, `shared/`, tooling | Small |
| Scrub 4 Fiskars refs in `stores/base/` | Small |
| Add `version.json.template` + 1 example store | Small |
| Write `scripts/init-client.ts` | Medium |
| Port `*-job.yml` reusables (already parametric) | Trivial |
| Add base-drift CI check | Medium |
| Docs: upstream pull runbook | Small |
| Fiskars: add `upstream` remote, document it | Trivial |

## Status / Timing

**Foundation Reset has been abandoned** on `feature/theme-optimisation-framework-foundation-fix`. It will not land in Fiskars.

However — the architectural work done during Foundation Reset (shared schemas, phase-based migration, base consolidation, soak-shop validation pattern) is exactly the right conceptual foundation for the new enterprise repo. Build it fresh, informed by that work, without Fiskars baggage.

**Do not extract from the Fiskars repo.** Build `stellar-shopify-framework` as a greenfield repo using Foundation Reset's architectural decisions as the blueprint. The Fiskars codebase is the reference implementation showing what works and what needs solving — not the source to copy from.

Fiskars stays as-is.
