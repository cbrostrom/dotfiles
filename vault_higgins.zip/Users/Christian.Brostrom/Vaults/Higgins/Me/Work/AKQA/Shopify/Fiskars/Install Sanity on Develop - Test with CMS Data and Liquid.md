Install Sanity on develop — test with CMS data and Liquid
