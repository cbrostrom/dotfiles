---
tags:
  - work
  - work/fiskars
---

Need to set up markets etc. properly — a lot of things need to be configured in markets.
