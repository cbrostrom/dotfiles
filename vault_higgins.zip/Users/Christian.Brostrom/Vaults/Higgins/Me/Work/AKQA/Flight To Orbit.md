---
created: 2024-01-01
type: project
project: AKQA
tags:
  - work
  - work/akqa
---

# Flight To Orbit

## Team
- Casper
- Joan
- Christian

## Huskeliste

- [x] Opret mail ✅ 2025-12-01
- [x] Adgange ✅ 2025-12-01
  - [x] Git ✅ 2025-12-01
  - [x] Jira ✅ 2025-12-01
