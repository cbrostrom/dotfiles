---
tags:
  - work/themelio
  - next
---
#next #work/fiskars 

Husk at lave konfigurationsguide til at kunne sendes mandag - overblik over ALT der skal sættes op 

