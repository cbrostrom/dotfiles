---
tags:
  - work
  - work/fiskars
---

Det er vigtigt at vi får sat markeder osv godt op

Der skal stå en masse ting i markeder