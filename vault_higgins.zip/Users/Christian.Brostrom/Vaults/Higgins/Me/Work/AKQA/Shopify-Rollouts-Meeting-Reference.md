---
created: 2026-07-02
tags: [shopify, fiskars, meeting, rollouts, scheduling]
---

# Shopify Rollouts — Meeting Reference
> For: Fiskars client meeting on campaign scheduling capability
> Two tickets in scope: **Price scheduling** + **Content scheduling**

---

## What Is Shopify Rollouts? (Non-Technical Explanation)

Think of Rollouts as a **"publish later" button for your storefront's look and feel**. Instead of changing your website's design and content immediately and hoping everything works, you can:

- Prepare changes in advance
- Tell Shopify *when* to show them
- Tell Shopify *when to stop* (auto-revert)
- Test changes on a small slice of visitors before showing everyone

It lives in your Shopify admin under **Markets → Rollouts** and was released by Shopify in March 2026 (with an expansion in June 2026).

**Analogy for the meeting:** It's like setting a social media post to publish at midnight on Black Friday — except for your entire website's design.

---

## Rollouts: What It Can and Cannot Do

### ✅ What Rollouts CAN do out of the box

| Feature | What it means in plain language |
|---|---|
| **Scheduled publishing** | "Flip to our Black Friday theme at exactly 00:00 on Nov 28" |
| **Automatic revert** | "Switch back to the normal theme after the campaign ends — without anyone having to be awake" |
| **Gradual rollout** | "Show the new design to 10% of visitors first, then increase if it's working" |
| **A/B testing** | "Show half your visitors Version A and half Version B — let the data pick the winner" *(Grow plan+)* |
| **Market-specific targeting** | "Run the EMEA campaign version for European visitors, a different version for US" *(Advanced/Plus only)* |
| **Multiple simultaneous rollouts** | Several different rollouts can run at the same time without conflicting |
| **Draft on live theme** | Edit your running theme without creating a messy duplicate |

### ❌ What Rollouts CANNOT do

| Limitation | Why it matters for these tickets |
|---|---|
| **No price or discount scheduling** | Rollouts is only for *design/content* — not prices. Ticket 1 is entirely out of scope. |
| **Theme-level, not component-level** | You can't say "schedule just the homepage banner" — the whole theme switches. This is the same core limitation Launchpad has. |
| **No overlap of content within a theme** | You can run two rollouts, but if they change the *same section*, they will conflict. True component-level scheduling is not possible. |
| **Market targeting is Plus/Advanced only** | Smaller-plan stores can't target by market |
| **A/B testing is Grow plan+** | Basic and Standard plan stores can schedule/revert, but can't do split tests natively |

---

## Ticket 1: Scheduled Discount Price Imports

### Does Rollouts help here?
**No. Not at all.** Rollouts deals with themes and storefront design — it has zero connection to prices, price lists, or discount management.

### What Shopify CAN do natively for pricing

| Native capability | Limitation |
|---|---|
| Automatic discounts with a start/end date | Works per-discount, not per bulk price list import. Each discount needs to be created individually. |
| Up to **25 concurrent automatic discounts** (increased from 5 in late 2024) | Sounds like a lot, but for multi-market multi-wave campaigns it fills up fast |
| Compare-at price (shows strikethrough "was £X") on variants | No scheduling — it goes live the moment you save |
| Price lists (per Market) | No scheduling — active immediately when uploaded |

### The core problem
Shopify's pricing model is **"set it and it's live"** — there is no native mechanism to say:

> *"Apply these 3,000 product prices at 6:00 AM on Thursday and remove them at 11:59 PM on Sunday."*

This is a **genuine gap in the Shopify platform**.

### Arguments FOR custom development here
- This is a high-value problem to solve (legal compliance, operational risk reduction)
- The pattern is well-understood: a scheduled job swaps prices via Shopify's Admin API at the right time
- It can be built once and reused across brands/markets/campaigns
- Enables price verification before go-live (campaign team can check prices in a staging state)

### Arguments AGAINST / risks
- Requires a custom app or integration — ongoing maintenance cost
- Needs careful handling of timezone logic for global markets
- Shopify's API has rate limits — bulk price updates for large catalogs need to be staged
- The 25-automatic-discount limit can still be hit for complex multi-wave campaigns

### Alternative options (brief)
1. **Custom-built scheduler app** (bespoke) — most control, highest cost
2. **Third-party apps** (e.g., Ablestar Bulk Product Editor, Sale & Discount Manager) — faster to launch, less control, ongoing subscription cost
3. **Shopify Functions for discounts** — can create start/end date logic per campaign, but not as a "price list import" — more like campaign discount rules

---

## Ticket 2: Content Scheduling (Homepage, Collection Page, Menu, Header)

### Does Rollouts help here?
**Partially — but not completely.** Rollouts is the closest native Shopify feature, and it's significantly better than Launchpad, but it still doesn't tick every box.

### Rollouts vs. the Acceptance Criteria

| Acceptance Criteria from ticket | Rollouts verdict |
|---|---|
| Start/end dates per market | ✅ Supported (Advanced/Plus only) |
| Market schedules override global | ✅ Supported |
| Multiple parallel events (time ranges can overlap) | ✅ Supported via multiple concurrent rollouts |
| Component-level scheduling (homepage, collection, menu, header *independently*) | ❌ Not supported — still theme-level |
| Consecutive content updates (Black Friday weekend waves) | ⚠️ Possible but each requires a separate rollout; no seamless chaining |
| Reliable activation and rollback at set time | ✅ This is where Rollouts improves on Launchpad — it's reliable |
| No 5-minute gap between events | ✅ No mandatory gap in Rollouts |

### The key remaining gap
The client's acceptance criteria explicitly asks for **component-level scheduling** — meaning:

> "Schedule the homepage banner for Market X, *without* touching the collection page or the header"

Rollouts operates at the **theme level**, meaning a "rollout" swaps the entire theme configuration (or checkout). You cannot surgically schedule one section while leaving others untouched — unless you build out the logic inside the theme itself (e.g., via metafields + custom Liquid logic that reads a "show after date X" flag).

### Where Rollouts beats Launchpad

| Issue with Launchpad | How Rollouts addresses it |
|---|---|
| Only one event at a time | Multiple simultaneous rollouts ✅ |
| Theme-level only | Still theme-level ❌ (same problem) |
| Unreliable — fresh session needed | Rollouts activates at set time, no session refresh needed ✅ |
| 5-minute mandatory gap | No gap in Rollouts ✅ |
| No market targeting | Market-level targeting on Advanced/Plus ✅ |

### Arguments FOR using Rollouts (partial solution)
- **Native, no third-party app cost** — reduces vendor risk
- **More reliable than Launchpad** — the activation timing criticism is addressed
- **Market targeting built in** — critical for multi-region campaigns
- **Available now** — released March 2026, stable
- Good for whole-theme campaign switches (BFCM theme, holiday theme) that are already common practice

### Arguments AGAINST Rollouts as a complete solution
- **Doesn't solve component-level scheduling** — the most important requirement
- **A/B testing locked to Grow plan** — may require a plan upgrade
- **Market targeting locked to Advanced/Plus** — multi-market campaigns may require plan upgrade
- Still requires a team member to build and configure each rollout ahead of time

### Alternative / complementary options (brief)

1. **Rollouts + Metafield-based date flags inside the theme** (hybrid approach)
   - Custom Liquid logic in theme sections reads a "show_from / show_until" metafield on each content block
   - A lightweight scheduled app flips the metafields at the right time
   - Achieves component-level precision while using Rollouts for larger theme swaps
   - **Moderate custom dev effort** — reusable once built

2. **Contentful / Sanity CMS with Shopify** (headless or hybrid)
   - Content scheduling lives in the CMS, not Shopify
   - Very powerful, full component-level control
   - **High complexity** — only makes sense if the client is already moving toward headless

3. **Custom scheduling app** (full bespoke)
   - Total control over granularity and timing
   - Highest cost, longest timeline

---

## Quick Summary for the Room

| Topic | What Shopify Rollouts gives you | What still needs custom work |
|---|---|---|
| **Price scheduling** | Nothing | Everything — needs custom solution |
| **Content scheduling** | Reliable theme-level scheduling + market targeting | Component-level control (homepage vs. menu vs. collection independently) |
| **Multi-market campaigns** | ✅ Built in (Advanced/Plus) | — |
| **Multiple parallel events** | ✅ Built in | — |
| **Legal compliance (timing precision)** | ✅ Rollouts is reliable at set time | Price timing still needs custom work |
| **Pre-campaign verification** | ⚠️ Can preview a draft rollout | Cannot verify prices before they're live |

---

## Plan Tiers Cheat Sheet (for any plan questions)

| Feature | Basic | Grow | Advanced | Plus |
|---|---|---|---|---|
| Rollouts (scheduling + revert) | ✅ | ✅ | ✅ | ✅ |
| Gradual rollouts (% of visitors) | ✅ | ✅ | ✅ | ✅ |
| A/B experiments | ❌ | ✅ | ✅ | ✅ |
| Market-specific targeting | ❌ | ❌ | ✅ | ✅ |

---

## Key Talking Points

1. **"Rollouts is not a silver bullet for these two tickets"** — it helps meaningfully with content scheduling reliability, but leaves both component-level granularity and all price scheduling unsolved.

2. **"The price scheduling ticket requires custom work regardless"** — there is no native Shopify mechanism to schedule bulk price list uploads. This is a known platform gap.

3. **"Rollouts is worth adopting for what it does well"** — whole-theme campaign switches (BFCM, seasonal) with reliable timing and market targeting. It replaces Launchpad without Launchpad's problems.

4. **"Component-level content scheduling needs a hybrid approach"** — the most pragmatic path is Rollouts for theme-level events + a lightweight scheduling mechanism for section-level metafield flags inside the theme.

5. **"Plan tier matters"** — multi-market targeting requires Advanced or Plus. If the client is on a lower tier, this needs to be factored into the plan.

---

*Sources: Shopify Changelog March 31 2026, Shopify Changelog June 5 2026, Shopify Help Center — Rollouts, Shopify Dev Docs — Discounts API, Shopify Dev Docs — Markets API*
