#work #work/fiskars - der skal kigges på hvordan vi strukturerer det og sørger for at versioner kan dokumenteres men også hvordan vi laver review osv.
