# OneTrust → Shopify Customer Privacy API Integration

**Date:** 2026-06-08
**Project:** Fiskars / Moomin Arabia (stellar-shopify-app-tracking-web-pixel)
**Status:** Part 1 implemented (2026-06-08) — Part 2 pending decision

---

## Why this exists

Shopify requires a "properly integrated" third-party CMP to call `Shopify.customerPrivacy.setTrackingConsent()` in order for:

1. **GPC (Global Privacy Control) header** opt-outs to be honoured at the data layer
2. **Shopify's data sharing opt-out page** opt-outs to propagate
3. **Customer activity to be marked** as excluded from **Shopify Network Intelligence** advertising

Currently OneTrust manages consent for our own tracking (GA4, Meta, Google Ads, Bloomreach) via GTM Consent Mode v2 — but it does NOT call Shopify's Customer Privacy API. That means Shopify cannot mark customer data appropriately for their own network, regardless of what the user chooses in the OneTrust banner.

---

## What needs to change

### Part 1 — Required (fixes Shopify Network Intelligence gap)

**Add an OneTrust → `Shopify.customerPrivacy` bridge in `tracking-receiver.js`**

The script must:
1. On page load: read the `OptanonConsent` cookie and call `Shopify.customerPrivacy.setTrackingConsent()` with the current consent state
2. On `OneTrustGroupsUpdated` event: call `setTrackingConsent()` again with the updated state

The bridge maps OneTrust groups to Shopify consent categories:
- `C0002` (Performance/Analytics) → `analytics`
- `C0004` (Targeting/Advertising) → `marketing`
- `C0003` (Functional) → `preferences`

This runs on the **storefront** (not in the pixel sandbox — `Shopify.customerPrivacy` is not available inside web pixel workers).

**File to change:** `extensions/tracking-receiver/assets/tracking-receiver.js`
or a new dedicated block.

---

### Part 2 — Optional but recommended (proper pixel declaration)

**Update `extensions/web-pixel/shopify.extension.toml`** from:

```toml
[customer_privacy]
analytics = false
marketing = false
preferences = false
sale_of_data = "disabled"
```

to:

```toml
[customer_privacy]
analytics = true
marketing = true
preferences = false
sale_of_data = "disabled"
```

This makes the pixel truthfully declare what consent it needs. With Part 1 in place, Shopify will then gate event delivery to the pixel based on actual consent state.

> **This is the highest-risk change.** See impact section below.

---

## Full impact analysis

### Part 1 only (bridge script — lower risk)

| Area | Impact | Severity |
|---|---|---|
| Shopify Network Intelligence | Data now correctly marked on opt-out | ✅ Intended |
| GPC header handling | Shopify now honours it at their data layer | ✅ Intended |
| Our tracking (GA4/Meta/Google Ads) | No change — still gated via GTM Consent Mode | None |
| Bloomreach | No change — still gated via own OneTrust check | None |
| sessionStorage bridge | No change | None |
| Checkout Custom Pixel | No change | None |
| Users who already accepted cookies | Must read existing cookie on load or they won't be registered with Shopify until next banner interaction | ⚠️ Need to handle |
| Pages where `Shopify.customerPrivacy` is not available (e.g. checkout) | Bridge must guard against undefined — won't throw but won't register | ⚠️ Need to guard |

---

### Part 2 (TOML change — higher risk)

**What changes in Shopify's behaviour:**
When `analytics = true` / `marketing = true`, Shopify's web pixel framework only delivers events to the App Pixel **after** the customer has given the corresponding consent. Before consent, the pixel receives no events.

| Area | Impact | Severity |
|---|---|---|
| sessionStorage bridge (storefront events) | No events written to sessionStorage until consent given → GTM receives nothing until consent | 🔴 Breaking for pre-consent tracking |
| GTM storefront tracking (page_view, view_item, add_to_cart, etc.) | These events will be lost for users who browse and leave without accepting the banner | 🔴 Loss of data |
| Google Consent Mode modelled data | GA4 uses Consent Mode to model/fill in unconsented users. If events never reach GA4 at all, modelling is also lost | 🔴 Analytics gap |
| Checkout Custom Pixel | Unaffected — runs in its own lax sandbox, separate from App Pixel consent gating | None |
| Server-side tracking (currently inactive) | When re-enabled: would also be gated, consistent behaviour | ✅ Correct |
| Bloomreach | Unaffected — gated separately via OneTrust, not via Shopify pixel events | None |
| App Pixel event subscriptions | All `analytics.subscribe()` calls fire only after consent. Event order and timing may shift (page_viewed could arrive late or be missed) | ⚠️ Test required |
| Existing users with accepted consent | Once Part 1 bridge is in place and `setTrackingConsent()` is called on load, these users should be gated correctly and events should flow | ✅ OK if Part 1 done first |

> **Recommendation:** Do Part 1 first and run it in production for at least 2 weeks before considering Part 2. Part 2 fundamentally changes how the storefront data pipeline works.

---

## What definitely does NOT break (regardless of both parts)

- The Bloomreach liquid block — completely independent
- The Checkout Custom Pixel (GTM bridge) — separate sandbox, own consent polling
- GTM itself and any tags configured inside the container
- OneTrust banner rendering and user interactions
- Shopify storefront functionality (cart, checkout, customer accounts)
- Any theme Liquid code
- The `stellar:` custom events published via `Shopify.analytics.publish()`
- The `_stellar_gcid` cookie written by tracking-receiver
- Server-side API calls (GA4 MP, Meta CAPI, Google Ads, Bloomreach via fetch) — currently inactive, unaffected

---

## Implementation order (if proceeding)

1. **Confirm with client** which OneTrust group IDs map to which consent categories on their specific OneTrust configuration (group IDs can differ between accounts)
2. **Implement Part 1** — bridge script in tracking-receiver
3. **Test on staging**: verify `Shopify.customerPrivacy.currentVisitorConsent()` reflects OneTrust choices correctly
4. **Test GPC**: use a browser extension to send GPC header — confirm Shopify marks correctly
5. **Deploy Part 1** to production stores one at a time
6. **Monitor** for 2+ weeks — check GA4 data quality, confirm no regressions
7. **Decide on Part 2** — discuss with client whether gating the pixel at Shopify level is desired given the data loss trade-off
8. **If Part 2 proceeds**: test thoroughly on staging, monitor session/event counts on GA4 before/after

---

## Files that would be touched

| File | Change |
|---|---|
| `extensions/tracking-receiver/assets/tracking-receiver.js` | Add OneTrust → `Shopify.customerPrivacy` bridge |
| `extensions/web-pixel/shopify.extension.toml` | (Part 2 only) Set `analytics = true`, `marketing = true` |

No changes needed to:
- `web-pixel/src/index.ts`
- `tracking-receiver/blocks/*.liquid`
- Custom pixel script (checkout GTM bridge)
- Any theme files

---

---

## Part 2 — Data loss explained for legal

> Use this section when presenting the Part 2 trade-off to the client's legal or analytics team.

### What Part 2 changes

Part 2 updates the web pixel manifest (`shopify.extension.toml`) to declare that the pixel requires analytics and marketing consent before Shopify delivers events to it. Currently those flags are set to `false`, meaning Shopify sends the pixel all events regardless of what the customer chose in the cookie banner.

### What is happening today (no Part 2)

Events flow like this for **every visitor**, consented or not:

```
Shopify event (page view, product view, etc.)
  → App Pixel receives it
  → writes to sessionStorage
  → tracking-receiver picks it up
  → pushes to window.dataLayer
  → GTM receives the event
  → GTM tags CHECK consent before firing
      → GA4 tag: blocked if analytics consent denied
      → Meta tag: blocked if marketing consent denied
      → Google Ads tag: blocked if marketing consent denied
```

The event data travels all the way to GTM for every visitor. GTM's built-in consent checks (Google Consent Mode v2) then decide whether to actually send that data to Google/Meta. For users who decline, the tags don't fire — but GA4 can still use the **fact that an event arrived** to produce **modelled data**: statistical estimates of what those unconsented users did, shown in GA4 reports alongside measured data.

This means: GA4 today shows near-complete traffic reporting. A portion is measured (consented users), a portion is modelled (GA4's estimate for declined users). The modelling is what keeps the numbers looking whole.

### What changes after Part 2

With `analytics = true` and `marketing = true` in the manifest, Shopify stops delivering events to the App Pixel for any visitor who has not yet given consent. The pipeline becomes:

```
Shopify event
  → Shopify checks consent state
  → If not consented: event is NOT sent to the App Pixel
  → sessionStorage is never written
  → GTM never receives the event
  → GA4 receives nothing — no measured data, no modelling signal
```

### The concrete impact

| Metric | Today | After Part 2 |
|---|---|---|
| GA4 sessions (consented users) | Measured accurately | Measured accurately |
| GA4 sessions (declined users) | Modelled by GA4 | **Not reported at all** |
| GA4 total sessions | Measured + modelled ≈ full traffic | Only consented traffic |
| Conversion rates | Based on near-complete traffic | Denominator shrinks → rates may look artificially inflated or deflated |
| Funnel analysis | Near-complete | Only consented users visible |

Depending on the banner opt-in rate, this can look like a 20–60% drop in reported sessions overnight. It is not a traffic drop — it is a reporting scope reduction.

### Is the current setup non-compliant?

No. The current setup (Part 1 only) is not non-compliant from a data protection perspective:

- Consented users: tracked fully via GTM tags
- Non-consented users: events reach GTM but no tags fire → no data sent to Google/Meta
- Google Consent Mode is specifically designed for this pattern: events arrive, tags respect consent, modelling fills the gap

Part 2 would make the implementation **stricter** — applying consent gating one layer earlier (at the Shopify event delivery level rather than at the GTM tag level). The outcome for actual data sent to third parties is the same. The difference is only in whether GA4's modelling engine receives a signal.

### Recommendation to legal

Part 1 (already implemented) closes the gap Shopify raised: OneTrust decisions now flow to Shopify's Customer Privacy API, meaning Shopify can correctly exclude opted-out visitors from Shopify Network Intelligence.

Part 2 is an additional layer of strictness that does not improve compliance meaningfully but does reduce analytics reporting completeness. The decision is a policy choice, not a legal requirement. If legal requires maximum technical strictness regardless of analytics impact, Part 2 should proceed. If legal is satisfied that consent is properly enforced at the GTM/tag layer (which it is), Part 2 is not necessary.

---

## Open questions for client

1. What are the exact OneTrust category group IDs configured for their account? (Assumption: C0002=analytics, C0004=marketing — but must verify)
2. Is there a staging/UAT environment to test consent flows before production?
3. Do they want Part 2 (pixel-level gating)? This is stricter compliance but trades off pre-consent modelled data in GA4.
4. Are there any other Shopify markets/stores beyond Moomin Arabia that need the same fix?
