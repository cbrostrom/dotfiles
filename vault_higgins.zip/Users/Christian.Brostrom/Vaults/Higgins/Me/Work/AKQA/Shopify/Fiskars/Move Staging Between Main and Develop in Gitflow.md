Move staging to sit between main and develop in the gitflow diagram #fiskars
