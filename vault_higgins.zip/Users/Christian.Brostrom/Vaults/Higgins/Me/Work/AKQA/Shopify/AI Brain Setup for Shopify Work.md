---
created: 2026-06-26
area: work
type: reference
client: shopify
tags: [ai, vault, token-efficiency, shopify]
---

# AI Brain Setup for Shopify Work

This note explains how I use my Obsidian brain with AI for work, especially Shopify work. The short version is that the vault is not meant to be a big archive the model reads from top to bottom. It is a routed memory system: small current-state files for active projects, structured work folders for durable client knowledge, and a set of lookup rules that tell the AI where to look first.

The aim is token efficiency. The AI should arrive with the right context, not all context.

## The Core Idea

My vault is designed around one constraint: AI context is expensive. If a model has to read every note to understand a project, the system has already failed.

Instead, the vault gives the AI a map. `AGENTS.md` is the root guide: it tells the agent that the human role is mostly viewer, the AI role is primary writer and organizer, and that Obsidian is the reading surface on top of that system. It also defines the top-level split between `Work/`, `Development/`, `Brains/`, `Plans/`, `Inbox/`, and the rest of the vault. Source: `AGENTS.md`.

For work, that means the AI does not start by searching personal notes or old archives. It starts in the work area, project brain, or active plan that matches the task.

## How The Vault Is Structured For Work

The work-relevant structure is simple:

- `Work/AKQA/` holds client and agency material.
- `Work/AKQA/Shopify/` holds Shopify-specific research, delivery notes, and reusable thinking.
- `Work/AKQA/Shopify/Fiskars/` holds concrete Fiskars notes.
- `Brains/` holds current project state: what is true now, what is next, what is risky.
- `Development/` holds cross-cutting technical knowledge that can support work without being client-specific.
- `Inbox/` is capture only. It is deliberately unprocessed until the librarian flow routes it.

The important detail is that these folders have different jobs. Shopify research belongs in `Work/AKQA/Shopify/`. A reusable AI or vault pattern belongs in `Development/` unless it is explicitly framed for work. A live project state belongs in `Brains/`. That separation keeps prompts small because the AI can ask: "Is this current state, durable work knowledge, or general technical reference?"

## The Token-Efficient Lookup Pattern

The vault guide defines a cheap-to-expensive lookup order:

1. Frontmatter search.
2. Hashtag search.
3. Filename match.
4. Content search.
5. Targeted reads of the best few files.

That order matters. Frontmatter and filenames are cheap. Reading a whole folder is expensive. So the AI should first narrow by `area: work`, `type: reference`, `client: shopify`, or a filename like `Fiskars`, then read only the one to three files that look relevant. Source: `AGENTS.md`.

This is the main trick: the vault is not just organized for humans browsing in Obsidian. It is organized so an AI can cheaply decide what not to read.

## Project Brains

For active code work, the `Brains/` layer is the first stop. The brain system loads a project-specific file at session start based on the current repository or working directory slug. Source: `Development/Vault/Brain-System.md`.

That means a Shopify repo session should not need a long recap every time. The project brain should carry the current decisions, gotchas, and next steps. The longer notes stay in `Work/AKQA/Shopify/` or `Development/`, while the brain keeps only the short "state of play".

The project brain is useful because it is intentionally small. It should answer:

- What is true right now?
- What decision has already been made?
- What is the next useful action?
- What trap should the next agent avoid?

It is not the place for a full architecture essay. It is the index card the AI reads before opening the bigger source notes.

## Inbox And Librarian Flow

The inbox is for speed. I can dump a thought without deciding where it belongs. The AI later processes `Inbox/` with a librarian flow: infer area and type, propose backlinks, propose a destination, and wait for confirmation before moving anything. Source: `AGENTS.md`.

That keeps capture lightweight without letting the vault rot. It also avoids a common AI-memory problem: if everything is saved immediately as "memory", retrieval becomes noisy. In this setup, raw thoughts stay raw until routed.

## Shopify Case: From Research To Reusable Work Memory

The Shopify notes show how the system works in practice.

`Work/AKQA/Shopify-Headless-Landscape.md` is a durable research brief. It compares Hydrogen, Hydrogen React, and Storefront API plus the Headless channel. The useful AI-memory point is not just the conclusion, but the shape of the conclusion: Hydrogen is strong when the project wants Shopify's opinionated React/Oxygen path, while Storefront API plus a framework adapter is better for a multi-framework offering. Source: `Work/AKQA/Shopify-Headless-Landscape.md`.

That kind of note should not be copied into every project brain. Instead, a future Shopify AI session should find it by work area, Shopify filename, and research intent. If the current task is "recommend a headless stack", the model reads this one note. If the task is "fix Liquid in Fiskars", it probably should not.

`Work/AKQA/Shopify/Fiskars/Enterprise Shopify Framework - Extraction Plan.md` is different. It is a project-specific architectural note. It records that the Fiskars `stellar-shopify` codebase was roughly assessed as 65% portable framework and 35% Fiskars-specific, and that the better path was not to extract directly from Fiskars but to build a greenfield `stellar-shopify-framework` informed by the Foundation Reset work. Source: `Work/AKQA/Shopify/Fiskars/Enterprise Shopify Framework - Extraction Plan.md`.

That distinction matters for AI work. A model helping on a new Shopify client should be able to reuse the architectural insight without carrying all Fiskars baggage. The note gives the reusable invariant: keep client-owned store work separate from framework-owned base code, and make upstream updates mergeable.

## How I Would Explain The Setup

If I had to explain this setup in a Shopify and AI case, I would say:

> I do not use the vault as a giant prompt. I use it as a routing layer. The AI starts with a small project brain, then uses frontmatter, filenames, and folder boundaries to find only the notes that matter. For Shopify work, that means one session can pick up current repo state from `Brains/`, durable Shopify research from `Work/AKQA/Shopify/`, and client-specific context from `Work/AKQA/Shopify/Fiskars/`, without reading personal notes or unrelated projects.

The benefit is not just speed. It changes the quality of the answer. The AI is less likely to blend old context with current context, less likely to overfit to a previous client, and less likely to spend the first half of the session rediscovering decisions that were already made.

## What Makes It Work

The setup works because it has a few hard rules:

- Current state is separated from durable reference material.
- Work knowledge is separated from personal knowledge.
- Raw capture is separated from processed notes.
- Notes get frontmatter so they can be found cheaply.
- AI is allowed to maintain the vault, but routing from inbox still requires confirmation.
- Big research notes are cited and reusable, while project brains stay short.

This is also why the system is token efficient. The vault does not try to make every note equally available. It makes the right note discoverable at the right time.

## Presentation Notes

For a Shopify AI case, I would frame the story in three layers:

1. **Memory layer:** `Brains/` keeps the current repo state small enough to load automatically.
2. **Knowledge layer:** `Work/AKQA/Shopify/` keeps durable Shopify decisions and research.
3. **Client layer:** `Work/AKQA/Shopify/Fiskars/` keeps the messy, specific reality of an actual enterprise Shopify implementation.

Then I would use the headless landscape note as the research example and the enterprise framework extraction note as the delivery example. One shows how AI helps compare platform paths. The other shows how AI preserves architectural decisions so the next session starts from judgment, not from scratch.

## Sources

- `AGENTS.md`
- `Development/Vault/Brain-System.md`
- `Development/Vault/Mappestruktur.md`
- `Work/AKQA/Shopify-Headless-Landscape.md`
- `Work/AKQA/Shopify/Fiskars/Enterprise Shopify Framework - Extraction Plan.md`
