---
tags: [wedgwood, performance, video, shopify, report]
created: 2026-06-17
updated: 2026-06-17
status: action-required
---

# Wedgwood Page Performance Report
**Date:** 17 June 2026 (revised after deeper testing)
**Pages audited:** Homepage, All Gifts, Wedding Gifts

> ⚠️ **Correction from earlier draft.** The initial report mistakenly attributed videos to All Gifts and Wedding Gifts. A clean per-page browser session shows those pages have **zero video elements and zero video network requests**. Only the homepage has videos. Each page has its own distinct performance problem.

---

## Verified findings per page

| Page | Total weight | Requests | Video elements | Video bytes | Cause |
|------|--------------|----------|---------------|-------------|-------|
| Homepage (`/en-gb`) | **23.7 MB** | 236 | 3 | 21.96 MB | Two HD-1080p 7.2 Mbps videos auto-downloading |
| All Gifts (`/en-gb/collections/all-gifts`) | 2.6 MB | 252 | 0 | 0 | High request count: 110 checkout preloads + 70 product images |
| Wedding Gifts (`/en-gb/collections/wedding-gifts`) | 2.7 MB | 237 | 0 | 0 | Heavy hero images load late, no preload/priority hints |

---

## Homepage — the real video offender

3 `<video>` elements in DOM. Two of them transfer over the wire:

| Source | Size | Format |
|--------|------|--------|
| `690e027036f74a0ca9336fa18d31e9b0...HD-1080p-7.2Mbps-86662145.mp4` | **12.1 MB** | 1080p, 7.2 Mbps |
| `ec43a2ce817e455f8242d630c88137aa...HD-1080p-7.2Mbps-79908518.mp4` | **9.3 MB** | 1080p, 7.2 Mbps |
| Third `<video>` (720p, 4.5 Mbps) | ~500 KB partial | Hidden (responsive) |

**Total ≈ 22 MB of video on a single page load.** The filename `7.2Mbps` confirms broadcast/studio bitrate — web video at the same resolution should be 1–2 Mbps.

None of the video elements have `preload="none"`. They're all set to `loop`, `muted`, and one is `autoplay`. Result: the browser starts downloading them immediately even when below the fold.

---

## All Gifts — request-count problem, not weight

Total page weight is only 2.6 MB. The slowdown comes from **252 separate HTTP requests**:

- **110 `<link rel="preload">` requests** for Shopify Checkout assets (`shopifycloud/checkout-web/assets/c1/*`) — these load checkout JS/CSS chunks on a collection page where checkout isn't used.
- **70 product/collection images** for the gift grid.
- **38 scripts** total (theme + Shopify pixels + tag manager + checkout preloads).

Heaviest individual asset is Shopify's own `hydrate.CGEe3Tl5.js` at 221 KB. Collection thumbnails are mostly 60–100 KB each.

This is a death-by-a-thousand-cuts problem: nothing is huge, but the parallel connection count blocks the browser from finishing critical work.

---

## Wedding Gifts — late-loading hero, similar request pattern

Total page weight is 2.7 MB across 237 requests. **FCP is ~1000 ms versus ~200 ms on the other pages.**

Heaviest assets are all hero/banner images that arrive *late*:

| Asset | Size |
|-------|------|
| `Wedgwood_Gifting_2026_11_8x9_Desktop.jpg` | 187 KB |
| `Wedgwood_Gifting_2026_12_9x8_Mobile.jpg` (LCP image) | 145 KB |
| `Wedgwood_Gifting_2026_04_16x9_Landscape.jpg` | 125 KB |
| `Wedgwood_Gifting_2026_38_9x8_Mobile.jpg` | 101 KB |
| `Wedgwood_Gifting_2026_38_8x9_Desktop.jpg` | 93 KB |

Inspection of the page `<head>` shows:
- **No `<link rel="preload">` for the LCP image.** Browser discovers it only after parsing the HTML.
- The LCP image has `loading="eager"` but **no `fetchpriority="high"`**.
- Same 110 checkout-asset preloads as All Gifts compete for the connection.

Result: the hero image starts at request sequence ~141 of 237, after dozens of scripts and stylesheets.

---

## Root cause summary

| Page | Content issue | Code issue |
|------|--------------|-----------|
| Homepage | Two 22 MB combined videos at 7.2 Mbps — must be re-encoded | `<video>` tags lack `preload="none"`, lack viewport gating |
| All Gifts | Many product images on grid — could lazy-load below fold | Section/template emits all 70 images upfront; checkout asset preloads can't be removed (Shopify platform) |
| Wedding Gifts | Multiple large hero variants (mobile + desktop both load) | No `<link rel="preload">` for LCP image, no `fetchpriority="high"` on hero `<img>` |

---

## Recommended fix plan

### Homepage — biggest impact, fastest win

**Content team** (saves ~18 MB per page load):
1. Re-encode the two videos at **1.5–2 Mbps, 720p–1080p H.264** (or H.265/AV1 if Shopify CDN serves them).
2. Replace them in Shopify admin. Expect final files ≈ 1.5–3 MB each.

**Dev team** (~10-line change in theme):
3. Add `preload="none"` to the `<video>` tags in the hero-group section.
4. Only set `autoplay` once the element enters the viewport (Intersection Observer).
5. Provide a `poster` image so the visual placeholder is instant.

### All Gifts — request count

**Dev team:**
1. Audit the collection product card template — confirm `loading="lazy"` is on all but the first row of product images.
2. Confirm `srcset` / `sizes` are correct so browsers pick the right resolution.
3. The 110 checkout asset preloads are emitted by Shopify itself; not actionable in the theme.

**Content team:**
4. Reduce the number of products shown above the fold if possible (smaller initial page size).

### Wedding Gifts — slow first paint

**Dev team** (small theme change):
1. Add `<link rel="preload" as="image" imagesrcset="..." imagesizes="..." href="...">` for the LCP hero image in the page `<head>`. This is the single biggest FCP win.
2. Add `fetchpriority="high"` to the hero `<img>` element.
3. Ensure only the responsive variant that matches the viewport is loaded (currently both mobile + desktop variants appear in the network log — verify the `<picture>`/`srcset` is set up correctly).

---

## Tools that would speed up future audits

- **Lighthouse / PageSpeed Insights** — automated scoring across all three pages, before/after comparison
- **WebPageTest** — waterfall + filmstrip view, can run from real geographic locations and throttled networks (we're currently measuring on a fast connection)
- **Access to the live Wedgwood theme repo / Shopify section configuration** — so we can verify exactly which section block renders each video and image and edit it directly
- **Access to Shopify admin for the Wedgwood store** — to swap the videos and inspect Hydrogen/section schema

---

## Branch / PR context

This audit was conducted from the `stellar-shopify` repo. Code-level fixes for items above would land in `stores/wedgwood/theme/` and possibly `shared/scripts/ui/`. Worth a separate PR per page to keep the changes reviewable.
