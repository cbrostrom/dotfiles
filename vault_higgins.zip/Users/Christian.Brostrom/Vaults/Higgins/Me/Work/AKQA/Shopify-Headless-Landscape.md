# Shopify Headless Landscape

> Research brief for HW — headless storefront offering, slim starter, framework options, CMS flexibility.
> Date: 2026-06-12 | Prepared by: Claude (shopify-mcp research)

---

## TL;DR

Shopify headless has three distinct tiers. Hydrogen is Shopify's opinionated bet on React Router — fast to start, but locks you into React and Oxygen hosting. For a multi-framework offering (Astro, Vue, SolidJS, Next.js), skip Hydrogen-the-framework and go Storefront API + Storefront API Client. That's more work upfront but gives full freedom on stack, hosting, and CMS.

---

## The Three Tiers

Shopify officially documents three paths:

| Build with | What it gives you | React required? | Hosting |
|---|---|---|---|
| **Hydrogen** | Full-stack React Router 7 framework, caching, cart, analytics, CSP, OAuth | Yes — React only | Oxygen (or self-host) |
| **Hydrogen React** (`@shopify/hydrogen-react`) | UI component library + hooks for any React app | Yes — React only | Anywhere |
| **Storefront API + Headless channel** | Raw GraphQL API, Storefront API Client | No — any framework | Anywhere |

For multi-framework support: **Tier 3 is the path**. Hydrogen React is React-specific. Hydrogen is React Router 7-specific.

---

## Hydrogen: Deep Dive

### What it is

Built on **React Router 7** (formerly Remix). Provides:
- `createHydrogenContext` — bundles Storefront API client, Customer Account API client, cart handler, session, env
- `createCartHandler` — full cart CRUD (lines, discounts, gift cards, buyer identity, delivery, metafields)
- `Analytics.Provider` + built-in events (page_viewed, product_viewed, cart_updated, etc.)
- `createWithCache` — cache-aware wrapper for any fetch, not just Storefront API
- Cache strategies: `CacheNone`, `CacheShort`, `CacheLong`, `CacheCustom` (stale-while-revalidate model)
- Privacy/GDPR: `useCustomerPrivacy`, CSP nonce via `createContentSecurityPolicy`
- Customer Account OAuth: `createCustomerAccountClient` with login/authorize/logout
- Sitemap generation: `getSitemapIndex`, `getSitemap`
- Deployed on **Oxygen** — Shopify's edge hosting, Cloudflare Workers-based

### What `@shopify/hydrogen` vs `@shopify/hydrogen-react` are

- `@shopify/hydrogen-react` — base layer: React components (`Image`, `Video`, `Money`, `ModelViewer`, `RichText`, `ShopPayButton`), hooks (`useMoney`, `useShopifyCookies`), analytics helpers, `flattenConnection`, `parseGid`, `parseMetafield`
- `@shopify/hydrogen` — extends hydrogen-react: adds React Router integration, caching infra, OAuth, cart handler, Analytics.Provider, CSP, i18n, Oxygen preset. Re-exports everything from hydrogen-react so you only import from one package.

### Required env vars

```
SESSION_SECRET
PUBLIC_STOREFRONT_API_TOKEN
PRIVATE_STOREFRONT_API_TOKEN
PUBLIC_STORE_DOMAIN
PUBLIC_STOREFRONT_ID
PUBLIC_CUSTOMER_ACCOUNT_API_CLIENT_ID
PUBLIC_CUSTOMER_ACCOUNT_API_URL
PUBLIC_CHECKOUT_DOMAIN
SHOP_ID
```

---

## Hydrogen: Pros & Cons

### For Hydrogen

- **Fastest path to production** — scaffolding, caching, cart, analytics, OAuth all pre-wired
- **Shopify-maintained** — API version bumps, deprecation handling, new Shopify features land here first
- **Caching is production-grade out of the box** — stale-while-revalidate per query, `createWithCache` for third-party API calls
- **Oxygen is included** — global edge CDN, zero infra setup for Shopify Plus clients (included in Plus plan)
- **Type safety** — full TypeScript surface, Storefront API types generated from schema
- **Cart handler depth** — covers delivery addresses, metafields, gift cards, buyer identity. Parity with native checkout requires significant work otherwise.
- **Analytics without a third-party tag manager** — built-in Shopify analytics events that feed native reporting

### Against Hydrogen

- **React Router 7 lock-in** — no Astro, no Vue, no SolidJS. If a client wants anything outside React, it's the wrong tool.
- **Oxygen or friction** — Hydrogen is built for Oxygen. Self-hosting is possible but several features assume the Workers runtime (`waitUntil`, `hydrogenPreset`, env var injection). Vercel/Netlify deploys exist but add config overhead and some features behave differently.
- **Blocked React Router features** — `prerender`, `serverBundles`, `buildEnd`, `unstable_subResourceIntegrity`, `v8_viteEnvironmentApi` are all blocked in the Hydrogen preset due to Oxygen/CLI incompatibilities. This constrains advanced build optimization.
- **Opinionated routing** — `hydrogenRoutes` injects built-in routes. Overriding or removing them requires understanding the framework internals.
- **Maintenance surface** — Hydrogen moves fast; major version bumps (it was Remix, now React Router 7) require migration effort. Clients absorb that cost.
- **No CMS layer** — Hydrogen provides no opinion on content. You integrate a CMS yourself on top of an already-opinionated framework — layering complexity.
- **React-only component library** — `@shopify/hydrogen-react` components are React. No Vue/Solid equivalents from Shopify.
- **Oxygen is paid above Shopify Plus** — non-Plus stores pay per request after free tier. For high-traffic or budget-sensitive clients: meaningful cost.
- **No prerender/SSG** — Hydrogen is SSR-first. Static generation is blocked. Bad fit for content-heavy marketing pages where ISR/SSG gives better performance/cost.

---

## The Non-Hydrogen Path: Storefront API + Any Framework

### What Shopify provides

**Storefront API** — GraphQL, framework-agnostic:
- Products, collections, cart, checkout, customer, international pricing, metafields, subscriptions
- Serves 1M+ queries/minute per Shopify docs
- Max 100 active storefronts/access tokens per shop

**Storefront API Client** (`@shopify/storefront-api-client`) — Shopify's recommended lightweight client for non-Hydrogen projects. No framework dependencies.

**Headless channel** — install from Shopify App Store to get:
- Public + private access tokens
- Storefront permission management
- Product publishing controls
- Order attribution as a channel
- Up to 100 storefronts

**Customer Account API** — manage customer data, SSO across surfaces

### Framework fit

| Framework | Notes |
|---|---|
| **Next.js** (React) | `@shopify/hydrogen-react` works here. Full component library. Best developer familiarity. App Router + Server Components align well with Storefront API. |
| **Astro** | Best non-React fit for content-heavy storefronts. Use Storefront API Client directly. Astro's island architecture means React/Vue/Solid components can coexist. No Shopify-official Astro integration, but community starters exist. |
| **Vue / Nuxt** | Storefront API Client is framework-agnostic; works in Vue. No Shopify official Vue components — build your own or use community libs. Nuxt's server routes map cleanly to private token proxying. |
| **SolidJS / SolidStart** | Storefront API Client works. SolidStart's architecture (similar to Remix) maps well to SSR + streaming. No official Shopify components. Smallest ecosystem — higher build cost. |

### The slim starter architecture

For a multi-framework offering, the minimal opinionated layer is:

```
Shopify Headless channel (access tokens, product publishing, order attribution)
        ↓
Storefront API Client (@shopify/storefront-api-client)
        ↓
Framework adapter (Astro / Nuxt / SolidStart / Next.js)
        ↓
CMS client (Sanity / Contentful / Storyblok / etc.)
        ↓
Your storefront
```

What you build once and reuse:
1. **Storefront API wrapper** — typed query/mutation helpers, token management, private token proxying
2. **Cart store** — framework-agnostic state (Nanostores works across Astro/Vue/Solid/React)
3. **CMS + Shopify data merge layer** — enriches product data with CMS content
4. **Auth proxy** — server route that forwards requests with private token (never expose to client)

---

## CMS Integration

Shopify docs explicitly list CMS as a primary reason to go headless:
> "You're either using or looking to use a content management system (CMS) for more complex content needs that are integrated into your storefront experience."

Shopify's native content (pages, blogs, metafields) is limited. CMS integration is a first-class headless use case.

### Common patterns

**Product enrichment** — CMS holds editorial content (long descriptions, lookbooks, sustainability claims), Shopify holds commerce data (price, inventory, variants). Merge at query time or build time.

**Page routing split** — CMS owns `/blog`, `/about`, `/campaigns`. Shopify Storefront API owns `/products`, `/collections`, `/cart`. Your framework router dispatches between them.

**Content-driven PDPs** — CMS stores rich product content keyed by Shopify product handle or ID. PDP fetches both in parallel.

### CMS options that work well headless

| CMS | Notes |
|---|---|
| **Sanity** | Strong GROQ query language, real-time preview, good DX. First choice for content-heavy. |
| **Contentful** | Enterprise standard, strong governance. Higher cost. REST + GraphQL APIs. |
| **Storyblok** | Visual editor is a selling point for clients who want in-context editing. Vue/React SDKs. |
| **Prismic** | Good for structured marketing content. Slice Machine fits component-based frameworks. |
| **Payload CMS** | Self-hosted, TypeScript-native, growing fast. Good if you want full ownership. |
| **Crystallize** | Built specifically for commerce + content hybrid. Shopify integration path exists. |

---

## stellar-shopify vs Slim Starter

### stellar-shopify is comprehensive because

It (presumably) covers: full Hydrogen stack, opinionated component system, app proxy, multi-region, analytics, full checkout flow. That's right for high-budget projects.

### What a slim starter needs

The slim starter should be additive — pick your tier, add what you need:

**Layer 0 — Shared (all tiers):**
- Headless channel setup guide
- Storefront API Client config + typed helpers
- Private token proxy pattern (server route)
- Cart state (Nanostores or similar, framework-agnostic)
- Product + collection query helpers
- TypeScript types generated from Storefront API schema

**Layer 1 — Per-framework adapters:**
- Next.js: App Router data fetching patterns, `@shopify/hydrogen-react` optional add-in
- Astro: Integration setup, island cart component
- Nuxt: Server routes for private proxy, Pinia cart store
- SolidStart: Server functions, context-based cart

**Layer 2 — Optional add-ons:**
- CMS adapter (Sanity first, others as community contributions)
- Hydrogen-full upgrade path (if client wants Oxygen + full tooling later)
- Analytics layer (GA4 / Klaviyo / Shopify Analytics)

---

## Recommendation for HW

1. **Don't build around Hydrogen for the offering** — it's React Router 7 and Oxygen. That's a narrow target. Use it as an optional upgrade path, not the foundation.

2. **Foundation = Storefront API Client + Headless channel** — framework-agnostic, hosting-agnostic, CMS-agnostic. Build typed helpers once, adapt per framework.

3. **First adapter: Next.js** — largest client demand, best community support, `@shopify/hydrogen-react` adds the Shopify component library without the framework lock-in.

4. **Second adapter: Astro** — best fit for content + commerce hybrid sites. Island architecture means you can bring React components where needed.

5. **CMS: design the layer, don't pick one** — provide the pattern and a Sanity reference implementation. Let clients choose. The data merge pattern is the same regardless.

6. **Hydrogen as upgrade path** — document clearly when to reach for it: high-traffic React projects, Shopify Plus clients who get free Oxygen, teams already on React Router.

---

## References

- [Options for building headless](https://shopify.dev/docs/storefronts/headless/getting-started/build-options)
- [Bring your own headless stack](https://shopify.dev/docs/storefronts/headless/bring-your-own-stack)
- [Storefront API reference](https://shopify.dev/docs/api/storefront/latest)
- [Hydrogen docs](https://shopify.dev/docs/api/hydrogen/latest)
- [Getting started with Storefront API](https://shopify.dev/docs/storefronts/headless/building-with-the-storefront-api/getting-started)
- [Headless channel management](https://shopify.dev/docs/storefronts/headless/building-with-the-storefront-api/manage-headless-channels)
