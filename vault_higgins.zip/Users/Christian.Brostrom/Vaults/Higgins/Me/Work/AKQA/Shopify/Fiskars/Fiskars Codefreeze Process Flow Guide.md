---
tags:
  - work/fiskars
  - next
---
#work/fiskars #next

Create process flow for codefreeze at Fiskars
