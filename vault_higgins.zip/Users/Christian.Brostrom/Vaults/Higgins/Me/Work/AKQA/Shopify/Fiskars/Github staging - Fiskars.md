---
created: 2025-12-02 15:20
type: inbox
tags:
  - work/fiskars
  - next
---
#work/fiskars #next

- [x] Fiskars - create GitHub diagram with a staging branch ✅ 2025-12-04
- [ ] When updating an app — do we need to manually trigger deploy via Dev Dashboard?
