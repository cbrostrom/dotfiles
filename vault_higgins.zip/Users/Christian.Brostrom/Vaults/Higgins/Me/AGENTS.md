# Me — Christian's Personal Vault

> Map for AI: where things live, how to find them, how to add to them.
> Read this FIRST, then go straight to the right file or directory.
> Token-efficient by design: grep frontmatter before reading files.

---

## Two vaults — know the split

| Vault | Path | Purpose | Owner |
|---|---|---|---|
| **Me** | `~/Vaults/Me/` | Human notes: personal, work, ideas, references | Human writes, AI reads + organises |
| **AI** | `~/Vaults/AI/` | AI knowledge base: project brains, cross-project knowledge, session logs | AI writes, human reads |

**AI brain files live in `~/Vaults/AI/brains/<slug>/`** — not here. This vault is for human content.

---

## Operating mode — AI-managed (read this first)

**Human role:** mostly **viewer**. Occasional Inbox dumps when a thought arrives.
**AI role:** primary writer. Reads, queries, organises, runs librarian, writes frontmatter, links notes.
**AI brain writes** go to `~/Vaults/AI/brains/<slug>/` — never to this vault's folders.
**Obsidian:** pretty viewer/editor on top. No plugin automation expected — AI fills that role.

Implications for AI behavior:

1. **Be proactive.** Don't ask the user to manually file notes, add frontmatter, or restructure folders — do it. User confirms moves via librarian flow, not by doing the work themselves.
2. **Keep AI brain current.** When working in a code repo, append new state (decisions, gotchas, open questions, next steps) to `~/Vaults/AI/brains/<slug>/`. Don't wait to be asked.
3. **Inbox triage on demand.** When user says "run librarian" / "triage inbox" / "process inbox", iterate Inbox/ oldest-first. Confirm-per-file. Don't auto-route.
4. **Respect viewer-only friction.** User opens Obsidian to read, not to edit. If a doc is messy, fix it yourself; don't add a TODO asking user to clean up.
5. **No plugin-dependent assumptions.** Don't write notes that require Dataview, Smart Connections, Bases, or other plugins to render correctly. Plain markdown only.

---

## Vault root (~/Vaults/Me/)

```
~/Vaults/Me/
├── Inbox/         unprocessed dumps, NO frontmatter expected
├── Personal/      private life: family, house, kid, household
├── Work/          AKQA + client work
├── Development/   universal tech + tooling knowledge
├── Ideas/         personal creative + side projects
├── Reference/     truly cross-cutting durable knowledge (small)
├── Plans/         active and done implementation plans
├── Templates/     Templater plugin templates
├── Archive/       cold storage
├── Attachments/   media (Obsidian default)
├── Dashboard.md   home page
└── AGENTS.md      this file
```

## AI vault root (~/Vaults/AI/)

```
~/Vaults/AI/
├── brains/<slug>/     per-project state (current.md, next.md, gotchas.md)
├── knowledge/<domain>/  cross-project reusable facts
└── sessions/          auto-generated session logs + TF-IDF summaries
```

---

## Find-by-intent (read this when user asks a question)

| User asks | Look here first | Then |
|---|---|---|
| "What did I decide about <project>" | `~/Vaults/AI/brains/<slug>/` | grep `brains/` if slug unclear |
| "What's the state of <code-repo>" | `~/Vaults/AI/brains/<slug>/` | falls back to repo's own brain if exists |
| "What's in <client>" | `Work/AKQA/<client>/` | `grep -lri "<client>" Work/` |
| "What about Lily, family, house, Grønnebakken" | `Personal/<topic>/` | |
| "EV / elbil / bil-køb / range to Boes / used car" | `Personal/Biler/INDEX.md` | then `current.md` + `reference/` |
| "How do I do <tech-thing>" | `Development/Tech/` or `Development/Homelab & VPS/` | |
| "Vault stuff, vault config" | `Development/Vault/` | |
| "What's in my inbox" | `Inbox/` | newest first |
| "What plans" | `Plans/Active/` | |
| "What about <game-idea> / Tessera / Svarr / Spatial" | `Ideas/<idea>/` | |
| "What did we talk about last session" | `~/Vaults/AI/sessions/` then `Plans/Active/` | |

---

## Token-efficient lookup heuristics

**Always prefer in this order:**

1. **Frontmatter grep** (cheapest)
   ```bash
   grep -lE '^area: (work|\[work)' -r ~/Vaults/Me
   grep -lE '^type: brain' -r ~/Vaults/AI
   ```
2. **Hashtag grep** (next cheapest)
   ```bash
   grep -lr '#dev/dotfiles' ~/Vaults/Me
   ```
3. **Filename match**
   ```bash
   /usr/bin/find ~/Vaults/Me -iname '*fiskars*'
   ```
4. **Content grep** (broadest, most expensive)
   ```bash
   grep -lr "search-term" ~/Vaults/Me --include='*.md'
   ```
5. **Targeted Read** of the 1-3 best matches. NEVER read every file.

---

## Frontmatter contract

Every NEW note written by AI gets:

```yaml
---
created: YYYY-MM-DD
area: personal | work | dev | idea | meta    # string OR array; first = primary
type: brain | project | reference | note | meeting | plan | idea
tags: []
---
```

Optional fields per type — only add when meaningful:
- `status: draft | active | done` (plans)
- `client: <slug>` (work notes)
- `repo: <slug>` (dev notes referencing code)
- `cross-area: [[link]]` (auto-added by librarian if secondary area exists)

**Inbox files have NO frontmatter** — they are pre-librarian. Don't add frontmatter while the file is in Inbox.

---

## Hashtag taxonomy (drives frontmatter and faceted search)

Hashtags live INLINE in note bodies (Obsidian tag pane reads them natively).

| Hashtag | Resolves to |
|---|---|
| `#personal` `#work` `#dev` `#idea` `#meta` | `area:` field. First occurrence = primary. Multiple = array. |
| `#brain` `#ref` `#project` `#meeting` `#plan` `#note` | `type:` field |
| `#work/fiskars` `#dev/dotfiles` (nested, 2 levels max) | area + project hint for routing |
| Anything else (`#urgent`, `#liquid`, `#fastfacts`) | appended to `tags:` array |

Librarian copies hashtags to frontmatter on Inbox promotion. Hashtags STAY in body — don't strip.

---

## Routing rules (when writing new content)

| `type` value | File destination |
|---|---|
| `brain` | `~/Vaults/AI/brains/<slug>/` (AI vault, not here) |
| `knowledge` | `~/Vaults/AI/knowledge/<domain>/` (cross-project reusable facts) |
| `project` | `<area-folder>/<project>/...` (this vault) |
| `reference` | `<area-folder>/Reference/...` for area-bound; `Reference/` for cross-cutting |
| `idea` | `Ideas/<idea-name>/...` |
| `note`, `meeting` | `<area-folder>/<context>/...` |
| `plan` | `Plans/Active/YYYY-MM-DD-<topic>.md` |

**Cross-area linking:** if a note applies to multiple areas (e.g., a Liquid pattern discovered on a Fiskars sprint = `area: [dev, work]`):
- Primary area's folder owns the file
- Add `Cross-area: [[secondary-area-path/...]]` in frontmatter or first body line
- Do NOT duplicate the file

---

## Capture flow (Inbox)

1. User dumps a thought (any way: hotkey, share sheet, voice, Claude session)
2. File lands in `Inbox/` named `YYYY-MM-DD-HHmm-<topic>.md` (or just timestamp)
3. Body is freeform. Hashtags optional but encouraged.
4. **No frontmatter required at capture time.**
5. Librarian (manual or scheduled) processes Inbox/ later — see below.

---

## Librarian (when user says "run librarian" or similar)

For each file in `Inbox/`:

1. Read file
2. Extract hashtags → infer `area`, `type`, `tags`
3. If no hashtags → infer from filename + content (keywords, structure, length)
4. Grep vault for entity matches → propose ≥1 `[[backlink]]`
5. Show proposed move:
   ```
   2026-06-14-1357.md
     area: dev          type: brain    tags: [mcp, dotfiles]
     dest: ~/Vaults/AI/brains/dotfiles/ (APPEND to current.md)
     backlinks: [[Development/MCP]]
     [y]es / [n]o / [e]dit / [s]kip
   ```
6. On `y`: rewrite frontmatter, prepend backlinks, move file.

**Librarian rules:**
- NEVER auto-route without explicit confirm.
- NEVER edit note body text.
- NEVER delete files.
- BRAINS APPEND, not replace — new content joins existing brain as a dated section.
- Reference targets: create new file unless a clear title match exists.

---

## What NOT to do

- Don't create new top-level folders without explicit ask. **When in doubt about where content belongs, use `Inbox/` — never invent a new folder.**
- Don't add frontmatter to historical files unless asked specifically.
- Don't touch `_dupe-from-Projects-Fiskars/` — staged for manual dedup review.
- Don't write brain state to this vault — use `~/Vaults/AI/brains/`.
- Don't summarize and overwrite — append timestamped sections to brains; create new files for references.
- Don't use Dataview queries — prefer Bases (when enabled).
- Don't fabricate links. If a `[[backlink]]` target doesn't exist, mention it — don't write the link.
- Don't reformat existing notes. Match existing style.

---

## Cross-system memory

| Layer | What | When |
|---|---|---|
| **`~/Vaults/AI/brains/<slug>/`** | Per-project current state. Loaded by hook at session start. | Always — first source |
| **`~/Vaults/AI/knowledge/`** | Cross-project reusable facts. Loaded by domain match. | When relevant domain detected |
| **`~/Vaults/AI/sessions/`** | Auto-generated session logs + TF-IDF summaries. | Zero tokens, always captured |

Session start: brain hook loads `~/Vaults/AI/brains/<slug>/` automatically. No MCP call needed.
Vault grep is cheaper and faster than Engram search — prefer it for "what do I know about X".

---

## Cite your source

When the AI surfaces a fact from the vault, **always cite the source path**, e.g.:

> "Per `~/Vaults/AI/brains/dotfiles/gotchas.md`, the wrap-reminder hook was disabled because it manufactured an OCD loop."

Every claim cites a vault file path. No unsourced assertions.

---

## Mode triggers (quick dispatch)

| Signal | Action |
|---|---|
| "capture this" / "dump this" | Write to `Inbox/YYYY-MM-DD-HHmm-<topic>.md`, body only, no frontmatter |
| "run librarian" / "triage inbox" / "process inbox" | invoke `inbox-librarian` skill |
| "what's the state of <project>" | Read `~/Vaults/AI/brains/<slug>/` |
| "what do I know about X" | Frontmatter grep → tag grep → filename → content grep → targeted Read |
| "what plans" | List `Plans/Active/` filenames + first heading |
| "save this for later" | Append to `Inbox/<timestamp>.md` |
| "promote to brain" | Move/append to `~/Vaults/AI/brains/<slug>/` |
| "what's new" | `Inbox/` sorted by mtime desc, last 7d |

---

## Known anomalies (staged, awaiting manual review)

- `Work/AKQA/Shopify/Fiskars/_dupe-from-Projects-Fiskars/` — duplicate Fiskars folder, content not yet merged. Resolve before adding new Fiskars notes.
- `Archive/Daily Notes 2025/` + `Archive/Daily Notes (archived 2024)/` — kept separate by year, may want to merge.
- `~/Vaults/Me/Brains/` — legacy copy of brain files. Canonical location is now `~/Vaults/AI/brains/`. Remove after confirming AI vault is working.

---

## Quick reference dump for token-cheap orientation

- Human vault: `~/Vaults/Me`
- AI vault: `~/Vaults/AI`
- Brains: `~/Vaults/AI/brains/<slug>/` (modular dirs with current.md, next.md, gotchas.md)
- Sessions: `~/Vaults/AI/sessions/` (auto-generated, zero tokens)
- Knowledge: `~/Vaults/AI/knowledge/<domain>/` (cross-project reusable facts)
- Inbox: `~/Vaults/Me/Inbox/*.md` (no frontmatter expected)
- Active plans: `~/Vaults/Me/Plans/Active/*.md`
- Templates: `~/Vaults/Me/Templates/*.md`

Don't read this whole file every session — read once, cache the map, use heuristics above.
