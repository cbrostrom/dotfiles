---
created: 2026-06-14
updated: 2026-06-14
tags: [dashboard]
icon: LiLayoutDashboard
cssclass: dashboard
status: candidate-for-deletion
---

# Dashboard

> Static AI-maintained home page. Plain markdown, zero plugin dependency.
> **Candidate for deletion** — if Obsidian Bookmarks plugin covers your navigation needs, this file is redundant. Decide after a week of use.
> Refresh: ask AI "update dashboard" — it scans the vault and rewrites this file.

## Quick links

- [[Inbox]] — capture
- [[Brains/dotfiles|Brain: dotfiles]]
- [[Plans/Active/2026-06-14-vault-second-brain-sparring|Vault sparring]]
- [[Plans/Active/2026-06-12-knowledge-base-strategy|KB strategy]]
- [[Development/Vault/Setup Guide|Setup guide]]
- [[CLAUDE|Vault rules (CLAUDE.md)]]

## Areas

- [[Personal/]] — family, house, Lily, Grønnebakken, Sunday meetings
- [[Work/]] — AKQA, Fiskars, Themelio, meetings
- [[Development/]] — universal tech, homelab, vault config
- [[Ideas/]] — Vaultkeeper, game ideas (Tessera, Svarr, Spatial)

## Operating mode

Vault is **AI-managed**, you are mostly **viewer + Inbox dumper**.

| Action | How |
|---|---|
| Capture a thought | New note in `Inbox/`, body only, no frontmatter |
| Trigger librarian | Claude Code session at vault root → "run librarian" |
| Read project state | `Brains/<project>.md` |
| Ask Claude across vault | grep frontmatter / hashtags / paths |

## Active brains

| Brain | Status | Last updated |
|---|---|---|
| [[Brains/dotfiles]] | active | 2026-06-13 |

(Refresh manually by asking AI to update.)

## Active plans

| Plan | Status |
|---|---|
| [[Plans/Active/2026-06-14-vault-second-brain-sparring]] | active |
| [[Plans/Active/2026-06-12-knowledge-base-strategy]] | superseded by sparring (consider archive) |

## Recently surfaced (refresh manually)

- AI-maintained snapshot of recent vault activity. Ask "update dashboard" to refresh.
- Last refresh: 2026-06-14

## To-decide

- Keep or delete Dashboard? After one week of use, evaluate against Bookmarks.
- Old vault cleanup (`~/Vaults/Christian/`) — once new flow validated.
- Sync mechanism choice — deferred.

---

*Refresh by asking Claude: "update dashboard". No plugin or query engine needed; static markdown only.*
