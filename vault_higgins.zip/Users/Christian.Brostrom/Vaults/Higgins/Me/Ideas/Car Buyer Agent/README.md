---
created: 2026-06-21
area: [idea, personal]
type: idea
tags: [agent, bil, elbil, car-buyer]
status: draft
topic: ev-car-purchase
---

# Car Buyer Agent — idea spec

Helper agent for used EV search, grounded in vault knowledge. **Not built yet.**

## Knowledge base (ready)

All context lives under [[../../Personal/Biler/INDEX|Personal/Biler/]]:

| File | Role |
|---|---|
| `INDEX.md` | Bootstrap + agent instructions |
| `current.md` | Live state, open decisions, shortlist |
| `reference/range-requirements.md` | Trip math, WLTP filters |
| `reference/model-matrix.md` | Brand/model verdicts |

Any agent session should: **read INDEX → current → references** before recommending.

## Proposed agent behavior

### Inputs

- Bilbasen / Biltorvet listing URL or pasted ad text
- Optional: budget, must-have features (træk, AWD, car seats, etc.)

### Outputs

- **Verdict:** fits requirement / borderline / skip
- **Why:** cite WLTP vs 300 km trip + model-matrix row
- **Questions for seller:** SoH, varmepumpe, accident, charging cable
- **Compare:** rank against shortlist in `current.md`

### Hard rules (from vault)

1. Never recommend below **550 km WLTP** for this use case (prefer **580+**)
2. Only VW, Skoda, Audi, Volvo unless user changes brands in `current.md`
3. RWD preferred over AWD for range
4. PHEV electric-only range is **not** sufficient — full EV only
5. Update `current.md` when user adds cars to shortlist or locks budget

### Possible tools (future)

| Tool | Purpose |
|---|---|
| Vault read | Load Personal/Biler/* |
| Vault write | Append to current.md |
| Bilbasen search | Filter by WLTP + brand (API or scrape — TBD) |
| Distance check | Recompute if origin/destination changes |

### Triggers

- "Evaluate this listing"
- "Search for EVs that reach Boes"
- "Update car shortlist"
- "What WLTP do we need again?"

## Open design questions

- [ ] CLI skill vs Cursor agent vs automation?
- [ ] Integrate with Sofie's preferences separately?
- [ ] Price alert when matching car appears?
- [ ] SoH: trust seller, CarVertical, or independent test?

## Cross-references

- [[../../Personal/Biler/INDEX|EV purchase knowledge base]]
- [[../../Personal/Biler/current|Current state]]
