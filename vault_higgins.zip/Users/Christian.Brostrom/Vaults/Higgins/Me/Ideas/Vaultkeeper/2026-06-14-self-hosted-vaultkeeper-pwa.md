---
created: 2026-06-14
area: [idea, dev]
type: idea
tags: [pkm, obsidian, pwa, tauri, docker, sync, self-hosted, vaultkeeper, side-project]
status: exploration
---

# Vaultkeeper — Simplified Self-Hosted Obsidian Alternative

> Side-project idea. Build a stripped-down Obsidian-like note app with built-in sync to a Dockerized backend ("Vaultkeeper"). PWA first, Tauri-native later.

## Why consider it

- Obsidian's value (for you) is ~20% of its surface: editor, links, tags, search, mobile.
- LiveSync's pain is real. Sync is what you actually want fixed.
- A purpose-built tool with sync as first-class citizen (not bolt-on plugin) would solve the chief pain.
- Bonus: self-hosted, free, your data on your hardware.

## Scope honest cut

### Must (Phase 1-3)
- Flat markdown on disk, open existing vault folder, no migration needed
- CodeMirror 6 editor — links, headings, tables, code, frontmatter
- Wiki-link `[[X]]` resolution + backlink pane
- Tag pane (`#tag` inline parsing)
- Full-text search across vault
- Built-in sync to Dockerized "Vaultkeeper" service over WebSocket
- CRDT-based merge (Yjs) so concurrent edits don't conflict
- Self-host Vaultkeeper on superbro, auth via JWT

### Should (Phase 4-5)
- Frontmatter-aware views (Bases-like): filter by `area`, `type`, etc.
- Inbox / Brain folder conventions baked in (matches your Brain vault)
- File tree with manual sort persisted to backend
- Theme support (light/dark, accent color)

### Could (Phase 6-7)
- Tauri wrap for native macOS/Linux/Windows app
- Simple graph view (D3 force layout, <500 nodes — your scale)
- Plugin SDK (defer indefinitely)

### Won't
- Mobile app — PWA only initially. iOS PWA is sandboxed; expect limits.
- Canvas, slides, audio recording, dataview — none of these are your needs.
- Cross-vault federation — single user, single vault.

## Architecture sketch

```
┌─────────────────────────┐        ┌────────────────────────────┐
│  PWA Client             │        │  Vaultkeeper (Docker)      │
│  (browser/Tauri)        │ <───>  │  on superbro               │
│                         │   WS   │                            │
│  CodeMirror 6           │  CRDT  │  Bun or Go + Yjs server    │
│  Yjs document           │  sync  │  SQLite for metadata       │
│  IndexedDB / OPFS cache │        │  Flat .md on volume        │
│  File System Access API │        │  WebDAV optional for       │
│   (desktop only)        │        │  external editor access    │
└─────────────────────────┘        └────────────────────────────┘
                                              │
                                       ┌──────┴─────┐
                                       │ Tailscale  │
                                       │ CGNAT only │
                                       └────────────┘
```

Backend stores files as plain `.md` on a Docker volume. Any external tool (Claude, VSCode, vim) can read/write the same volume. PWA syncs via Yjs over WebSocket. Conflict-free thanks to CRDT.

## What's reusable (don't reinvent)

| Need | Use |
|---|---|
| Editor | CodeMirror 6 — mature, customizable, Obsidian uses it |
| Markdown parse | unified / remark / micromark |
| CRDT sync | Yjs + y-websocket — production-grade |
| File sync alternative | PouchDB ↔ CouchDB — exactly what LiveSync does |
| Frontmatter | gray-matter |
| Native wrap | Tauri (~10MB binary, Rust core, WebView UI) |
| Server | Bun (fast TS) or Go (smaller container) |
| Auth | JWT, basic auth, or Tailscale-fronted (CGNAT trust) |

## Phases + estimated effort

| Phase | Scope | Human-only time | With AI assist |
|---|---|---|---|
| 1 | PWA scaffold + CodeMirror + open-vault-folder + local edit | 2 weeks | 4-6 days |
| 2 | Vaultkeeper backend (Docker, Bun/Go, file storage, basic auth) | 1 week | 2-3 days |
| 3 | Yjs CRDT sync wire-up, bidirectional | 1-2 weeks | 4-7 days |
| 4 | Tags, backlinks, full-text search, frontmatter parsing | 1 week | 3-4 days |
| 5 | Frontmatter-driven views (Bases-equivalent) | 1 week | 3-4 days |
| 6 | Tauri wrap for native build | 3-5 days | 1-2 days |
| 7 | Graph view (D3), polish | 1 week | 3-4 days |
| **Total** | **MVP through usable daily-driver** | **~8-10 weeks** | **~3-5 weeks** part-time |

## Token cost ballpark (with AI-assisted dev)

Assumptions:
- Pristine context per phase = fresh Claude Code session at phase boundary
- Heavy use of file tools (Read, Edit) — efficient token use vs all-in-prompt
- Reasonable iteration (some debugging, ~2x naive)
- Public list pricing (subject to change)

### Per phase (rough)

| Phase | Input tokens | Output tokens | Sonnet 4.6 cost | Opus 4.7 cost |
|---|---|---|---|---|
| 1 (PWA scaffold) | ~300k | ~80k | ~$2.10 | ~$10.50 |
| 2 (backend) | ~200k | ~60k | ~$1.50 | ~$7.50 |
| 3 (CRDT sync — hardest) | ~500k | ~120k | ~$3.30 | ~$16.50 |
| 4 (tags/links/search) | ~300k | ~70k | ~$1.95 | ~$9.75 |
| 5 (views) | ~250k | ~60k | ~$1.65 | ~$8.25 |
| 6 (Tauri) | ~150k | ~30k | ~$0.90 | ~$4.50 |
| 7 (graph + polish) | ~300k | ~70k | ~$1.95 | ~$9.75 |
| **Total** | **~2M input** | **~490k output** | **~$13** | **~$67** |

Add 50-100% buffer for backtracking and debugging:
- **Sonnet 4.6 realistic: $20-$30**
- **Opus 4.7 realistic: $100-$150**

### Hybrid strategy (recommended for cost)

- **Sonnet for scaffolding** (Phase 1, 2, 6) — boilerplate, library glue, framework setup
- **Opus for hard reasoning** (Phase 3 CRDT, Phase 5 view system design) — architecture choices, novel logic
- **Sonnet for cleanup** (Phase 4, 7) — tests, docs, refinements

Hybrid total: **~$30-$60** realistic.

### Pristine-context discipline matters

Token cost drops sharply if you:
1. Start a fresh session per phase (no inherited context bloat)
2. Use Plans/ files to hand off between sessions (write what's done, what's next)
3. Use `lean-ctx` MCP tools for big-file reads (already in your stack)
4. Avoid letting Claude re-read the same file 5 times — use Edit not Write for targeted changes
5. Spawn subagents for parallel discovery (Explore/Plan agents) — keeps main context lean

Without discipline, double the numbers.

---

## Grilling this idea (honest)

### 1. Sync is the HARD part

Obsidian LiveSync took years to stabilize. Replicating it = real engineering, not a weekend project. CRDT via Yjs is the right shortcut — already-built sync primitive. But integrating Yjs with file-on-disk semantics (where external tools also write the same files) is **non-trivial**: you need a daemon watching the filesystem to translate FS changes into Yjs ops, and Yjs ops back into FS writes, without infinite loops.

`[Likely]` Phase 3 takes longer than estimated. Mentally double it.

### 2. You'd lose plugins you actually use

You said you do use:
- **Templater** (templates with JS)
- **QuickAdd** (capture macros)
- **Iconize** (folder icons)
- **Flexplorer** (manual sort)
- **LiveSync** (the very thing we're replacing)

Reimplement those? Or accept you lose them?
- Templater equivalent: small JS template system, weekend project
- QuickAdd: hotkey + form, easy
- Iconize: trivial UI
- Flexplorer: manual sort = store order in `.vault-sort.json`, doable
- LiveSync: replaced by Yjs sync (the whole point)

Manageable, but each one is more code you maintain.

### 3. iOS gap

PWA on iOS:
- Can install to home screen
- Limited filesystem access (OPFS only — not arbitrary folders)
- Notifications limited
- WebSocket works
- IndexedDB works

You lose:
- Share Sheet dump-to-vault (PWAs can register as share target on Android but iOS support is partial)
- Background sync (iOS aggressive on suspending PWAs)
- Truly native feel

If iPhone capture is critical → PWA won't fully replace Obsidian Mobile. Tauri doesn't help on iOS (no native target).

### 4. There may already be a thing

Before building, evaluate:
- **SilverBullet** — single-binary self-hosted markdown PKM, web UI, runs in Docker, has frontmatter queries, plugins, sync via just being web-app. Closest pre-existing match. https://silverbullet.md
- **Trilium Notes** — self-hosted, hierarchical, web. Less markdown-pure but mature.
- **Logseq** — already evaluated; flat MD; sync still a problem. Could you sync Logseq via Syncthing + accept block-based UI? Maybe.
- **Foam** — VSCode extension; not standalone app but pairs with VSCode for free.
- **AppFlowy** — local-first, P2P sync, self-host option, active development.
- **Dendron** — VSCode-based, hierarchical notes. Not your style.

`[Likely]` **Try SilverBullet for a week before writing one line of code.** If it covers 80% of your needs, fork/contribute. Building from scratch when SilverBullet exists = vanity unless you have a specific reason it fails.

### 5. Maintenance burden

You're one person. Custom app = you maintain it forever. Security patches, dependency upgrades, OS changes, breaking changes in CodeMirror/Yjs/Tauri. Compare to Obsidian's paid full-time team. Compare to SilverBullet's small active community.

A "labor of love" project is fine if you enjoy the build. If the goal is just "I want a working PKM", the build cost dwarfs the differential value.

### 6. Cost without your time

Token cost = $30-$150 realistic. Your time at any rate = $2k-$8k+ even on AI assist. The opportunity cost matters more than the AI bill.

---

## What I'd actually recommend

1. **Spend 2 hours evaluating SilverBullet** as drop-in for Obsidian. Self-host on superbro. Open same vault folder. Use for a week.
2. **If SilverBullet covers 80% of needs:** stop here. You won. Total cost: 2 hours.
3. **If SilverBullet fails specifically on sync or one feature:** fork it. Add what's missing. Total cost: days, not months.
4. **If SilverBullet is fundamentally wrong shape:** then consider Vaultkeeper as a real project. Start with Phase 1 PWA prototype, validate the architecture, then commit.

The path matters more than the destination. Don't burn $100 in tokens building something that already exists.

---

## If you DO build it — phasing for pristine context

| Phase | New Claude session? | Model | Why |
|---|---|---|---|
| 0 — Eval SilverBullet | Yes | Sonnet | Cheap exploration |
| 1 — PWA scaffold | Yes | Sonnet | Boilerplate |
| 2 — Backend | Yes | Sonnet | Boilerplate |
| 3 — CRDT sync | Yes | **Opus** | Hard reasoning, novel logic |
| 4 — Tags/links/search | Yes | Sonnet | Pattern-following |
| 5 — Views | Yes | **Opus** | Design choices matter |
| 6 — Tauri wrap | Yes | Sonnet | Mechanical |
| 7 — Graph + polish | Yes | Sonnet | Mechanical |

Per-phase handoff: write progress + open issues to `Brains/vaultkeeper.md` before closing session. Next session reads that first. Keeps context tight.

---

## Design quality is a hard constraint (the diva clause)

Update 2026-06-14: SilverBullet evaluated visually. UI doesn't feel right. SilverBullet+ desktop apps moving in a direction that doesn't match either.

This isn't vanity. For a tool touched dozens of times a day, "feels good" affects whether you actually use it. Aesthetics + interaction polish = adoption. A functional but ugly PKM gets abandoned. Already happened with Daily Notes — friction killed the habit. Same risk applies double for a custom app.

### What "feels good" means for THIS app (lock these design rules early)

- **Typography** — proportional serif (or high-quality sans) body, monospaced code, tight vertical rhythm. Match Obsidian's reading-first feel.
- **Density** — sparse, not Notion-overstuffed. Single-column primary read, optional side panel for backlinks/tags.
- **Motion** — minimal, fast (<150ms), no bouncy or showy transitions.
- **Color** — restrained palette, ~2 accents max. Dark default. Light mode that actually works.
- **Iconography** — Lucide or Phosphor (consistent, geometric). Iconize-style folder customization if you keep using it.
- **Editor chrome** — invisible by default. UI fades when typing. Only essentials surface.
- **No "AI inside" UI flourishes** — no chat sidebar, no suggestion popups in the editor. AI is invisible co-author writing to filesystem.

If the prototype's first screenshot doesn't make you smile, scrap it. Don't ship ugly.

### What this means for the build calculus

- **Adds 1-2 phases for design iteration.** Not "skin a working app" — design must be load-bearing from Phase 1.
- **Tokens go up.** UI iteration with AI is expensive — you'll redo screens repeatedly until they feel right. Add ~30% to estimates.
- **Reference-driven helps.** Pick 2-3 reference apps for visual taste (Obsidian, Things 3, Linear, iA Writer, Bear) and tell AI explicitly "match this feel" with screenshots in context.
- **Tauri > PWA on this axis.** Native window chrome + system fonts + proper macOS feel = closer to "feels right". PWAs always feel slightly off on macOS. Skip the PWA-first phase IF design polish is the priority — go Tauri straight away.

### Alternative path: fork Obsidian's open-source pieces

Obsidian core is closed. BUT its underlying tech (CodeMirror 6, Electron, file format) is open. Some projects worth a look:

- **Obsidian Bases plugin source** — read it to understand what Bases does, replicate if needed.
- **Obsidian-style editor:** CodeMirror 6 + a few Obsidian plugins ported = 60% of the look. Several Markdown editors take this route.
- **`memos`, `Outline`, `Notesnook`** — open-source PKMs worth a 30-min visual eval each. Notesnook in particular has polish.

## Decision

Status: **exploration**. No action yet.

Action gate to leave this status:
- 30-min visual eval of: Notesnook, AppFlowy, AnyType (already noted), Trilium, Logseq (re-evaluate UI), AFFiNE
- Reach a verdict per-app: usable / forkable / dropped
- If all fail the diva test → consider Vaultkeeper but raise estimates 30% for design iteration
- Update this file with verdicts

Until then: don't build. UI taste is the gate.

## Storage layer candidates (if/when building)

If Vaultkeeper ever gets built, evaluate storage options:

| Option | What | Verdict |
|---|---|---|
| **HelixDB** (https://github.com/HelixDB/helix-db) | Graph + vector in one. Rust. Newer. | Strong fit for "single store for graph + embeddings". Bet on smaller community vs Neo4j. |
| **Neo4j + pgvector** | Mature graph (Graphiti uses this) + Postgres vector ext | Boring, proven, two stores |
| **SQLite + sqlite-vec** | Single file, embedded, vector via extension | Smallest infra, good for local-first |
| **Postgres + pgvector + Apache AGE** | One Postgres handles graph + vector | Heaviest infra, most flexible |
| **Yjs + persistence backend of choice** | CRDT for sync (orthogonal to graph/vector) | Required regardless — sync layer |

Don't pick storage now. Pick when you have real schema + query patterns.

### Quick reference apps to evaluate visually (~30 min each)

| App | URL | What to check |
|---|---|---|
| Notesnook | notesnook.com | Polish, theme support, self-host option |
| AppFlowy | appflowy.io | Local-first claim, desktop feel |
| AnyType | anytype.io | Beautiful but object-based — confirm/reject |
| AFFiNE | affine.pro | Notion competitor, open source, self-host |
| Trilium Next | github.com/TriliumNext/Notes | Active fork, modern UI passes |
| Reflect | reflect.app | Closed-source but reference for "feels-right" daily PKM polish |

Don't install all six. Skim screenshots first, install only those that pass the eyeball test.
