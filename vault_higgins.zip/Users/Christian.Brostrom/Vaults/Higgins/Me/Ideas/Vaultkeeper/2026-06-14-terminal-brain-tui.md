---
created: 2026-06-14
area: [idea, dev]
type: idea
tags: [tui, terminal, ollama, ai, pkm, markdown, vibe-coded, brain]
status: dropped
dropped: 2026-06-14
dropped_reason: |
  Tried Leaf — didn't feel right. TUI feels decoupled from rest of flow.
  Would require another multiplexer alongside default (herdr).
  Verdict: terminal-pane PKM is not the shape. Abandon.
---

> **DROPPED 2026-06-14** — see frontmatter `dropped_reason`.
> Kept for reference; not pursuing.


# Terminal Brain — TUI with Local AI + Markdown Viewer

> Side-by-side terminal app: local AI (Ollama) + markdown viewer over vault.
> NOT a Claude Code SDK wrapper. Local-first, lightweight, daily-driver.

## Shape

```
┌──────────────┬─────────────────────────┬───────────────────────┐
│ Vault tree   │ Markdown viewer         │ AI chat (local LLM)   │
│              │                         │                       │
│ Brains/      │ # Brains/dotfiles.md    │ > what changed in     │
│ Personal/    │                         │   dotfiles last week  │
│ Work/        │ ## Current State        │                       │
│ Development/ │ ...                     │ AI: pulled commits    │
│ Inbox/       │                         │     from Brain... ←   │
│              │                         │   writes update       │
└──────────────┴─────────────────────────┴───────────────────────┘
```

Three panes. Tree on left, current note in middle, AI on right.

AI talks to vault as filesystem — reads selected note as context, writes responses or updates back to disk. Viewer hot-reloads on file change.

## Why this beats building Vaultkeeper

| Vaultkeeper (PWA/Tauri PKM app) | Terminal Brain (TUI) |
|---|---|
| 8-10 weeks human-equivalent | 3-7 days |
| $30-$150 in AI tokens | $5-$25 in AI tokens |
| UI taste = hard constraint | Terminal aesthetic is honest, less subjective |
| Replaces Obsidian | Coexists with Obsidian (different surface) |
| iOS gap | Terminal-only anyway, no mobile assumed |
| Sync complexity | Filesystem only — sync handled elsewhere |
| Maintenance burden = entire app | Maintenance = thin TUI glue |

This is the **vibe-coded** version: glue existing pieces, don't build a platform.

## Existing tools to glue (don't reinvent)

| Need | Use |
|---|---|
| Markdown viewer (terminal) | **Frogmouth** (Textual-based, scrollable, links) or `glow` for pipe-style |
| File tree picker | Custom TUI widget OR `yazi`/`broot` as pane |
| AI chat (terminal) | **`mods`** (Charm), **`aichat`**, **`fabric`** — all pipe-friendly |
| Local LLM | **Ollama** — qwen2.5:14b, llama3.3:70b (if RAM), phi-4, mistral-small |
| Pane layout | **Zellij** (Rust, layouts as KDL files) or **tmux** |
| TUI framework if building | **Bubble Tea** (Go, Charm aesthetic) or **Ratatui** (Rust) or **Textual** (Python) |
| Hot-reload viewer | Frogmouth supports file watching; or write thin shim |
| Frontmatter parse | `yq`, `gray-matter`, or Python `frontmatter` |

## Two paths

### Path A — Zero-code Zellij layout (1 hour)

Build it with config alone. No new app.

```kdl
// ~/.config/zellij/layouts/brain.kdl
layout {
  pane size=20 split_direction="horizontal" {
    pane command="yazi" { args "~/Vaults/Brain" }
  }
  pane split_direction="vertical" {
    pane command="frogmouth" { args "~/Vaults/Brain/Brains/dotfiles.md" }
    pane size="40%" command="mods" {
      args "--model" "qwen2.5:14b"
    }
  }
}
```

Launch with `zellij --layout brain`. Done. Iterate from there.

Honest assessment: this might be 80% of what you actually want. Try it before building anything custom.

### Path B — Custom TUI (3-7 days w/ AI)

If Path A friction is too high (e.g., AI doesn't know which file is active, no auto-context-pass), build minimal app.

**MVP scope:**
- Three-pane layout
- Tree pane: reads `~/Vaults/Brain/` recursively, filterable
- Viewer pane: renders selected MD file, hot-reloads on FS change
- AI pane: chat with Ollama, current selected note auto-included as context
- Hotkeys: `[s]` save AI response into current note, `[a]` append, `[n]` create new note from response
- Frontmatter-aware: parses `area`, `type`, `tags` from selected file, displays in status bar
- Persistent chat history per note (sidecar `.chat.jsonl` file? or in-memory only?)

**Out of MVP:**
- Multiple AI models / model switching (use one default; flag for override)
- Vault graph / backlinks visualization
- Plugin system
- Mobile

**Tech choice:**
- **Bubble Tea (Go)** — Charm aesthetic, gorgeous defaults, single binary, easy ollama integration via REST
- **Ratatui (Rust)** — fastest, smallest binary, steeper learning curve
- **Textual (Python)** — fastest to prototype, Python+pip baggage, slower

`[Likely]` Bubble Tea. Single Go binary, looks great by default, mature ollama client libraries exist.

## Token cost (Path B custom build)

Assumptions: pristine context per session, AI-assisted, ~2x naive for iteration.

| Phase | Input | Output | Sonnet 4.6 | Opus 4.7 |
|---|---|---|---|---|
| 0 — Eval Zellij path | minimal | minimal | ~$0.50 | n/a |
| 1 — Bubble Tea scaffold + three-pane layout | 200k | 50k | ~$1.35 | ~$6.75 |
| 2 — File tree + viewer hot-reload | 150k | 40k | ~$1.05 | ~$5.25 |
| 3 — Ollama integration + AI pane | 250k | 70k | ~$1.80 | ~$9.00 |
| 4 — Frontmatter + hotkeys + write-back | 200k | 50k | ~$1.35 | ~$6.75 |
| **Total** | **~800k** | **~210k** | **~$5.50** | **~$28** |

Realistic with backtracking: **Sonnet ~$10, Opus ~$40, Hybrid ~$15**.

## Grilling

### Real wins
- Local AI = no API cost, no rate limit, no privacy concern. Big.
- Filesystem-native = AI writes land directly in vault, Obsidian shows them on next open.
- No mobile = honest scope. Terminal users don't need mobile, Obsidian Mobile already covers your phone case.
- Lightweight = single binary, no Electron. Fits the "I just want a tool" energy.

### Where it fails
1. **Local LLMs are weaker.** qwen2.5:14b ≠ Sonnet 4.6. For "summarise this", fine. For "refactor this Liquid pattern with caveats", you'll miss frontier-model quality. Decide what tasks you'd use it for.
2. **Context size matters.** Local models have smaller usable contexts than Sonnet/Opus. Reading full vault into prompt = won't fit. Need RAG-style retrieval (embeddings + search) — extra layer to build.
3. **Search/retrieval is harder than chat.** AI in pane is easy. AI knowing which OTHER notes are relevant to current question = embedding store + retrieval logic. That's another week of work.
4. **The Zellij path is already 80% there.** Be honest about whether you'd actually use the extra 20% enough to justify building it.
5. **macOS-only or cross-platform?** If you only run it on Mac, building is easier. If MonsterBro/LinuxBro too, package + sync becomes a small chore.
6. **Discoverability of features.** TUIs trade visibility for keyboard speed. You'd need to remember hotkeys. Not great for ADHD-brain — visual cues lose.

### Comparison vs Claude Code already running

You currently use Claude Code in terminal. It reads vault files, writes to them, has filesystem access. Is the proposed app meaningfully different from "just run Claude Code at vault root + open a markdown viewer in another pane"?

Honest: **no, not really**. Claude Code already does AI-side. Add a viewer pane (zellij/tmux) and you have it.

Real differentiator: **local model**. If you want offline / cost-free / private AI in your vault flow, that's the actual value. Without that, this is "Claude Code + viewer", not a new app.

## Recommended path

1. **15 min:** install Zellij + Frogmouth + mods + Ollama with qwen2.5:14b
2. **10 min:** write the KDL layout above
3. **2 hours:** use it for actual work. Note what's missing.
4. **Decision gate:**
   - If Zellij + existing tools is enough → stop. Total cost: 3 hours.
   - If specific friction needs custom code → build small Bubble Tea TUI per Path B. Total cost: ~1 week + $15 in tokens.
5. Don't decide before step 4. Premature builds become abandoned binaries.

## Reference apps for inspiration

- **`fabric`** (Daniel Miessler) — terminal-AI patterns, pipe-friendly
- **`aider`** — TUI AI pair-programmer, similar mechanical layout
- **`harlequin`** — TUI SQL editor, side-by-side pane discipline
- **`jrnl`** — minimalist CLI journal
- **`gum`** (Charm) — TUI primitives if rolling own
- **`mods`** — model-of-the-month picker, pipe AI

## Decision

Status: **exploration**. Action gate to leave this status:
- Run Path A (Zellij + existing tools) for at least 2 hours of real work
- Capture friction in this file
- Then decide build / don't build

Until then: don't write code.
