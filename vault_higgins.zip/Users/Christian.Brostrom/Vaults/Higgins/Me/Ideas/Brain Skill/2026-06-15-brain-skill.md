---
created: 2026-06-15
area: [idea, dev, meta]
type: idea
tags: [skill, claude-code, brain, vault, librarian, dashboard, brain-os]
status: deferred
defer_until: ~2026-06-22  # 1 week after vault restructure — build against real pain, not anticipated
---

# Brain Skill — packaged vault operations for Claude Code

> Custom Claude Code skill that bundles multi-step vault operations. Reduces "which procedure do I follow" decision overhead. NOT a "Brain OS" — routing stays in CLAUDE.md, skill owns procedures only.

## Why deferred

Vault was just restructured 2026-06-14. Plugins enabled today. Operating mode (AI-managed, viewer-only) is unvalidated. Build the skill against REAL friction after ~1 week of use, not anticipated friction.

## Scope (decision locked: option b — medium)

Skill owns **procedural ops only**:

| Op | Multi-step? | Owned by skill |
|---|---|---|
| Capture (Inbox dump) | No | Yes (entry point, simple write) |
| Librarian (Inbox triage) | **Yes** | **Yes** (highest value — confirm-per-file flow) |
| Brain append (timestamped section) | Yes | Yes |
| Dashboard refresh | Yes | Yes |
| Cross-layer routing (vault / Engram / Graphiti) | No (one-step decision) | **No — stays in CLAUDE.md** |

## Naming

Locked: **`brain`** (concept-grep risk minor; clearest semantic). Path: `~/.claude/skills/brain/SKILL.md`.

## Cross-layer awareness — how

Skill does NOT duplicate routing rules. References vault + global CLAUDE.md as source of truth:

> When user request implies a memory operation that may span layers, consult the routing table in `~/Vaults/Brain/CLAUDE.md` and global `~/.claude/CLAUDE.md` (Memory routing section). Choose the cheapest applicable layer first: vault grep → Engram `mem_search` → Graphiti `search_*`. Combine layers only when single-layer answer is incomplete.

## Dot-commands

Locked: skill REPLACES capture/librarian/brain-append dot-commands. KEEPS `.remember` / `.recall` (those route to Engram/Graphiti — separate layer).

Proposed bindings (to add to global CLAUDE.md):

| Command | Skill op |
|---|---|
| `.capture <text>` | brain:capture |
| `.librarian` / `.triage` | brain:librarian |
| `.brain <slug>` | brain:append (with append target) |
| `.dashboard` | brain:dashboard-refresh |

`.remember` / `.recall` unchanged — route to Engram + Graphiti as today.

## Sketch (NOT the final skill — for reference when building)

```markdown
---
name: brain
description: |
  Procedural toolkit for the Vault Brain (~/Vaults/Brain). Use when user wants
  to capture an Inbox dump, run librarian over Inbox, append to a project Brain,
  or refresh the Dashboard. Reads vault CLAUDE.md for routing rules — does not
  duplicate them.
---

# brain skill

## When invoked

Pick the op from user signal:
- "capture", "dump this", "save to inbox" → capture
- "run librarian", "triage inbox", "process inbox" → librarian
- "update brain <slug>", "append to <slug>", "save to <slug>'s brain" → brain-append
- "update dashboard", "refresh dashboard" → dashboard-refresh

## Capture

1. Read ~/Vaults/Brain/CLAUDE.md (skim — already cached most sessions)
2. Generate filename: `Inbox/YYYY-MM-DD-HHmm-<topic-slug>.md`
3. Write body only. No frontmatter. Hashtags inline if user provided.
4. Confirm path + filename to user.

## Librarian

(detailed multi-step flow — confirm-per-file rules from CLAUDE.md)

## Brain append

(append timestamped section to `Brains/<slug>.md`, never replace)

## Dashboard refresh

(scan vault, rewrite Dashboard.md per its current shape — see candidate-for-deletion clause)
```

## Pre-build action gate (re-evaluate when defer expires)

Before writing skill in ~1 week, answer:

1. Did vault restructure stick? (any second migration needed?)
2. Is operating mode (AI-managed/viewer) holding up? Or pulled toward more manual flow?
3. Which ops did you actually invoke? Skip ops you didn't use.
4. Any new ops emerged from real use? (e.g., archive-stale-brain, promote-orphan)

If answer to 1+2 = yes and you've used librarian + capture in real flow → build the skill per scope above.

If still figuring out the system → keep deferring.

## Grilled risks (recorded)

1. Skills are prompts, not code — duplication risk vs CLAUDE.md
2. Wrapper grandeur ("Brain OS") = YAGNI; bundle only multi-step procedures
3. Three memory layers + skill wrapper = 4 things that can drift
4. Pre-mature build before vault use validates pain
5. Engram/Graphiti are MCPs already accessible — skill doesn't unlock new capability, only shapes WHEN

## Cross-references

- Vault map: [[CLAUDE]]
- Setup guide: [[Development/Vault/Setup Guide]]
- Sparring summary: [[Plans/Active/2026-06-14-vault-second-brain-sparring]]
