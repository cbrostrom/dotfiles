---
created: 2026-07-01
updated: 2026-07-02
status: mvp-shipped
tags: [hopper, product, pivot]
---

# Hopper Omnibox — Pivot Spec

## One-liner

A macOS menubar app that gives you instant keyboard access to every browser tab you have open or saved — command bar first, sidebar optional.

## Origin / learnings from sidebar-first approach

Hopline started as an always-on sidebar (Tauri + SolidJS + Helium/Chrome extension) for managing browser tabs across spaces. Renamed **Hopper** (2026-07). Primary browser target: **Helium** (`net.imput.helium`).

**What worked:**
- Chrome extension bridge (native messaging) — reliable real-time tab sync
- Persistent tabs with SQLite — save/reopen/reset URL model is solid
- Spaces as context buckets — users think in projects, not windows
- Command panel (`CommandPanelApp`) — fuzzy search across tabs, spaces, saved items with web search fallback
- Status bar mode — menubar app without dock icon already implemented

**What didn't earn its complexity:**
- Sidebar autohide / multi-monitor cursor tracking — fragile, edge-case heavy
- Drag-and-drop tab organization (HoldDragSensor, folder nesting, innermost-wins) — significant engineering for a feature that's secondary to "find and open the right tab fast"
- Sidebar screen real estate trade-off — always-on panel competes with browser content
- Folder/pin visual hierarchy — users who want organization may prefer bookmarks; users who want speed want a search box

## Core thesis

> Most people don't need to *see* their tabs — they need to *find* them.
> The fastest path to any tab is a keyboard shortcut + fuzzy search, not a visual list.

## Product shape

### Primary interface: Hop Bar (command bar)

- Global hotkey summons a floating panel (like Spotlight/Raycast)
- Fuzzy search across: open tabs, saved tabs, spaces, folders, browsing history
- Actions: switch to tab, reopen saved tab, open URL, web search, switch space
- Dismiss on action, Escape, or blur
- Panel appears at top-center of active screen

### Secondary interface: Sidebar (opt-in)

- Full sidebar view for users who want persistent visual organization
- Toggle via menubar icon or hotkey
- Contains everything the current sidebar has (pins, folders, spaces, open tabs)
- Can be disabled entirely — "omnibox-only mode"

### Menubar presence

- Status bar icon (already working)
- Click → shows hop bar (or dropdown with recent tabs + search)
- Right-click → preferences, quit

## What to keep from current codebase

| Component | Keep | Modify | Drop |
|---|---|---|---|
| Chrome extension bridge | ✓ | | |
| Native messaging / Rust bridge | ✓ | | |
| SQLite persistence layer | ✓ | | |
| `CommandPanelApp` | | Promote to primary UI | |
| `search.ts` fuzzy search | ✓ | Extend with history | |
| Spaces store | ✓ | | |
| Persistent tabs store | ✓ | | |
| Sidebar autohide logic | | | ✓ |
| Multi-monitor cursor tracking | | | ✓ |
| DnD system (HoldDragSensor etc) | | | Move to sidebar-only code path |
| Folder nesting UI | | | Move to sidebar-only code path |
| Settings window | ✓ | Add "omnibox-only mode" toggle | |

## Hotkey strategy

**Do NOT hijack Cmd+T globally.** Hopper is a companion app, not the browser.

**Default behaviour:** register the hop bar shortcut **only while Helium is the frontmost app** (`net.imput.helium`). When you switch to Cursor, Terminal, etc., Hopper unregisters the shortcut entirely — those apps get their keys back. Menubar click always works.

Shortcut options (user-configurable):
- `Option+Space` (default — low collision vs Spotlight's `Cmd+Space`)
- `Cmd+Shift+T`, `Hyper+T`, or custom Tauri shortcut string

Scope options:
- **Helium only** (default) — dynamic register/unregister via `NSWorkspace`
- **Always** — global, for power users who accept conflicts
- **Off** — menubar click only

Implementation: `tauri-plugin-global-shortcut` + macOS `NSWorkspace.didActivateApplicationNotification`. Do not rely on a frontmost-app check inside the handler alone — the shortcut must be unregistered when Helium loses focus.

## Competitive positioning

| Tool | What it does | Hopline's edge |
|---|---|---|
| Raycast / Alfred | General-purpose launcher | Hopline has *live* tab awareness — real-time Chrome tab state, not just history |
| Arc command bar | Browser-native command bar | Arc is a full browser; Hopline works with Chrome/any Chromium browser the user already has |
| Chrome Cmd+T / address bar | Tab search | No saved tabs, no spaces, no cross-session persistence |
| Tab manager extensions | In-browser tab lists | No global hotkey, limited to one browser window, no native app speed |

## MVP scope (Phase 1)

**Status: SHIPPED 2026-07-02** (Phases 0–6, commit 1dc53e8 on `main`)

1. ✅ **Omnibox-only mode toggle** — `uiMode` setting (omnibox/sidebar/both), sidebar subsystem gated at startup
2. ✅ **Promote hop bar** — statusbar default, tray left-click → hop bar, onboarding rewrite
3. ✅ **Global hotkey** — `Alt+Space` default, Helium-only scope, dynamic register/unregister via 300ms poll
4. ✅ **Enhance search** — folder names in corpus, Space › Folder context in results, active-tab boost
5. ✅ **Quick actions** — `>` prefix: `>switch <space>`, `>new`, `>save`, `>folder` (switch stub needs wiring)
6. ✅ **Result quality** — frecency decay scoring (tab_events table, migration 13)

## Phase 2 (post-MVP)

- Browser history search (Chrome history SQLite or extension API)
- Tab groups (Chrome's native groups) awareness
- Multi-browser support (Firefox, Safari via separate extensions)
- Quick-save from hop bar ("save this tab to Work space" without opening sidebar)
- Snippet/note attachment to saved tabs

## Phase 3 (stretch)

- Shared spaces (sync via cloud for teams)
- Smart suggestions ("you usually open these 4 tabs together on Monday morning")
- Keyboard-driven tab close/mute/pin from hop bar results

## Architecture changes needed

### Minimal:
- Add `omnibox_only` setting to settings store
- When enabled: don't create main sidebar window, only register global hotkey + hop bar window
- Hop bar window config already exists in Tauri — just needs to be the primary entrypoint

### Moderate:
- Frecency scoring table in SQLite (track opens per tab/space)
- Command prefix parsing in search (`>switch Work`, `>save`, `>new`)
- Sidebar code stays but becomes lazy-loaded when mode is "both"

### Heavy (Phase 2+):
- Chrome history access (extension permission upgrade or direct SQLite read)
- Cross-browser extension ports

## Risks

1. **Extension dependency** — without the Chrome extension, there's no live tab data. Extension install friction is the biggest adoption barrier.
2. **Global hotkey conflicts** — mitigated by Helium-only dynamic registration; `always` mode and custom shortcuts remain user choice
3. **Scope creep into launcher territory** — must stay focused on browser context. The moment you add app launching or file search, you're a worse Raycast.
4. **"Just use Cmd+L"** — Chrome's address bar already does tab search (`@tabs`). Need to be meaningfully better (saved tabs, spaces, cross-session).

## Success criteria

- Open any tab (live or saved) in < 2 seconds from hotkey press
- Zero screen real estate when not in use
- Works without sidebar for users who want minimal footprint
- Sidebar still available for organization-heavy users

## Open questions

- ~~Should the menubar icon click open the hop bar or a mini dropdown?~~ → hop bar (shortcut optional via scope)
- Should saved tabs auto-expire if not opened in N days? (Reduces stale clutter in search)
- Is "spaces" the right metaphor for omnibox-first, or should it be tags/labels?
