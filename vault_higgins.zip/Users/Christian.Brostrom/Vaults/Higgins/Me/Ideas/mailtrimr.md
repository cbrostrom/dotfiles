# mailtrimr

> Local IMAP email bulk-cleanup tool. Cleaning-first UX. No cloud, no subscription.

## Problem

17k+ emails in personal accounts. Existing options:
- Clean Email — SaaS, monthly cost, credentials leave device
- imapfilter — powerful but scary CLI
- Thunderbird filters — slow for bulk ops

Gap: **local-only GUI with a cleanup-first mindset**.

## Stack

| Layer | Tech |
|---|---|
| Frontend | Vite 8 + SolidJS + Tailwind |
| Backend | Hono + imapflow |
| Credentials | Local config/env — never leaves machine |

Same pattern as huskr / laesr / lommr.

## Architecture

```
frontend (SolidJS)
  ↕ REST
backend (Express)
  ↕ IMAP
imapflow → mail server
```

### API

```
GET  /api/folders
GET  /api/messages?folder=INBOX&groupBy=sender&olderThan=365
DELETE /api/messages   { uids: [...] }
```

## Key Views

1. **Connect** — IMAP host / port / user / pass
2. **By Sender** — grouped list, count per sender, "delete all" action
3. **By Age** — "older than N months" bulk select
4. **By Size** — large attachments sorted desc
5. **Preview → Confirm → Delete** — show what dies before committing

## Notes

- `imapflow` over `node-imap` — latter unmaintained since 2019
- Start with plain IMAP (password auth) — OAuth for Gmail/Outlook adds complexity, tackle later
- Effort: ~1 week to MVP

## Status

`ready to build` — stack confirmed, design done.

## Next Steps (resume here)

1. Create repo + `cd` into it
2. Open Claude Code in that dir
3. Say **"let's build mailtrimr"** — Claude has full context in Engram
4. First decision: monorepo (`apps/api` + `apps/web`) or flat structure?
