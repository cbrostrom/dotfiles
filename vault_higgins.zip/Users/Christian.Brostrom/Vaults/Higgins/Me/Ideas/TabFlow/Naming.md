# Naming

> Back to [[README]]

**Status**: Chosen name: **Hopline**.

Hopline keeps the useful verb **hop** — moving quickly between tabs, spaces, browsers, and profiles — while adding **line**, which suggests a through-line across the user's whole browsing context. It feels less literal than "Hopbar", less project-management-coded than "Hopboard", and less crowded than plain "Hop" or "Hopper".

---

## What the Name Should Evoke

The app is:
- A **persistent sidebar** — always there, always watching
- A **tab bar replacement** — not a launcher, not a browser
- An **organisational layer** — spaces, folders, pins
- A **reactive companion** — follows the browser, doesn't fight it

The name should feel like a natural part of a power user's vocabulary. Short, memorable, not already taken by a major app in the same space.

---

## Rejected

| Name | Why rejected |
|---|---|
| **Helm** | Too generic. Kubernetes Helm is too prominent. Feels "taggy" — like a placeholder, not a product name. |
| **Omnibar** | Chrome's address bar is already called the Omnibar. Instant confusion. |
| **TabFlow** | Descriptive but flat. Doesn't evoke anything beyond "tabs." |
| **Hop** | Strong verb, but an existing browser extension uses Hop for bookmark management. Better as product language than the formal name. |
| **Hopper** | Semantically good, but crowded: travel app, disassembler, DVR brand, GPU architecture, and tab-related extensions. |
| **Hopboard** | Clear, but evokes kanban/project boards and Jira too strongly. |

---

## Previous Candidates

| Name | Pronunciation | Feel | Pros | Cons |
|---|---|---|---|---|
| **Quay** | "key" | Nautical dock | Tabs dock here. "Key" pronunciation = keyboard resonance. Short, unique. | People will mispronounce it. Obscure. |
| **Vigil** | VIH-jil | Watchful | The sidebar is always watching your tabs. Distinctive. | Slightly dark/surveillance-y connotation. |
| **Perch** | perch | Elevated vantage | You see everything from it. Light, approachable. | Maybe too casual. |
| **Bento** | BEN-toe | Organised compartments | Spaces = bento boxes. Playful, modern, memorable. | Overused in tech (Bento.me, etc.). |
| **Deck** | deck | Control deck | "On deck." Ready. Short. | Very generic. Many apps called Deck. |
| **Nave** | nayv | Cathedral spine | The central structural element. Beautiful. | Too obscure. Nobody will know what it means. |
| **Pilot** | PIE-lot | Flight control | Direct Arc/flight metaphor. | Many apps named Pilot already. |
| **Strut** | strut | Structural support | The sidebar as structure. Also "to strut" = confidence. | Might sound aggressive. |
| **Omnitab** | OM-ni-tab | All tabs | Clear what it does. | "Tab" is limiting — the app is more than tabs. |
| **Anchor** | ANN-ker | Stability | Locked tabs = anchored. Always present. | Many apps called Anchor (podcasting, etc.). |

---

## Product Language

- **Hopline**: the app name.
- **Hop**: the primary action. Example: "Hop to Linear", "Hop to this tab", "Recent hops".
- **Line**: the cross-browser through-line that connects live tabs, pins, bookmarks, spaces, and profiles.
- **Global tab bar**: the clearest tagline-level description.

Possible taglines:

- **Hopline — your global tab bar.**
- **Hopline — one line through every browser.**
- **Hopline — hop between tabs, spaces, and browsers.**
- **Hopline — tabs and bookmarks, everywhere.**

---

## First-Pass Conflict Scan

Quick web searches did not show an obvious browser/tab/productivity app named **Hopline**. Nearby results exist, especially **TheHopeLine** (lifestyle/crisis-support app), **Hoplite** (game/security products), **Pline**, **Pushline**, and **Zipline**, but no direct same-space conflict surfaced.

This is not a legal clearance. Before public release, check domains, package names, app stores, browser extension stores, GitHub, and trademarks.

---

## Directions to Explore

Some naming angles that haven't been fully explored:

**Spatial / place metaphors**: The sidebar is a *place* you go to. A dock, a perch, a station, a roost, a ledge, a landing.

**Verbs as names**: What do you *do* with it? You dock tabs. You pin things. You browse from it. You switch. You rally. You muster.

**Invented words**: Short, ownable, domain-available. Sounds good, means nothing specific but feels right. Examples: Tabi (Japanese for "journey/travel"), Zumo, Nook, Floe.

**Tool metaphors**: It's a tool for organising. A sieve, a lens, a prism, a compass, a beacon.

---

## TODO

- [ ] Check Hopline domain availability
- [ ] Search Mac App Store, Windows Store, Chrome Web Store, Firefox Add-ons, and GitHub for Hopline conflicts
- [ ] Check basic trademark risk before any public release
- [ ] Decide whether to rename the docs folder from `TabFlow` to `Hopline`
