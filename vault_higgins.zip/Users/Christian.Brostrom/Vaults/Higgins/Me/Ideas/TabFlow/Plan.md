# Plan

> Back to [[README]]

---

## V1 Cutline

**Ship Hopline v1 before chasing Arc parity.**

The first shippable version should be:

- macOS only
- Single Chromium browser/profile, starting with Chrome
- Live tab sidebar with `hopline-bridge`
- Spaces, saved items, folders, and switch-to-tab
- Command panel + local API foundation
- No locked tabs, no multi-profile, no Windows parity, no Air Traffic Control

Everything beyond this is valuable, but it should be treated as a post-v1 track so the app becomes useful before the hardest edge cases consume the project.

---

## Phased Milestones

### Phase 0 — Spike / Proof of Concept (1–2 days)

Goal: Validate the two hardest parts work before building the full app.

- [ ] Create a bare Tauri 2 window with macOS Vibrancy effect active — confirm glass renders
- [ ] Write a minimal Chrome extension that logs tab events to console
- [ ] Add `nativeMessaging` to the extension, register a tiny `hopline-bridge` Native Messaging helper
- [ ] Confirm a message flows: Chrome tab opens → extension detects it → helper receives it over stdio → forwards it to the running app over local IPC → Rust logs it
- [ ] Done → the full communication pipeline is proven

### Phase 1 — Skeleton App (Week 1–2)

Goal: A working sidebar that shows live Chrome tabs.

- [ ] First-run onboarding: copy extension, install Native Messaging host manifest, open `chrome://extensions/`, verify connection
- [ ] Pin sideloaded extension ID with a manifest `"key"` so Native Messaging `allowed_origins` stays stable
- [ ] Configure sidebar window: left edge, always-on-top, non-activating, glass
- [ ] Extension streams tab events → Native Messaging helper → local IPC → Tauri `tauri::event` → frontend
- [ ] Use composite tab identity from day one: `(browserId, profileId, tabId)`
- [ ] SolidJS tab store: `createStore` + `reconcile` for snapshot, surgical `setTabs(idx, patch)` for deltas
- [ ] `<For>` component for tab list (never `.map()`)
- [ ] Basic sidebar UI: tab list with favicon + title
- [ ] Click tab → extension `chrome.tabs.update` + `chrome.windows.update` (focus tab)
- [ ] "Switch to tab" logic: if URL already open, focus it; otherwise open new
- [ ] Close tab from sidebar
- [ ] Connection status indicator (extension connected / disconnected)

### Phase 2 — Spaces + Persistence (Week 3–4)

Goal: Multiple spaces with URL-based tab association and auto-switching.

- [ ] SQLite schema setup (via tauri-plugin-sql) — see [[Data Model]]
- [ ] Space CRUD: create, rename, delete, reorder
- [ ] Space URL rules: create, edit, reorder, enable/disable
- [ ] Space switcher UI (top of sidebar)
- [ ] Space color tint via Tailwind 4 `bg-space/12`
- [ ] Auto-switch setting: off / suggest / automatic. Default to suggest until the behavior feels trustworthy.
- [ ] Auto-switch: `TAB_ACTIVATED` event → evaluate URL → switch space only when enabled
- [ ] Matched vs Other tabs sections in sidebar
- [ ] Persist space selection across restarts

### Phase 3 — Saved Items + Folders (Week 5–6)

Goal: The "bookmarks as tabs" sidebar model.

- [ ] Pin a live tab → saves to `pins` table
- [ ] Add bookmark manually (URL + title input)
- [ ] Render pins + bookmarks in sidebar (above live tabs)
- [ ] Click pin/bookmark → switch-to-tab or open new
- [ ] Folder creation + collapse/expand
- [ ] Manual reorder controls for v1; drag-and-drop is post-v1 polish unless this phase has extra time
- [ ] Folder collapse/expand state persisted

### Phase 4 — Command Panel (Week 7–8)

Goal: Global hotkey opens an ephemeral command + search overlay.

- [ ] Register global shortcut via `tauri-plugin-global-shortcut`
- [ ] Create panel window: centered, floating, transparent, hidden on startup
- [ ] Panel UI: single input, fuzzy results list, keyboard navigation (uFuzzy)
- [ ] Commands: switch space, switch to tab, open URL, close tab
- [ ] Searches across: live tabs, pinned tabs, bookmarks, spaces
- [ ] Escape / blur dismisses panel
- [ ] Expose authenticated localhost HTTP API foundation for launcher integrations

### Ship — macOS V1

Goal: Make Hopline useful on your Mac before expanding scope.

- [ ] Run full Phase 0–4 verification
- [ ] Test with 50+ tabs and at least two spaces
- [ ] Verify extension reconnect and app restart flows
- [ ] Verify uninstall cleanup removes Native Messaging host manifest
- [ ] Write a short limitations note: native browser tab strip remains visible, single profile only, Chrome-first

---

## Post-V1 Tracks

Each post-v1 track needs separate approval and its own mini-spec before implementation.

### Locked Tabs

Goal: The Arc feature. Tabs that reset.

- [ ] Add `webNavigation` as optional permission in extension manifest
- [ ] Sidebar UI: prompt user to grant `webNavigation` when they first lock a tab
- [ ] Extension: `chrome.webNavigation.onCommitted` listener for locked tab IDs
- [ ] On navigation away → `chrome.tabs.update(tabId, {url: originalUrl})`
- [ ] On tab close → `chrome.tabs.create({url: originalUrl})`
- [ ] Lock/unlock toggle on tab items in sidebar
- [ ] Lock registry persisted in SQLite and rebound by profile + URL on reconnect, not only tab ID

### Browser Profiles

Goal: Multiple Chrome profiles visible as distinct contexts.

- [ ] Existing `hopline-bridge` helper supports multiple simultaneous Native Messaging connections
- [ ] Extension sends a persistent profile identity during handshake; `Local State` is used for display names, not inference
- [ ] Read `Local State` JSON to enumerate profile names + avatars
- [ ] Tag each tab with its source profile
- [ ] Profile indicator on tab items in sidebar UI
- [ ] Option to scope a Space to a specific profile
- [ ] Extension onboarding: guide through loading in each profile

### Windows Port + Polish

Goal: Build and test on Windows PC.

- [ ] Switch to Windows Mica effect (platform conditional in Tauri config)
- [ ] Test extension + Native Messaging on Windows (registry-based host manifest)
- [ ] Test window overlay behaviour on Windows (taskbar, multiple monitors)
- [ ] Keyboard shortcuts (Cmd → Ctrl across the board)
- [ ] Installer: `.dmg` (macOS) and `.msi` (Windows) via Tauri bundler
- [ ] Adapt existing onboarding flow for Windows registry-based Native Messaging host manifests

### Stretch Goals

- [ ] Raycast extension (calls localhost HTTP API)
- [ ] PowerToys Run plugin (calls localhost HTTP API)
- [ ] Multi-monitor: sidebar follows active screen
- [ ] Browser window push: resize browser window to make room for sidebar
- [ ] Firefox support (WebExtensions — mostly same API)
- [ ] Safari support via AppleScript (macOS only)
- [ ] Sync between Mac and Windows
- [ ] Import Arc sidebar data (`StorableSidebar.json`)
- [ ] Tab history / recently closed
- [ ] CLI: calls HTTP API

Realistic estimate: **3–4 months of focused effort** for v1. Full feature set: 6–12 months.

---

## First Session Checklist

When ready to start, do this before writing any real code. De-risks the entire project in under an hour.

**Step 1 — Rust + Tauri glass effect**
```bash
rustup update
sh <(curl https://create.tauri.app/sh)
```
Set `transparent: true, decorations: false` in `tauri.conf.json`. Apply vibrancy via Rust platform code using `objc2-app-kit` (NOT a config key). Run `cargo tauri dev` — confirm the transparent/glass window renders.

**Step 2 — Minimal extension**
Create a folder with:
```json
{
  "manifest_version": 3,
  "name": "Dev Bridge",
  "version": "0.1",
  "background": { "service_worker": "background.js" },
  "permissions": ["tabs", "nativeMessaging"]
}
```
```javascript
chrome.tabs.onCreated.addListener(tab => console.log('tab created', tab.title));
```
In Chrome: Extensions → Enable Developer Mode → Load Unpacked → select the folder. Confirm you see logs.

**Step 3 — Native Messaging handshake**
Add Native Messaging to the extension and write a minimal Rust receiver in Tauri. Confirm a message flows end-to-end: new tab opens in Chrome → extension sends message → Rust prints it.

If all three work: you're ready to build the real app. ~20 minutes each.
