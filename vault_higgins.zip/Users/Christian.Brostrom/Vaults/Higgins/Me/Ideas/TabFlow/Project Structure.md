# Project Structure & Dev Setup

> Back to [[README]]

---

## Prerequisites

```bash
# 1. Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
rustup update

# 2. Install Node (via bun)
curl -fsSL https://bun.sh/install | bash

# 3. macOS dependencies (likely already installed)
xcode-select --install
```

---

## Scaffold the Project

```bash
# Official Tauri scaffolder (verified)
sh <(curl https://create.tauri.app/sh)
# Choose: SolidJS, TypeScript

# Add plugins (from project root)
npm run tauri add sql
npm run tauri add global-shortcut
```

Note: `npm run tauri add <plugin>` handles both the JS package and the Rust crate automatically.

---

## Folder Layout

```
project/
├── src-tauri/                    # Rust backend
│   ├── src/
│   │   ├── lib.rs                # Tauri app entry + setup
│   │   ├── messaging/
│   │   │   ├── mod.rs            # App-side IPC receiver + connection registry
│   │   │   ├── bridge.rs         # Native Messaging helper: stdio ⇄ local IPC
│   │   │   └── protocol.rs       # Message types (serde)
│   │   ├── locks/
│   │   │   └── enforcer.rs       # Lock state, commands to extension
│   │   ├── db/
│   │   │   ├── migrations.rs     # SQL migrations (include_str!)
│   │   │   └── queries.rs        # All DB read/write operations
│   │   ├── routing/
│   │   │   └── rules.rs          # Air Traffic Control rule evaluation
│   │   ├── api/
│   │   │   └── http.rs           # localhost HTTP API (Raycast etc.)
│   │   └── platform/
│   │       ├── macos.rs          # Vibrancy, non-activating window
│   │       └── windows.rs        # Mica/Acrylic, WS_EX_NOACTIVATE
│   ├── capabilities/
│   │   └── default.json          # Plugin permissions
│   ├── Cargo.toml
│   └── tauri.conf.json
│
├── extension/                    # Companion browser extension
│   ├── manifest.json             # MV3 manifest
│   ├── background.js             # Service worker (tab events, locks)
│   └── icons/
│
└── frontend/                     # SolidJS frontend
    ├── src/
    │   ├── App.tsx               # Root, window routing (sidebar vs panel)
    │   ├── store/
    │   │   ├── tabs.ts           # createStore + reconcile for live tabs
    │   │   ├── spaces.ts         # Space state (createStore)
    │   │   └── bookmarks.ts      # Pinned/bookmark store
    │   ├── components/
    │   │   ├── Sidebar.tsx       # Main sidebar container
    │   │   ├── SpaceBar.tsx      # Space switcher
    │   │   ├── TabList.tsx       # <For> over tab store
    │   │   ├── TabItem.tsx       # Individual tab row
    │   │   ├── Folder.tsx        # Collapsible folder
    │   │   └── Panel.tsx         # Command panel UI (separate window)
    │   ├── hooks/
    │   │   ├── useTabs.ts        # Extension events → store reconcile
    │   │   ├── useSpaceMatch.ts  # URL → space rule evaluation + auto-switch
    │   │   └── useSearch.ts      # Fuzzy search (uFuzzy)
    │   └── app.css               # Tailwind 4: @import "tailwindcss" + @theme
    ├── index.html
    ├── panel.html                # Separate entry for command panel window
    ├── vite.config.ts            # includes @tailwindcss/vite plugin
    └── tsconfig.json
```

---

## Cross-Platform Build Strategy

**Development happens on Mac.** Windows testing on your Windows PC.

### Building for macOS
```bash
cargo tauri build
# Output: src-tauri/target/release/bundle/dmg/Hopline.dmg
```

### Building for Windows

**Option A — Build on Windows PC directly**
```bash
cargo tauri build
# Output: src-tauri/target/release/bundle/msi/Hopline.msi
```

**Option B — GitHub Actions CI (recommended once stable)**
```yaml
jobs:
  build-windows:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo tauri build
      - uses: actions/upload-artifact@v4
        with:
          name: windows-build
          path: src-tauri/target/release/bundle/
```
