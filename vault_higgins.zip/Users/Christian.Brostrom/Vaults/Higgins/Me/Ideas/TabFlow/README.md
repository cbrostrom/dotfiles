# Hopline — Cross-Platform Arc-Style Browser Sidebar

> **Status**: Idea / Pre-development  
> **Target platforms**: macOS (primary dev), Windows 11  
> **Develop on**: MacBook — cross-compile or remote-test on Windows PC  
> **Name**: Hopline — see [[Naming]]

---

## The Problem Worth Solving

Arc Browser introduced the best tab management ideas in years:

- A persistent sidebar that lives *beside* the browser, not inside it
- Pinned tabs that always exist and survive restarts
- Locked tabs that reset to their original URL when you navigate away or close them
- Bookmarks and tabs treated as the same kind of thing
- Workspaces (Spaces) that keep work and personal completely separate

The problem: Arc is Mac-only, its future is uncertain, and it forces you to abandon your existing browser. Every other tab manager is a browser extension — sandboxed to one browser, no cross-browser view, gone when you uninstall.

**This project is Arc's ideas, extracted into a standalone sidebar and command panel. V1 starts as a macOS Chrome-first app, then expands to any Chromium browser where the Hopline bridge is installed.**

---

## Spec Documents

| Document | What's in it |
|---|---|
| [[Features]] | Core concept, spaces, sidebar items, tab management, command panel, locked tabs |
| [[Architecture]] | Stack choices (Tauri, SolidJS, Tailwind 4, SQLite), architecture diagram, Tauri capabilities |
| [[Extension]] | Companion browser extension design, Native Messaging protocol, switch-to-tab, locked tab implementation, bundling |
| [[Data Model]] | SQLite schema — spaces, space rules, folders, pins, locked tabs, routes |
| [[Visual Design]] | Glass effects, per-space color tints, typography, animation, dark/light mode, platform matrix |
| [[Performance]] | SolidJS primitives (stores, reconcile, For), IPC payload discipline, CSS rendering, latency budget, memory targets |
| [[Command Panel]] | Global hotkey, command+search UI, localhost HTTP API, Raycast/Alfred/PowerToys integration |
| [[Browser Profiles]] | Multi-profile architecture, bridge helper pattern, profile identity, UI treatment |
| [[Air Traffic Control]] | URL routing rules, save/open routes, profile-linked routes, route data model |
| [[Project Structure]] | Folder layout, dev environment setup, scaffold commands |
| [[Plan]] | Phased milestones (Phase 0–8), cross-platform build strategy, first session checklist |
| [[Risks and Review]] | Known risks, design flaws, hallucination audit, verification status table |
| [[Naming]] | Name brainstorm and shortlist |
| [[AI Build Spec]] | Phased execution plan for AI agents — quality gates, fallow checkpoints, code reuse targets, AI slop prevention |

---

## Key Decisions

| Decision | Rationale |
|---|---|
| Tauri over Electron | Performance, binary size, native feel — Electron contradicts the whole point |
| SolidJS over React | Fine-grained reactivity matches the live-updating tab list model; smaller runtime |
| Tailwind 4 over vanilla CSS | CSS-first config (no JS config file), native `color-mix()` for dynamic space colors, Vite plugin, microsecond rebuilds |
| Extension + Native Messaging over raw CDP | No debug port required; user-visible permissions; works for normal users; expands browser-by-browser as the Hopline bridge is installed |
| Spaces with URL rules + auto-switch | Spaces don't hide tabs or fight the browser's tab bar — they organise curated items and auto-associate live tabs via URL matching. Sidebar follows the browser. |
| SQLite over cloud sync | Personal project; simplicity first; sync is a stretch goal |
| Chromium-first | Covers the vast majority of real-world browsers; Firefox/Safari add significant complexity for v1 |
| Develop on Mac | macOS toolchain is smoother; build Windows via Windows machine or GitHub Actions |

---

## Resources

### Tauri
- [Tauri 2.x Docs](https://v2.tauri.app)
- [tauri-plugin-sql](https://github.com/tauri-apps/tauri-plugin-sql)
- [tauri-plugin-global-shortcut](https://github.com/tauri-apps/tauri-plugin-global-shortcut)

### Browser Extension APIs
- [Chrome Extensions API — tabs](https://developer.chrome.com/docs/extensions/reference/api/tabs)
- [Chrome Extensions API — webNavigation](https://developer.chrome.com/docs/extensions/reference/api/webNavigation)
- [Native Messaging guide](https://developer.chrome.com/docs/extensions/develop/concepts/native-messaging)
- [Manifest V3 permissions](https://developer.chrome.com/docs/extensions/develop/concepts/declare-permissions)
- [Firefox WebExtensions compatibility](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Chrome_incompatibilities)

### SolidJS
- [SolidJS Docs](https://docs.solidjs.com)
- [SolidJS Stores (createStore, reconcile)](https://docs.solidjs.com/concepts/stores)
- [SolidJS Signals](https://docs.solidjs.com/concepts/signals)

### Tailwind CSS 4
- [Tailwind 4 Installation (Vite)](https://tailwindcss.com/docs/installation)
- [Tailwind 4 Theme Variables (@theme)](https://tailwindcss.com/docs/theme)
- [Tailwind 4 Announcement](https://tailwindcss.com/blog/tailwindcss-v4)

### Inspiration
- [SupaSidebar](https://supasidebar.com) — macOS reference; Air Traffic Control feature inspiration
- [Arc Browser](https://arc.net) — feature inspiration (spaces, locked tabs, sidebar UX)
- [Sidebery](https://github.com/mbnuqw/sidebery) — open source Firefox sidebar
- [uFuzzy](https://github.com/leeoniya/uFuzzy) — fast fuzzy search library
