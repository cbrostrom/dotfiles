# Risks and Critical Review

> Back to [[README]]

This section exists to challenge the plan before writing a line of production code. Every item is either a real technical trap, an overstated claim, or a design decision that deserves harder scrutiny.

---

## Known Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Locked tab flicker on reset | Medium | Medium | Use `onBeforeNavigate` where possible; add CSS transition to mask |
| Windows Mica not available (Win10) | High (Win10) | Low | Detect OS version, fall back to solid |
| Sidebar focus stealing | Medium | High | `NSWindowStyleMaskNonactivatingPanel` on macOS; `WS_EX_NOACTIVATE` on Windows |
| Tauri WebView2 on Windows oddities | Medium | Medium | Test early; WebView2 is mature but has edge cases |
| Service worker dormancy | Medium | Medium | Keep Native Messaging port open permanently |
| Extension ID instability on sideload | High | High | Pin with `"key"` field in manifest — see item #8 |
| Native Messaging host launches a separate process | High | High | Use `hopline-bridge` helper from Phase 0, not the GUI app executable |
| Broad extension permissions scare users | Medium | High | Avoid `<all_urls>` in base install unless a feature truly requires it |
| Locked tab IDs are unstable across browser restarts | High | Medium | Rebind locks by profile + URL/window context, not only extension tab ID |

---

## Hallucinations / Overconfident Claims

**1. ~~`"vibrancy": "sidebar"` config~~ — CORRECTED**

Now corrected throughout docs. Vibrancy requires platform-specific Rust code using `objc2-app-kit`, not a config key. Exact API must be verified against installed crate version.

**2. `color-mix()` in the WebView**

Requires Safari 16.2+ (WKWebView) and recent WebView2. Tailwind 4 uses `color-mix()` by default. Older systems fail silently. Add `@supports` fallback.

**3. `chrome.tabs.query` URL matching — CORRECTED**

Corrected in [[Extension]]. Uses client-side URL normalisation now, not invalid Chrome match patterns.

**4. Multiple simultaneous Native Messaging connections**

Chrome's Native Messaging spawns a **new process** for each connection. Two profiles = two app instances fighting for the screen.

**Fix**: lightweight `hopline-bridge` helper as the Native Messaging host. Each helper connects to the main GUI app via Unix domain socket / named pipe. Standard practice (1Password uses it) but adds a second binary.

This is not only a multi-profile issue. Even one profile launches a host process, so the helper pattern belongs in Phase 0/1. Do not point the Native Messaging manifest at the main GUI executable unless the app has an explicit headless host mode and single-instance forwarding.

**5. `chrome.webNavigation.onCommitted` flicker on locked tabs**

`onCommitted` fires AFTER navigation is committed — the new page has started loading. The user sees a brief flash. `onBeforeNavigate` fires earlier but cannot cancel navigation in MV3.

**The locked tab experience will not be as clean as Arc's.** Functional but not identical. This is a fundamental MV3 limitation.

---

## Design Flaws

**6. Non-activating sidebar on Windows is not a Tauri checkbox**

On macOS, Tauri surfaces `NSWindowStyleMaskNonactivatingPanel`. On Windows, `WS_EX_NOACTIVATE` likely requires raw Win32 calls via `raw_window_handle`. Budget time for this.

**7. The sidebar covers browser content**

280px sidebar takes ~11% on a MacBook, ~15% on 1080p Windows. Options:
- **Overlap** (current plan): simplest, visually awkward
- **Push browser window right**: accessibility APIs, fragile
- **User sets manually**: easy but poor UX

Overlap is fine for v1. Should be a conscious decision, not ignored.

**8. Extension ID instability for sideloaded extensions**

Sideloaded extension ID derives from disk location. Moving the folder changes the ID. Native Messaging `allowed_origins` must match exactly — breaks silently.

**Fix**: include a `"key"` field in `manifest.json` with a generated RSA key pair. Pins the ID regardless of install path.

**9. Air Traffic Control "open in different browser" — Windows edge cases**

`start firefox https://...` only works if Firefox is on PATH (not guaranteed). Chrome `--profile-directory` uses internal names ("Profile 1") not human-readable names.

**10. Scope is growing beyond a weekend project**

Current scope: sidebar, extension, command panel, HTTP API, Air Traffic Control, profiles, Windows port. Realistic v1 (macOS, single profile, sidebar + command panel): **3–4 months**. Full scope: 6–12 months.

**11. Localhost HTTP API is a local control surface**

Any local process could call an open localhost API. Hopline should bind only to `127.0.0.1`, require a bearer token from the first implementation, and store the active port/token in settings.

**12. Fuzzy search at scale**

uFuzzy is the current choice (10–20x faster than fuse.js). For 500+ items it's fine. For 1000+, consider running search in Rust via `tauri::command`.

**13. Browser chrome cannot be hidden**

Hopline can make the native browser tab bar feel redundant, but it cannot hide Chrome/Edge/Brave's built-in tab strip. Users will still see duplicated browser chrome unless they choose a browser/window setup that minimizes it. This should be explicit in onboarding and screenshots.

**14. Broad host permissions are a trust barrier**

The extension manifest currently sketches `<all_urls>`. That is a scary permission prompt and may not be needed for the base tab-listing feature. Start with `tabs` + `nativeMessaging`; only request host permissions or `webNavigation` when the user enables locked tabs or routing features that require them.

**15. Profile identity is harder than reading Chrome Local State**

`Local State` gives profile names and directories, but an incoming Native Messaging connection does not automatically say "I am Profile 1." The onboarding flow needs a reliable profile handshake, such as a generated profile identity stored in extension storage during setup, or a per-profile registration step that maps the helper connection to the selected profile.

**16. Locked tab registry cannot rely only on `ext_tab_id`**

Chrome tab IDs are session-scoped and change after browser restart. The data model should store enough context to rebind locks on reconnect: profile identity, original URL, pin ID, maybe last known window/tab metadata. On startup, reconcile by URL/profile and recreate missing locked tabs intentionally.

**17. Fixed localhost port can collide**

`localhost:42420` is fine as a default, but another process may already use it. The app should either retry within a small port range and expose the active port to launcher integrations, or fail with a clear error and setting.

**18. HTTP API should get a token before distribution**

Do not wait too long on this. A local token in the user config, required as an `Authorization` header, is cheap to add early and prevents local malware or random local scripts from controlling tabs through Hopline.

**19. Fallow does not cover Rust**

Fallow is useful for the SolidJS/TypeScript side, but Rust needs its own gates: `cargo fmt --check`, `cargo clippy -- -D warnings`, and targeted `cargo test`. The AI Build Spec should treat these as mandatory once Rust modules exist.

**20. Saving a fallow baseline can hide new slop**

`fallow dead-code --save-baseline` should only be run after the phase is clean, and preferably after reviewing the diff. Otherwise an agent can accidentally bless new dead code as the baseline. The report should state whether the baseline changed and why.

---

## Verification Status

| Claim | Status |
|---|---|
| Tauri glass effects (Vibrancy/Mica) | ✅ Real — verify exact API against Tauri 2.x docs |
| Extension tabs API for tab management | ✅ Solid — standard, well-documented |
| Native Messaging for extension↔app comms | ✅ Real — use `hopline-bridge` helper from Phase 0/1 |
| Global shortcut via Tauri plugin | ✅ Verified against actual plugin docs |
| Tailwind 4 CSS-first config + color-mix | ✅ Verified against v4 announcement + install docs |
| Locked tabs via webNavigation | ⚠️ Works but has visible flicker — not Arc-quality |
| Non-activating window on Windows | ⚠️ Possible but not a Tauri checkbox |
| Switch-to-tab URL matching | ⚠️ Needs careful URL normalisation |
| Multi-profile simultaneous connections | ⚠️ Needs bridge helper connection tagging |
| "Open in different browser" routing | ⚠️ OS shell works but has edge cases |
| Extension ID stability on sideload | ⚠️ Needs pinned key in manifest |
| Code snippets in these docs | ❌ Treat as pseudocode — verify before using |
