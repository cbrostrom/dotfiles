# Architecture

> Back to [[README]]

---

## Browser Bridge: Extension + Native Messaging

**This is the key architectural decision.** Rather than connecting via Chrome DevTools Protocol (which requires launching Chrome with a debug flag — a developer-level setup step), the app uses a **companion browser extension** that communicates with the native app via Chrome's Native Messaging API.

Why this is the right choice:

- **No debug port required** — works for any user out of the box
- **User-visible permissions** — the extension shows exactly what it's requesting; nothing hidden
- **Granular scopes** — lock enforcement is an optional permission; basic tab management is minimal
- **Browser-by-browser bridge** — same extension pattern should work across Chromium browsers, but each browser/profile needs its own extension install and Native Messaging setup
- **"Switch to tab"** — trivially implementable via the tabs API
- **Locked tabs** — fully implementable via `webNavigation` API, no debug port needed
- **Bundleable** — the extension ships inside the app bundle; onboarding loads it automatically

See [[Extension]] for the full extension design.

---

## Stack

### Tauri 2.x (app framework)

- Uses OS-native webview — not bundled Chromium like Electron
- Binary size: ~5–10 MB vs Electron's 80–150 MB
- Memory: ~20–40 MB baseline vs Electron's 200 MB+
- Rust backend handles: app state, SQLite, OS window effects, and the local IPC endpoint used by the Native Messaging helper
- Cross-platform: one codebase, builds for macOS + Windows natively

### SolidJS (frontend framework)

- Fine-grained reactivity — no virtual DOM diffing
- When a tab title changes, only that exact DOM element updates
- For a sidebar showing 30–80 live-updating tabs, this matters
- Familiar JSX syntax, TypeScript-first, small runtime (~7 KB)
- `createStore` + `reconcile` for live tab list (see [[Performance]])

### Tailwind CSS 4 (styling)

- CSS-first configuration — no `tailwind.config.js`, just `@import "tailwindcss"` + `@theme {}` block
- First-party Vite plugin (`@tailwindcss/vite`) — tightest possible integration
- Built on `color-mix()` — per-space color tints work natively: `bg-space/12` generates `color-mix(in oklch, var(--color-space) 12%, transparent)`
- Zero-runtime — generates static CSS, purged to only classes used (~5–10 KB for a sidebar UI)
- Incremental rebuilds in microseconds
- `dark:` variant handles `prefers-color-scheme` branching
- Auto-detects content files — no glob paths to maintain

```css
/* app.css — entire Tailwind setup */
@import "tailwindcss";

@theme {
  --color-space: var(--space-color, oklch(0.55 0.15 260));
}
```

```typescript
// vite.config.ts
import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [tailwindcss()],
})
```

Then in components: `bg-space/12` for space tint, `dark:text-white/90` for dark mode text, etc.

### SQLite via tauri-plugin-sql (persistence)

- Zero-config, file-based, works identically on Mac and Windows
- Stores: spaces, space rules, pinned tabs, bookmarks, folders, locked tab registry
- Live tabs are NOT stored — those stream in from the extension in real time
- See [[Data Model]] for schema

---

## Full Architecture Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                        Native App                            │
│                                                              │
│  ┌──────────────────────┐   ┌──────────────────────────────┐ │
│  │   SolidJS Frontend   │   │       Rust Backend            │ │
│  │                      │   │                              │ │
│  │  Space Switcher       │   │  ┌──────────────────────┐   │ │
│  │  Tab List (stores)   │◄──┼──│ Local IPC Endpoint    │   │ │
│  │  Pinned / Bookmarks  │   │  │ - Recv tab events     │   │ │
│  │  Folders             │   │  │ - Send commands       │   │ │
│  │  Fuzzy Search        │   │  └──────────┬───────────┘   │ │
│  │                      │   │             │ app state      │ │
│  │  tauri::invoke() ────┼───┼──►  ┌───────▼───────────┐   │ │
│  │  tauri::event()  ◄───┼───┼──   │ SQLite             │   │ │
│  └──────────────────────┘   │     │ Spaces/Pins/Folders│   │ │
│                              │     └───────────────────┘   │ │
│                              └──────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
         │ WebView                        │ local IPC
         ▼                                ▼
   OS-native glass              ┌─────────────────────┐
   (Vibrancy/Mica)              │ Native Host Helper  │
                                │ stdio ⇄ IPC relay   │
                                └──────────┬──────────┘
                                           │ stdio pipe
                                           ▼
                                ┌─────────────────────┐
                                │  Browser Extension   │
                                │                      │
                                │  chrome.tabs API     │
                                │  chrome.windows API  │
                                │  chrome.webNavigation│
                                │  (optional — locks)  │
                                └──────────┬──────────┘
                                           │
                                    Chrome / Brave
                                    Edge / Firefox
```

**Important correction**: Chrome does not connect to an already-running GUI app for Native Messaging. It launches the configured host executable and talks to that process over stdio. Hopline should therefore include a tiny Native Messaging helper from Phase 0, even for one browser profile. The helper speaks stdio to the extension and forwards messages to the running Tauri app over Unix domain sockets on macOS and named pipes on Windows. Multi-profile support later extends the same helper pattern instead of replacing the architecture.

---

## Sidebar Window Behaviour

- Fixed to the left edge of the screen (configurable: right edge option later)
- Always on top of other windows but **non-activating** — clicking the sidebar doesn't steal focus from the browser
- Width: ~260–320px (user resizable)
- Transparent/glass background using OS native effects (see [[Visual Design]])
- When browser is in full screen: sidebar hides automatically (or user toggles)

---

## Tauri 2.x Capabilities (Required — Easy to Miss)

Every plugin command is **blocked by default** in Tauri 2.x. After adding plugins, you must grant permissions in `src-tauri/capabilities/default.json`:

```json
{
  "$schema": "../gen/schemas/desktop-schema.json",
  "identifier": "main-capability",
  "description": "Main window capabilities",
  "windows": ["main", "panel"],
  "permissions": [
    "core:default",
    "core:window:default",
    "sql:default",
    "sql:allow-execute",
    "global-shortcut:allow-register",
    "global-shortcut:allow-unregister"
  ]
}
```

Forgetting this causes silent failures — the JS call returns nothing and no error is thrown in the frontend.

---

## Browser Tab Coverage

| Browser | Platform | Support |
|---|---|---|
| Chrome | Mac + Windows | ✅ Primary target |
| Brave | Mac + Windows | Likely, test before promising |
| Edge | Mac + Windows | Likely, test before promising |
| Arc | Mac | Best-effort Chromium fork, test before promising |
| Firefox | Mac + Windows | Partial (different protocol, v2) |
| Safari | Mac only | Partial (AppleScript, v2) |
