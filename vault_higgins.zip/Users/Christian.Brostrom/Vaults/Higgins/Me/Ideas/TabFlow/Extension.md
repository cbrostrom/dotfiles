# Extension Design

> Back to [[README]] | See also: [[Architecture]], [[Performance]]

---

## Permissions Model (Minimal + Transparent)

```json
{
  "manifest_version": 3,
  "name": "Hopline Bridge",
  "permissions": [
    "tabs",
    "nativeMessaging"
  ],
  "optional_permissions": [
    "webNavigation"
  ],
  "host_permissions": []
}
```

`webNavigation` is **optional** — users who don't want locked tabs never grant it. Keep the base install to `tabs` + `nativeMessaging`; do not request `<all_urls>` unless a concrete feature needs page-level access. This keeps the permission prompt less scary and improves future store-review odds.

---

## Key Extension APIs Used

```
chrome.tabs.query()              → list all open tabs
chrome.tabs.update(id, {active}) → focus a tab
chrome.windows.update(id, {focused}) → focus the browser window
chrome.tabs.create({url})        → open a new tab
chrome.tabs.remove(id)           → close a tab
chrome.tabs.onCreated            → live event: tab opened
chrome.tabs.onUpdated            → live event: title/URL changed
chrome.tabs.onRemoved            → live event: tab closed
chrome.tabs.onActivated          → live event: user switched tabs
chrome.webNavigation.onCommitted → navigation event (for lock enforcement)
chrome.tabs.update(id, {url})    → redirect tab (for lock enforcement)
```

---

## "Switch to Tab" Implementation

**Important**: `chrome.tabs.query({ url: pattern })` uses Chrome match pattern format, not arbitrary strings. The safest approach is to fetch all tabs and normalise URLs client-side.

```javascript
function normalizeUrl(url) {
  try {
    const u = new URL(url);
    u.hash = '';
    return u.toString().replace(/\/$/, '');
  } catch { return url; }
}

async function switchToOrOpen(url) {
  const normalTarget = normalizeUrl(url);
  const allTabs = await chrome.tabs.query({});
  const match = allTabs.find(t => normalizeUrl(t.url ?? '') === normalTarget);

  if (match) {
    await chrome.tabs.update(match.id, { active: true });
    await chrome.windows.update(match.windowId, { focused: true });
    return { action: 'switched', tabId: match.id };
  } else {
    const tab = await chrome.tabs.create({ url });
    return { action: 'opened', tabId: tab.id };
  }
}
```

---

## Locked Tab Implementation (via webNavigation)

```javascript
const lockedTabs = new Map(); // tabId → originalUrl

chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return;
  const originalUrl = lockedTabs.get(details.tabId);
  if (!originalUrl) return;
  if (details.url !== originalUrl && !details.url.startsWith('chrome://')) {
    chrome.tabs.update(details.tabId, { url: originalUrl });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (lockedTabs.has(tabId)) {
    const url = lockedTabs.get(tabId);
    lockedTabs.delete(tabId);
    chrome.tabs.create({ url });
  }
});
```

> **Known limitation**: `onCommitted` fires AFTER navigation — some flicker is unavoidable. See [[Risks and Review]] item #5.

---

## Native Messaging Protocol

The browser extension connects to Hopline through the `hopline-bridge` helper binary, not directly to the GUI executable. Chrome launches Native Messaging hosts as stdio child processes, so the helper forwards messages to the already-running Tauri app over local IPC. This keeps the app single-instance and becomes the foundation for multi-profile support later.

Chrome Native Messaging uses **4-byte little-endian length-prefixed JSON messages** over stdin/stdout. `hopline-bridge` owns this framing. The Tauri app should receive already-decoded typed messages over local IPC.

Every message should include:

- `version`: protocol version, starting at `1`
- `requestId`: present for request/response commands
- `browserId`: stable browser family/install identifier, e.g. `chrome`, `brave`, `edge`
- `profileId`: stable per-extension-install identity generated during onboarding and stored in extension storage

Do not use raw `tabId` as a global key. Chrome tab IDs are only meaningful inside one browser/profile connection and can be recycled after restart. Hopline's runtime tab key is `(browserId, profileId, tabId)`.

```javascript
// Extension → App (events)
{ version: 1, type: 'HELLO', browserId, profileId, profileLabel }
{ version: 1, type: 'TAB_CREATED',   browserId, profileId, tab: { id, url, title, favIconUrl, windowId } }
{ version: 1, type: 'TAB_UPDATED',   browserId, profileId, tab: { id, url, title, favIconUrl } }
{ version: 1, type: 'TAB_REMOVED',   browserId, profileId, tabId: 123 }
{ version: 1, type: 'TAB_ACTIVATED', browserId, profileId, tabId: 123, url: 'https://...' }  // includes URL for space matching
{ version: 1, type: 'TABS_SNAPSHOT', browserId, profileId, tabs: [...] }  // sent on connect and reconnect

// App → Extension (commands)
{ version: 1, requestId, type: 'OPEN_URL',    browserId, profileId, url: 'https://...' }
{ version: 1, requestId, type: 'FOCUS_TAB',   browserId, profileId, tabId: 123 }
{ version: 1, requestId, type: 'CLOSE_TAB',   browserId, profileId, tabId: 123 }
{ version: 1, requestId, type: 'LOCK_TAB',    browserId, profileId, tabId: 123, url: 'https://...' }
{ version: 1, requestId, type: 'UNLOCK_TAB',  browserId, profileId, tabId: 123 }
{ version: 1, requestId, type: 'GET_TABS',    browserId, profileId }  // request fresh snapshot
```

Reconnect sequence:

1. Extension connects to `com.hopline.bridge`
2. Extension sends `HELLO`
3. App records connection under `(browserId, profileId)`
4. App requests or receives `TABS_SNAPSHOT`
5. App reconciles runtime tabs and rebinds any persisted locks/saved state by profile + URL

**Auto-switch flow:**
`TAB_ACTIVATED` is the critical event for space auto-switching. When the user clicks a tab in Chrome's own tab bar, the extension sends this with the tab's URL. Rust evaluates the URL against space rules (top-down, first match) and emits a `switch-space` event to the SolidJS frontend if the matched space differs from the active one. Total latency: ~15–20ms.

---

## Service Worker Keep-Alive

Chrome aggressively kills idle MV3 service workers (~30s inactivity). The Native Messaging port keeps it alive:

```javascript
let port = null;

function connectToNativeHost() {
  port = chrome.runtime.connectNative('com.hopline.bridge');
  port.onDisconnect.addListener(() => {
    setTimeout(connectToNativeHost, 1000);
  });
  port.onMessage.addListener(handleCommand);
}

connectToNativeHost();
```

With an open port, the service worker stays alive indefinitely. Without it, every cold-start click adds 50–300ms delay.

---

## Bundling the Extension

The extension lives inside the app bundle. On first run:

1. Copies the extension folder to a known location (`~/Library/Application Support/Hopline/extension/`)
2. Installs the Native Messaging host helper manifest to the correct OS location automatically
3. Pins the extension ID with a generated manifest `"key"` so `allowed_origins` stays stable
4. Opens Chrome to `chrome://extensions/` and guides the user to click "Load unpacked"
5. Waits for `HELLO` + `TABS_SNAPSHOT` and shows a connected state before onboarding is considered complete

No Chrome Web Store is required for personal use, but onboarding is a core product flow, not polish. If the bridge does not connect, the app should show the exact host manifest path, extension ID, and last bridge error.

**Native Messaging host helper manifest** (auto-installed):

```json
{
  "name": "com.hopline.bridge",
  "description": "Hopline browser bridge",
  "path": "/Applications/Hopline.app/Contents/MacOS/hopline-bridge",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://EXTENSION_ID/"
  ]
}
```

Installed to:
- macOS: `~/Library/Application Support/Google/Chrome/NativeMessagingHosts/`
- Windows: Registry key `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.hopline.bridge`

> **Important**: sideloaded extension IDs are unstable unless pinned with a `"key"` field in `manifest.json`. See [[Risks and Review]] item #8.
