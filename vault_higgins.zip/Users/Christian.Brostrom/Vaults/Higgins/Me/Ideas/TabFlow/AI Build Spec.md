# AI Build Spec — Phased Execution Plan

> Back to [[README]]  
> **Purpose**: This document is the master instruction set for AI agents building Hopline. Each phase is fully autonomous — the agent must be able to complete it without asking questions or requiring human interaction.

---

## Execution Model

This spec is designed for **unattended phase-by-phase execution**.

### How it works

1. The human tells the agent: "Execute Phase N of the AI Build Spec at `Ideas/TabFlow/AI Build Spec.md`"
2. The agent reads this file and the spec docs listed in that phase's `Spec refs`
3. The agent executes every checklist item autonomously — no questions, no clarifications, no "should I...?" prompts
4. The agent runs the quality gate and fixes any issues it finds
5. The agent **stops and reports** what was built, what works, and any issues encountered
6. The human reviews, approves, and triggers the next phase

### Decision authority

The agent has full authority to make implementation decisions within a phase's scope. If the spec says "implement X," the agent picks the approach and builds it. The spec docs contain enough detail to resolve ambiguity — read them.

If a genuinely blocking external issue arises (e.g., a dependency doesn't install, an API has been removed, a platform tool is missing), the agent should:
1. Document the blocker clearly
2. Complete everything else in the phase that isn't blocked
3. Report the blocker in the phase completion summary

Do NOT stop the entire phase to ask about a non-blocking decision.

### Phase completion report

At the end of every phase, the agent must produce a structured summary:

```
## Phase N Complete

### Built
- [list of what was implemented]

### Verification results
- [for each "How to verify" step: pass / fail / requires human testing]
- [include what you tested, what you observed, and any caveats]

### Quality gate results
- tsc: [pass/fail + error count]
- cargo fmt: [pass/fail]
- cargo clippy: [pass/fail + warning count]
- cargo test: [pass/fail + test count]
- fallow dead-code: [pass/fail + issue count]
- fallow dupes: [pass/fail + block count]
- fallow health: [notable findings]

### Blockers (if any)
- [description of anything that couldn't be completed and why]

### Notes for next phase
- [anything the next agent should know]
```

### Pre-phase setup

Before starting ANY phase, the agent must:

1. Read this entire "Ground Rules" section
2. Read [[Risks and Review]] — it contains corrections to claims made elsewhere in the spec
3. Read every spec doc listed in the phase's `Spec refs` line
4. Verify the current state of the codebase (what exists from previous phases)
5. Fetch latest docs for any framework/library being used for the first time in this phase (Tauri, SolidJS, Tailwind, Chrome Extension APIs)

---

## Ground Rules for ALL Phases

These rules apply to every phase, every commit, every file.

### Code Quality — Non-Negotiable

1. **No dead code.** Every file, export, function, type, and variable must be used. If you write it, something must import or call it. If you remove a feature, remove all code that supported it.

2. **No speculative abstractions.** Do not create "utility" modules, wrapper functions, or abstraction layers "in case we need them later." Build exactly what the current phase requires. Future phases will extend — not inherit from phantom scaffolding.

3. **No hallucinated APIs.** Every Tauri plugin call, Chrome extension API, SolidJS primitive, and Tailwind class must be verified against the linked documentation before use. The spec docs (referenced per phase) contain known corrections — read the [[Risks and Review]] file for every claim that was already caught and fixed.

4. **No copy-paste boilerplate.** If two components share logic, extract it into a shared module immediately — not "later." If three files import the same 5 lines, that's a hook or utility waiting to happen.

5. **No orphaned imports.** Every `import` statement must resolve to a used binding. TypeScript's `noUnusedLocals` and `noUnusedParameters` must be enabled in `tsconfig.json` from Phase 1.

6. **Treat spec code as pseudocode.** The snippets in the spec documents illustrate intent, not production code. Verify APIs, adapt signatures, and test — do not paste them verbatim. See [[Risks and Review]] item "Code snippets in these docs → ❌ Treat as pseudocode."

### AI Slop Prevention

AI-generated code has predictable failure patterns. Watch for and avoid these:

| Pattern | What it looks like | What to do instead |
|---|---|---|
| **Narration comments** | `// Set the title`, `// Import the module` | Delete the comment. The code speaks. |
| **Phantom types** | Interfaces with 15 optional fields "for future use" | Define only fields the current phase uses. Extend later. |
| **God modules** | `utils.ts` with 20 unrelated functions | One module per concern. Name it after what it does. |
| **Defensive overengineering** | Try-catch around every line, null checks on non-nullable types | Trust the type system. Catch at boundaries only. |
| **Hallucinated config** | `tauri.conf.json` keys that don't exist (e.g., `"vibrancy": "sidebar"`) | Check the Tauri 2.x docs. The spec already caught this one — see [[Visual Design]]. |
| **Wrong API signatures** | `chrome.tabs.query({ url: "github.com" })` | Match patterns ≠ arbitrary strings. See [[Extension]] for the corrected approach. |
| **Placeholder implementations** | `// TODO: implement this` in shipped code | If the phase doesn't require it, don't stub it. If it does, implement it. |
| **Redundant state** | Storing derived data alongside source data | Use `createMemo` for derived views. See [[Performance]]. |

### Quality Gates (Run After Every Phase)

```bash
# 1. TypeScript — zero errors
npx tsc --noEmit

# 2. Rust — formatting, warnings, and tests once Rust code exists
cargo fmt --check
cargo clippy -- -D warnings
cargo test

# 3. Fallow — dead code and structural health
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow health --format json --quiet 2>/dev/null || true

# 4. Fallow — code duplication
npx fallow dupes --format json --quiet 2>/dev/null || true
```

**Fallow** is the primary tool for catching dead code, unused exports, circular dependencies, code duplication, and complexity hotspots in the TypeScript/SolidJS side. It does not cover Rust, so Rust quality must be enforced with `cargo fmt`, `cargo clippy`, and `cargo test`. See the fallow section at the bottom of this document for detailed usage.

**Phase advancement rule**: A phase is complete when (a) all checklist items are done, (b) all "How to verify" steps pass or are documented as requiring human testing, (c) `tsc --noEmit` passes, (d) Rust gates pass once Rust code exists: `cargo fmt --check`, `cargo clippy -- -D warnings`, and relevant `cargo test`, (e) `fallow dead-code` reports zero issues in project-owned frontend code, and (f) `fallow dupes` reports no duplicated blocks > 5 lines.

### V1 Cutline

Build Hopline to a useful macOS v1 before chasing Arc parity.

V1 includes Phase 0 through Phase 4:

- Phase 0: proof of concept
- Phase 1: live sidebar + onboarding + `hopline-bridge`
- Phase 2: spaces + persistence
- Phase 3: saved items + folders
- Phase 4: command panel + local API foundation

Locked tabs, browser profiles, Windows parity, Air Traffic Control, sync, and advanced drag-and-drop are **post-v1 tracks**. Do not build them before the v1 phase report is approved.

---

## Phase 0 — Proof of Concept

> **Goal**: Validate the three hardest integration points before writing production code.  
> **Time**: 1–2 days  
> **Spec refs**: [[Architecture]], [[Extension]], [[Visual Design]]

### Before starting

Read [[Architecture]], [[Extension]], [[Visual Design]], and [[Risks and Review]] in full. Fetch the latest Tauri 2.x docs and Chrome Extension MV3 docs online. Do not rely on cached knowledge — the spec already caught multiple hallucinated APIs (see Risks and Review).

### Checklist

- [ ] Scaffold Tauri 2.x project with SolidJS + TypeScript via `sh <(curl https://create.tauri.app/sh)`
- [ ] Set `transparent: true` and `decorations: false` in `tauri.conf.json`
- [ ] Apply macOS vibrancy via Rust platform code using `objc2-app-kit` — **not** a config key. See [[Visual Design]] for the corrected approach and [[Risks and Review]] item #1.
- [ ] Confirm the glass window renders with `cargo tauri dev`
- [ ] Create minimal Chrome extension (MV3): `manifest.json` with `tabs` + `nativeMessaging` permissions, `background.js` that logs `chrome.tabs.onCreated` events
- [ ] Load extension unpacked in Chrome, confirm tab events log to console
- [ ] Register a tiny `hopline-bridge` Native Messaging helper, write the host manifest JSON file, and have it forward messages to the running Tauri app over local IPC
- [ ] Pin the sideloaded extension ID with a manifest `"key"` so Native Messaging `allowed_origins` remains stable
- [ ] Confirm end-to-end: Chrome tab opens → extension detects → sends via Native Messaging → `hopline-bridge` receives over stdio → forwards over local IPC → Rust logs the event

### What NOT to build

- No UI beyond a blank glass window
- No SQLite, no store, no components
- No multi-file Rust module structure — `lib.rs` is fine for the spike

### How to verify

1. **Glass window**: Run `cargo tauri dev`. A transparent window with OS-native blur should appear. If you see a white or black opaque window, vibrancy is not working.
2. **Extension tab events**: Open Chrome → Extensions → Load Unpacked → select the extension folder. Open a new tab. Open the service worker console (click "Inspect views: service worker" on the extension card). You should see `tab created` log entries.
3. **Native Messaging end-to-end**: With both the Tauri app and the extension running, open a new Chrome tab. Check the Tauri app's terminal output — it should log the received tab event. If the extension's service worker shows `Disconnected` errors, the host manifest path or `allowed_origins` is wrong.

### Cleanup before advancing

- If the spike works, restructure into the folder layout from [[Project Structure]]
- Delete any throwaway test code — it must not survive into Phase 1

### Done

**STOP.** Report what worked and what didn't using the phase completion report format. Wait for human approval before starting Phase 1.

---

## Phase 1 — Skeleton Sidebar

> **Goal**: A working sidebar that shows live Chrome tabs and lets you click to focus them.  
> **Time**: 1–2 weeks  
> **Spec refs**: [[Architecture]], [[Extension]], [[Performance]], [[Project Structure]]

### Before starting

Read [[Architecture]], [[Extension]], [[Performance]], [[Project Structure]], and [[Risks and Review]]. Fetch the latest SolidJS docs (especially `createStore`, `reconcile`, `<For>`) and Tailwind 4 installation docs. Verify the Phase 0 spike code has been cleaned up and restructured.

### Checklist

- [ ] Set up the full folder structure per [[Project Structure]]
- [ ] Enable `noUnusedLocals`, `noUnusedParameters`, `strict: true` in `tsconfig.json`
- [ ] Install Tailwind 4 via `@tailwindcss/vite` plugin — CSS-first config only, no JS config file. See [[Architecture]] for setup.
- [ ] Configure sidebar window: left edge, always-on-top, non-activating, glass background
- [ ] Implement Native Messaging helper + app IPC receiver in Rust (`src-tauri/src/messaging/`) with typed protocol messages via serde. See [[Extension]] for the message protocol.
- [ ] Extension streams `TAB_CREATED`, `TAB_UPDATED`, `TAB_REMOVED`, `TAB_ACTIVATED`, `TABS_SNAPSHOT` events via Native Messaging helper
- [ ] Implement first-run onboarding: copy extension, install host manifest, open `chrome://extensions/`, wait for `HELLO` + `TABS_SNAPSHOT`, and show connected state
- [ ] Use composite runtime tab identity from day one: `(browserId, profileId, tabId)`. Do not key stores by raw `tabId`.
- [ ] Extension implements service worker keep-alive via open Native Messaging port. See [[Extension]] "Service Worker Keep-Alive" section.
- [ ] Rust backend receives events, forwards to frontend via `tauri::event`
- [ ] SolidJS tab store using `createStore` + `reconcile` for snapshots, surgical `setTabs(idx, patch)` for deltas. See [[Performance]] for the exact pattern.
- [ ] `<For>` component for tab list rendering — never `.map()`. See [[Performance]].
- [ ] Basic sidebar UI: tab list with favicon + title, styled with Tailwind 4
- [ ] Click tab → extension receives `FOCUS_TAB` → `chrome.tabs.update` + `chrome.windows.update`
- [ ] "Switch to tab" logic using client-side URL normalisation. See [[Extension]] `switchToOrOpen` — do NOT use `chrome.tabs.query` URL patterns directly.
- [ ] Close tab from sidebar → extension receives `CLOSE_TAB` → `chrome.tabs.remove`
- [ ] Connection status indicator (extension connected / disconnected)
- [ ] Tauri capabilities file (`src-tauri/capabilities/default.json`) with required permissions. See [[Architecture]] "Tauri 2.x Capabilities" section — forgetting this causes silent failures.

### How to verify

1. **Tab list renders**: Run `cargo tauri dev`. Open Chrome with the extension loaded. Open 3–5 tabs. The sidebar should show all tabs with favicons and titles within 1 second.
2. **Live updates**: With the sidebar visible, open a new Chrome tab. It should appear in the sidebar immediately. Close a tab in Chrome — it should disappear from the sidebar.
3. **Click to focus**: Click a tab in the sidebar. Chrome should bring that tab to the foreground and focus its window. If Chrome doesn't respond, check that `FOCUS_TAB` messages are reaching the extension (check service worker console).
4. **Switch-to-tab**: Pin a URL mentally (e.g., `github.com`). Open it in Chrome. Now trigger `switchToOrOpen("https://github.com")` — it should focus the existing tab, not open a duplicate.
5. **Close from sidebar**: Right-click or use the close button on a tab in the sidebar. The tab should close in Chrome.
6. **Connection indicator**: Kill the extension (disable it in `chrome://extensions`). The sidebar should show a "disconnected" state. Re-enable — it should reconnect and show tabs again.
7. **Service worker keep-alive**: Leave the app idle for 2+ minutes. Then open a new tab in Chrome. The sidebar should update instantly (no 50–300ms cold-start delay). If there's a delay, the keep-alive port is not working.

### Code reuse targets

- `normalizeUrl()` in extension — single implementation, used by switch-to-tab and future space matching
- Typed message protocol (`protocol.rs` / `protocol.ts`) — shared types between Rust and TypeScript, single source of truth
- Tab store (`store/tabs.ts`) — the reconcile + delta pattern is reused in every subsequent phase

### Quality gate

```bash
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow health --hotspots --format json --quiet 2>/dev/null || true
```

Fallow should report zero unused exports in `frontend/src/`. Complexity hotspots should be reviewed — any function with cyclomatic complexity > 10 should be refactored before advancing.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline` to lock in the clean state. Report whether the baseline changed and why. Wait for human approval before starting Phase 2.

---

## Phase 2 — Spaces + Persistence

> **Goal**: Multiple spaces with URL-based tab association, auto-switching, and SQLite persistence.  
> **Time**: 2 weeks  
> **Spec refs**: [[Features]], [[Data Model]], [[Performance]], [[Visual Design]]

### Before starting

Read [[Features]], [[Data Model]], [[Performance]], [[Visual Design]], and [[Risks and Review]]. Verify Phase 1's tab store and Native Messaging pipeline work end-to-end. The tab store from Phase 1 is the foundation — understand it before extending.

### Checklist

- [ ] Add `tauri-plugin-sql` via `npm run tauri add sql`. Grant permissions in capabilities file.
- [ ] Create SQLite migration for `spaces` and `space_rules` tables. See [[Data Model]].
- [ ] Space CRUD in Rust: create, rename, delete, reorder — exposed via `tauri::command`
- [ ] Space rule CRUD: create, edit, reorder, enable/disable
- [ ] Settings table + UI for `auto_switch_mode`: `off`, `suggest`, `automatic`. Default to `suggest`.
- [ ] Space store in SolidJS (`store/spaces.ts`) — loaded from SQLite on startup
- [ ] Space switcher component (`SpaceBar.tsx`) — renders space names with color indicators
- [ ] Per-space color tint using Tailwind 4 `@theme` + CSS custom property. See [[Visual Design]]. Set `--space-color` on `:root` when switching spaces.
- [ ] `useSpaceMatch` hook: evaluates a URL against all space rules (top-down, first match wins). This hook is used for both auto-switching and tab categorisation.
- [ ] Auto-switch: `TAB_ACTIVATED` event → match URL → if different space, suggest or switch based on `auto_switch_mode`. See [[Features]] "How it feels to use" section.
- [ ] Sidebar layout: Matched Tabs section (tabs whose URL matches current space rules) + Other Tabs section (dimmed, collapsible). See [[Features]] sidebar layout diagram.
- [ ] Persist selected space across app restarts
- [ ] `batch()` wrapper when switching spaces to prevent intermediate renders. See [[Performance]].

### How to verify

1. **Space creation**: Create two spaces (e.g., "Work" and "Personal") via the UI. Assign different colors. Both should appear in the space switcher with their respective color tints.
2. **Space rules**: Add a rule to Work: `domain` match `github.com`. Add a rule to Personal: `domain` match `youtube.com`. Rules should persist after restarting the app.
3. **Auto-switch**: Be in the Work space. Click a YouTube tab in Chrome's tab bar. The sidebar should auto-switch to Personal space within ~20ms. The YouTube tab should be highlighted under "Matched Tabs."
4. **Matched vs Other**: While in Work space, tabs matching `github.com` should appear under "Matched Tabs." All other tabs (YouTube, Gmail, etc.) should appear under "Other Tabs" — dimmed but visible and clickable.
5. **Color tint**: Switch between spaces. The sidebar background tint should change to match each space's color. Check in both light and dark mode (toggle system appearance).
6. **Persistence**: Close and reopen the app. The last-selected space should be restored. All spaces and rules should survive the restart.
7. **Default space**: Tabs whose URLs don't match any rule should appear in the default space. Open a random URL like `example.com` — it should be categorised into the default/fallback space.

### Code reuse targets

- Space matching — used here for auto-switch, reused later if Air Traffic Control is approved
- Space rule evaluation logic — implement once in Rust, expose via command. The same evaluator is used for auto-switch (frontend-driven) and for route evaluation (backend-driven in later phases).

### Quality gate

```bash
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow dupes --format json --quiet 2>/dev/null || true
npx fallow health --circular --format json --quiet 2>/dev/null || true
```

Check specifically for circular dependencies between `store/tabs.ts`, `store/spaces.ts`, and `hooks/useSpaceMatch.ts`. Fallow's `--circular` flag catches these.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline`. Report whether the baseline changed and why. Wait for human approval before starting Phase 3.

---

## Phase 3 — Pinned Items + Folders

> **Goal**: The "bookmarks as tabs" model — pins, bookmarks, and folders persisted in SQLite.  
> **Time**: 2 weeks  
> **Spec refs**: [[Features]], [[Data Model]]

### Before starting

Read [[Features]] and [[Data Model]]. Review the existing `switchToOrOpen` implementation from Phase 1 — you will reuse it, not rewrite it. Check that spaces from Phase 2 are working.

### Checklist

- [ ] Create SQLite migration for `folders` and `pins` tables. See [[Data Model]].
- [ ] Pin a live tab → writes to `pins` table with `type: 'pin'`
- [ ] Add bookmark manually (URL + title input) → writes with `type: 'bookmark'`
- [ ] Bookmark store (`store/bookmarks.ts`) using `createStore`
- [ ] Render pins + bookmarks in sidebar above the live tabs section, per space
- [ ] Click pin/bookmark → reuse `switchToOrOpen` logic from Phase 1 (same URL normalisation, same code path)
- [ ] Folder component (`Folder.tsx`): collapsible, supports nesting via `parent_id`
- [ ] Manual reorder controls for pins/bookmarks within folders. Drag-and-drop is post-v1 polish unless this phase has extra time and remains simple.
- [ ] Folder collapse/expand state persisted to SQLite
- [ ] Favicon fetching and caching strategy — fetch once, store URL, let browser cache handle the rest

### How to verify

1. **Pin a tab**: Right-click a live tab in the sidebar → "Pin." The tab should move to the Pinned section above the live tab list. Close the original Chrome tab — the pin should remain in the sidebar.
2. **Pin opens or switches**: Click the pinned item. If the URL is already open in Chrome, it should focus that tab (switch-to-tab). If not, it should open a new tab. Do NOT open a duplicate.
3. **Add bookmark**: Use the "Add bookmark" UI to enter a URL and title manually. It should appear in the sidebar and persist after app restart.
4. **Folders**: Create a folder. Move pins/bookmarks into it. Collapse the folder — items should hide. Expand — they reappear. Restart the app — collapse state should be preserved.
5. **Nested folders**: Create a folder inside a folder. Move items into the nested folder. Collapse the parent — everything inside (including the nested folder) should hide.
6. **Manual reorder**: Move a pin above another pin with the v1 reorder controls. The new order should persist after restart.
7. **Per-space pins**: Switch to a different space. The pins/bookmarks should be different (each space has its own). Pins from Work should not appear in Personal.

### Code reuse targets

- `switchToOrOpen` — already built in Phase 1, reused here for pin/bookmark clicks. Must not be reimplemented.
- `<For>` rendering pattern — same pattern from Phase 1 tab list, applied to pins/bookmarks list

### What NOT to build

- No locked tabs yet (post-v1 track)
- No drag between spaces (stretch goal)

### Quality gate

```bash
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow dupes --format json --quiet 2>/dev/null || true
```

Pay attention to fallow's duplication report — the pin list and tab list will look similar. If `TabItem.tsx` and a hypothetical `PinItem.tsx` share > 60% of their JSX, extract a shared `SidebarItem.tsx` component.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline`. Report whether the baseline changed and why. Wait for human approval before starting Phase 4.

---

## Post-V1 Track — Locked Tabs

> **Goal**: Arc-style locked tabs that reset when navigated away or closed.  
> **Time**: 1 week  
> **Spec refs**: [[Features]] "Locked Tab Behaviour", [[Extension]] "Locked Tab Implementation", [[Risks and Review]] item #5

Do not execute this track until the macOS v1 cutline has shipped or the human explicitly approves locked tabs as the next post-v1 feature.

### Before starting

Read [[Features]] "Locked Tab Behaviour", [[Extension]] "Locked Tab Implementation", and [[Risks and Review]] item #5. Understand that the locked tab flicker is a known, accepted MV3 limitation — do not try to work around it.

### Checklist

- [ ] Add `webNavigation` as optional permission in extension `manifest.json`. See [[Extension]].
- [ ] Sidebar UI: when user first tries to lock a tab, prompt to grant `webNavigation` permission via `chrome.permissions.request()`
- [ ] Extension: `chrome.webNavigation.onCommitted` listener for locked tab IDs. See [[Extension]] for implementation.
- [ ] On navigation away from locked URL → `chrome.tabs.update(tabId, {url: originalUrl})`
- [ ] On locked tab close → `chrome.tabs.create({url: originalUrl})` and update the `ext_tab_id` in the lock registry
- [ ] Lock/unlock toggle on pin items in sidebar
- [ ] Lock registry: `locked_tabs` table in SQLite. On extension reconnect, re-send all active locks.
- [ ] Pin type `'locked'` in `pins` table — a locked tab is a pin with enforcement

### Known limitation — document prominently

The locked tab redirect fires AFTER `onCommitted` — the user will see a brief flash of the new page before it snaps back. This is a fundamental MV3 limitation and is NOT a bug. See [[Risks and Review]] item #5. Do not try to "fix" this with hacks — accept it and ensure the snap-back is as fast as possible.

### How to verify

1. **Permission prompt**: Lock a tab for the first time. The extension should prompt for `webNavigation` permission. Grant it. The lock should activate.
2. **Navigation reset**: Lock a tab on `https://github.com`. Click a link on that page that navigates to a different URL. The tab should snap back to `https://github.com`. There will be a brief flash of the new page — this is expected (see Known limitation above).
3. **Close recovery**: Close a locked tab in Chrome. It should immediately reopen at the locked URL.
4. **Unlock**: Unlock the tab via the sidebar. Navigate away — it should stay on the new page. Close it — it should stay closed.
5. **Persist across restart**: Lock a tab. Restart the app (not Chrome). The tab should still be locked — navigating away should still reset it. This verifies the lock registry is re-sent to the extension on reconnect.
6. **Permission denied**: Revoke the `webNavigation` permission (Chrome → Extensions → Details → remove the permission). The lock UI should hide or disable gracefully. No errors in the console.

### Code reuse targets

- Lock state management reuses the existing `pins` store — a locked tab is a pin with `type: 'locked'` + an entry in `locked_tabs`
- The `LOCK_TAB` / `UNLOCK_TAB` messages use the same Native Messaging protocol from Phase 1

### Quality gate

```bash
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
```

If `webNavigation` permission is not granted, all lock-related code paths must gracefully degrade. Fallow won't catch runtime-only dead paths — manually verify that lock UI is hidden when the permission is absent.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline`. Report whether the baseline changed and why. Wait for human approval before starting another post-v1 track.

---

## Phase 4 — Command Panel

> **Goal**: Global hotkey opens a floating command + search overlay. Localhost HTTP API for external integrations.  
> **Time**: 2 weeks  
> **Spec refs**: [[Command Panel]], [[Performance]] "Fuzzy Search"

### Before starting

Read [[Command Panel]] and [[Performance]] "Fuzzy Search" section. Fetch the latest `tauri-plugin-global-shortcut` docs. Review the existing `switchToOrOpen` and space-switching code — the panel must call the same functions, not reimplement them.

### Checklist

- [ ] Add `tauri-plugin-global-shortcut` via `npm run tauri add global-shortcut`. Grant capabilities.
- [ ] Register global shortcut `CommandOrControl+Shift+Space`. See [[Command Panel]] for verified API.
- [ ] Panel window config in `tauri.conf.json`: separate entry point (`panel.html`), hidden on startup, centered, transparent, always-on-top, skip-taskbar. See [[Command Panel]].
- [ ] `toggle_panel` Rust command: show/hide + focus the panel window
- [ ] Panel UI (`Panel.tsx`): single input field, fuzzy results list, keyboard navigation (up/down/enter/escape)
- [ ] Fuzzy search using uFuzzy — search across live tabs, pins, bookmarks, and space names. See [[Performance]] for the `createMemo` + uFuzzy pattern.
- [ ] Commands: switch space, switch to tab, open URL, close tab
- [ ] Escape or blur dismisses the panel
- [ ] Localhost HTTP API bound to `127.0.0.1` via Rust (hyper or axum, lightweight). Default to port `42420`, handle collisions, and require bearer token auth. See [[Command Panel]] for endpoint spec.
- [ ] API endpoints: `GET /tabs`, `POST /open`, `POST /space`, `POST /search`

### How to verify

1. **Global hotkey**: Press `Cmd+Shift+Space` (macOS) or `Ctrl+Shift+Space` (Windows) from any app — not just the sidebar. The command panel should appear centered on screen. If nothing happens, check Tauri capabilities and the global shortcut registration.
2. **Fuzzy search**: Type "git" in the panel. If you have a GitHub tab open, it should appear in the results. Type a partial bookmark title — it should match.
3. **Switch to tab**: Select a tab result and press Enter. Chrome should focus that tab. The panel should dismiss.
4. **Space switching**: Type a space name (e.g., "Work"). Select the space result. The sidebar should switch to that space.
5. **Open URL**: Type a full URL (e.g., `https://example.com`). The panel should offer to open it. If it's already open, it should switch to it.
6. **Keyboard navigation**: Use arrow keys to move through results. Enter to select. Escape to dismiss. Tab should not cycle focus outside the panel.
7. **Dismiss on blur**: Click outside the panel. It should close.
8. **HTTP API**: With the app running, from a terminal:
   ```bash
   curl -H "Authorization: Bearer $HOPLINE_TOKEN" http://127.0.0.1:42420/tabs
   # Should return JSON array of all open tabs
   
   curl -H "Authorization: Bearer $HOPLINE_TOKEN" -X POST "http://127.0.0.1:42420/search?q=github"
   # Should return matching tabs/pins/bookmarks
   
   curl -H "Authorization: Bearer $HOPLINE_TOKEN" -X POST "http://127.0.0.1:42420/open?url=https://github.com"
   # Should switch to or open that URL in Chrome
   
   curl -H "Authorization: Bearer $HOPLINE_TOKEN" -X POST "http://127.0.0.1:42420/space?name=Work"
   # Should switch the sidebar to the Work space
   ```

### Code reuse targets

- `switchToOrOpen` — called from both sidebar clicks (Phase 1) and panel "open" command. Same code path.
- Space switching — same `batch()` + store update from Phase 2. Panel calls the same Rust command.
- uFuzzy search — the `createMemo` pattern from [[Performance]] is implemented once in `hooks/useSearch.ts` and used by both the panel and (in future) the sidebar search.

### What NOT to build

- No Raycast/Alfred/PowerToys extensions yet (post-v1 stretch)
- No `lock` command in the panel unless the post-v1 Locked Tabs track has already been completed

### Quality gate

```bash
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow dupes --format json --quiet 2>/dev/null || true
npx fallow health --hotspots --format json --quiet 2>/dev/null || true
```

The HTTP API and the panel UI should share zero duplicated logic — both should call the same Rust commands. Fallow dupes will catch if the API handler reimplements tab listing instead of calling the existing store query.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline`. Report whether the baseline changed and why. This completes the macOS v1 build path. Report v1 readiness and wait for human approval before starting any post-v1 track.

---

## Post-V1 Track — Browser Profiles

> **Goal**: Multiple Chrome profiles visible as distinct contexts in the sidebar.  
> **Time**: 1–2 weeks  
> **Spec refs**: [[Browser Profiles]], [[Risks and Review]] item #4

Do not execute this track until the macOS v1 cutline has shipped or the human explicitly approves browser profiles as the next post-v1 feature.

### Before starting

Read [[Browser Profiles]] and [[Risks and Review]] item #4. The relay/helper pattern should already exist from Phase 0/1. This phase extends it for multiple simultaneous profile connections instead of introducing a new architecture.

### Checklist

- [ ] Extend `hopline-bridge` to handle multiple concurrent Native Messaging helper processes and tag each connection by profile identity. See [[Risks and Review]] item #4 for why this is needed.
- [ ] Confirm Native Messaging host manifest points to `hopline-bridge`
- [ ] Main app accepts multiple simultaneous connections from relay instances
- [ ] Each connection is tagged with profile identity
- [ ] Read Chrome `Local State` JSON to enumerate profile names + avatars. See [[Browser Profiles]] for the Rust implementation sketch.
- [ ] Extend tab grouping by `(browserId, profileId)` while preserving the composite tab key from Phase 1
- [ ] Profile indicator on tab items in sidebar (small avatar or color dot)
- [ ] Option to scope a Space to a specific profile
- [ ] Extension onboarding: guide user through loading extension in each profile

### How to verify

1. **Two profiles connected**: Load the extension in two Chrome profiles (e.g., Personal and Work). Both should connect to the app via separate relay instances. The sidebar should show tabs from both profiles.
2. **Profile indicator**: Each tab in the sidebar should show which profile it belongs to (avatar, dot, or label). Tabs from Profile 1 should be visually distinguishable from Profile 2.
3. **Cross-profile tab list**: Open `github.com` in Profile 1 and `youtube.com` in Profile 2. Both tabs should appear in the sidebar, tagged with their respective profiles.
4. **Focus routes correctly**: Click a tab from Profile 1 in the sidebar. Chrome should focus the correct profile's window and tab — not the other profile's window.
5. **Profile-scoped space**: Scope a space (e.g., "Work") to Profile 1. Only tabs from Profile 1 should appear in the "Matched Tabs" section of that space. Profile 2 tabs should appear in "Other."
6. **Relay reconnect**: Kill one Chrome profile. The other profile's tabs should remain. Reopen the killed profile — its tabs should reappear as the relay reconnects.
7. **Profile names**: The sidebar should show human-readable profile names (e.g., "Christian" or "Work"), not internal names like "Profile 1." These come from Chrome's `Local State` file.

### Code reuse targets

- Tab store update logic — the reconcile + delta pattern from Phase 1 is extended with a profile key, not reimplemented
- `switchToOrOpen` — now routes through the correct profile's relay connection. The extension-side code is unchanged.

### Quality gate

```bash
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow health --circular --format json --quiet 2>/dev/null || true
```

Profile support adds complexity. Run fallow health with `--hotspots` and refactor any function that crossed complexity threshold during this phase.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline`. Report whether the baseline changed and why. Wait for human approval before starting another post-v1 track.

---

## Post-V1 Track — Windows Port + Polish

> **Goal**: Build and test on Windows. Cross-platform parity.  
> **Time**: 2–3 weeks  
> **Spec refs**: [[Visual Design]], [[Architecture]], [[Project Structure]], [[Risks and Review]] items #6, #7

Do not execute this track until the macOS v1 cutline has shipped or the human explicitly approves Windows parity as the next post-v1 feature.

### Before starting

Read [[Visual Design]], [[Architecture]], [[Project Structure]], and [[Risks and Review]] items #6 and #7. This phase requires a Windows machine. If running on macOS, focus on the code changes (platform abstraction, conditional compilation) and flag the Windows testing as a blocker for the human.

### Checklist

- [ ] Windows Mica/Acrylic effect via `tauri-plugin-window-effects` (or platform-conditional Rust). See [[Visual Design]].
- [ ] Windows: non-activating window via `WS_EX_NOACTIVATE` — requires `raw_window_handle`. See [[Risks and Review]] item #6.
- [ ] Test extension + Native Messaging on Windows (registry-based host manifest, different path from macOS)
- [ ] Test `hopline-bridge` on Windows (named pipes instead of Unix sockets)
- [ ] Test window overlay behaviour on Windows (taskbar, multiple monitors, DPI scaling)
- [ ] Keyboard shortcuts: `Cmd` → `Ctrl` via `CommandOrControl` (already handled by Tauri, but verify)
- [ ] Build installers: `.dmg` (macOS) via `cargo tauri build`, `.msi` (Windows) via same
- [ ] Onboarding flow: auto-copy extension to known location, open Chrome extensions page
- [ ] Run full test pass on Windows — all v1 features plus any completed post-v1 tracks

### How to verify

These tests must pass on **both macOS and Windows**. If the agent only has access to macOS, document the Windows items as requiring human verification.

1. **Window effect**: On Windows 11, the sidebar should have Mica or Acrylic blur. On Windows 10, it should fall back to a solid background (no crash, no blank window).
2. **Non-activating window**: Click the sidebar on Windows. The browser behind it should NOT lose focus. If Chrome deactivates when you click the sidebar, `WS_EX_NOACTIVATE` is not working.
3. **Native Messaging on Windows**: The extension should connect via the registry-based host manifest (`HKCU\Software\Google\Chrome\NativeMessagingHosts\...`). Open a tab — it should appear in the sidebar.
4. **Bridge on Windows**: Verify `hopline-bridge` uses named pipes (not Unix sockets). If multi-profile is implemented, two profiles should connect simultaneously.
5. **DPI scaling**: On a Windows machine with 125% or 150% DPI scaling, the sidebar should render correctly — no blurry text, no misaligned elements.
6. **Installer**: Build with `cargo tauri build` on Windows. Install the `.msi`. Launch the installed app — it should work identically to the dev build.
7. **Full regression**: Run through the v1 verification steps on Windows, plus any completed post-v1 tracks. Every supported feature should work identically to macOS (except platform-specific visual effects).

### Code reuse — platform abstraction

All platform-specific code must live in `src-tauri/src/platform/macos.rs` and `src-tauri/src/platform/windows.rs` behind `#[cfg(target_os = "...")]`. The rest of the codebase must be platform-agnostic. If you find an `#[cfg]` outside the `platform/` module, refactor it.

### Quality gate

```bash
# Run on BOTH platforms
npx tsc --noEmit
npx fallow dead-code --format json --quiet 2>/dev/null || true
npx fallow dupes --format json --quiet 2>/dev/null || true
```

Check for platform-conditional dead code — e.g., Windows-only functions that are never called on macOS builds and vice versa. Fallow only covers the TypeScript side; use `cargo clippy --all-targets -- -D warnings` plus focused review for Rust platform branches.

### Done

**STOP.** If `fallow dead-code` is clean, run `fallow dead-code --save-baseline`. Report whether the baseline changed and why. Wait for human approval before starting another post-v1 track.

---

## Post-V1 Stretch Goals

> **Goal**: Nice-to-haves. Only start these after macOS v1 is stable and the human explicitly chooses one.  
> **Spec refs**: [[Air Traffic Control]], [[Command Panel]], [[Plan]]

**These are individual features, not a single phase.** The human picks one, the agent builds it, runs the quality gate, reports, and waits for the next pick. Do not build multiple stretch goals in one session.

Pick from this list based on what the human requests:

- [ ] Air Traffic Control: URL routing rules for save/open actions. Reuses `useSpaceMatch` hook from Phase 2 + the `routes` table from [[Data Model]].
- [ ] Raycast extension calling the configured local API (built in Phase 4)
- [ ] PowerToys Run plugin calling the same API
- [ ] CLI tool: `hopline switch linear` → calls HTTP API
- [ ] Firefox support via WebExtensions (mostly compatible, see [[Architecture]] browser support table)
- [ ] Tab history / recently closed
- [ ] Multi-monitor: sidebar follows active screen
- [ ] Import Arc sidebar data (`StorableSidebar.json`)

---

## Fallow Usage Guide

Fallow is the codebase intelligence tool used throughout this project. Here's how to use it at each quality gate.

### Installation

```bash
npm install -g fallow
# or use npx for one-off runs:
npx fallow dead-code
```

### Key commands for this project

```bash
# Find unused files, exports, types, and dependencies
npx fallow dead-code --format json --quiet 2>/dev/null || true

# Codebase health: complexity hotspots, circular deps, ownership
npx fallow health --hotspots --circular --format json --quiet 2>/dev/null || true

# Code duplication detection
npx fallow dupes --format json --quiet 2>/dev/null || true

# After a phase is clean — save a baseline for regression detection
npx fallow dead-code --save-baseline --quiet 2>/dev/null || true

# In CI — check for regressions against the saved baseline
npx fallow dead-code --save-regression-baseline --quiet 2>/dev/null || true
```

### When to run fallow

| Moment | Command | Why |
|---|---|---|
| End of every phase | `dead-code` + `dupes` + `health` | Full quality gate |
| After removing a feature | `dead-code` | Catch orphaned code the removal left behind |
| After refactoring | `dupes` + `health --circular` | Catch introduced duplication or circular deps |
| Before advancing to next phase | `dead-code --save-baseline` | Only after a clean run; report whether the baseline changed and why |
| During code review | `health --hotspots` | Flag complexity that crept in during development |

### Interpreting results

- **Dead code**: Zero tolerance. If fallow says a TypeScript export is unused, either use it or delete it. Rust dead code is handled by compiler warnings, `cargo clippy`, and review of platform-specific branches.
- **Duplication**: Blocks > 5 lines duplicated across files must be extracted into shared modules. The tab list and pin list rendering are the most likely duplication source — watch for it.
- **Circular dependencies**: Zero tolerance between stores, hooks, and components. The dependency flow must be: `stores → hooks → components` (one direction only).
- **Complexity hotspots**: Any function with cyclomatic complexity > 15 should be split. The space rule evaluator and the Native Messaging message handler are the most likely hotspots.

---

## Reference Map

Quick lookup for which spec doc covers what. AI agents should read the relevant spec docs before starting each phase.

| Spec Document | Covers | Critical for Phase |
|---|---|---|
| [[Architecture]] | Stack, architecture diagram, Tauri capabilities | 0, 1 |
| [[Extension]] | Extension APIs, Native Messaging protocol, switch-to-tab, locked tabs, keep-alive | 0, 1, post-v1 locks |
| [[Features]] | Core concept, spaces, sidebar items, locked tab behaviour | 2, 3, post-v1 locks |
| [[Data Model]] | Full SQLite schema | 2, 3, post-v1 tracks |
| [[Visual Design]] | Glass effects, colors, typography, animations, platform matrix | 0, post-v1 Windows |
| [[Performance]] | SolidJS primitives, IPC discipline, CSS rendering, latency budget | 1, 2, 4 |
| [[Command Panel]] | Global hotkey, panel UI, HTTP API, launcher integration | 4 |
| [[Browser Profiles]] | Multi-profile architecture, bridge helper, profile identity | post-v1 profiles |
| [[Air Traffic Control]] | URL routing rules, open-in-browser mechanism | post-v1 stretch |
| [[Project Structure]] | Folder layout, scaffold commands, build strategy | 0, 1, post-v1 Windows |
| [[Risks and Review]] | Known risks, hallucination audit, verification status | ALL |
| [[Naming]] | Product name exploration | — |
