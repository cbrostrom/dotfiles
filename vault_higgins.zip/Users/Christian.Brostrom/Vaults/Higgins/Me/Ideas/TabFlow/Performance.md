# Performance

> Back to [[README]] | See also: [[Architecture]], [[Extension]]

Performance is a first-class constraint throughout — a sidebar that's always visible cannot afford jank. Every layer has its own performance profile.

---

## SolidJS: The Right Primitives

### `createStore` + `reconcile` for the tab list

`createStore` (from `solid-js/store`) maintains fine-grained reactivity at the *property* level — when one tab's title changes, only that tab's title DOM node updates. A `createSignal` holding an array would re-render the entire list on any change.

`reconcile` is essential when receiving a full tab snapshot from Native Messaging: it diffs the incoming data against the existing store, only triggering updates for properties that actually changed.

```typescript
import { createStore, reconcile } from 'solid-js/store';
import { listen } from '@tauri-apps/api/event';

export interface Tab {
  browserId: string;
  profileId: string;
  id: number;
  url: string;
  title: string;
  favIconUrl: string;
  windowId: number;
}

function tabKey(tab: Pick<Tab, 'browserId' | 'profileId' | 'id'>) {
  return `${tab.browserId}:${tab.profileId}:${tab.id}`;
}

const [tabs, setTabs] = createStore<Tab[]>([]);

// On full snapshot from extension (connect / reconnect)
listen<Tab[]>('tabs-snapshot', (event) => {
  setTabs(reconcile(event.payload));
});

// On incremental events (preferred — no reconcile needed)
listen<Tab>('tab-updated', (event) => {
  const key = tabKey(event.payload);
  const idx = tabs.findIndex(t => tabKey(t) === key);
  if (idx >= 0) setTabs(idx, event.payload);  // surgical update
});

listen<Pick<Tab, 'browserId' | 'profileId' | 'id'>>('tab-removed', (event) => {
  const key = tabKey(event.payload);
  setTabs(tabs => tabs.filter(t => tabKey(t) !== key));
});
```

### `<For>` for the tab list — never `.map()`

SolidJS's `<For>` component is keyed by identity and never re-creates DOM nodes for items that haven't changed.

```tsx
import { For } from 'solid-js';
import { tabs } from '../store/tabs';

export function TabList() {
  return (
    <For each={tabs} fallback={<div>No tabs</div>}>
      {(tab) => <TabItem tab={tab} />}
    </For>
  );
}
```

### `createMemo` for derived data

Fuzzy search results and per-space filtered views should be memos — they recompute only when their dependencies change.

```typescript
const filteredTabs = createMemo(() =>
  tabs.filter(t => t.profileId === currentSpace().profileId)
);
const searchResults = createMemo(() =>
  query() ? fuzzySearch(filteredTabs(), query()) : filteredTabs()
);
```

### `batch` for multi-property updates

When switching spaces (color + filtered list both change), wrap in `batch` to prevent intermediate renders:

```typescript
import { batch } from 'solid-js';

function switchSpace(space: Space) {
  batch(() => {
    setCurrentSpace(space);
    document.documentElement.style.setProperty('--space-color', space.color);
  });
}
```

---

## Tauri IPC: Keep Payloads Small

Every `invoke` and `event` crosses the Rust↔WebView boundary as **serialised JSON**. Design the protocol to minimise data:

| Instead of | Do this |
|---|---|
| Send full tab object on title change | Send `{ id, title }` patch only |
| Send full tab list on every event | Send snapshot once on connect, then deltas |
| Store favicon URLs as base64 in events | Send URL only; let the frontend fetch/cache |
| Large SQLite query results on every render | Query once at startup, update incrementally |

---

## CSS: Compositor-Friendly Rendering

Use only compositor-layer properties to avoid triggering layout or paint:

```css
/* Good — compositor only, no repaint */
.tab-item {
  transition: opacity 120ms ease, transform 120ms ease;
}
.tab-item:hover {
  transform: translateX(2px);
  opacity: 0.9;
}

/* Bad — triggers repaint on every frame */
.tab-item:hover {
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  left: 2px;
}
```

---

## Virtual Scrolling (Future)

For 100+ tabs, use `@tanstack/solid-virtual` for virtualised list rendering. Not needed in v1, but design `<TabList>` as a swappable abstraction.

---

## Fuzzy Search: uFuzzy over fuse.js

[uFuzzy](https://github.com/leeoniya/uFuzzy) is ~10–20x faster than fuse.js with zero dependencies:

```typescript
import uFuzzy from '@leeoniya/ufuzzy';

const uf = new uFuzzy();

const searchResults = createMemo(() => {
  if (!query()) return filteredTabs();
  const haystack = filteredTabs().map(t => `${t.title} ${t.url}`);
  const [, info, order] = uf.search(haystack, query());
  if (!order) return [];
  return order.map(i => filteredTabs()[i]);
});
```

---

## Latency Budget: Click to Response

```
Click in sidebar           ~0ms   SolidJS event handler
tauri invoke()             ~1ms   JSON serialise + IPC
Rust → Native Messaging    ~3ms   stdio pipe to extension
Service worker receives    ~3ms   Chrome dispatches to worker
chrome.tabs.update()      ~10ms   Browser switches tab (in-process)
chrome.windows.update()    ~5ms   Window focus
─────────────────────────────────
Total                    ~20ms   Imperceptible (<50ms threshold)
```

For comparison, SupaSidebar's Accessibility API path is typically **50–200ms**.

**Critical risk: MV3 service worker dormancy** — Chrome kills idle service workers after ~30s. Cold-start cost: 50–300ms. Mitigated by keeping the Native Messaging port open permanently. See [[Extension]] for the keep-alive pattern.

---

## Memory Footprint Targets

| Component | Target | Notes |
|---|---|---|
| Native app | < 50 MB RAM | Rust + WebView baseline |
| Extension (per profile) | < 5 MB RAM | Service worker, dormant most of the time |
| SQLite file | < 5 MB disk | Thousands of bookmarks/spaces |
| JS heap (SolidJS) | < 20 MB | Fine-grained stores, no vdom overhead |
