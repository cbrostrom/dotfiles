# Command Panel (Global Hotkey)

> Back to [[README]] | See also: [[Architecture]], [[Performance]]

A second, distinct UI surface from the sidebar. Think Raycast — it appears anywhere on screen via a global keyboard shortcut, lets you act fast, then disappears.

---

## What it is

- **Not a launcher.** The sidebar already exists. The panel is for *acting on* what's already there.
- Triggered by configurable hotkey (e.g., `Cmd+Shift+Space` / `Ctrl+Shift+Space`)
- Appears as a floating overlay, centered on screen, on top of everything
- Dismissed by Escape or losing focus
- Separate Tauri window: `always_on_top: true`, `decorations: false`, `skip_taskbar: true`

## What you can do from it

```
> switch to Linear                → fuzzy matches open tabs, switches to it
> open github.com                 → switch-to-tab or open new
> Work space                      → switch active space
> lock this tab                   → lock the currently focused browser tab
> new folder Research             → create a folder in current space
> close duplicates                → close duplicate tabs across all windows
```

The input is a fuzzy command + search combined — you never know if you're "searching" or "commanding," you just type what you want.

---

## Implementation

**Global shortcut (Tauri) — verified API**

```bash
npm run tauri add global-shortcut
```

```typescript
import { register } from '@tauri-apps/plugin-global-shortcut';

await register('CommandOrControl+Shift+Space', () => {
  invoke('toggle_panel');
});
```

`CommandOrControl` resolves to `Cmd` on macOS and `Ctrl` on Windows automatically.

Capabilities required:
```json
{
  "permissions": [
    "global-shortcut:allow-register",
    "global-shortcut:allow-unregister"
  ]
}
```

**Panel window config (`tauri.conf.json`)**

```json
{
  "label": "panel",
  "url": "panel.html",
  "width": 640,
  "height": 400,
  "decorations": false,
  "transparent": true,
  "alwaysOnTop": true,
  "skipTaskbar": true,
  "focus": true,
  "visible": false
}
```

The panel window is created on startup but hidden. The global shortcut toggles visibility.

---

## Launcher Integration Hooks

Rather than building deep integrations with each launcher, expose a **local HTTP API** bound to `127.0.0.1`. Default to `42420`, but handle port collisions by choosing the next available port and storing it in settings.

The API should require a local auth token from the first implementation. Store it in Hopline settings and require it via `Authorization: Bearer <token>`. This is cheap to add early and avoids leaving a local control surface open to any process on the machine.

```
GET  /tabs                        → list all tabs (JSON)
POST /open?url=https://...        → switch-to-tab or open
POST /space?name=Work             → switch active space
POST /search?q=linear             → fuzzy search, return matches
```

| Tool | Integration path |
|---|---|
| **Raycast** | Raycast Extension (TypeScript) calling the configured localhost API |
| **Alfred** | Alfred Workflow (shell/Python) calling the API |
| **Windows PowerToys Run** | PowerToys plugin (C#) calling the API |
| **Tuna / any other** | Any HTTP client, shell script, or automation tool |
| **CLI** | `hopline switch linear` → calls the API |

You build and own the API. Others integrate to it.

**Raycast extension sketch:**

```typescript
import { List, Action } from "@raycast/api";
import fetch from "node-fetch";

const API_BASE = "http://127.0.0.1:42420";
const TOKEN = "read-from-hopline-settings";

export default function Command() {
  const tabs = useFetch(`${API_BASE}/tabs`, {
    headers: { Authorization: `Bearer ${TOKEN}` },
  });
  return (
    <List>
      {tabs.map(tab => (
        <List.Item
          title={tab.title}
          actions={
            <Action title="Switch" onAction={() =>
              fetch(`${API_BASE}/open?url=${tab.url}`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${TOKEN}` },
              })
            }/>
          }
        />
      ))}
    </List>
  );
}
```

> **Security note**: See [[Risks and Review]] items #11, #17, and #18. Bind only to `127.0.0.1`, require a token, and make port collisions explicit.
