# Browser Profiles

> Back to [[README]] | See also: [[Extension]], [[Architecture]]

Each Chrome profile runs as a completely separate browser process, with its own tabs, history, and extension installs. Supporting profiles is important because many people use Profile 1 for personal and Profile 2 for work.

---

## The Challenge

The extension installed in Profile A has zero visibility into Profile B's tabs. There is no cross-profile browser API. Each profile = a separate Native Messaging connection.

---

## Architecture: Multiple Simultaneous Connections

```
Profile: Personal  ──── Native Messaging ────┐
Profile: Work      ──── Native Messaging ────┤──► Rust backend
Profile: Freelance ──── Native Messaging ────┘       (fan-in)
```

The app accepts multiple concurrent Native Messaging connections. Each connection is tagged with `(browserId, profileId)`. The tab list becomes grouped by browser/profile rather than a raw flat `Tab[]` keyed only by `tabId`.

> **Important**: Chrome's Native Messaging spawns a new process per connection. Hopline should already have the `hopline-bridge` helper from Phase 0/1; multi-profile support extends that helper so each profile connection can be tagged and routed. See [[Risks and Review]] item #4.

---

## Profile Identity

Chrome stores profile names, avatars, and metadata in:

```
macOS:   ~/Library/Application Support/Google/Chrome/Local State
Windows: %LOCALAPPDATA%\Google\Chrome\User Data\Local State
```

The app reads this file at startup to get profile names and avatars. It should not infer incoming connection identity from this file alone. Each extension install sends a persistent `profileId` during the `HELLO` handshake; onboarding maps that `profileId` to a browser/profile display name.

```rust
let local_state = read_chrome_local_state()?;
let profiles = local_state["profile"]["info_cache"]
    .as_object()
    .map(|profiles| profiles.iter().map(|(dir, info)| Profile {
        directory: dir.clone(),
        name: info["name"].as_str().unwrap_or("Profile").to_string(),
        avatar: info["last_downloaded_gaia_picture_url_with_size"].as_str()
            .map(String::from),
    }).collect())
    .unwrap_or_default();
```

---

## UI Treatment

- Profile indicator shown on each live tab (small avatar or color dot)
- Option to scope a Space to a specific profile ("this Work space only shows tabs from my Work profile")
- Or show all profiles together and let folders/spaces provide the separation
- Extension must be loaded once per profile (onboarding guides through this)

---

## Profile-Aware "Switch to Tab"

The backend routes `FOCUS_TAB` commands to the correct `(browserId, profileId)` Native Messaging connection. The extension in each profile already knows its own context.
