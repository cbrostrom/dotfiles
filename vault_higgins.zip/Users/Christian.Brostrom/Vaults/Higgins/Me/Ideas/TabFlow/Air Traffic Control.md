# Air Traffic Control (URL Routing)

> Back to [[README]] | See also: [[Features]], [[Browser Profiles]], [[Data Model]]

Directly inspired by SupaSidebar's feature. A rule-based URL routing system that answers two questions automatically:

- **Where should this link be saved?** → file it into the right Space
- **Which browser/profile should open this link?** → route it to the right browser

---

## How It Works

Routes are evaluated top-to-bottom. First match wins. Two types:

**Save routes** — triggered when you save a page

- `IF url contains "github.com" → save to Work space`
- `IF url contains "youtube.com" → save to Personal space`

**Open routes** — triggered when you click a link in the sidebar

- `IF url contains "google.com" → open in Work profile`
- `IF space = Personal → open in Personal profile`

---

## Profile-Linked Routes

When you link a Space to a browser profile, the app automatically creates a route:

- `All URLs from [Space] → open in [linked Profile]`

Work space links always open in your Work Chrome profile, Personal links in your Personal profile — without thinking about it.

---

## "Open in Different Browser" Mechanism

The extension cannot open a URL in a different browser — it's sandboxed. This is handled by the **native app** via OS shell:

```rust
// macOS
std::process::Command::new("open")
    .args(["-a", "Firefox", url])
    .spawn()?;

// Windows
std::process::Command::new("cmd")
    .args(["/c", "start", "firefox", url])
    .spawn()?;
```

For specific Chrome profiles:
```rust
Command::new("open")
    .args(["-a", "Google Chrome", "--args",
           "--profile-directory=Profile 2",
           url])
    .spawn()?;
```

> **Known issue**: Windows `start` requires Firefox on PATH. Chrome profile `--profile-directory` uses internal names ("Profile 1") not human names. See [[Risks and Review]] item #9.

---

## Route Data Model

See [[Data Model]] for the full `routes` table schema.

---

## UI (Settings → Air Traffic Control)

- List of routes with drag-to-reorder
- Per-route toggle (enable/disable without deleting)
- Match condition builder: type selector (contains / starts with / regex) + value input
- Target selector: space picker + browser/profile picker
- "Add with AI" — stretch goal: describe the rule in plain English, AI generates it
