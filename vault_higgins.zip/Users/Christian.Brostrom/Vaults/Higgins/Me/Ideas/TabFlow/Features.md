# Features

> Back to [[README]]

---

## Core Concept

A native desktop app that acts as a **replacement tab bar** sitting as a persistent sidebar on the left edge of your screen. It overlays on top of browser windows — it doesn't replace the browser, but it becomes the primary way you navigate and organise your tabs. You keep using Chrome, Brave, Edge, Arc — the sidebar gives you a smarter tab bar with persistence, organisation, and cross-browser intelligence.

The sidebar doesn't fight the browser's built-in tab bar. It **reacts** to it — when you click a tab in Chrome, the sidebar follows. When you click a tab in the sidebar, Chrome follows. The two stay in sync.

---

## Spaces

Spaces group your curated items (pins, bookmarks, folders) and intelligently associate live browser tabs based on URL matching rules. They are NOT browser-level tab isolation — the browser's own tab bar remains unchanged. Spaces are the app's organisational layer on top of the browser.

- Named spaces: Work, Personal, Research, etc.
- Each space has a custom color (applied as a tint over the global glass effect)
- Each space has URL matching rules (e.g., "github.com → Work", "youtube.com → Personal")
- **Auto-switching**: when the user activates a tab in the browser, the app evaluates its URL against all space rules. If the matched space differs from the active space, Hopline can switch the sidebar automatically. Default v1 behavior should be **suggest** rather than fully automatic, so users are not surprised while rules are still being tuned.
- Spaces persist to SQLite — survive app restarts

**How it feels to use:**
```
You're in Work space. Sidebar shows your Work pins + matching live tabs.
You click a YouTube tab in Chrome's tab bar.
→ App detects the tab activation via the extension
→ youtube.com matches the "Personal" space rule
→ Sidebar suggests or auto-switches to Personal space, depending on your setting
→ The YouTube tab is highlighted
→ You see your Personal pins + bookmarks now
→ No action required from you

You click a GitHub pinned tab in the sidebar.
→ Chrome switches to the GitHub tab (or opens it)
→ App stays in Work space (github.com matches Work)
→ The GitHub tab is highlighted
```

**Sidebar layout per space:**
```
┌─────────────────┐
│ ☰ Work          │  ← space selector
├─────────────────┤
│ 📌 Pinned       │  ← curated items, per space
│  Linear         │
│  GitHub PRs     │
│  Figma          │
│ 📁 Docs         │
│  API spec       │
│  RFC template   │
├─────────────────┤
│ 🟢 Matched Tabs │  ← live tabs matching this space's URL rules
│  github.com/... │
│  linear.app/... │
├─────────────────┤
│ 🔘 Other Tabs   │  ← all other live tabs (dimmed, collapsible)
│  youtube.com    │
│  gmail.com      │
└─────────────────┘
```

Tabs are never hidden. "Other Tabs" is collapsible and visually dimmed but always accessible. No tab disappears just because you're in a different space.

Auto-switch modes:

- **Off**: Hopline never changes spaces because of browser activity.
- **Suggest**: Hopline highlights the matched space and offers a one-click switch. This should be the v1 default.
- **Automatic**: Hopline switches spaces immediately when a rule matches.

---

## Sidebar Item Types

| Type | Description |
|---|---|
| **Live tab** | A currently-open browser tab. Click to focus it. Shows favicon + title. Auto-sorted into matched/other based on space rules. |
| **Pinned tab** | A URL the app remembers. Persists across browser + app restarts. Click to switch-to-tab or open. |
| **Locked tab** | Like a pinned tab, but actively enforces its URL — navigating away resets it. |
| **Bookmark** | A saved URL. Opens on click. Functionally identical to a pinned tab. |
| **Folder** | Contains any combination of the above. Collapsible. Draggable. |

---

## Tab Management

- Live view of all open tabs in connected Chromium browsers
- Click any tab to focus it (brings browser to front, activates that tab)
- **Switch-to-tab**: clicking a pinned/bookmarked URL that's already open focuses the live tab instead of opening a duplicate
- **Auto-switch spaces**: browser tab activation triggers space switching based on URL rules
- Close tabs from the sidebar
- Move pins/bookmarks between spaces by dragging
- Browser profile awareness: tabs tagged by profile (Work profile / Personal profile)

---

## Command Panel

See [[Command Panel]] for full details.

- Global hotkey (`Cmd+Shift+?` / `Ctrl+Shift+?` — configurable) opens a Raycast-style floating overlay
- Single input: fuzzy search + commands in one
- Works from anywhere — no need to have the app focused or visible
- Dismiss with Escape or clicking away
- Integrates with Raycast, Alfred, PowerToys Run, and any tool via Hopline's authenticated local HTTP API

---

## Locked Tab Behaviour (the Arc feature)

When you lock a tab:

1. The app records the URL at lock time
2. The extension monitors that tab via `chrome.webNavigation` for navigation events
3. If the tab navigates to a different URL → extension immediately redirects it back
4. If the tab is closed → extension reopens it
5. To "unlock" and actually leave the URL — you explicitly unlock it first

This is perfect for things like your email, Notion workspace, or Linear board — URLs you always want to be there at that exact location.

> **Known limitation**: locked tab redirect via MV3 `webNavigation` will have slight visible flicker — not as seamless as Arc's native integration. See [[Risks and Review]] item #5.
