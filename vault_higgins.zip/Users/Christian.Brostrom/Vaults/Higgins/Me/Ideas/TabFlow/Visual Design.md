# Visual Design

> Back to [[README]] | See also: [[Architecture]], [[Performance]]

---

## Glass Effect Implementation

The glass effect is applied at the **OS window level**, not via CSS. The blur happens behind the webview, using the OS compositor.

### macOS — Vibrancy

Vibrancy is NOT a `tauri.conf.json` config key. It requires platform-specific Rust code using `objc2-app-kit`.

```toml
# src-tauri/Cargo.toml — macOS only dependency
[target."cfg(target_os = \"macos\")".dependencies]
objc2-app-kit = { version = "0.3", features = ["NSVisualEffectView", "NSWindow"] }
```

```rust
#[cfg(target_os = "macos")]
fn apply_vibrancy(window: &tauri::WebviewWindow) {
    use objc2_app_kit::{NSVisualEffectMaterial, NSVisualEffectView};
    // Apply sidebar vibrancy material via platform handle
    // Exact API: verify against current objc2-app-kit version
}
```

```json
// tauri.conf.json — required base config
{
  "windows": [{
    "transparent": true,
    "decorations": false
  }]
}
```

### Windows 11 — Mica/Acrylic

Applied via the `tauri-plugin-window-effects` community plugin. Verify plugin availability and API at install time.

### Available macOS Materials

- `NSVisualEffectMaterial::Sidebar` — matches Finder sidebar (recommended)
- `NSVisualEffectMaterial::Menu` — slightly lighter
- `NSVisualEffectMaterial::HUDWindow` — dark, HUD-style
- `NSVisualEffectMaterial::FullScreenUI` — fullscreen-optimized

> **Verify before use**: exact Rust struct names and method calls must be confirmed against the installed crate version.

---

## Per-Space Color Tint

With Tailwind 4, the dynamic space color works natively via `@theme`:

```css
/* app.css */
@import "tailwindcss";

@theme {
  --color-space: var(--space-color, oklch(0.55 0.15 260));
}
```

In components: `bg-space/12` for the 12% space tint, `bg-space/25` for active states.

Space color is a CSS custom property set on the root when switching spaces:

```typescript
document.documentElement.style.setProperty('--space-color', space.color);
```

**Fallback for older WebViews**:
```css
@supports not (background: color-mix(in srgb, red 10%, transparent)) {
  .sidebar-content {
    background: rgba(var(--space-color-rgb), 0.12);
  }
}
```

---

## Typography

```css
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI Variable', sans-serif;
  font-size: 13px;
  -webkit-font-smoothing: antialiased;
}
```

Resolves to: San Francisco (macOS) / Segoe UI Variable (Windows 11).

---

## Iconography

- Use [Lucide](https://lucide.dev) icons — clean, consistent, permissive license
- Or SF Symbols-style icons on macOS (platform-branch if desired)
- Favicon display: fetch via `chrome://favicon/` for Chromium tabs

---

## Animation Principles

```css
.tab-item {
  transition: background 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; }
}
```

Only compositor-layer properties (`transform`, `opacity`) for animations — never `box-shadow`, `left`, `width` etc. See [[Performance]] CSS section.

---

## Dark / Light Mode

OS vibrancy automatically adapts to system appearance. Tailwind 4 handles the CSS side with the `dark:` variant.

For custom properties (used by glass tint, borders, etc.):

```css
@media (prefers-color-scheme: dark) {
  :root {
    --text-primary: rgba(255,255,255,0.9);
    --text-secondary: rgba(255,255,255,0.5);
    --border: rgba(255,255,255,0.08);
  }
}
@media (prefers-color-scheme: light) {
  :root {
    --text-primary: rgba(0,0,0,0.85);
    --text-secondary: rgba(0,0,0,0.45);
    --border: rgba(0,0,0,0.08);
  }
}
```

---

## Platform Limitation Summary

| Feature | macOS | Windows 11 | Windows 10 | Linux |
|---|---|---|---|---|
| Glass effect | ✅ Vibrancy (native) | ✅ Mica/Acrylic | ⚠️ Solid fallback | ⚠️ Solid fallback |
| Space color tint | ✅ | ✅ | ✅ | ✅ |
| System fonts | ✅ SF Pro | ✅ Segoe UI Variable | ✅ Segoe UI | ✅ System |
| Native feel | ✅ Excellent | ✅ Good | ✅ Acceptable | — |
