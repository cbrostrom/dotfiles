---
tags:
  - idea
  - gamedev
created: 2026-05-30
updated: 2026-06-02
---

# Tessera Descent: Synthesis Brief

## One-Paragraph Pitch

A single-player spatial roguelike where both the town and the dungeon are grid-based puzzle systems. The player collects and places tiles, buildings, items, and modifiers that gain value from adjacency, shape, rotation, and chain reactions. Dungeon runs feed the town, the town improves future runs, and the main source of fun is making layout decisions that feel meaningful, surprising, and strategically expressive.

## Design Pillars

- Spatial decisions matter more than raw stats
- Every tile is valuable because of its neighbors
- The town is a puzzle board, not a menu
- Loot should change rules, not just numbers
- Dungeon and town progression reinforce each other
- Clarity must stay ahead of complexity

## What the Game Is

A spatial optimization roguelike with emergent systems.

Built around placement, adjacency, footprint, and transformation as the main sources of strategy. Both layers feel like puzzle boards where small changes create meaningful downstream effects.

## What the Game Is Not

- A city builder
- A pure roguelike focused only on combat
- An exploration game (dungeon navigation is NOT the puzzle)
- A narrative-first experience
- A stats-only progression game

## Core Promise

Every decision is architectural. Moving a tile can change the whole system.

---

## Two Loops

### Town Loop (long-term — the main spatial puzzle)

- Place buildings on a grid
- Create adjacency synergies
- Generate passive resources and unlock modifiers
- Use resources to improve dungeon runs

Town is a puzzle board, not a menu.

### Dungeon Loop (short-term — Hand of Fate 2-style card map)

NOT a top-down exploration grid. The dungeon is a **card map** — cards on a table that deliver encounters, events, loot, and decisions.

Why this matters:
- Removes the "competing spatial systems" problem (not everything is a grid)
- Reads instantly — progression, routes, risk/reward visible at a glance
- Perfect for portable/touch — discrete, readable, quick sessions
- Lets the town system breathe as the primary spatial layer

The dungeon delivers pressure. The town absorbs and responds to it.

---

## Combat

**Simple tactically. Rich systemically.**

Combat's job is not to be mechanically deep in isolation. It exists to:

- Stress the player's build
- Expose weaknesses in town layout
- Reward spatial synergies
- Force adaptation

### Physicalized Status Effects

Statuses are NOT icons under a health bar. They are **spatial systems**:

| Status | Behavior |
|--------|----------|
| Burn | Spreads heat via adjacency, empowers forge items, destroys organic tiles |
| Poison | Contaminates inventory slots |
| Frost | Slows adjacent tiles |
| Corruption | Mutates town rooms |

This means combat, inventory, and town all speak the same spatial language. A status effect from a dungeon encounter can propagate into your town layout on return.

---

## Adjacency System

Each tile can:

- Buff neighbors
- Debuff neighbors
- Transform neighbors over time
- Trigger chain reactions

Example chains:
- Forge heats adjacent tiles
- Water spreads to nearby empty tiles
- Corruption spreads unless blocked

---

## Loot Philosophy

Loot must be spatially meaningful, build-altering, and combinatorial.

Avoid: flat +% stats with no interaction.  
Prefer: items that change adjacency rules, alter grid behavior, or transform layout logic.

---

## Prototype Goal

**One question only:** Is moving things around on a grid inherently satisfying and meaningful?

If yes → continue. If no → pivot immediately.

---

## Technology Stack

### Web Prototype (Phase 1)

| Layer | Choice |
|-------|--------|
| Framework | SolidJS |
| Language | TypeScript |
| Bundler | Vite |
| Styles | TailwindCSS |
| Rendering | DOM/CSS grid first |

**Why SolidJS:** Signals map naturally to reactive tile state and adjacency recalculation. Avoids React hook complexity. Fast iteration without engine overhead.

**Why DOM first (not Canvas):** The prototype question is about system feel, not rendering performance. DOM is faster to iterate, debug, and touch-test.

### Architecture Rule (CRITICAL)

The simulation layer must be completely independent from the UI.

```
/src
  /simulation   — grid.ts, tile.ts, adjacency.ts, propagation.ts, systems.ts
  /state        — gameStore.ts
  /ui           — GridView.tsx, TileView.tsx, Sidebar.tsx
  /styles
  /utils
```

No gameplay logic inside UI components. No adjacency logic in rendering code. The game must function as pure data before any visuals are added.

### Tile Model

```typescript
export type Tile = {
  id: string
  type: string
  position: { x: number; y: number }
  modifiers: string[]
  state: Record<string, number>
}
```

### Upgrade Path

```
SolidJS + DOM
  ↓ (if rendering performance needed)
Add PixiJS canvas layer
  ↓ (if going production-serious)
Evaluate Godot migration
```

---

## MVP Scope

Must have:
1. Grid system
2. Drag/drop placement
3. Adjacency detection
4. 5–10 interactive tile types
5. Resource generation based on layout

Must NOT have yet:
- Full procedural generation
- Multiple classes
- Combat system
- UI polish
- Narrative

---

## Visual Language

Color channels for systems (example):

| Color | System |
|-------|--------|
| Red | Heat / Burn |
| Blue | Moisture / Frost |
| Purple | Corruption |
| Yellow | Energy |
| Green | Growth |

Buildings emit visible influence. Overlays communicate system state instantly. No text-heavy UI in prototype.

---

## Success Indicators

On track if:
- Players experiment naturally
- Players discover combos without explanation
- Removing a tile changes strategy meaningfully
- Layout decisions feel emotional, not mathematical

Off track if:
- Systems added faster than readability
- UI becomes cluttered
- Interactions become hidden or opaque

---

## Day-by-Day Prototype Roadmap

**Day 1:** Vite + SolidJS + Tailwind. Simple grid rendering.  
**Day 2:** Draggable tiles, placement snapping, tile rotation.  
**Day 3:** Adjacency highlighting, simple modifiers, visual feedback.  
**Day 4+:** Experiment aggressively. Remove anything unfun immediately. Do not polish early.

---

## Long-Term Vision

- Town evolves like a living puzzle
- Dungeon card map feeds town structure changes (returning with corruption mutates rooms)
- Items modify the rules of space itself
- NPCs act as movable modifiers
- Status effects bridge all three systems: combat → inventory → town
