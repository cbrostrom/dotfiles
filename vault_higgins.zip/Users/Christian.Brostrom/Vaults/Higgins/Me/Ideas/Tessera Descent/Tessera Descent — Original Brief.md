---
tags:
  - idea
created: 2026-05-30
---

# Tessera Descent: Draft Design & Getting Started

## 1. High Concept

A single-player, portable-friendly roguelike where all progression systems are spatial puzzles.

The player optimizes two interconnected layers:

- Dungeon Runs -> combat, loot, risk, exploration
- Town / Base -> long-term progression through spatial building systems

Both layers use the same core language:

- adjacency
- placement
- transformation
- chain reactions

## 2. Core Design Pillar (Non-Negotiable)

Everything in the game must obey this rule:

> "A tile's value is defined by what it touches."

No system should exist that does not interact spatially or through placement logic.

## 3. Core Game Loop

### Dungeon Loop (Short-term)

- Enter dungeon
- Collect spatially relevant loot (items, modules, relics)
- Fight turn-based / grid-based encounters
- Extract with resources or die and lose run progress

### Town Loop (Long-term)

- Place buildings / rooms on a grid
- Create adjacency synergies
- Generate passive resources / unlock modifiers
- Use resources to improve future dungeon runs

## 4. Core Systems

### 4.1 Spatial Grid System (Shared Foundation)

- Everything exists on a grid
- All objects have shape and footprint
- Placement matters more than raw stats
- Rotation matters

### 4.2 Adjacency System

Each tile can:

- Buff neighbors
- Debuff neighbors
- Transform neighbors over time
- Trigger chain reactions

Example:

- Forge heats adjacent tiles
- Water spreads to nearby empty tiles
- Corruption spreads unless blocked

### 4.3 Town System (Base Building)

- Town is a grid board
- Buildings are modular pieces
- NPCs act as movable modifiers (optional advanced layer)
- Buildings generate resources based on adjacency

Key idea:

Town is not a menu - it is a puzzle board

### 4.4 Dungeon System

- Tile-based dungeon exploration
- Rooms act as modular chunks
- Loot includes:
  - items
  - passive modifiers
  - new town building pieces
  - system-altering artifacts
- Dungeon modifies town and vice versa

### 4.5 Loot Philosophy

Loot must be:

- spatially meaningful
- build-altering
- combinatorial

Avoid:

- flat +% stats with no interaction

Prefer:

- items that change adjacency rules
- items that alter grid behavior
- items that transform layout logic

## 5. System Identity (Important)

The game is NOT:

- a city builder
- a pure roguelike
- a combat game

It IS:

- a spatial optimization roguelike with emergent systems

## 6. MVP (Minimum Viable Prototype)

Do NOT build everything.

Must have:

1. grid system
2. drag/drop placement
3. adjacency detection
4. 5-10 interactive tiles
5. simple dungeon movement OR mock dungeon
6. resource generation based on layout

Must NOT have (yet):

- full procedural generation
- multiple classes
- full combat system
- UI polish
- narrative

## 7. Prototype Goal

The ONLY question the prototype must answer:

> "Is moving things around on a grid inherently satisfying and meaningful?"

If yes -> continue
If no -> pivot immediately

## 8. Recommended Engine Setup

### Engine

Godot 4 (recommended)

### Why

- fast 2D iteration
- strong grid support
- lightweight scripting (GDScript)
- easy UI prototyping

## 9. Getting Started Setup (Step-by-Step)

### Step 1: Install Tools

- Install Godot 4
- Create new 2D project

### Step 2: Create Grid Foundation

- Make a TileMap or custom grid system
- Each tile stores:
  - type
  - state
  - adjacency list

### Step 3: Create Basic Tile Objects

Implement 5 tile types:

- Empty
- Resource Generator
- Buff Tile
- Debuff Tile
- Transformer Tile

### Step 4: Implement Adjacency Logic

On placement:

- scan neighbors (up/down/left/right)
- apply effects
- update visuals immediately

### Step 5: Add Simple Interaction Loop

- place tile
- observe change
- remove tile
- re-place tile

No combat needed yet

### Step 6: Add Feedback Layer

- highlight affected tiles
- show simple numbers or icons
- animate chain reactions (basic flashes OK)

## 10. Design Warning (Read This)

This concept will fail if:

- systems are added faster than readability
- UI becomes cluttered
- interactions become hidden or opaque

Always prioritize:

- clarity over complexity

## 11. Success Indicators

You are on the right track if:

- players experiment naturally
- players discover combos without explanation
- removing a tile changes strategy meaningfully
- layout decisions feel emotional, not mathematical

## 12. Long-Term Vision (Optional)

- Town evolves like a living puzzle
- Dungeon feeds town structure changes
- Items modify rules of space itself
- NPCs act as movable modifiers

## End State

If successful, this becomes:

- a systemic spatial roguelike where every decision is architectural
