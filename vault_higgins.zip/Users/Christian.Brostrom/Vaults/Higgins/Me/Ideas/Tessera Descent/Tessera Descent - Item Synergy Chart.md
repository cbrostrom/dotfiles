# Tessera Descent — Item Synergy Chart

Last updated: 2026-06-03

## Tags Reference

| Tag | Description | Items |
|---|---|---|
| `blade` | Bladed melee weapon | Sword, Dagger |
| `heavy` | Heavy melee weapon | Mace |
| `melee` | Any melee weapon | Sword, Dagger, Mace |
| `weapon` | Any weapon | Sword, Dagger, Mace, Staff |
| `shield` | Blocking item | Shield, Buckler |
| `armor` | Defensive piece | Leather Armor, Iron Helmet, Shield, Buckler |
| `fire` | Fire source | Match (Torch), Lantern |
| `arcane` | Arcane source | Staff, Amulet of Focus |
| `healing` | Healing item | Herb, Salve |
| `utility` | Utility/consumable | Match, Lantern, Herb, Salve |
| `trinket` | Accessory | Iron Ring, Iron Helmet, Amulet of Focus |

---

## Items — Full Definition

### Weapons (Active)

| Item | Rarity | Footprint | Cost | Base Effect | Tags | Adj Bonus Trigger | Adj Bonus |
|---|---|---|---|---|---|---|---|
| **Sword** | Common | 1×3 | 1 | 3 atk | blade, melee, weapon | adj `fire` | +Burn on attack |
| **Dagger** | Uncommon | 1×1 | 1 | 5 atk | blade, melee, weapon | adj `fire` | +2 atk + Burn |
| **Mace** | Uncommon | 1×3 | 1 | 4 atk | heavy, melee, weapon | adj `armor` | +2 atk |
| **Staff** | Rare | 1×1 | 2 | 7 atk (magic) | arcane, weapon | adj `arcane` | +3 atk |
| **Lantern** | Uncommon | 1×1 | 1 | Burn + 1 atk | fire, utility | adj `blade` | +2 atk |
| **Match** | Common | 1×1 | 1 | Burn | fire, utility | — | (none — match grants Burn to adjacent blade/heavy, not itself) |

### Shields (Active)

| Item | Rarity | Footprint | Cost | Base Effect | Tags | Adj Bonus Trigger | Adj Bonus |
|---|---|---|---|---|---|---|---|
| **Shield** | Common | 1×1 | 1 | 2 block | shield, armor | adj `shield` | +1 block |
| | | | | | | adj `armor` | +1 block |
| **Buckler** | Uncommon | 1×1 | 1 | 3 block | shield, armor | adj `shield` | +1 block |
| | | | | | | adj `armor` | +1 block |

### Healing (Active)

| Item | Rarity | Footprint | Cost | Base Effect | Tags | Adj Bonus Trigger | Adj Bonus |
|---|---|---|---|---|---|---|---|
| **Herb** | Common | 1×1 | 1 | 5 HP | healing, utility | adj `shield` | +1 block |
| **Salve** | Rare | 1×1 | 1 | 10 HP | healing, utility | adj `healing` | +5 HP |

### Passives

| Item | Rarity | Footprint | Base Passive | Tags | Adj Bonus Trigger | Adj Bonus |
|---|---|---|---|---|---|---|
| **Leather Armor** | Common | 1×1 | +3 block/turn | armor | adj `shield` | +1 block/turn |
| **Iron Ring** | Uncommon | 1×1 | +1 atk/hit (all attacks) | trinket | adj `melee` | +1 atk/hit |
| **Iron Helmet** | Uncommon | 1×1 | +3 max HP | armor, trinket | adj `armor` | +1 max HP |
| **Amulet of Focus** | Rare | 1×1 | +1 energy/turn | arcane, trinket | — | — |

---

## Modifier Conditions

These are the conditions items can respond to. Each condition is a tag or type check on an orthogonal neighbor (unless `reach` is specified).

| Condition | What triggers it | Which items respond |
|---|---|---|
| adj `fire` | Match or Lantern placed adjacent | Sword (→ Burn), Dagger (→ +2 atk + Burn) |
| adj `blade` | Sword or Dagger placed adjacent | Lantern (→ +2 atk) |
| adj `melee` | Sword, Dagger, or Mace adjacent | Iron Ring (→ +1 atk/hit) |
| adj `armor` | Leather Armor, Helmet, Shield, Buckler adjacent | Mace (→ +2 atk), Shield (→ +1 block), Buckler (→ +1 block), Helmet (→ +1 max HP) |
| adj `shield` | Shield or Buckler adjacent | Shield (→ +1 block), Buckler (→ +1 block), Leather Armor (→ +1 block/turn), Herb (→ +1 block) |
| adj `healing` | Herb or Salve adjacent | Salve (→ +5 HP) |
| adj `arcane` | Staff or Amulet of Focus adjacent | Staff (→ +3 atk) |

---

## Planned / TODO

- [ ] `passiveAttack` applied to all attacks (melee AND arcane?) — decide scope
- [ ] `diagonal` reach items — which items should look diagonally?
- [ ] Status effects: Poison, Stun, Freeze — tags and item types
- [ ] Ranged weapon type — `ranged` tag, no melee bonus from ring
- [ ] Thrown weapon type — consumes item on use
- [ ] Focus Crystal passive — grants energy when arcane item used
- [ ] More arcane items — Tome, Wand (blade-arcane hybrid?)
- [ ] Enemy types that are immune to Burn, resistant to physical, etc.
- [ ] Footprint shapes beyond rectangles (L-shape, T-shape)

---

## Adjacency Reach Definitions

| Reach | Cells checked | Use case |
|---|---|---|
| `orthogonal` (default) | 4 cardinal neighbors | Standard adjacency |
| `diagonal` | 4 corner neighbors | Specific positional bonuses |
| `all` | All 8 surrounding cells | Area-of-effect passives |
