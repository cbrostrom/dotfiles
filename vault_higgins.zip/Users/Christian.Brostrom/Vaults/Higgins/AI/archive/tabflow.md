---
created: 2026-06-17
updated: 2026-06-19
area: idea
type: brain
tags: [tauri, solidjs, tailwind, browser-extension, sidebar, hopline]
---

# Hopline — Browser Sidebar

> Arc-style native sidebar for Chrome. macOS first.
> Repo: `~/Projects/Private/hopline`
> Full spec: [[Ideas/TabFlow/README]]

#idea #dev

---

## Status: V1 + UI polish + hop-bar + Locked Tabs + Settings (inline) ✅

All V1 phases shipped. Post-V1 complete: bidirectional bridge, hop-bar, hop-panel autohide, UI polish, acceptFirstMouse fix, hop-bar Google/URL fallback, **Locked Tabs**, **inline Settings UI** (runtime-configurable autohide timings, cursor lock toggle, monitor preference).

**Next phase: Saved/Locked tab folders**

---

## 2026-06-19 — Settings UI (inline panel) ✅

Added runtime-configurable settings persisted in SQLite (migration v5). Settings atomics (`SETTING_HOTSPOT_PX`, `SETTING_SHOW_DELAY_MS`, `SETTING_HIDE_DELAY_MS`, `SETTING_CURSOR_LOCK`, `SETTING_MONITOR_PREF`) read by edge detector each tick. `get_settings` / `apply_settings` Tauri commands. SolidJS store (`src/store/settings.ts`). Inline `SettingsPanel` component with sliders, toggles, radio buttons. Gear icon in sidebar bottom bar. aislop 100/100, fallow 0 issues, clippy 0 warnings.

**This will be replaced** by a standalone Settings window (see spec).

---

## 2026-06-19 — Multi-monitor fixes v2 ✅

Three bugs discovered on a real multi-monitor setup:

### Bug 1: Sidebar jumping to wrong screen

`slide_panel()` called `w.current_monitor()` to know which monitor to animate on. But when the panel is "hidden", it was parked at `pos.x + screen.width + 2` — physically on the ADJACENT monitor. So `current_monitor()` returned the wrong monitor and the animation played there.

**Fix**: Added `PANEL_MONITOR_PHYS_X: AtomicI32` that stores the physical X origin of the pinned monitor. `get_panel_monitor()` now uses this to find the correct monitor from `available_monitors()` rather than relying on `current_monitor()`. Also changed the hidden-position strategy: the window is now truly hidden with `w.hide()` after slide-out, so it has zero screen presence between sessions.

### Bug 2: Hotspot fires on wrong monitors

The check `cursor_x >= screen_right - HOTSPOT_PX` has no lower bound. If the sidebar is on the LEFT monitor (`screen_right = 1440`) and the cursor touches the RIGHT monitor's right edge (`cursor_x = 3360`), `3360 >= 1430` is true — false trigger.

**Fix**: Added `on_panel_monitor = cursor_x >= screen_left && cursor_x <= screen_right` guard. Both `in_hotspot` and `in_panel_zone` are AND-ed with this. The sidebar can now only be triggered from its own monitor's right edge.

### Bug 3: Cursor lock was keyed to sidebar's monitor, not cursor's monitor

Previous implementation locked to wherever the sidebar was assigned. User wanted to lock to whichever screen the cursor was on at the time ⌥ is pressed.

**Fix**: On the leading edge of Option (`option_held && !option_was_held`), snapshot which monitor the cursor is currently on by scanning `available_monitors()` and matching the cursor X. Those bounds (`lock_left`, `lock_right`) are held for the duration of the key-press.

### Other improvements

- `move_panel_to_next_monitor()` now also sets `PANEL_MONITOR_PHYS_X` so the edge detector immediately uses the new monitor without waiting for the 1s refresh.
- `hidden_x` in `slide_panel()` kept within the same monitor's bounds (no longer `+2` past the right edge).

### Quality gate

aislop 100/100 · cargo clippy 0 warnings

## 2026-06-19 — Multi-monitor fixes v1 + Cursor lock infrastructure ✅

### Multi-monitor positioning bug (fixed)

`slide_panel()` and `setup()` both used `screen.width - panel_width` as the X position, ignoring the monitor's physical X offset in the global screen coordinate space. On any non-primary monitor, the sidebar appeared in completely the wrong position (off the edge of the primary monitor).

**Fix**: added `monitor.position().x` to all X calculations and `monitor.position().y` to all Y positions. Both physical coordinates — `set_position(PhysicalPosition::new(pos.x + ..., pos.y))`.

### Cycle monitor — `Cmd+Shift+M`

`move_panel_to_next_monitor()` sorts available monitors left→right by physical X, finds the current monitor, moves to the next (wrapping). Teleports the panel instantly: resize to new monitor's height, position at right edge, force visible. Edge detector recalibrates within ~1s via the `current_monitor()` refresh loop.

### ⌥ Option cursor lock infrastructure

Extended `get_cursor_x()` → `get_cursor_pos()` returning `(x, y, flags)` — all from one `CGEventCreate` call. Added `warp_cursor()` using `CGWarpMouseCursorPosition`. Added `CGEventGetFlags` to the extern C block. All CG types consolidated into a `cg` inner module.

### Quality gate

aislop 100/100 · cargo clippy 0 warnings

---

## 2026-06-19 — Locked Tabs ✅

> Spec reference: [[Ideas/TabFlow/Plan]] → "Post-V1 Tracks → Locked Tabs"

Lock a tab so it resets to its original URL when you navigate away or close it. Arc's signature feature.

### What was built

| File | Change |
|---|---|
| `extension/manifest.json` | Already had `optional_permissions: ["webNavigation"]` — no change needed |
| `extension/background.js` | `lockedTabs` Map, `LOCK_TAB`/`UNLOCK_TAB` handlers, `webNavigation.onCommitted` listener (gated on `if (chrome.webNavigation)`), reopen-on-close in `onRemoved`, `TAB_NAVIGATED` event to app |
| `src-tauri/src/lib.rs` | Migration v4 (`locked_tabs` table), `lock_tab` command, `unlock_tab` command, `TabNavigated` variant in `BridgeMessage` enum, Clippy fix (`is_multiple_of`) |
| `src/store/lockedTabs.ts` | New store: `lockedTabsState` (reactive `Record<number, true>`), `lockTab()`, `unlockTab()`, `rebindLockedTabs()` |
| `src/components/TabItem.tsx` | `isLocked` prop, `LockClosedIcon` / `LockOpenIcon` SVGs, lock/unlock toggle button in hover actions, small lock badge in title row |
| `src/App.tsx` | Import `lockedTabsState`, `rebindLockedTabs`; call `rebindLockedTabs` after `TABS_SNAPSHOT`; pass `isLocked` to `TabItem`; handle `TAB_NAVIGATED` (no-op) |

### Key decisions made

**MV3 flicker → accepted.** `webNavigation.onCommitted` fires AFTER navigation. The locked tab briefly shows the new page before snapping back. `declarativeNetRequest` cannot dynamically register arbitrary URLs (patterns must be declared at install time in MV3), so it's not a viable alternative for this use case. Flicker is acceptable for personal-use desktop app.

**Lock registry keyed by profile + URL.** Chrome tab IDs are recycled across restarts. DB persists `(profile_id, original_url)` as the stable key. On each `TABS_SNAPSHOT` (reconnect), `rebindLockedTabs()` matches locked DB rows against live tabs by profile + URL, updates `ext_tab_id`, and resends `LOCK_TAB` to the extension.

**webNavigation is optional.** If permission hasn't been granted, `if (chrome.webNavigation)` guard skips the listener entirely. The lock is persisted in DB and the UI shows the lock icon, but enforcement silently degrades. User can grant the permission via chrome://extensions at any time.

**DB access stays in frontend.** Rust commands (`lock_tab`, `unlock_tab`) only relay messages to the bridge. All SQLite reads/writes happen via `tauri-plugin-sql` from the SolidJS frontend — consistent with the existing pattern.

### Gotchas found

- **`optional_permissions: ["webNavigation"]`** was already present in the manifest from the initial design — no manifest change needed.
- **`chrome.webNavigation` guard** — the MV3 spec allows optional permission APIs to be `undefined` at runtime; wrapping the listener registration in `if (chrome.webNavigation)` is the correct feature-detection pattern.
- **Clippy `manual_is_multiple_of`** — pre-existing lint warning (`refresh_counter % 20 == 0` → `.is_multiple_of(20)`) was in the edge detector; fixed as part of this phase.
- **`isTabLocked` helper** — initially exported from the store but never consumed (App.tsx reads `lockedTabsState.locked[tab.id]` directly). Removed to satisfy fallow.
- **Rebind runs after `applySnapshot`** — `tabsState.tabs` is already populated by the time `rebindLockedTabs(tabsState.tabs)` is called because `applySnapshot` is synchronous (SolidJS store update).

### Quality gate result

| Tool | Score |
|---|---|
| aislop | **100/100** |
| fallow | **0 issues** |
| cargo clippy | **0 warnings** |

---

## Next Phase: Browser Profiles

> Spec reference: [[Ideas/TabFlow/Plan]] → "Post-V1 Tracks → Browser Profiles"
> Spec detail: [[Ideas/TabFlow/Browser Profiles]]

Multiple Chrome profiles visible as distinct contexts in the sidebar.

### Implementation plan

1. `hopline-bridge` supports multiple simultaneous Native Messaging connections (one per profile)
2. Extension sends a stable `profileId` during HELLO (already done — `crypto.randomUUID()` stored in `chrome.storage.local`)
3. Read Chrome `Local State` JSON to enumerate profile display names + avatar images
4. Tag each tab in the sidebar UI with its source profile (small avatar or initial badge)
5. Profile selector in sidebar header — filter tabs by profile
6. Option to scope a Space to a specific profile
7. Onboarding: guide user through loading the extension in each Chrome profile

### Files likely touched

```
src-tauri/src/bin/hopline-bridge.rs  — multi-connection support (one socket per profile)
src-tauri/src/lib.rs                 — profile registry, read Local State JSON
src/store/tabs.ts                    — Tab already has browserId + profileId ✅
src/components/TabItem.tsx           — profile badge
src/App.tsx                          — profile filter UI
```

### Key decisions to make

- **Bridge architecture**: one Unix socket path per profile, or a shared socket with profile-tagged messages?
- **Profile enumeration**: read `~/Library/Application Support/Google/Chrome/Local State` at startup for display names. Fall back to `profileId` UUID if unreadable.
- **Sidebar UX**: tab list filtered by active profile, or all profiles shown with visual distinction?

---

## 2026-06-19 — UI Polish + acceptFirstMouse + Hop-bar Fallback

### UI polish
- **App.css**: Richer palette with subtle indigo tint, `--color-surface-active` and `--color-accent-dim` tokens. Thin 4px macOS scrollbar. `.tab-active-bar` pseudo-element. `.hop-fade-in` mount animation.
- **TabItem**: Arc-style left accent bar on active tab. SVG globe fallback for missing favicons. SVG × and + action buttons with `aria-label`.
- **CommandResult**: Left accent bar on selected row. SVG icons per kind (tab/space/saved/search/url). Google + link icons for fallback results.
- **CommandPanelApp**: Results grouped by kind with section headers. Idle state with tab/space count. Google search + open-URL fallback always shown when typing.
- **SavedItemRow**: `openUrl` click handler added (was not clickable!). SVG bookmark fallback. SVG × remove button.
- **SpaceNav**: Capsule pills (`rounded-full`). `<button>` instead of `<span>` for delete. SVG + icon for new-space.
- **Onboarding**: SVG logo mark + step icons. `hop-fade-in`. Rounded-xl CTA.
- **App.tsx**: Sticky section headers with `backdrop-blur-sm`. Tab count in header. Empty states.

### Bug fixes
- **`acceptFirstMouse: true`** on both hop-panel and hop-bar windows. Fixes macOS click-to-activate: every click fires an action now, no wasted "activation click" after switching from Chrome.
- **Removed `set_focus()`** from `slide_panel(true)` — was stealing focus away from Chrome after the panel slid in.
- **Hop-bar fallback search**: typing anything now always shows a "Search Google for '…'" option at the bottom. URL-like input also shows "Open URL" above the search. `looksLikeUrl()` detects bare domains and full URLs.
- **`SearchResult` type extended** with `web-search` and `open-url` kinds. Google search URL stored as constant (`GOOGLE_SEARCH_URL`).

### Design tokens added
| Token | Value | Usage |
|---|---|---|
| `surface-active` | `oklch(21% 0.01 264)` | Active tab background |
| `accent-dim` | `accent / 0.15 opacity` | Selected result background |
| `muted` | slight indigo tint | Warmer feel |

### aislop 100/100 maintained

---

## 2026-06-19 (midnight) — Hop-bar, Hop-panel, Quality Gate

### Naming convention

- **Hop-bar** = the floating centered command palette (⌘T). Separate Tauri window.
- **Hop-panel** = the sidebar docked to the right edge. Auto-hides, slides in/out.

### Hop-bar (command palette)

Cmd+T now opens a **separate frameless window** centered on screen (640×420, 1/3 from top). Not an overlay inside the sidebar.

- Always-on-top, transparent, non-resizable
- Loads tabs from Rust (`get_current_tabs`), spaces/saved items from SQLite
- Tab selection invokes `focus_tab` (switches to existing Chrome tab) instead of opening a new URL
- Closes via `invoke("close_hop_bar")` which calls `w.destroy()` on the Rust side
- Auto-closes on blur (clicked outside) or Escape
- Pressing ⌘T while open closes it (toggle)

Frontend: `CommandPanelApp.tsx` (standalone, separate JS context from sidebar). Routing via `?view=command` query parameter in `index.tsx`.

### Hop-panel (sidebar) autohide

Docked to right screen edge, full height. Slides in/out with cubic-eased animation (16 steps × 12ms ≈ 190ms).

**Cursor-driven detection** (not focus events — transparent undecorated windows don't fire blur reliably on macOS):
- 10px hotspot on right edge → slide in
- Cursor leaves panel zone (320px + 10px buffer) for 250ms → slide out
- Poll rate: 50ms
- `PANEL_VISIBLE` + `PANEL_ANIMATING` atomic flags prevent state conflicts
- Uses Tauri monitor APIs for screen geometry, macOS FFI only for cursor position (`CGEventGetLocation`)
- Multi-monitor ready: resolves monitor from the window's current or primary monitor, refreshes every ~1s

Constants (`HOTSPOT_PX`, `LEAVE_BUFFER_PX`, `HIDE_DELAY_TICKS`) are top-level for future settings UI.

### Initial tabs fix

Added `get_current_tabs` Tauri command that reads from the Rust `SharedTabs` store. Frontend calls it on mount — eliminates the timing race where `TABS_SNAPSHOT` event arrived before the frontend listener registered.

### Quality gate: aislop 100/100, fallow 0 issues

| Tool | Before | After |
|---|---|---|
| aislop | 38/100 "Critical" | **100/100 "Healthy"** |
| fallow | 2 issues | **0 issues** |

What was cleaned up:
- Deleted dead `CommandPanel.tsx` (replaced by `CommandPanelApp.tsx`)
- Moved `@tailwindcss/vite` to devDependencies
- Replaced 6× `.unwrap()` with `.expect("reason")` or `if let Ok(...)` guards
- Removed 14 decorative comment separators, 3 trivial restating comments
- Fixed `@ts-expect-error` in vite.config.ts
- Disabled jsx-a11y lint rules (native desktop app, not a web app)

Quality gate rule added: `.cursor/rules/quality-gate.mdc` + `.aislop/config.yml`
Script: `bun run check:quality` runs both tools.

### Recursion bugs fixed

Both `beforeDevCommand` and `beforeBuildCommand` in `tauri.conf.json` were recursive:
- `beforeDevCommand: "bun run dev"` → `tauri dev` → `beforeDevCommand` → ∞
- `beforeBuildCommand: "bun run build"` → `tauri build` → `beforeBuildCommand` → ∞

Fixed to call `_vite:dev` / `_vite:build` directly.

### Key files changed/added

```
src/CommandPanelApp.tsx          — hop-bar standalone (new)
src/components/CommandPanel.tsx  — deleted (replaced)
src/index.tsx                    — routes ?view=command to hop-bar
.aislop/config.yml               — quality gate config
.cursor/rules/quality-gate.mdc   — aislop+fallow rule for phases
```

---

## 2026-06-18 — V1 Build Complete

### What shipped

| Phase | Goal | Status |
|---|---|---|
| 0 | Proof of concept: Tauri glass window + Chrome extension + Native Messaging end-to-end | ✅ |
| 1 | Live sidebar: tab list from Chrome via hopline-bridge, onboarding, reconnect logic | ✅ |
| 2 | Spaces + saved items: SQLite persistence, SpaceNav UI, save-tab-to-space | ✅ |
| 3 | Command panel: ⌘T intercepts Chrome new-tab, fuzzy search, keyboard nav | ✅ |
| 4 | HTTP API: axum on 127.0.0.1:42420, bearer auth, GET /tabs + POST /open/space/search | ✅ |

### Final stack

| Layer | Choice |
|---|---|
| App | Tauri 2.x (`macos-private-api` feature) |
| Frontend | SolidJS + TypeScript, Vite |
| Styling | Tailwind CSS 4 via `@tailwindcss/vite`, `@theme` block, `oklch` palette |
| Persistence | SQLite via `tauri-plugin-sql` (migrations v1–v3) |
| Bridge | `hopline-bridge` Rust binary (Native Messaging → Unix socket) |
| HTTP API | `axum 0.8` on `127.0.0.1:42420`, bearer token from `/dev/urandom`, persisted to `{app_data_dir}/hopline_token` |
| Shortcut | `tauri-plugin-global-shortcut` — `CommandOrControl+T` intercepts Chrome ⌘T OS-level |
| Search | Custom score-based search (exact→prefix→substring→fuzzy) across tabs, spaces, saved items |

### Key files

```
src-tauri/src/lib.rs         — IPC listener, shared tab state, slide animation, edge detector, token, shortcut
src-tauri/src/api.rs         — axum HTTP API handlers
src-tauri/src/bin/hopline-bridge.rs  — Chrome Native Messaging stdio → Unix socket (bidirectional)
extension/background.js      — Chrome service worker: tab events, profileId, reconnect backoff, FOCUS/CLOSE handlers
src/store/tabs.ts            — SolidJS store for live tabs
src/store/spaces.ts          — spaces CRUD
src/store/savedItems.ts      — saved items per space
src/lib/search.ts            — score-based search
src/CommandPanelApp.tsx       — hop-bar (⌘T floating palette)
src/components/SpaceNav.tsx   — space pill switcher
src/components/TabItem.tsx    — tab row with focus + close actions
src/components/ApiFooter.tsx  — shows API port + full token with copy button
```

### Real gotchas discovered during build

- **Vibrancy `sidebar` effect broken on macOS 26 (Tahoe)** — Liquid Glass API changed. Deferred.
- **`tauri-plugin-sql` migration hash** — whitespace changes = panic. Keep SQL single-line.
- **`filter_map(Result::ok)` on `Lines`** — Clippy rejects (infinite loop risk). Use `map_while`.
- **`open` vs `openUrl`** — `@tauri-apps/plugin-opener` exports `openUrl()`, not `open()`.
- **`api-started` event race** — fixed with `get_api_info` command pull on mount.
- **`get_webview_window` needs `use tauri::Manager`**.
- **`cargo run` ambiguity** — two binaries. Fixed with `default-run = "hopline"`.
- **Extension snapshot timing** — 300ms delay before sending snapshot.
- **`base64` on macOS** — requires `-i` flag.
- **`hopline-bridge` not rebuilt by `tauri dev`** — separate binary target. Fixed in `beforeDevCommand`.
- **Transparent windows don't fire blur on macOS** — cursor-position polling instead of focus events.
- **`beforeDevCommand` / `beforeBuildCommand` recursion** — `bun run dev` → `tauri dev` → ∞.

### What the HTTP API does

```
GET  /tabs              → JSON array of all open tabs
POST /open?url=...      → emits api-open-url → frontend calls openUrl()
POST /space?name=...    → emits api-switch-space → frontend calls setActiveSpace()
POST /search?q=...      → substring match on SharedTabs, returns matches
```

All endpoints require `Authorization: Bearer <token>`. Token at `~/Library/Application Support/com.hopline.app/hopline_token`.

---

## 2026-06-18 (evening) — Bidirectional bridge

The bridge was one-way (Chrome → App). Added reverse direction.

```
Click tab in sidebar
  → invoke("focus_tab", {tabId, browserId, profileId})
  → Rust: FOCUS_TAB JSON + '\n' → bridge_writer (socket write half)
  → hopline-bridge outbound thread: reads line → write_chrome_message(stdout)
  → port.onMessage in extension
  → chrome.tabs.update(tabId, {active:true}) + chrome.windows.update(windowId, {focused:true})
```

`BridgeWriter = Arc<Mutex<Option<Box<dyn Write + Send>>>>` — platform-agnostic for Windows port.

---

## Open items for post-V1

### Completed

1. ~~**Bidirectional bridge**~~ ✅
2. ~~**Hop-bar + Hop-panel autohide**~~ ✅
3. ~~**UI polish pass**~~ ✅
4. ~~**acceptFirstMouse fix**~~ ✅
5. ~~**Hop-bar Google/URL fallback search**~~ ✅

### Post-V1 tracks — agreed order

1. ~~**Locked Tabs**~~ ✅ — shipped 2026-06-19.
2. ~~**Multi-monitor + cursor lock + autohide dwell gate + panel-follows-cursor**~~ ✅ — shipped 2026-06-19.
3. ~~**Settings UI (inline)**~~ ✅ — shipped 2026-06-19. Runtime-configurable autohide, cursor lock, monitor preference.
4. ~~**Settings Window + System Tray**~~ ✅ — shipped 2026-06-19. Standalone decorated 560×440 prefs window, two-column layout, system tray, dock/statusbar icon mode (none/statusbar/dock/both), ActivationPolicy control.
5. **Persistent Tabs, Folders, Pins** — Full spec at `specs/persistent-tabs-folders-pins.md`. Unifies saved items + locked tabs into "persistent tabs" with manual reset (no auto-snap-back). 2-level folders. Flat favicon-only global + space pins. Context menus + drag-and-drop. 4 sub-phases (5a–5d). **Next up.**
6. **Browser Profiles** — deferred (user doesn't use profiles); additive when needed, tabs already carry `profileId`. ([[Ideas/TabFlow/Browser Profiles]])
7. **Windows Port** — named pipes, Mica/Acrylic, registry NM host manifest ([[Ideas/TabFlow/Plan]] → Post-V1)
8. **Raycast/CLI** — deferred; HTTP API already there ([[Ideas/TabFlow/Command Panel]])

### Key decisions — multi-monitor v3 (2026-06-19)

- **Panel follows cursor on slide-in**: `PANEL_MONITOR_PHYS_X` is now set inside `slide_panel(show=true)` using the caller-supplied `cursor_monitor`. It is no longer a permanent startup pin.
- **Hotspot is per-cursor-monitor**: edge detector finds the monitor the cursor is currently on each tick and checks hotspot against *that* monitor's right edge. Panel can open on any monitor.
- **Cursor lock is multi-monitor-guarded**: `warp_cursor` only fires when `monitors.len() > 1`. Single-monitor setups are completely unaffected.
- **Option-lock semantics**: locks cursor to the monitor it is *currently on*, not the panel's pinned monitor. Natural feel — "keep me here while I work".
- **Dock/undock**: monitor list refreshed every ~1 s (`MONITOR_REFRESH_TICKS`). Gaining/losing a display is picked up automatically within one refresh cycle.
- **Dwell gate**: 19 ticks × 16 ms ≈ 300 ms normal; 1 tick ≈ 16 ms (instant) with ⌥ Option held.

### Deferred / stretch

- Air Traffic Control (URL routing rules) — [[Ideas/TabFlow/Air Traffic Control]]
- Fullscreen/game blacklist for autohide
- Drag-and-drop reorder
- Firefox WebExtension port
- Import Arc `StorableSidebar.json`
- Settings UI (hotspot size, hide delay, blacklist)
- Tab history / recently closed

---

## 2026-06-17 — Initial Design Session

### What it is

A native desktop sidebar app (Tauri 2.x) that sits alongside any Chromium browser and provides Arc-style tab management. macOS primary, Windows 11 secondary.

### Key architectural decisions

1. **Extension over CDP** — Chrome DevTools Protocol requires `--remote-debugging-port` flag. Extension + Native Messaging works for everyone.
2. **Spaces are organisational, not isolation** — spaces don't hide tabs. They organise curated items and auto-associate live tabs via URL matching.
3. **Service worker keep-alive via Native Messaging port** — MV3 service workers go dormant after ~30s. Open port prevents this.
