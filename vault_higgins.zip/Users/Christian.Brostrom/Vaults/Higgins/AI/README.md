# Patina — AI Knowledgebase

**Patina** is Christian's persistent AI memory layer. A plain-markdown, git-tracked vault consumed by every agent harness (PI, Cursor IDE, Cursor-Agent in Zed). The longer you use it, the richer each session gets.

For the machine-readable contract agents read, see [`AGENTS.md`](./AGENTS.md).

---

## The problem it solves

Every session an agent starts from zero. It re-asks the same questions, re-discovers the same gotchas, re-learns the same conventions. This burns tokens and erodes quality.

Patina is a **flywheel**: session learnings are promoted upward into permanent context. The next session starts denser and cheaper. Over time, the agent compounds knowledge rather than discarding it.

---

## Tier map

```
Vaults/AI/
├── AGENTS.md                    Machine contract — all harnesses obey this
├── README.md                    This file
├── _schema/                     JSON schemas for lint enforcement
├── _ops/                        Migration logs, curator reports
│
├── personal/                    ALWAYS LOADED: Christian's cross-cutting brain
│   ├── current.md               Active focus (≤5 bullets)
│   ├── preferences.md           Stack, style, hates, conventions (on-demand)
│   └── gotchas.md               Cross-project traps
│
├── modules/                     Reusable knowledge units (extractable per-module)
│   ├── shopify/                 Shopify platform: MCP-first, theme patterns, metafield gotchas
│   ├── tauri-solidjs/           Tauri 2 + SolidJS: HoldDragSensor, jiggle_cursor, stable keys
│   ├── bun-sqlite-hono/         Bun + WAL + Hono + Drizzle: pragmas, migration runner, LWW sync
│   ├── agent-harness/           This system: hooks, skills, kb CLI, slug resolution, session capture
│   └── obsidian-vault-ops/      Vault operations: tier model, write protocol, promotion flywheel
│
├── projects/                    Per-project state (8 active)
│   └── <slug>/
│       ├── INDEX.md             Auto-generated ≤500 bytes
│       ├── current.md           Active state (≤5 bullets hard cap)
│       ├── next.md              Open actions ([done: YYYY-MM-DD] auto-pruned)
│       ├── gotchas.md           Append-only traps
│       ├── history/             YYYY-MM-DD-HHMM.md snapshots
│       ├── archive/             Periodic rollups
│       └── plans/               Ad-hoc planning docs
│
├── infra/                       Per-machine state
│   └── <host>/current.md        superbro / monsterbro / linuxbro / homelab / cloudcli
│
├── sessions/YYYY/MM/            Auto TF-IDF captures — never hand-edited
│   └── YYYY-MM-DD-<slug>-session.md
│
├── tools/
│   ├── kb                       Canonical CLI (Python 3, stdlib only)
│   └── session-promote          Zero-token grep → sessions/candidates.md
│
└── archive/                     Retired projects/modules
```

---

## How context loads (per session)

### Default load (token-efficient, ~800 tokens)

```
personal/current.md        Active state + cross-project gotchas
personal/gotchas.md
modules/ index             One-line description per module (not the full gotchas)
projects/<slug>/           INDEX + current + next (active items only)
```

### Full load (on-demand, ~4,000 tokens)

```
kb load --full             Adds preferences.md + all module gotchas
```

Use `--full` when starting a new problem domain or after a long gap.

### Harness adapters

| Harness | How context loads |
|---|---|
| **PI** | Type `kb load` at session start; idle hook nudges + auto-prunes |
| **Cursor IDE** | `sessionStart` hook calls `brain-load.sh` → `kb load <slug>` → injected as `additional_context` |
| **Claude Code** | `SessionStart` hook in `~/dotfiles/.claude/hooks/brain-load.sh` → same `kb load` |

---

## How context saves

### Automatic (zero-token, background)

Every session stop (Cursor `stop` hook / PI `session.deleted` hook):

1. Session marker appended to `sessions/YYYY/MM/YYYY-MM-DD-<slug>-session.md`
2. `session-summarize` runs in background: reads Cursor JSONL transcript → TF-IDF + TextRank extractive summary appended to session file (pure Python stdlib, no API)
3. `kb prune` + `kb compact` run silently for the active slug

Before context compaction (`preCompact` hook):

4. Agent is instructed to persist new facts using `kb` commands before proceeding

### Manual (requires judgement)

```bash
kb current "<one-line fact>"    # append to current.md (≤5 bullets)
kb next "<open action>"         # append to next.md
kb gotcha "<trap>"              # append to gotchas.md
kb wrap "<summary>" [topic]     # save timestamped snapshot + set new focus
kb remember                     # full digest: scan sessions, propose updates, auto-prune+compact
```

**When to call what:**
- Discovery mid-session → `kb gotcha` immediately, don't wait
- New action item → `kb next`
- State changed → `kb current`
- Topic shift or end of chunk → `kb wrap`
- End of big session / before compaction → `kb remember`

---

## kb CLI — full reference

```bash
kb                          # dashboard: active slug, file sizes, history count
kb load [slug]              # inject context (all 3 tiers)
kb load --full [slug]       # inject context + preferences + all module gotchas
kb current "<fact>"         # append to current.md
kb next "<action>"          # append to next.md
kb gotcha "<trap>"          # append to gotchas.md
kb done <substr>            # mark matching next item [done: YYYY-MM-DD]
kb save "<summary>"         # write history/YYYY-MM-DD-HHMM.md
kb wrap "<summary>" [topic] # save + update current focus
kb remember [slug]          # digest + prune + compact (aka kb digest)
kb prune [slug]             # move [done:] items → history/
kb compact [slug]           # cap current.md at 5 bullets, overflow → history/
kb lint                     # validate vault against _schema/ (also runs pre-commit)
kb path                     # print active brain dir
kb slug                     # print resolved slug
```

CLI location: `$VAULT_AI/tools/kb`
Shim: `~/dotfiles/scripts/brain` → execs `kb` (transition alias)

---

## Slug resolution (how kb knows which project)

1. `--tier <t> --slug <s>` args
2. `$KB_SLUG` env var
3. `personal` — when cwd is inside `$VAULT_AI`
4. Active plan `repo:` field
5. `git rev-parse --show-toplevel` basename
6. `$PWD` basename

---

## Automation hooks — what fires automatically

### Cursor IDE (`~/.cursor/hooks.json`)

| Event | Hook | What it does |
|---|---|---|
| `sessionStart` | `brain-load.sh` | Calls `kb load <slug>` → injects 3-tier context as `additional_context` |
| `afterFileEdit` | aislop | Code quality gate |
| `preToolUse` (Shell) | rtk | Token-compressed shell output |
| `stop` | `vault-save.sh` | Session marker + TF-IDF + background prune/compact + AI nudge |
| `preCompact` | `brain-save-inject.sh` | Instructs agent to persist facts before context is lost |

### PI (`~/.pi/agent/hook/hooks.yaml` via `pi-yaml-hooks`)

| Event | Hook | What it does |
|---|---|---|
| `session.created` | session-ready | Notifies: `kb load` + `.remember` available |
| `session.idle` | idle-kb-tidy | Silent prune + compact; nudges to `.remember` |
| `session.deleted` | session-end-tidy | Final prune + compact (best-effort) |
| `file.changed` | aislop-after-edit | Code quality gate |
| `tool.before.bash` | guard-destructive | Blocks force-push, rm -rf root, publish |

**PI hook limitation:** hook stdout ≠ `additional_context`. Context injection requires the agent to run `kb load` explicitly. Idle/end hooks only do housekeeping + notifications.

---

## The promotion flywheel

```
Session work
    ↓ (auto, stop hook)
sessions/YYYY/MM/<slug>-session.md   ← TF-IDF summary appended
    ↓ (weekly, manual review)
sessions/candidates.md               ← session-promote grep scan
    ↓ (you review, keep keepers)
modules/<name>/gotchas.md            ← kb gotcha
personal/gotchas.md                  ← kb gotcha
    ↓ (next session)
additional_context injection         ← denser, cheaper, more accurate
```

Run `./tools/session-promote` weekly. Review `sessions/candidates.md`. Promote survivors with `kb gotcha`.
For big sessions: `kb remember` — scans recent sessions, proposes entries, auto-prunes.

---

## Modules — the shareable unit

Each `modules/<name>/` contains:

```
MODULE.md        What it is, owner, license, version, consumption notes
gotchas.md       Non-obvious facts (injected on kb load --full; indexed on default load)
patterns.md      Proven patterns with code snippets
decisions.md     ADR-lite: what was decided, why, what was rejected
references.md    Links back to source project brains + external docs
```

Extractable via:
```bash
git subtree split --prefix=modules/shopify -b shopify-module
git push git@github.com:akqa-den/shopify-kb.git shopify-module:main
```

All AKQA content is private by default. Only push to private org repos.

---

## Schema enforcement

`kb lint` validates:
- Project folders: required files (`current.md next.md gotchas.md`), slug format, ≤5 bullets, no orphans
- Module folders: required files (`MODULE.md gotchas.md patterns.md decisions.md references.md`)
- Personal: required files (`current.md preferences.md gotchas.md`)
- Top-level: no flat `.md` files except `AGENTS.md README.md PLAN.md`

Runs automatically on `git commit` via `.git/hooks/pre-commit`.

---

## Invariants (never break these)

- **Only `kb` writes to this vault.** No harness edits files directly.
- **`current.md` ≤ 5 bullets.** Hard cap. `kb compact` enforces it.
- **Slugs are `lowercase-kebab`.** No CamelCase, no dots.
- **No stub brains.** Empty `current.md` with only a header = lint error.
- **No flat `.md` at tier roots.** Put plans in `<project>/plans/`, docs in modules.
- **Sessions are read-only after write.** TF-IDF summariser appends; nothing else touches them.
- **AKQA content is private.** Never push modules with client work to public repos.

---

## pi-memory-md (installed but dormant)

`pi-memory-md` is installed in PI but intentionally **not configured** (`repoUrl` unset). It would create a parallel write target at `~/.pi/memory-md/` that conflicts with this vault. The three useful ideas from it are already native here:

- `kb digest` / `kb remember` → equivalent of `memory-digest`
- `kb load` tier index → equivalent of memory index injection
- `modules/` extraction → better than their flat tag approach

Do not configure `repoUrl` in `~/.pi/agent/settings.json`.
