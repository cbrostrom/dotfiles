# Finance Sanitizer Pipeline — Spec
_Created: 2026-07-08_

## Problem

Need AI-assisted budget overview without PII (account names, creditor names, addresses, IBANs) reaching cloud models. Amounts and categories are fine.

**Constraints:**
- Bank transactions: CSV available
- Betalingsservice aviseringer: PDF-only
- `actual-mcp-server` gives direct payee/account access — wrong tool for PII boundary
- Cursor subagents cannot run on local models — preprocessing must be external

## North star

```
Raw sources (local, encrypted)  →  local sanitizer  →  sanitized markdown  →  open-notebook
                                         ↓
                              alias-map.json (human-only, never in MCP path)
```

Cloud agent (Cursor) queries open-notebook only. Never sees raw PDFs, CSVs, or alias map.

## Architecture

```
┌─────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│  Bank CSV       │     │  finance-sanitize    │     │  open-notebook  │
│  BS PDF         │────►│  (local script)      │────►│  notebook:      │
│  Actual export  │     │                      │     │  finance        │
└─────────────────┘     │  1. extract          │     └────────┬────────┘
                        │  2. Presidio/regex   │              │
                        │  3. alias replace    │              ▼
                        │  4. summarize (opt)  │     ┌─────────────────┐
                        └──────────────────────┘     │  Cursor agent   │
                                 ▲                   │  (cloud model)  │
                        ┌────────┴────────┐          └─────────────────┘
                        │ alias-map.json  │
                        │ (~/Vaults/Me or │
                        │  1Password ref) │
                        └─────────────────┘
```

## Data tiers

| Tier | Location | Agent access |
|------|----------|--------------|
| **Raw** | Encrypted local folder or 1Password attachments | Never |
| **Alias map** | `~/Vaults/Me/finance/alias-map.json` (human vault, not AI vault) | Never |
| **Sanitized** | open-notebook `finance` notebook | Read via MCP |
| **Summaries** | Monthly `.md` notes in open-notebook | Read via MCP |

## Ingest sources

| Source | Format | Tool | Frequency |
|--------|--------|------|-----------|
| Bank transactions | CSV | Direct parse | Monthly |
| Betalingsservice | PDF | Docling / pdfbankstatementconverter.app → text | Per notice |
| Actual Budget | CSV export (optional) | Direct parse | Monthly |
| Manual fixed costs | Hand entry | Template row | As needed |

**Do not** wire `actual-mcp-server` to Cursor for this use case.

## Sanitization layers (run in order)

### Layer 1 — Deterministic (required)

- **Presidio** (`pip install presidio-analyzer presidio-anonymizer`) — names, emails, phone, IBAN patterns
- **Regex** — Danish CPR (`\d{6}-\d{4}`), IBAN (`DK\d{16}`), account numbers (bank-specific patterns)
- **Alias dictionary** — exact + fuzzy match against `alias-map.json` before any LLM pass

### Layer 2 — Local LLM (optional, on already-scrubbed text)

- **Runtime:** Ollama (`ollama run qwen2.5:7b` or `llama3.2`)
- **Job:** Structure into monthly summary tables, categorize unknown lines, flag unmapped strings for human review
- **Never** send raw text to cloud for redaction

### Layer 3 — Human gate

- First 3 months: spot-check every sanitized output
- Ongoing: review `UNMAPPED:` flags only

## Alias map schema

```json
{
  "version": 1,
  "accounts": {
    "Danske Bank hovedkonto": "ACCT_CHECKING",
    "Opsparingskonto": "ACCT_SAVINGS"
  },
  "payees": {
    "Norlys": "UTILITY_A",
    "Tryg": "INSURANCE_B",
    "Betalingsservice": "BS_HUB"
  },
  "fuzzy_threshold": 0.85
}
```

Store at `~/Vaults/Me/finance/alias-map.json` — outside `~/Vaults/AI/`.

## Output format (monthly note)

```markdown
# Budget summary — 2026-03
_Sanitized. Alias key: ~/Vaults/Me/finance/alias-map.json_

## Fixed (Betalingsservice)
| Alias | Amount DKK | Due |
|-------|-----------|-----|
| UTILITY_A | 847 | 1st |
| INSURANCE_B | 412 | 15th |

## Variable spending by category
| Category | Amount DKK | Δ vs prior month |
|----------|-----------|------------------|
| Groceries | 4,200 | +3% |
| Transport | 890 | -12% |

## Cashflow
| Metric | DKK |
|--------|-----|
| Income | 42,000 |
| Fixed | 8,400 |
| Variable | 12,300 |
| Net | +21,300 |

## Flags
- UNMAPPED: "XYZ ApS" — 299 DKK on 2026-03-14 (add to alias map)
```

## Tooling

| Component | Choice | Notes |
|-----------|--------|-------|
| Script home | `~/Vaults/Me/finance/tools/sanitize.py` or dotfiles `scripts/finance/` | TBD at build |
| PDF extract | Docling (self-hosted) or pdfbankstatementconverter.app | BS PDFs only |
| Redaction | Presidio + regex | Non-negotiable |
| Summarize | Ollama local | Optional |
| Publish | open-notebook MCP `create_note` or file drop | Monthly cron or manual |
| Budget app | Actual Budget | CSV export only; no MCP to Cursor |

## Security rules

1. Raw files never in `~/Vaults/AI/` or open-notebook
2. Alias map never in MCP tool path or Cursor context
3. Sanitizer runs offline; no cloud API in the pipeline
4. open-notebook notebook scoped: single `finance` notebook, sanitized notes only
5. Cursor rule: "Finance queries via open-notebook only; never request raw exports"

## Implementation phases

### P0 — Alias map + manual template (1 hour)
- Create `alias-map.json` with top 20 creditors/accounts
- Write monthly summary template by hand for one month
- Publish to open-notebook; verify Cursor can query without PII

### P1 — Deterministic sanitizer (half day)
- Python script: CSV in → Presidio + alias replace → markdown out
- Unit test: known input with fake names → zero leaks in output

### P2 — PDF ingest (half day)
- BS PDF → text extract → same sanitizer pipeline
- Manual review gate on first 5 PDFs

### P3 — Ollama summarize (optional, half day)
- Local summarization pass on redacted text only
- Category rollup, month-over-month deltas

### P4 — Automation (optional)
- Monthly cron or Raycast script: drop folder → sanitize → publish
- `UNMAPPED` flags → notification for alias map update

## Out of scope

- Real-time bank sync
- `actual-mcp-server` integration
- Cursor-native local subagent (not supported)
- 100% automated redaction without human review period
- Tax document / investment portfolio parsing (separate spec if needed)

## Open decisions

- [ ] Script lives in dotfiles vs `~/Vaults/Me/finance/tools/`
- [ ] Actual Budget as primary categorizer vs category rules in sanitizer
- [ ] open-notebook publish: MCP API vs filesystem watch

## Success criteria

- [ ] Cursor can answer "how much on utilities last 3 months?" from open-notebook
- [ ] No creditor/account real names in any sanitized note or agent context
- [ ] BS PDF → sanitized row in <5 min manual effort per notice
- [ ] `UNMAPPED` flags catch anything Presidio + alias miss
