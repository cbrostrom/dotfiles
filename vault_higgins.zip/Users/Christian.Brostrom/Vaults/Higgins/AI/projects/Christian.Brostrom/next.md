# Next: Christian.Brostrom

- **[build]** Finance sanitizer P0: alias-map + manual monthly template → open-notebook (see `spec-finance-sanitizer.md`)
