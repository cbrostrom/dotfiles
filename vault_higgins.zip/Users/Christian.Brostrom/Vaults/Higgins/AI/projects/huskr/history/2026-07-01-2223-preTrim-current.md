# Brain: huskr
_Updated: 2026-07-01_

## Current State

**P0 complete. P1 complete. P2 complete. P3 (Sync Engine) complete.**

Branch: `main`. All work merged and pushed.

### What's done (P0–P3)

- Notes fully excised, Butler lazy-mode, WAL pragmas, `SERVE_WEB=false`
- **Tauri shell complete** — tray, hotkey, hide-to-tray, quick-capture
- **Sidecar complete** — Rust spawns sidecar, reads `HUSKR_READY`, stores `{port, token}` in managed state, exposes via `get_sidecar_config` command
- **Custom migration runner** — `sidecar-migrate.ts` bundles all 31 SQL files, uses `sqlite.exec()` for multi-statement support
- **Frontend wired** — `platform.ts` auto-inits sidecar at module load, `onSidecarReady()` callback, `api.ts`/`websocket.ts` use sidecar URL + launch-token header
  - Migration 0031: `synced_at`/`sync_origin` on todos/lists/folders/tags + `sync_config` table
  - `GET/POST /sync` endpoints (apiKeyAuth, cursor-paginated, per-row LWW results)
  - `SyncEngine` class: pull then push on startup, every 30s, and on each WS client connect
  - `sync:start`/`sync:done` WS events → `syncStatus` signal → blue pulsing dot in Tauri title bar
  - Activated by inserting `remote_url` + `remote_api_key` into `sync_config` (id="default")

### Key decisions logged in gotchas.md


## Conventions
