# Context Bridge — huskr — 2026-06-30 14:03

## What we were doing

Building the Huskr Tauri desktop app — completed P0 (notes excision), P1 (Tauri shell + sidecar), and P2 (connection status UI). P3 (Sync Engine) is the active phase — not started yet, plan is written and in vault.

## Decisions made

- **Sidecar IPC via TCP localhost + launch token:** Rust spawns compiled Bun/Hono binary, reads `HUSKR_READY port=N` from stdout, stores `{port, token}` in managed Rust state. Frontend polls `get_sidecar_config` Tauri command until ready. Reasoning: avoids Unix socket complexity, works cross-platform, token prevents port hijacking.
- **Custom sidecar migration runner:** Drizzle's `prepare()` fails on multi-statement SQL in compiled binaries. Custom `sidecar-migrate.ts` imports all `.sql` files as strings via Bun import attributes and uses `bun:sqlite`'s `sqlite.exec()`. Reasoning: only way to reliably run migrations inside a VFS-constrained compiled binary.
- **CORS any-origin when isSidecar=true:** In `bun tauri dev`, the WebView loads from `http://localhost:3000` which differs from the ephemeral sidecar port — strict CORS would block all API calls. Reasoning: sidecar is local-only, launch token is the real security boundary.
- **LWW sync, server-authoritative:** `updated_at` timestamp is the conflict discriminator; server wins on ties. Tombstones via existing `deleted_at` column. Reasoning: simple, proven pattern (Wunderlist/MS Todo style), good enough for family-scale use.
- **Supabase rejected:** Too heavy, wrong fit for self-hosted + local-first hybrid. Reasoning: documented in gotchas.md.
- **No unsolicited Canvas:** User explicitly disallowed it. Only use when asked.
- **Token/cost estimates:** User prefers rough token estimates over time estimates for planning tasks.
- **P3 split into 5 chunks (3a→3b+3c→3d→3e):** ~60k tokens total. 3b and 3c can execute in parallel after 3a schema migration. Plan is authoritative in `p3-sync-plan.md`.

## Files touched

- `src-tauri/tauri.conf.json` — `titleBarStyle: "Overlay"`, `hiddenTitle: true`, no quick-capture on startup
- `src-tauri/src/lib.rs` — sidecar spawn, `SidecarConfig` managed state, `get_sidecar_config` command, tray + hotkey
- `src-tauri/Cargo.toml` — added `tauri-plugin-shell`, `uuid`
- `src-tauri/capabilities/default.json` — `allow-start-dragging`, `shell:allow-execute/kill/stdin-write`
- `apps/api/src/index.ts` — sidecar CORS any-origin, `HUSKR_READY` print, calls `runSidecarMigrations()`
- `apps/api/src/middleware/auth.ts` — `X-Huskr-Launch-Token` header auth path for sidecar
- `apps/api/src/lib/sidecar-migrate.ts` — custom multi-statement migration runner (new)
- `apps/api/src/sql.d.ts` — TS declaration for `.sql` string imports (new)
- `apps/web/src/lib/platform.ts` — `initSidecar()` idempotent, `onSidecarReady()` callback, eager auto-init in Tauri
- `apps/web/src/lib/api.ts` — dynamic `getApiUrl()`, injects `X-Huskr-Launch-Token` header
- `apps/web/src/lib/websocket.ts` — dynamic `resolveWsUrl()`, appends `?token=` for sidecar
- `apps/web/src/lib/appContext.tsx` — `connectionStatus` signal (online/offline/connecting), window online/offline events
- `apps/web/src/components/layout/AppLayout.tsx` — `ConnectionDot` component in Tauri title bar
- `apps/web/src/lib/device.ts` — `isTouchDevice()` returns `false` unconditionally in Tauri
- `apps/web/src/routes/login.tsx` — `showServerSetup` re-evaluates after sidecar init via `onSidecarReady()`
- `apps/web/src/components/settings/ConnectionContent.tsx` — active mode badge (Local/Remote/Dev proxy)
- `~/Vaults/Brain/Brains/huskr/p3-sync-plan.md` — P3 detailed plan (new)
- `~/Vaults/Brain/Brains/huskr/current.md` — updated to reflect P1+P2 done, P3 next
- `~/.cursor/rules/token-efficiency.mdc` — global rule for token-efficient tool use (new)
- `~/.cursor/rules/no-unsolicited-canvas.mdc` — global rule blocking unsolicited Canvas (new)

## Open questions

- Should `sync_config.remote_api_key` be encrypted at rest in the local SQLite? (SQLCipher deferred, but a plain API key sitting in the DB is worth discussing before 3d ships)
- Device ID strategy for `sync_origin` — random UUID generated at first launch and stored in `sync_config`? Or Tauri machine ID?

## Dead ends (don't repeat)

- **`titleBarStyle: "overlay"` (lowercase)** — invalid, must be `"Overlay"` (PascalCase). Tauri silently ignores the bad value.
- **Drizzle migrator inside compiled binary** — `prepare()` fails on multi-statement SQL. Do not try to use the standard Drizzle migrate helper in sidecar context; use the custom runner.
- **Quick-capture window on startup** — never create it eagerly in `run()`. Must be lazy (only on first hotkey/tray invoke). Took many iterations; do not regress this.
- **`isTouchDevice()` false positive in Tauri** — macOS WebKit reports `maxTouchPoints > 0` on Apple Silicon. The explicit Tauri guard is essential; don't remove it.
- **Sidecar binary in git** — gitignored intentionally. Do not try to `git add` it.
- **`navigate` in login.tsx** — was unused, caused TS6133. Already removed.

## Exact next step

Start **P3a — Schema migration**:
1. Read `packages/db/src/schema.ts` (current schema)
2. Add `synced_at` (INTEGER nullable) and `sync_origin` (TEXT nullable) to `todos`, `folders`, `lists`, `tags` tables
3. Add new `sync_config` table (`id`, `last_sync_ts`, `remote_url`, `remote_api_key`)
4. Run `bun run db:generate` to generate the migration SQL
5. Update `apps/api/src/lib/sidecar-migrate.ts` to import the new `.sql` file
6. Run `bun run typecheck` to confirm no errors

## Context to reload

- Brain: `brain load` in `/Users/Christian.Brostrom/Projects/Private/huskr`
- Key files on resume:
  - `~/Vaults/Brain/Brains/huskr/p3-sync-plan.md` — P3 plan (authoritative)
  - `packages/db/src/schema.ts` — schema before touching anything
  - `apps/api/src/lib/sidecar-migrate.ts` — understand existing pattern before extending
  - `apps/api/src/index.ts` — router mounts + sidecar mode detection
