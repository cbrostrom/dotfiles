# Brain: huskr
_Updated: 2026-07-01_

- P0–P3 complete. Tauri shell + Bun sidecar + custom migration runner + frontend wired to sidecar via launch-token.
- Sync engine (P3): LWW bidirectional between local sidecar and remote, `GET/POST /sync` (cursor-paginated), pull-then-push on startup + every 30s + on WS connect.
- Notes archive read-only on `archive/huskr-with-notes` branch. Main is pivoted; no PRs against archive.
- Activate sync by inserting `remote_url` + `remote_api_key` into `sync_config` (id="default").
- Full architecture + gotchas distilled to `modules/bun-sqlite-hono/` + `modules/tauri-solidjs/`; project-specific in `gotchas.md`.
