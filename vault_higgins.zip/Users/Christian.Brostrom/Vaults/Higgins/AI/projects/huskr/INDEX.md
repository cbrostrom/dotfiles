# Brain index: huskr
- current.md (8L) — _Updated: 2026-07-01_
- gotchas.md (31L) — - **Bun does not run on iOS.** Tauri iOS (P3) cannot use the
- next.md (60L) — All items complete. See `current.md`.
- history/ — 4 session(s), last 2026-07-01-2223-preTrim-current
