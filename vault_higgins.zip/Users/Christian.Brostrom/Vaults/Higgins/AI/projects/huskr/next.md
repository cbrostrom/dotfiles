# Next: huskr

## P0 ✅ — Notes excision + backend slim + Butler lazy-mode

All items complete. See `current.md`.

---

## P1 — Tauri desktop shell (in progress)

### Done
- [x] Tauri scaffolded, `bun run dev` starts everything
- [x] Connected mode: Settings → Connection, first-run server URL gate on login
- [x] Tray icon + hide-to-tray
- [x] Global hotkey `⌘⇧Space` + quick-capture floating window
- [x] Sidecar step 1: API sidecar-ready (HUSKR_SIDECAR, HUSKR_LAUNCH_TOKEN, HUSKR_READY signal)
- [x] Sidecar step 2: `bun run build:sidecar` → `src-tauri/binaries/huskr-api-<triple>`

### Remaining (paused at step 3 — meaty, token-expensive)
- [ ] **Step 3** — Rust: spawn sidecar, read port from stdout, expose `get_sidecar_config` command
  - Add `tauri-plugin-shell` to Cargo.toml + capabilities
  - Register `SidecarState { port: u16, token: String }` in app state
  - In `setup()`: generate UUID token → spawn with env vars → read stdout until `HUSKR_READY port=N`
  - Kill child on `RunEvent::Exit`
  - Expose `#[tauri::command] get_sidecar_config() → { url, token }`
- [ ] **Step 4** — Frontend: mode awareness
  - `platform.ts`: `getSidecarConfig()` calls `invoke("get_sidecar_config")`
  - `api.ts`: if sidecar → use `http://127.0.0.1:{port}`, inject `X-Huskr-Launch-Token` header
  - `websocket.ts`: if sidecar → use `ws://127.0.0.1:{port}`
  - Settings → Connection: Local / Remote toggle (store in `huskr_mode` localStorage)
- [ ] **Step 5** — Encryption key persistence
  - Rust: check `app_data_dir()/.huskr_enc_key`; if missing, generate 32 random bytes → hex → write
  - Pass to sidecar as `ENCRYPTION_KEY` env var

### Other P1 items
- [ ] Auto-update (stable channel only) — `tauri-plugin-updater`
- [ ] Code-signing stubs (macOS notarization, Windows Authenticode)
- [ ] GitHub Actions build + release workflow

---

## P2 — Sync delta + connectors + grocery beachhead

Full spec: `pivot-tauri.md`.

---

## P3 ✅ — Sync Engine

All chunks complete (3a → 3e). See `current.md` for details.

### Done
- [x] 3a — Schema migration 0031: synced_at/sync_origin on todos/lists/folders/tags + sync_config table
- [x] 3b/3c — GET+POST /sync LWW endpoints (apiKeyAuth, cursor pagination, per-row results)
- [x] 3d — SyncEngine: push/pull loops, 30s interval + WS-connect trigger, HUSKR_SIDECAR guard
- [x] 3e — sync:start/sync:done WS events, syncStatus signal, blue pulsing dot in Tauri title bar

### What's still needed to activate sync at runtime
- [ ] Insert a row into `sync_config` (id="default") with `remote_url` + `remote_api_key` on the sidecar DB
- [ ] Consider a Settings UI for configuring sync (remote URL + API key input)
