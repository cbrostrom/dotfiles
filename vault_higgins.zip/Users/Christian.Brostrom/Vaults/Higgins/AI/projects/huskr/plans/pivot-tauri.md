# Huskr — Pivot Spec: Todo-Only + Tauri v2 + Sharp Sync Backend

_Status: draft (approved direction, not started)_
_Updated: 2026-06-21_
_Owner: Christian_

Huskr keeps its name. The product narrows to **todos only** with optional per-todo markdown content. The web stays available but becomes secondary. Native Tauri desktop apps become the primary surface, with PWA + Raycast + iOS Shortcuts + MCP as quick-capture connectors. Backend is sharpened into a thin sync + sharing service. iOS Tauri is on the roadmap but not P0.

## Glossary

- **Tauri v2** — Rust-based framework for building native desktop (and now mobile) apps that wrap a system webview. The visible window is the webview; logic that needs the OS lives in Rust.
- **Sidecar** — an extra executable bundled inside a Tauri app and launched by it as a child process. For Huskr the sidecar is the **Bun/Hono API server compiled to a single binary** via `bun build --compile`. Tauri starts it on app launch and kills it on exit. The frontend talks to it exactly like it talks to a remote API today.
- **IPC** — Inter-Process Communication. How the frontend (in the webview) reaches the sidecar (a separate OS process). We use **TCP on `127.0.0.1`** with an ephemeral port + per-launch random token. From the frontend's POV it's just `fetch()`.
- **Local mode** — Tauri app running with the sidecar + local SQLite only; no server involved.
- **Connected mode** — Same Tauri app, additionally syncing to a remote Huskr server over HTTP + WebSocket.
- **Sync arbiter** — Whoever decides the canonical ordering of conflicting changes. For Huskr: the **server** when online; LWW per field for shared rows; LWW per row for solo rows.

## Vision

> A todo app for people for whom todos are the main thing. Instant capture, instant sync, instant render. Optional cloud — fully local by default. Sharp enough that capture beats Apple Reminders and organisation beats Todoist. Soul of Wunderlist, feel of Microsoft Todo, ADHD-friendly categorisation, and *sync that actually works*.

## Design north

The UX bar is **Microsoft Todo / Wunderlist** — familiar, calm, focused. The
current Huskr web UI already hits this bar; don't reinvent it. The pivot is
about *what runs underneath* (sync, performance, Tauri shell) and *what's
removed* (notes, always-on Butler), not about rethinking the visual product.

## Beachheads

Two complementary "this is what success looks like" anchors. Every decision is
checked against both.

1. **Primary product beachhead — a solid solo todo app.** Match Microsoft Todo
   in look-and-feel and reliability, then *exceed* it on: instant capture,
   ADHD-friendly categorisation, keyboard ergonomics, performance, and offline.
   This is paramount. If the solo experience isn't great, nothing else matters.
2. **Family-adoption beachhead — shared grocery list with auto-categories and
   attribution.** The single concrete feature that gets the wife (and family
   members of other users) to actually adopt Huskr instead of MS Todo:
   - a list shared with one or more people in the same instance
   - items auto-grouped by aisle/category (produce, dairy, frozen, …) using
     the existing `heuristicTagger` + `storeFrequency` infrastructure
   - "added by Christian" attribution surfaced on each item — a feature MS
     Todo conspicuously lacks
   - real-time sync that actually feels real-time

Success metric for #2: wife uses it weekly without prompting.

## Positioning

- Native-first (Tauri desktop) — web is a fallback, not the focus.
- Local-first — Tauri app runs entirely offline with its own SQLite. Sign in for sync only when sharing is desired.
- INSTANT — every interaction is optimistic; sync is push-based via WebSocket; cold-start budgeted at <600ms.
- Connector-rich — Raycast, iOS Shortcuts, MCP, x-callback-url, share targets. Capture from anywhere in <2s.
- Family-shareable — spaces + memberships kept from current Huskr.
- Personal tool, possibly open-sourced later — no billing, no multi-tenant SaaS, no enterprise complexity. Self-host first-class. License decision deferred.

## Scope

### In
- Todos (the only first-class content primitive).
- Per-todo markdown content field (optional, render in expanded view).
- Lists, folders, tags, shares, reminders, recurrence, smart lists, Butler AI, MCP.
- Tauri v2 desktop apps (macOS, Windows, Linux).
- PWA (existing) — for users without the native app.
- Raycast extension, iOS Shortcuts, MCP connector (already exists), x-callback-url.
- Optional self-hostable sync server (current Bun/Hono backend, sharpened).

### Out (P0)
- **Notes** as a content primitive — removed entirely.
- Tauri iOS / Android — deferred to P3.
- Voice capture — deferred.
- Calendar integration — deferred to P3.

### Out (forever, probably)
- Mixed timeline of notes+todos — gone with notes.
- Long-form note workflows (table of contents, backlinks, etc).

## Naming & Identity

- **Name stays: Huskr** (Danish "to remember"). Fits the pivot — a todo app *is* a remembering tool.
- Tagline candidate: _"Huskr. Husk det hele."_ (Remember it all.) — refine when designing.
- Logo direction: TBD; the current logo can be retained or refreshed but is not blocking.

## Architecture

### High level

```
┌────────────────────────────────────────────────────────────┐
│  Tauri Desktop App (mac/win/linux) — primary client        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  SolidJS frontend (shared with web)                  │  │
│  │  Data layer: HuskrClient interface                   │  │
│  │    ├─ LocalSidecarClient (Bun sidecar + SQLite)      │  │
│  │    └─ RemoteHttpClient   (HTTP + WS to server)       │  │
│  └──────────────────────────────────────────────────────┘  │
│  Sidecar: bun-compiled API binary (only when local mode)   │
│  Tray, global hotkey, quick-capture window, auto-update    │
└────────────────────────────────────────────────────────────┘
                            │ (optional, when signed in)
                            ▼
┌────────────────────────────────────────────────────────────┐
│  Sync Server (Bun/Hono — sharpened existing backend)       │
│  • REST + WS + MCP (HTTP)                                  │
│  • Spaces, memberships, shares                             │
│  • Delta sync endpoint                                     │
│  • SQLite (Drizzle) — same schema as local                 │
│  • PWA static serving (the web client)                     │
└────────────────────────────────────────────────────────────┘
                            ▲
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
  Raycast ext          iOS Shortcuts         PWA (web)
  (HTTP + token)       (x-callback-url +     (HTTP + WS)
                       REST)
```

### The "sharp backend" principle

- Backend has **one job**: be the sync + sharing arbiter for clients that opt in.
- It stops being a frontend host once Tauri ships — PWA continues to be served, but no longer "the product".
- Business logic must be **portable** between server and Tauri sidecar — co-locate it in `packages/core` (new) so the same code runs in both.
- Strip everything notes-related from routes, schemas, MCP tools, UI.

### Local vs. Connected mode (Tauri)

| Aspect | Local mode | Connected mode |
|---|---|---|
| DB | `~/Library/Application Support/Huskr/local.db` (**SQLCipher-encrypted**) | Same local DB + WS pipe to remote |
| API | Bun sidecar bound to `127.0.0.1:<random>` + per-launch random token | Same sidecar, plus sync agent |
| Writes | Local SQLite, instant | Local SQLite immediately, then WS-push to server |
| Reads | Local SQLite | Local SQLite (server is source-of-eventual-truth, not on the read path) |
| Sharing | Disabled | Enabled via spaces |
| Local MCP | Sidecar's MCP endpoint exposed on the same loopback port, gated by the per-launch token | Same — and additionally the remote server's MCP is reachable via the normal API key flow |

The sidecar is the same binary in both modes. "Connected" just enables the sync agent and points it at a server URL with a session cookie/token.

### Sidecar IPC

- Sidecar binds to `127.0.0.1:<ephemeral-port>` chosen at launch.
- On startup, sidecar emits a per-launch token to stdout; Tauri reads it and
  injects `Authorization: Bearer <token>` into every frontend `fetch()` via a
  webview request interceptor. Token is never written to disk.
- The frontend treats the sidecar identically to a remote API — same Hono
  routes, same WS endpoint, just a different base URL. No new code paths.
- The **MCP endpoint** is reachable at the same base URL; settings surfaces a
  copy-paste Claude Desktop / Raycast config snippet ("Local MCP — works
  while Huskr is running"). Token rotates each launch, so the snippet is
  generated dynamically and copied with one click.
- UDS / named-pipe deferred to P2; revisit only if IPC latency shows up in
  profiles.

### Encryption-at-rest

- Local DB is **SQLCipher-encrypted**. Key is derived (Argon2id) from a
  passphrase set on first launch.
- Derived key cached in the OS keychain (macOS Keychain / Windows Credential
  Manager / libsecret on Linux) so the passphrase is asked at most once per
  device after install.
- "Forgot passphrase" → wipe + re-sync from server (Connected mode) or factory
  reset (Local mode). Document clearly in onboarding.

### Sync protocol (Phase 1)

- Every row gets `updated_at` (epoch ms, server-authoritative when online) and `server_version` (monotonic per space).
- WS broadcast: on every server-confirmed mutation, push the full row payload to all space members, scoped by `spaceId`.
- Initial / reconnect sync: `GET /sync/since?space=<id>&cursor=<server_version>` → list of changed rows + new cursor.
- Conflict policy: **server timestamp wins** when online. Offline mutations queue locally with `client_op_id` + `client_ts`; on reconnect they replay through the server which arbitrates (LWW per field for shared rows, last-write-wins per row for solo rows).
- Tombstones: deletes are soft; replicated as `deleted_at` rows; hard-purge after 30 days server-side.
- Optimistic UI: client commits locally immediately, displays as `pending`, reconciles on ACK or rollback.

### Connectors (P2)

- **Raycast**: thin TS extension hitting `/api/*` with a stored API key. Quick-capture command, Today view, search.
- **iOS Shortcuts**: REST + x-callback-url scheme `huskr://capture?title=…&list=…&due=…` (PWA-handleable + Tauri-handleable).
- **MCP**: already exists. Sharpen for todo-only after notes are removed (drop `mcp/tools/notes.ts`).
- **Share target**: PWA manifest `share_target` + Tauri OS-level "Add to Huskr" share-extension (macOS Services, Windows share menu).
- **Alfred** (bonus): same as Raycast pattern.

## Performance budget

| Metric | Target |
|---|---|
| Tauri cold start to interactive | < 600 ms |
| Capture keypress → visible todo | < 50 ms |
| List render (1000 todos, first paint) | < 100 ms (virtualized) |
| WS sync roundtrip p50 | < 100 ms |
| Local DB read for "today" view | < 5 ms |
| Sidecar memory ceiling | < 150 MB RSS |
| Bundle size (Tauri desktop dmg) | < 80 MB |

## AI scope — Butler in lazy-mode

**Root cause from the brainstorm:** the current Butler design pegs the VPS on
memory + CPU. The always-on inbox watcher is the culprit — it's a background
worker that processes mutations continuously and is expensive both in compute
and in LLM tokens.

**Decision:** **kill the always-on inbox watcher.** Butler becomes a strict
on-demand feature in the pivot. This drops the steady-state load on the VPS to
near zero and makes Huskr cheap to self-host.

### Lazy Butler behaviour

| Trigger | Behaviour |
|---|---|
| User presses Enter on a quick-capture | NLP parse runs **synchronously inline** (already fast — `dateParser/`, heuristic tagging). LLM is only invoked if the heuristic layer is ambiguous *and* the user has Butler enabled. |
| User opens a todo | Auto-tag / category suggestions computed lazily, cached on the row. No background sweep. |
| User invokes "Tidy my inbox" from the UI | One-shot batch run, with a visible progress indicator and token budget cap. User sees what it cost. |
| Reminders | Stay scheduled the existing way (cron-style, cheap). |

### Self-host kill switches

- `BUTLER_ENABLED=false` env flag — disables every LLM-touching path. Hosted
  users get the option in Settings.
- LLM call budget: per-user daily token cap, enforced server-side.
- No background workers running when no user has Butler enabled.

### Removed
- Note summarisation / expansion (gone with notes).
- The always-on inbox watcher entirely.
- Any periodic cron that fans out LLM calls.

### Possible future additions (not P0–P2)
- **Morning agenda** — opinionated brief of today's todos. On-demand, generated
  when user opens it. Cached for the day.
- **Stale-todo nudge** — weekly summary of todos languishing > 14 days. Run
  weekly per user, not continuously.
- **Voice capture** — deferred.

## Migration plan (from current Huskr → pivot)

1. **Archive branch**: `git checkout -b archive/huskr-with-notes && git push -u origin archive/huskr-with-notes` — frozen, reference only.
2. **Work branch**: `pivot/todo-only` on `main`.
3. **Notes removal pass**:
   - Delete `apps/api/src/routes/notes.ts`, `apps/api/src/lib/mcp/tools/notes.ts`, `noteLastSeen.ts`, all note components in `apps/web/src/components/`, note-specific hooks, note routes in web router.
   - Schema migration: drop `notes` table + any note-referencing columns/indexes.
   - Update `mcp/tools/overview.ts` to drop note references.
   - Strip "mixed timeline" code paths from Inbox/All views — now todos-only.
   - Update README, CLAUDE.md, .cursor rules.
4. **Drizzle migration** generated + manually reviewed before merging to `main`.
5. **No data migration** for existing note content — users wanting to preserve notes can run `archive/huskr-with-notes` or export from the DB before upgrading. Add a one-liner in release notes.

## Phasing & rough effort

Corrected 2026-06-26: the sync investigation was based on a misunderstanding —
the described bug was Microsoft Todo's behaviour, not Huskr's. Huskr's sync
has been fine since the WebSocket fix. Sync delta work (offline queue, test
harness, `server_version`) is deferred to P2 when multiple native clients
actually need it.

### P0 — Notes excision + backend slim + Butler lazy-mode (1–2 weeks evenings)

**Goal:** delete dead weight and make the server Vaultwarden-style — lean,
self-hostable, no notes bloat, no always-on Butler eating VPS resources.

- Archive branch: `archive/huskr-with-notes` pushed and frozen.
- Remove notes: routes, schema (Drizzle migration), MCP tools, UI, hooks,
  types, mixed-timeline code paths.
- Extract portable logic into `packages/core` so it can run in both server
  and Tauri sidecar.
- Add `SERVE_WEB=false` mode for headless deployments.
- Audit SQLite indexes + WAL pragmas.
- **Butler lazy-mode rewrite** (see "Butler" section below).
- Update README, CLAUDE.md, .cursor rules to reflect todo-only positioning.

### P1 — Tauri desktop shell (2–3 weeks)

**Goal:** ship the native desktop app.

- `apps/desktop/` Tauri v2 project.
- Bundle SolidJS frontend (shared build).
- Bun sidecar build (`bun build --compile` per platform).
- Local / Connected mode switching in onboarding.
- SQLCipher-encrypted local DB (Argon2id passphrase + OS keychain caching).
- Local MCP endpoint exposed via the sidecar (token-gated, copy-paste config
  for Claude Desktop / Raycast).
- Tray, global hotkey, quick-capture window, auto-update via Tauri updater
  (stable channel only).
- Code-signing setup (macOS notarization, Windows EV cert deferred).
- Distribute via GitHub Releases.

### P2 — Sync delta + connectors + grocery-beachhead polish (2 weeks)

**Goal:** make sync rock-solid across multiple native clients, add connectors,
and polish the family-adoption beachhead. Sync delta work deferred here
because you only need it once Tauri + iOS clients exist.

- Polish the shared grocery list flow end-to-end: invite, auto-categorisation,
  attribution chip on each item, mobile-first interactions.
- Raycast extension (quick-capture, today view, search).
- iOS Shortcuts pack + `huskr://` x-callback-url handler.
- Share target (PWA `share_target` + Tauri OS share extension).
- Performance pass to hit the budget table.
- Alfred workflow (bonus).

### P3 — Mobile + calendar (later)
- Tauri iOS evaluation. Likely **sync-only mode** there (Bun sidecar doesn't run on iOS; either require server or port hot-path routes to Rust + sqlx).
- iCal/CalDAV: due-dated todos appear in user's calendar; one-way push first, two-way later.

## Decisions & open questions

Format: **Q** (when posed) → **A** (decision + date). Questions kept visible so
future sessions see the reasoning, not just the outcome.

### Resolved

**Q (2026-06-21):** Sidecar IPC on the Tauri client — bind to ephemeral TCP port
on `127.0.0.1`, or use a Unix Domain Socket?
**A (2026-06-21):** **Ephemeral TCP localhost + per-launch random token** for
P1. Frontend `fetch()` calls stay byte-identical to today's web client, zero new
code paths. Revisit UDS in P2 if profiling shows IPC latency matters.

**Q (2026-06-21):** Auto-update channels — stable + beta, or stable only?
**A (2026-06-21):** **Stable only.** No beta channel until there is real demand.

**Q (2026-06-21):** Multi-user per instance — should one self-hosted Huskr serve
multiple users with private lists + shared lists?
**A (2026-06-21):** **Yes — already supported via spaces + memberships.** Each
user has a personal space (private lists) and can be a member of shared spaces
(lists visible to all members of that space). This is locked in; no change to
the existing model needed.

**Q (2026-06-21):** Should the local sidecar expose its MCP endpoint to other
apps on the machine (so Claude Desktop, Raycast, etc. can talk to the local DB
without a server)?
**A (2026-06-21):** **Yes — make the sidecar's MCP endpoint reachable.** Bind
behind the same per-launch token used by the frontend, document it as "local
MCP" in settings, surface a copy-paste config snippet for Claude Desktop. This
turns Huskr into a personal organisation hub even in fully-local mode.

**Q (2026-06-21):** Encrypted-at-rest for `local.db`?
**A (2026-06-21):** **Yes — integrate SQLCipher.** Key derived from a passphrase
set during first-run (with OS keychain caching so it's not re-entered every
launch). Locked in for P2 (Tauri shell phase, where the local DB first exists).

**Q (2026-06-21 brainstorm):** Phasing — current spec puts notes-removal in P0
and sync upgrade in P2, but the real failure mode is sync itself ("todos get
re-added as incomplete", sync is slow). Shouldn't sync lead?
**A (2026-06-21):** **Yes — reorder.** P0 = sync correctness pass with
observability, repro of re-incomplete bug, and a test harness. P1 = notes
excision + backend slim + Butler lazy-mode. P2 = Tauri shell. P3 = connectors
+ grocery beachhead polish. P4 = mobile + calendar. Rationale: shipping a
faster Tauri client on top of broken sync would lose data faster, not slower.

**Q (2026-06-21 brainstorm):** "Butler is way too resource consuming" — which
resource specifically, and does Butler survive the pivot?
**A (2026-06-21):** **VPS memory + CPU.** The always-on inbox watcher is the
problem. Fix: **kill the always-on watcher.** Butler becomes strictly
on-demand — NLP parse runs synchronously at capture, auto-tag/category
suggestions are computed lazily when a todo is opened, "tidy my inbox" is a
one-shot user-invoked batch with a visible token budget. Add
`BUTLER_ENABLED=false` env kill switch for self-hosters. Steady-state Butler
load drops to ~zero.

**Q (2026-06-21 brainstorm):** Is "shared grocery list with auto-categories +
attribution" THE beachhead, or one of multiple?
**A (2026-06-21):** **Dual beachhead.** Primary: a solid solo todo app
matching Microsoft Todo / Wunderlist quality (paramount — nothing else
matters if this isn't great). Secondary, for family-adoption: the shared
grocery list with auto-categorisation + attribution. Both anchored in the
spec; every decision is checked against both. Success for grocery = wife uses
it weekly without prompting.

**Q (2026-06-21 brainstorm):** Tauri vs Electron / Wails / Flutter / native?
**A (2026-06-21):** **Tauri v2 is correct.** Numbers (rough): Tauri bundle
~5–10 MB vs Electron ~120–180 MB; RAM ~40–80 MB vs ~150–300 MB; cold start
~200–400 ms vs ~600–1200 ms. With the sidecar architecture the Rust footprint
is ~100–300 lines, mostly tauri.conf.json plus copy-paste command stubs for
tray/hotkey. No need to learn Rust deeply.

### Still open

**Q (2026-06-21):** Multi-account on the Tauri **client** — should one desktop
app switch between multiple servers (e.g. work + family) without logging out?
This is distinct from multi-user-per-server which is resolved above.
**A:** Not P1. Revisit in P2 if real need surfaces — most likely add a "server
profile" picker that swaps the active token + sync target.

**Q (2026-06-21):** Bun-on-iOS reality check before P3 starts (or commit to a
Rust port of the hot-path routes for mobile then).
**A:** Defer to start of P3. Track Bun mobile status quarterly; if still no
iOS support by P3, port the sync-critical routes (todos CRUD + `/sync/since`)
to Rust + sqlx and have iOS run sync-only-mode (server required).

## Non-goals (explicit)

- Real-time collaborative editing of a single todo's content (Notion-style). Family use doesn't need it.
- Cross-space anything. Spaces remain hard boundaries.
- Plugins / extensions API. MCP is the extension story.
- Built-in calendar UI. Calendar **integration** yes; building a calendar no.

## Success criteria

- Wife uses it daily on her phone (PWA) and macOS (Tauri).
- Capture from Raycast / Shortcuts feels faster than Apple Reminders.
- Cold start + capture latency under budget on a 2020 M1 Air.
- Zero data loss across 30 days of mixed local + connected use.
- Self-host instructions fit on one README page.
