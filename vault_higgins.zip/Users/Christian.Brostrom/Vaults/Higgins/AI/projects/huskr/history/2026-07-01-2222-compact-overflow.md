# Compact overflow — huskr — 2026-07-01 22:22

- **Connection status** — `connectionStatus` signal (online/offline/connecting), dot indicator in Tauri title bar
- **Settings → Connection** — shows active mode (Local sidecar / Remote / Dev proxy)
- **P3 Sync Engine complete** — LWW bidirectional sync between sidecar and remote:
- Supabase rejected as sync layer (too heavy, wrong fit)
- SQLCipher passphrase loss is destructive
- Shared lists not synced via sidecar (createdById-scoped) — server-authoritative only
- Device origin is static `"sidecar"` string (audit only, no LWW impact); device UUID deferred
- Conventional Commits, lowercase, no period, verb-first. See `.cursorrules`.
- Notes feature removed. `archive/huskr-with-notes` branch is frozen.
- Local-first by default; cloud sync is opt-in. Server is arbiter when online, LWW on `updated_at`.
- Sidecar IPC: TCP localhost + `X-Huskr-Launch-Token` header (per-launch UUID from Rust).
- Auto-update: stable channel only.
- Multi-user per instance: confirmed via spaces + memberships.
- Butler lazy-mode: on-demand only, never always-on.
- Personal tool, possibly OSS later. No billing.
