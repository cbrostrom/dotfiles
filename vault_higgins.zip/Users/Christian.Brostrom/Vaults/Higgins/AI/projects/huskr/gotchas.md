# Gotchas: huskr

- **Bun does not run on iOS.** Tauri iOS (P3) cannot use the Bun sidecar — plan
  ahead for either a "sync-only" iOS client (requires server) or a Rust port of
  the hot-path routes + sqlx. Decide before P3 starts, not during.
- **MCP audit log scope.** Audit log lives in `mcp_audit_log` and currently only
  records writes. When notes routes are removed, also drop any
  notes-tool audit entries via migration or accept stale references.
- **Notes archive branch is read-only.** No PRs against `archive/huskr-with-notes`.
  If a notes feature ever needs to come back, cherry-pick from archive into a
  fresh branch on top of pivoted main.
- **`ENCRYPTION_KEY` (64-char hex) is still required** even after the pivot —
  Butler stores encrypted LLM API keys.
- **WebSocket cookie auth** must keep working through reverse proxies; Traefik
  `responseforwarding.flushinterval=0ms` is load-bearing for INSTANT sync.
- **PWA on iOS Safari** supports push since 16.4, but only when added to home
  screen. Document this in onboarding before assuming notifications work.
- **Per-launch sidecar token is not persisted.** If the user inspects the local
  MCP snippet, copies it into Claude Desktop, then restarts Huskr, the token
  changes — Claude Desktop will fail until the snippet is re-pasted. Surface
  this clearly in settings (or have Tauri auto-update Claude's config file
  with the new token — investigate in P2).
- **Supabase is not the right sync layer for this project (decided 2026-06-28).**
  Self-hosted Supabase is 20+ Docker services — opposite of Vaultwarden simplicity.
  Their Realtime is WebSocket-to-table-changes, which is already solved by the existing
  WS broadcast layer. Local-first/offline would still require a separate layer (PowerSync,
  ElectricSQL) on top. Butler/AI still needs a custom server regardless. Verdict: stay
  on Bun + SQLite. **PowerSync** is worth revisiting post-P1 if delta sync proves hard.
- **SQLCipher passphrase loss is destructive.** "Forgot passphrase" means
  factory-reset in Local mode, re-sync from server in Connected mode. Make
  this loud during onboarding so nobody learns it the hard way.
