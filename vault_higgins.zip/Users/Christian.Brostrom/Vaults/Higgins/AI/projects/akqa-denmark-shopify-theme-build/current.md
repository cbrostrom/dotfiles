# Brain: akqa-denmark-shopify-theme-build
_Updated: 2026-07-01_

- Active AKQA DEN client — Shopify theme build project (Liquid + Tailwind)
- Consumes patterns from `modules/shopify/` (private team module)
- Extraction history: see `projects/stellar-shopify/plans/akqa-denmark-shopify-theme-build-extraction.plan.md`
- Status: initial content pending — **user to seed real current state on next session**
- Sharing: internal AKQA only
