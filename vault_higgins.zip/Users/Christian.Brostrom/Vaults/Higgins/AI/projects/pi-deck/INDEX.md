# Pi Deck

Native desktop agent workspace — Tauri v2 + SolidJS + Pi RPC. Workspace-aware session manager with structured event rendering, progressive enhancement, and command bar.
