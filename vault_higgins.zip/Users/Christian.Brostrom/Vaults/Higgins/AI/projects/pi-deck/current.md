# Brain: pi-deck
_Updated: 2026-07-02_

- Spec complete: `plans/2026-07-02-pi-deck.plan.md` — 6 phases, Tauri v2 + SolidJS + Pi RPC mode
- Stack confirmed: SolidJS (fine-grained reactivity, no VDOM), Tailwind v4, Pi RPC JSONL protocol
- Pi SDK surface mapped: `createAgentSession`, RPC mode, typed `AgentSessionEvent` stream, extension hooks
- Key patterns carried from huskr: sidecar IPC, `data-tauri-drag-region`, `jiggle_cursor`, stable `<For>` keys
- Progressive enhancement via `~/.pi/agent/settings.json` package detection — features light up per installed packages
