# Gotchas: pi-deck

- **Pi RPC JSONL framing**: split records on `\n` only. Do NOT use Node `readline` — it splits on U+2028/U+2029 which are valid inside JSON strings. Use raw line-by-line parsing.
- **RPC `steer` vs `followUp`**: during streaming, `steer` delivers after current tool calls finish (before next LLM call); `followUp` waits until the entire turn completes. Use `steer` for quick-send.
- **`tool_execution_update.partialResult` is accumulated**: it contains ALL output so far, not just the delta. Replace the entire display on each update, don't append.
- **Pi child process cwd**: must pass `--cwd` or set the working directory on the spawned process for session naming + resource discovery to work correctly.
- **Session file path encoding**: `cwd` has `/` replaced with `-`, wrapped in `--`. E.g. `/Users/foo/project` → `--Users-foo-project--/`.
- **Window drag + frameless**: `data-tauri-drag-region` on title bar div ONLY. Never on the whole window. Test immediately after any layout change.
- **macOS traffic lights with frameless**: need `hiddenTitle: true` + explicit positioning offset.
- **Pi extensions in RPC mode**: `ctx.hasUI === true` and `ctx.mode === "rpc"`. Extension UI dialogs (select, confirm, input) are forwarded as JSON protocol events. `custom()` returns undefined in RPC mode.
