# Next: pi-deck

- [ ] Execute Phase 1: Tauri scaffold + frameless window + single-session RPC chat
- [ ] Validate Pi RPC spawning works cleanly from Tauri child process
- [ ] Test window drag region early — known footgun from hopper/huskr
- [ ] Decide repo location: standalone or monorepo with companion extension
