# Dotfiles — Command Cheatsheet

## kb

```bash
kb load                              # load vault context (personal + modules + project brain)
kb map scan                          # refresh project registry
kb map codebase --all --missing-only # generate CODEBASE.md skeletons for repos that lack them
kb map list                          # read registry without rescanning
kb map doctor                        # AI setup audit
kb current "<text>"                  # save session note to current.md
kb next "<text>"                     # add task/next-step to next.md
kb gotcha "<text>"                   # save gotcha to gotchas.md
kb remember                          # full session digest → vault snapshot
```

## agent-core-sync

Syncs AGENTS.md-level behavioral rules across harness-specific configs.

```bash
DOTFILES_DIR=~/dotfiles ~/dotfiles/scripts/agent-core-sync.sh
```

## dotfiles update

```bash
dotfiles --update    # interactive TUI update (local only)
/dotfiles            # skill: local update + propagate to servers
```

## codebase-memory-mcp

```bash
codebase-memory-mcp config set auto_index true     # enable auto-indexing on file save
codebase-memory-mcp cli index_repository           # manually index current repo
codebase-memory-mcp cli list_projects              # list indexed projects
codebase-memory-mcp cli get_architecture           # dump architecture graph for current repo
```

MCP tools (in Cursor/CC): `search_graph`, `get_architecture`, `trace_path`

## map-doctor

AI setup audit — checks brain files, CODEBASE.md coverage, agent rule consistency.

```bash
kb map doctor
```

## project-mcp

Inject per-project MCP servers into `.claude/settings.json`.

```bash
project-mcp add akqa        # inject atlassian-akqa
project-mcp add fiskars     # inject atlassian-fiskars
project-mcp add shopify     # inject shopify-dev
project-mcp list            # show active project MCPs
project-mcp remove akqa     # remove
```

## sync-agent-rules

Drift detection — checks key behavioral rules exist in both `core.mdc` and `AGENTS.md`.

```bash
~/dotfiles/scripts/sync-agent-rules.sh    # exits 0 if clean, 1 if drift detected
```
