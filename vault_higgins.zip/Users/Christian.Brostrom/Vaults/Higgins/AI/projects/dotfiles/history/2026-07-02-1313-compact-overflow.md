# Compact overflow — dotfiles — 2026-07-02 13:13

- hooks.yaml: `vault-ctx-index` (session.created) + `kb-write-reindex` (tool.after.bash) keep FTS5 vault index fresh; full bootstrap done 2026-07-02.
