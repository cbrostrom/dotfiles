# Session — 2026-07-08 — Cursor cost audit + budget tiers

## Done
- Identified Jul 1–2 usage spike: PI→Cursor bridge sessions (not chat)
- Implemented budget tiers (high/medium/low) in core.mdc with `.low` `/low` etc. triggers
- Capped brain-load hook; cleared PI cursor enabledModels; added mcp.minimal.json

## Usage habit
- Ask mode: questions, compare, audit (no edits)
- Agent + `.low`: trivial fixes
- Agent, no tag: high rigor (default)

## Next
- Optional: compare-only rule in core.mdc
- Swap MCP minimal for daily non-Shopify work
- Review Jul 2 billing in Cursor dashboard
