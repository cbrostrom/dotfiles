# Dotfiles Cleanup Spec
_Created: 2026-07-07_

## North star
One repo, three profiles (desktop-full / server-headless / wsl). Every file either installed by a module or explicitly documented as reference-only. `dotfiles --update` + `dot-doctor` green on all four hosts.

## Machine matrix

| Host | Profile | Must have | Must NOT have |
|------|---------|-----------|---------------|
| GY-M-WHKK2PF6N7 (Mac) | desktop-full | Full Claude/Cursor, rbw, GUI, herdr opt-in | Server-only MCPs |
| LinuxBro | server-headless | Lean Claude, mcp-servers.server, agentsync target | plannotator, GUI modules |
| SuperBro | server-headless | Same + ssh-superbro, docker MCP | Same exclusions |
| MonsterBro (WSL) | wsl | Shell + symlinks + wsl MCP list | Unverified — P0 gate |

## Phase 0 — Finish in-flight migrations (block everything else)

| Item | Done when |
|------|-----------|
| Skills collapse `.claude/skills/` → `.agents/skills/` | Install reads `.agents/skills/` directly; `skills.list` = external npx only; `AGENT_SKILLS.md` = truth |
| brain → kb | Zero refs to `scripts/brain` as canonical; CODEBASE.md updated |
| AGENTS.md trim | ≤1.5k; policy only |
| Propagate to servers | `dotfiles-update` on LinuxBro + SuperBro after P0 lands |

## Phase 1 — Prove dead, then delete

### 1a. Zellij corpse
grep `zellij|Zellij` → delete/rewrite each hit. Fix `.local-config.example` profile docs.

### 1b. Attic + migration artifacts
Run `migrate-diff.sh` once → archive result to vault → delete `.attic/` + migrate-diff scripts.

### 1c. Build/cache in repo
- `.fallow/cache.bin` → gitignore it
- `.DS_Store` → delete + confirm gitignored

### 1d. Orphan top-level dirs
| Path | Action |
|------|--------|
| `functions/port-utils.sh` | Merge into zsh/04-functions or scripts/ |
| `vivaldi/phi/custom.css` | Move to Vaults/Me or delete |
| `.shared-rules/` | Audit: collapse into .cursor/rules/ if duplicate |

### 1e. Private/non-git dirs
Per-host: `git status --ignored`, `du -sh */` → archive to ~/Archive/dotfiles-YYYY/ or delete.

## Phase 2 — Module rationalization

| Module | Issue | Target |
|--------|-------|--------|
| herdr | modules.conf enables, bootstrap shows disabled | Fix status.sh or remove from modules.conf |
| herdr-autostart | Not a real module dir | Remove from modules.conf; comment in herdr docs |
| rbw | Tracked but machine-specific | Move to ~/.config/dotfiles/modules.conf (gitignored) |
| engram | N/A on Mac despite darwin platform | Investigate gate; servers-only or remove |

Structural fix: `modules.conf` (tracked) = repo defaults only. `~/.config/dotfiles/modules.conf` (gitignored) = per-host overrides.

## Phase 3 — Lean per-profile overlays

1. Plannotator: confirm Mac-only; update device snapshots
2. MCP audit via tool-restraint: each MCP must have a named consumer. Server list ≤5.
3. Brewfile: tag packages with `# @profile:desktop-full` vs server
4. Scripts inventory: extend doctor.sh with "orphan script" check

## Phase 4 — Docs alignment

| Doc | Action |
|-----|--------|
| CODEBASE.md | Regenerate after cleanup; remove .claude/skills/ section |
| CLAUDE.md | Claude-specific only; no AGENTS.md overlap |
| README.md | Quick start: profile → bootstrap → doctor |
| Vault gotchas.md | Record D1–D6 decisions |

## Decision log

| # | Question | Recommendation |
|---|----------|----------------|
| D1 | Plannotator | Keep Mac-only (server overlay already handles it) |
| D2 | Engram MCP | Servers only (kb vault replaced local memory need on Mac) |
| D3 | Herdr | Finish or remove — half-enabled is worst state |
| D4 | Attic | Archive + delete after one final migrate-diff |
| D5 | vivaldi/ | Move to Vaults/Me |
| D6 | Private dirs | Host audit first; default archive |

## Verification gate (per host)

```bash
./bootstrap.sh --list         # no unexpected blocked/N/A
./scripts/doctor.sh           # 0 issues
./modules/claude-settings/doctor.sh --fix
aislop scan --changes         # if code touched
ssh linuxbro 'cd ~/dotfiles && ./scripts/doctor.sh'
ssh superbro  'cd ~/dotfiles && ./scripts/doctor.sh'
```

## Execution order

1. P0: land skills migration commit (current dirty tree)
2. D1–D6: decisions recorded in vault
3. P1: zellij purge + attic + orphan dirs (one PR/commit)
4. P2: modules.conf split + herdr/rbw/engram resolution
5. P3: MCP/Brewfile profile tags
6. P4: docs trim + propagate + MonsterBro bootstrap

## Decisions (confirmed 2026-07-08)

- **D1 Plannotator** — REMOVE entirely. Delete from plugins.list, device snapshots, install script.
- **D2 Engram** — REMOVE module. Not in use; kb vault replaced it.
- **D3 Herdr** — KEEP but STANDBY. Good tool, Cursor covers current need. Make it opt-in (remove from tracked modules.conf, keep module clean for manual enable). Document as "available when Cursor CLI isn't enough". Do NOT autostart.
- **D4 Attic** — DELETE directly. No migration value.
- **D5 Vivaldi** — DELETE. No backup needed.
- **D6 Private dirs** — NOT dotfiles concern. Leave gitignored, handle separately on Mac.
