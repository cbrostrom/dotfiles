## Context Bridge — dotfiles — 2026-07-08 15:04

### What we were doing
Auditing and optimising the AI harness with Cursor as primary: codebase-memory-mcp config/hooks, token diet (AGENTS.md/CLAUDE.md bloat), Cursor CLI usability, and context-mode evaluation.

### Decisions made
- **Cursor is primary harness** — all docs and config references lead with `~/.cursor/mcp.json`, not Claude Code overlay. CC gets mirrors only.
- **codebase-memory-mcp hooks stay in `settings.base.json`** — `cbm-code-discovery-gate` (PreToolUse Grep|Glob) and `cbm-session-reminder` (SessionStart). Work in Cursor via CC compat layer; never move to `hooks.json` (no additionalContext there).
- **Token diet via stubs, not ignore** — root `AGENTS.md` + `CLAUDE.md` replaced with 4-line stubs; full content in `.agents/AGENTS.md` + `.claude/CLAUDE.md`. `.cursorignore` does NOT block `AGENTS.md` (Cursor native instruction file).
- **codebase-memory skill promoted** — moved to `.agents/skills/codebase-memory/` for shared Cursor access.
- **Shell: `agent` = CLI, `cursor` = IDE** — `zsh/05-integrations.zsh` now aliases `/usr/local/bin/cursor` before the `open -a Cursor` fallback.
- **context-mode: skip for Cursor** — already in Pi; WIP Cursor support + hook collision risk vs existing stack (kb, cbm, effort-classifier, vault-save). Revisit only for specific pain points.

### Files touched
- `~/dotfiles/.claude/settings.base.json` — cbm hooks wired (canonical source)
- `~/dotfiles/.claude/hooks/cbm-code-discovery-gate`, `cbm-session-reminder` — copied to dotfiles, symlinked back
- `~/.claude/mcp-servers.developer.list` — comment clarifying Cursor is primary
- `~/dotfiles/AGENTS.md`, `CLAUDE.md` — stubbed at repo root
- `~/dotfiles/.agents/AGENTS.md` — full policy (moved from root)
- `~/dotfiles/.cursorignore` — created (AGENTS.md listed; ineffective alone)
- `~/dotfiles/zsh/05-integrations.zsh` — cursor CLI alias fix
- `~/dotfiles/.agents/skills/codebase-memory/SKILL.md` — promoted to shared layer
- `~/Vaults/AI/projects/dotfiles/gotchas.md` — cbm + Cursor primary entries

### Open questions
- **Do CC-compat hooks fire in `agent` CLI sessions?** — effort-classifier and cbm-code-discovery-gate confirmed in Cursor IDE; `agent` CLI untested.
- **Global `.cursorignore` for AGENTS.md** — could reduce stub need across repos; untested.

### Dead ends (don't repeat)
- `codebase-memory-mcp install -y` resets `auto_index` to false — re-set manually after install.
- Installer hook writes to `settings.local.json` wiped on SessionStart — must edit `settings.base.json`.
- `.cursorignore` cannot prevent AGENTS.md auto-load — stub approach required.

### Exact next step
Run a short `agent` CLI session in `~/dotfiles` and verify whether `effort-classifier` / `cbm-code-discovery-gate` inject context (grep a symbol, check for graph augment in output). Add gotcha if confirmed.

### Context to reload
- Brain: `kb load` in `~/dotfiles`
- Key files: `~/dotfiles/.claude/settings.base.json`, `~/dotfiles/.cursor/rules/core.mdc`, `~/Vaults/AI/projects/dotfiles/gotchas.md`
