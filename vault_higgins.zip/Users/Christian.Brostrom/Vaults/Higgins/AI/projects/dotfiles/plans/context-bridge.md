## Context Bridge — dotfiles — 2026-07-02 01:52

### What we were doing
Integrating context-mode into the Pi setup so vault knowledge (modules, personal, project brains) is sideloaded into an FTS5 SQLite index instead of being dumped into context on every session.

### Decisions made
- **context-mode as vault sidecar** — `kb load` stays for the structured 5-bullet briefing; `ctx_search` handles all deep vault lookups. This drops session token cost from ~3KB file dumps to ~150-token BM25 snippets on demand.
- **`--project "$PWD"` for indexing** — indexes are keyed to the current working directory, so `ctx_search` works without flags from any project. Chose this over per-vault DB because Pi sessions always run from a project dir.
- **Two-hook maintenance model** — `vault-ctx-index` (session.created, ~300ms) + `kb-write-reindex` (tool.after.bash on kb save/wrap/compact/prune, ~100ms). No daemon, no cron, zero ongoing overhead.
- **Exclude sessions/, history/, archive/** — noisy, not actionable knowledge; kept out of FTS5 index intentionally.
- **personal/current.md** is the right home for cross-cutting agent infra facts (context-mode is harness-level, not project-level).

### Files touched
- `~/dotfiles/.config/pi/agent/hook/hooks.yaml` — added `vault-ctx-index` and `kb-write-reindex` hooks (symlinked to `~/.pi/agent/hook/hooks.yaml`)
- `~/Vaults/AI/personal/current.md` — added context-mode integration bullet
- `~/Vaults/AI/projects/dotfiles/current.md` — added hooks.yaml change fact

### Open questions
- None blocking. infra/ indexing is an optional nice-to-have (see next steps).

### Dead ends (don't repeat)
- Don't pass a slug positional arg to `kb current` — it gets appended to the text, not treated as a slug. Use `BRAIN_SLUG=<slug> kb current "<fact>"` or cd to the project dir.
- `mcp.json` does not need a context-mode entry for Pi — the Pi extension (`build/adapters/pi/extension.js`) auto-registers all ctx_* tools and hooks at session start via `pi.registerTool()`.

### Exact next step
Run `pi` in a new session → confirm hooks.yaml shows 8+2=10 hooks loaded via `/hooks-status` → type `ctx_search "test"` to verify FTS5 is live. Then optionally: `~/.pi/agent/npm/node_modules/.bin/context-mode index ~/Vaults/AI/infra/ --project "$PWD" --ext .md` to add host-state knowledge.

### Context to reload
- Brain: `kb load dotfiles` from `~/dotfiles`
- Key files: `~/.pi/agent/hook/hooks.yaml`, `~/Vaults/AI/personal/current.md`
- Verify with: `ctx_doctor` in Pi session
