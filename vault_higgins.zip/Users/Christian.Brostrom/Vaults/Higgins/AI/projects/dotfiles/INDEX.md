# Brain index: dotfiles
- current.md (8L) — _Updated: 2026-07-08_
- gotchas.md (13L) — - **cloudcli auth shim**: synthetic `~/.claude/.credentials.
- next.md (12L) — - **[decide]** Private/ non-git dirs: `Fynder/` (84MB), `tai
- history/ — 24 session(s), last archived-2026-07-07
- archive/ — 1 monthly file(s)
