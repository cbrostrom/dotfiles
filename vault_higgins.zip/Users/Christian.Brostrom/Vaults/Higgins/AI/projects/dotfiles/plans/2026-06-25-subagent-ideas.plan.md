# Subagent Ideas — 2026-06-25

Creative proposals for day-to-day productivity agents. Each includes trigger keywords,
model recommendation, and token efficiency design.

---

## 1. `standup` — Daily standup generator
**Model:** `composer-2.5-fast`  
**Triggers:** "standup", "daily", "what did I do yesterday"  
**What it does:** Pulls last 24h of git commits across all repos (`git log --since=yesterday`), open Jira issues in progress, brain `next.md` done items → formats a tight standup in 3 bullets (did / doing / blocked). No filler.  
**Token design:** Only reads git --oneline + Jira summary; never full diffs. Output ≤150 words.

---

## 2. `worklog` — Jira time logging assistant  
**Model:** `composer-2.5-fast`  
**Triggers:** "worklog", "log hours", "log time"  
**What it does:** Reads git commits + brain notes for a date range → infers issue keys → drafts worklog entries for Atlassian. You confirm per-entry before posting.  
**Token design:** Scope to `git log --since=X --until=Y --oneline`. Never loads full diffs.

---

## 3. `pr-shepherd` — PR merge-readiness loop  
**Model:** `claude-4.6-sonnet-medium-thinking`  
**Triggers:** "babysit PR", "shepherd PR", "keep PR green"  
**What it does:** Monitors a PR for CI failures, review comments, and merge conflicts. Fixes obvious things (linter, import sort, trivial feedback). Escalates architectural comments. Reports status and asks before merging.  
**Token design:** Only fetches CI diff + failing checks. Never loads full PR unless editing.  
**Note:** Cursor already has `babysit` built-in. This would be the opinionated wrapper knowing your stack.

---

## 4. `context-bridge` — Session context save/restore  
**Model:** `composer-2.5-fast`  
**Triggers:** "save context", "I'll continue later", "context bridge"  
**What it does:** Extracts decisions made, files touched, open questions, next step → writes to vault in a structured format. On next session: loads and presents as "where you left off". Richer than `brain save`.  
**Token design:** Summarises, never dumps raw conversation.

---

## 5. `spec-writer` — Requirement → structured spec  
**Model:** `claude-4.6-sonnet-medium-thinking`  
**Triggers:** "write spec", "spec this", "draft requirements"  
**What it does:** Takes a fuzzy feature description → asks 3-5 targeted questions → outputs a structured spec (problem, constraints, acceptance criteria, out-of-scope, open questions). Saves to `docs/` or vault.  
**Token design:** Interactive clarification loop kept tight (3 exchanges max before drafting).

---

## 6. `debt-tracker` — Tech debt radar  
**Model:** `composer-2.5-fast`  
**Triggers:** "debt", "tech debt", "what should we refactor"  
**What it does:** Runs `fallow audit` + `aislop scan` → cross-references with open Jira issues → presents prioritised debt list with complexity estimate + suggested model per item. Never creates tickets without confirmation.  
**Token design:** Uses fallow `--format json --quiet`. Builds table in chat, not full report.

---

## 7. `deploy-watcher` — Deployment status monitor  
**Model:** `composer-2.5-fast`  
**Triggers:** "deploy status", "how's the deploy", "watch deploy"  
**What it does:** Polls Superbro/LinuxBro via mcp-dockhand for container health, recent restarts, memory/CPU → presents compact status table. Detects anomalies and alerts.  
**Token design:** Uses mcp-dockhand `list-containers` only; never fetches logs unless anomaly detected.

---

## 8. `release-notes` — Changelog / release note generator  
**Model:** `claude-4.6-sonnet-medium-thinking`  
**Triggers:** "release notes", "changelog", "what changed since"  
**What it does:** Takes a git range (`v1.2..v1.3` or date range) → groups commits by type (feat/fix/chore/perf) → writes release notes in your voice. Filters noise (dependency bumps, device snapshots). Drafts for review before publishing.  
**Token design:** `git log --oneline` first; only fetches full commit messages for feat/fix types.

---

## 9. `jira-assistant` — Jira triage + ticket writer  
**Model:** `claude-4.6-sonnet-medium-thinking`  
**Triggers:** "jira", "write ticket", "create issue", "triage bug"  
**What it does:** Write a ticket from scratch or triage an existing bug report — finds duplicates, suggests epic, writes acceptance criteria, estimates story points based on codebase familiarity. Uses Atlassian MCP.  
**Note:** Routes to fiskars or akqa MCP based on project context.

---

## 10. `morning-brief` — Daily context loader  
**Model:** `composer-2.5-fast`  
**Triggers:** "morning brief", "start day", "what's on today"  
**What it does:** Loads brain `current.md` + `next.md` → fetches today's calendar events (Google Calendar MCP) → checks open PRs (GitHub MCP) → presents compact brief: 3 priority items, 2 meetings, 1 unblocking ask.  
**Token design:** All sources fetched with minimal fields. Output ≤200 words. No context injection.

---

## 11. `dot-doctor` — Dotfiles health check agent  
**Model:** `composer-2.5-fast`  
**Triggers:** "dot-doctor", "dotfiles health", "check setup"  
**What it does:** Runs `scripts/doctor.sh` + `modules/claude-settings/doctor.sh` → interprets output → flags real issues vs expected warnings → proposes fix commands. Knows the difference between "stale symlink" and "missing critical hook".  
**Note:** Thin wrapper over existing doctor scripts with smart interpretation.

---

## 12. `memory-curator` — Vault quality guard  
**Model:** `composer-2.5-fast`  
**Triggers:** "curate vault", "clean brain notes", "memory audit"  
**What it does:** Reads vault files for current project → finds stale `[done:]` items, contradictory facts, over-grown `current.md` → proposes consolidation. Trims without losing signal. Never writes without confirmation.  
**Token design:** Reads only active brain files (current.md, next.md, gotchas.md). No full vault scan.

---

## Implementation notes

**Highest ROI for immediate build:** `standup`, `morning-brief`, `dot-doctor` — pure reads, fast model, daily use.  
**Highest ROI for project work:** `jira-assistant`, `spec-writer`, `pr-shepherd`.  
**Best for dotfiles specifically:** `dot-doctor`, `memory-curator`, `context-bridge`.

**Pattern to follow for all:**
- Thin Cursor wrapper (`.cursor/agents/<name>.md`) pointing at `.agents/skills/<name>/SKILL.md`
- `readonly: true` where no writes needed
- `composer-2.5-fast` default; upgrade only for reasoning-heavy tasks
- Approval gate in skill for any mutations
