## Context Bridge — dotfiles — 2026-07-08

### What we were doing
Diagnosed insane Cursor usage spike (Jul 1–2), then implemented budget tiers and cost controls so daily agent work doesn't burn tokens on advisor/ponytail overhead by default.

### Decisions made
- **Jul 1–2 spike root cause:** PI→Cursor SDK bridge (`pi-cursor-sdk`) spawning 30–108 cloud agent sessions with ~32K-token wrappers — not regular chat. PI `enabledModels` cursor entries cleared.
- **Budget tiers in `core.mdc`:** high (default) / medium / low. Opt *down* with tags; auto-low only for obvious trivial fixes.
- **Tier triggers:** `.low` `/low` `.medium` `/medium` `.high` `/high` plus `[budget:*]` and `[eff:*]` — anywhere in message.
- **First pass had low default** — realigned to spec with **high default**; user uses Ask mode + `.low` for cheap paths.
- **Ponytail:** `alwaysApply: false`; full ladder high only, rungs 1–3 medium.
- **brain-load.sh:** 6KB cap, 1.5KB pending cap, home/empty-window → personal only, no `additional_context` stdout (avoid double injection).
- **Ask mode** for compare/audit — no edits, biggest token win for questions.
- **Deferred:** explicit "compare/verify = no edits" rule in core.mdc (user said go only for dot/slash triggers).

### Files touched
- `dotfiles/.cursor/rules/core.mdc` — budget tiers + triggers
- `dotfiles/.cursor/rules/ponytail.mdc` — tiered ladder
- `dotfiles/.cursor/rules/token-efficiency.mdc` — tier-aware output
- `dotfiles/.cursor/hooks/brain-load.sh` — capped injection
- `dotfiles/scripts/cursor/install-cursor-config.sh` — rule symlinks
- `dotfiles/.cursor/mcp.minimal.json` — GitHub-only MCP template
- `~/.pi/agent/settings.json` — `enabledModels: []`
- `~/.cursor/rules/` — symlinks to dotfiles rules

### Open questions
- Add compare-only no-edits line to core.mdc?
- User on OpenCode daily; Cursor agent only — confirm MCP swap habit (`mcp.minimal.json` vs full)
- Clear stale `pending.md` in active project brains

### Dead ends (don't repeat)
- Low-as-default tier policy — user spec wanted high default; reverted.
- Editing on "Is this what we implemented?" — `[eff:high]` + spec-shaped prompt triggered alignment edits without approval.

### Exact next step
Use **Ask mode** for compare/audit. Agent + `.low` for trivial fixes. Check Cursor billing dashboard for Jul 2 (worse than Jul 1). Optionally: `cp ~/dotfiles/.cursor/mcp.minimal.json ~/.cursor/mcp.json` for non-Shopify days.

### Context to reload
- Brain: `kb load` in `~/dotfiles`
- Key files: `dotfiles/.cursor/rules/core.mdc`, `dotfiles/.cursor/hooks/brain-load.sh`
