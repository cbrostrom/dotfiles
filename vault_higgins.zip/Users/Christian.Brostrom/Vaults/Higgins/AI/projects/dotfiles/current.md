# Brain: dotfiles
_Updated: 2026-07-08_

- `kb map` system built (P0–P3): `config/projects-map.conf`, `scripts/projects/map.sh` dispatcher, `map-scan.sh`, `map-codebase.sh`, `map-doctor.sh`. `kb` CLI dispatch extended with `map` subcommand. Registry: `~/Vaults/AI/personal/projects-registry.md`.
- Bash 4+ version guards added to all new `scripts/projects/map-*.sh` scripts (macOS ships bash 3.2 — guards re-exec via Homebrew bash).
- `brain` CLI → transition shim; canonical `kb` CLI now lives at `$VAULT_AI/tools/kb`. All memory = markdown via kb.
- CODEBASE.md + `codebase` skill route task → relevant files. Two-vault: `~/Vaults/Me` (human/Obsidian) vs `~/Vaults/AI` (agent-owned, git).
- Cursor stop hook wired: vault-save.sh → sessions/ + pending.md; brain-load picks up pending.md on next sessionStart via session-brain.mdc (alwaysApply workaround for Cursor sessionStart race bug).
