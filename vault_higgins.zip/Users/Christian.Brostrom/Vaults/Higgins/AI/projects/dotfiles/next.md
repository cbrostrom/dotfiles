# Next: dotfiles

- **[decide]** Private/ non-git dirs: `Fynder/` (84MB), `tailwind4-astro/`, `aleksdeejay-fetch/`, `Superbro/`, `bitwarden/` — archive or delete.
- Run `kb map codebase --all --missing-only` to generate CODEBASE.md skeletons for remaining 107 repos without one.
- Seed Keychain + enable pinentry-touchid (manual: `rbw unlock` in Terminal → "Save in Keychain" → `rbw config set pinentry pinentry-touchid`).
- Bootstrap MonsterBro (`dotfiles --update` end-to-end on WSL host — `mcp-servers.wsl.list` exists but full bootstrap loop unverified).
- Fix memory-curator.sh paths for Vaults/AI/projects/, then install weekly cron.
- Pull token-diet ultra telegraphic mode concept into core.mdc as opt-in hint.
- Propagate dotfiles to LinuxBro/SuperBro after today's skill layer changes.
- Decide on Plannotator skills once Cursor plan/agent mode flow is understood.
- Test `agent` CLI: verify CC-compat hooks (effort-classifier, cbm-code-discovery-gate) fire in CLI sessions — main open question from harness audit.
- Evaluate global `~/.cursorignore` for AGENTS.md across repos (stub works per-repo; global untested).
