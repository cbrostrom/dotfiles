## Context Bridge — dotfiles — 2026-06-30 15:55

### What we were doing
Reducing redundant AI file search token costs by adding a codebase map + enforcing it across all agents.

### Decisions made
- **CODEBASE.md over repomix-for-generation**: repomix is on-demand/gitignored; CODEBASE.md is the permanent cheap-read map. Generating CODEBASE.md from repomix output was rejected — backwards ROI.
- **Skill as router, not generator**: `codebase` skill routes task → 2–3 targeted files. Offers to generate CODEBASE.md (via `find -maxdepth 2`, no LLM reads) only if missing.
- **Two enforcement layers**: `AGENTS.md` (agnostic, "ALL agents must") + `core.mdc` (Cursor-specific, fires every turn). Belt and suspenders.

### Files touched
- `CODEBASE.md` (new) — full directory/file index for dotfiles repo
- `AGENTS.md` — added mandatory codebase map instruction pointing to CODEBASE.md + codebase skill
- `.cursor/rules/core.mdc` — added Codebase map section before Glob/search
- `.agents/skills/codebase/SKILL.md` (new) — shared router skill: reads map → outputs 3 file paths; generates map if missing
- `~/.agents/skills/codebase/` + `~/.cursor/skills/codebase/` — installed

### Open questions
- None — session goals fully completed.

### Dead ends
- Repomix → CODEBASE.md pipeline: expensive (50–200k tokens to produce a 500-token file). Rejected.

### Exact next step
Commit the 4 changed/new files: CODEBASE.md, AGENTS.md, .cursor/rules/core.mdc, .agents/skills/codebase/SKILL.md.

### Context to reload
- Brain: `brain load` in ~/dotfiles
- Key files: `CODEBASE.md`, `AGENTS.md`, `.cursor/rules/core.mdc`, `.agents/skills/codebase/SKILL.md`
