# Compact overflow — dotfiles — 2026-07-08 15:05

- AI harness audit (2026-07-08): Cursor primary. codebase-memory-mcp hooks in settings.base.json (cbm PreToolUse + SessionStart). Root AGENTS.md/CLAUDE.md stubbed for token diet. codebase-memory skill in .agents/skills/. context-mode skipped for Cursor.
