# Gotchas: dotfiles

- **cloudcli auth shim**: synthetic `~/.claude/.credentials.json` with placeholder `accessToken` lets cloudcli show "connected" under enterprise Keychain auth. Breaks if cloudcli ever validates token against API.
- **CLAUDEMD editing**: blocked by auto-mode self-modification guard. Edit source at `~/dotfiles/.claude/CLAUDE.md` (symlink target).
- **kb CLI canonical**: brain shim at ~/.local/bin/brain → $VAULT_AI/tools/kb. No brain skill, no MCP.
- **Plan files**: $VAULT_AI/projects/<slug>/plans/YYYY-MM-DD-<topic>.plan.md — never .planning/ in repo
- Cursor sessionStart additional_context silently dropped (race condition, confirmed Cursor bug, no ETA). Workaround: brain-load.sh writes ~/.cursor/rules/session-brain.mdc (alwaysApply:true). One-session lag expected. See: forum.cursor.com/t/157141
- codebase-memory-mcp: Cursor is primary harness — configured in ~/.cursor/mcp.json (auto_index=true, limit=50000). Claude Code gets it via .claude/mcp-servers.developer.list as a secondary overlay. When describing setup, lead with Cursor, not CC.

- **Cleanup 2026-07-08 decisions**: plannotator removed (D1), engram removed (D2), herdr kept as per-host standby (D3), vivaldi/attic deleted (D4/D5). Module config now two-layer: `~/dotfiles/modules.conf` (repo defaults) + `~/.config/dotfiles/modules.conf` (per-host, auto-seeded on first bootstrap). Pi platform tag was `darwin` → fixed to `macos` (platform_tag returns macos not darwin). Symlink farm renamed from `.zellij-projects` → `.project-farm`.
- Cursor loads CC hooks via compat layer from ~/.claude/settings.json (symlink → settings.local.json, generated from settings.base.json). Hooks needing per-prompt additionalContext (effort-classifier, cbm-code-discovery-gate) ONLY work this way — Cursor's native beforeSubmitPrompt cannot inject context, and preToolUse has no additionalContext either. Never move these to hooks.json.
- **Cursor CLI naming**: `agent` = CLI agent mode; `cursor` = IDE binary (`/usr/local/bin/cursor`) or `open -a Cursor` fallback. Don't use `cursor` expecting CLI behaviour.
- **codebase-memory-mcp install -y** resets `auto_index` to false — run `codebase-memory-mcp config set auto_index true` after any reinstall.
