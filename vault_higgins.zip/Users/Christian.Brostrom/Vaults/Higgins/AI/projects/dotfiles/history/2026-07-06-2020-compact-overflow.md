# Compact overflow — dotfiles — 2026-07-06 20:20

- Week 1 AI setup cleanup done: AGENTS.md vault paths fixed (Vaults/AI + kb), graphify removed (shelfware), subagent policy table added, CODEBASE.md added to stellar-shopify, stellar-shopify-app-gift-purchase-discount, pi-ui
