# Session: kb map + project cleanup — 2026-07-07 19:35

## What happened
- Implemented full `kb map` system (P0–P3) from plan `2026-07-06-kb-map-and-machine-cleanup.plan.md`
- New files: `config/projects-map.conf`, `scripts/projects/map.sh`, `map-scan.sh`, `map-codebase.sh`, `map-doctor.sh`
- `kb` CLI dispatch extended: `elif raw[0] == "map":` → calls `map.sh`
- Registry generated: 113 repos, 10 with brain, 6 with CODEBASE.md, 81 with issues
- Bash 4+ version guards added after macOS bash 3.2 broke `mapfile` and `declare -A`
- `printf --` fix for format strings starting with `-`

## Project restructuring decisions
- `Shopify/` dir: all removed — either archived to `_archive/` or deleted (generic boilerplate)
- Stale internal repos archived: astro-events, ExpressWebApp, fastify-docker, Hippo, meet-akqa, test-strapi, reviews (Internal/); microsoft-todo, laesr-placeholder (Private/)
- `unify` project in Internal/: removed (stale, no recent commits, repo content gone)
- `Logos/` → moved to `Projects/_assets/`
- Ghost file `Icon\r` removed from Internal/
- akqa-attend, akqa-bets, Directus removed from Internal/

## Pending decisions
- 9 `.env.local` security alerts in `_inventory.json` — not yet reviewed
- Private/: Fynder (84MB), tailwind4-astro, aleksdeejay-fetch, Superbro, bitwarden — deferred

## Hook gap identified
- `brain-save-inject.sh` only injects a prompt instructing AI to save. When Cursor summarizes out-of-band, the AI never sees this — nothing gets saved.
- Fix: Cursor `stop` hook that writes git diff stat + edited files directly to vault trace file. No AI dependency.
