# Pending review — 2026-07-08 20:43
_Unreviewed. At session start: promote to current.md/next.md if relevant, then delete._

## Commits this session
- 35ec89e fix(zsh): prefer /usr/local/bin/cursor CLI over app bundle
- 4314bbb feat(skills): add codebase-memory skill to shared layer
- 7f60b52 docs(claude): slim root CLAUDE.md to CC stub
- a2dbdde refactor(agents): move policy to .agents/AGENTS.md stub root
- c44866c chore(zsh): add ~/.local/bin to PATH for codebase-memory-mcp binary
- 6111657 feat(claude): wire cbm hooks into settings.base.json
- cab1dce feat(hooks): add codebase-memory-mcp hooks (discovery gate + session reminder)
- 58ce39f docs: update CODEBASE.md + README for post-cleanup state
- ff2cd9c chore(mcp): remove deprecated graphiti from memory overlay
- e06343d chore(mcp): remove engram, move shopify-dev-mcp to work overlay
- 870ca69 chore(modules): remove pi from repo baseline (opt-in per-host only)
- 1d964e3 fix(modules): wire two-layer config + auto-seed per-host modules.conf
- 2241c12 docs(projects): rewrite README.md in English, update symlink farm name
- afc3ebb refactor(projects): purge zellij, rename symlink farm to .project-farm
- 6ec3eaa chore(modules): move rbw + herdr to per-host opt-in
- 09becee chore(cleanup): remove plannotator from plugins, devices, and install
- 943181f chore(cleanup): remove engram module, attic migration scripts, vivaldi
- 5defe37 refactor(agents): trim AGENTS.md from 234 to 103 lines
- a7db677 fix(docs): replace stale brain refs with kb
- d79b020 fix(skills): hoist cursor symlink before skills.list guard
- 8928fe1 feat(cursor): add session wrap-up nudge to core.mdc
- b7a1a52 fix(skills): update context-bridge vault paths brains/ → projects/
- 6ae9190 feat(hooks): add git commits to pending.md session capture
- b8042c2 fix(agents): update AGENT_SKILLS.md + CLAUDE.md for current setup
- dfa81f6 fix(cursor): update core.mdc skills ref + add compact mode hint
- 01f0ef1 refactor(agents): trim AGENTS.md from 312 to 234 lines
- f9b3189 perf(skills): slim fallow from 14.6k to 609 tokens
- ed101a4 feat(skills): add 5 loopkit skills
- a361ad7 feat(skills): collapse .claude/skills layer into .agents/skills
- 60dca77 fix(skills): model assignments, vault paths, dispatch table
- 716106d feat(skills): add commit and push shared skills
- 1917e61 fix(hooks): workaround Cursor sessionStart additional_context race condition

## Files edited (7)
- `~/dotfiles/.cursor/rules/core.mdc`
- `~/dotfiles/.cursor/rules/ponytail.mdc`
- `~/dotfiles/.claude/hooks/effort-classifier.sh`
- `~/dotfiles/.cursor/hooks/brain-load.sh`
- `~/dotfiles/scripts/cursor/install-cursor-config.sh`
- `~/dotfiles/.cursor/rules/token-efficiency.mdc`
- `~/.cursor/rules/session-brain.mdc`

## Where we left off
Done. All 5, plus one fix so it sticks. | # | Change | File | |---|---|---| | 1 | `alwaysApply: false` | `~/.cursor/rules/session-brain.mdc` | | 1b | Hook writes `alwaysApply: false` on regen | `.cursor/hooks/brain-load.sh` | | 2 | Binary lean/rigor rewrite | `.cursor/rules/core.mdc` | | 3 | Classif…

Full session log: `~/Vaults/AI/sessions/2026/07/2026-07-08-dotfiles-session.md`
