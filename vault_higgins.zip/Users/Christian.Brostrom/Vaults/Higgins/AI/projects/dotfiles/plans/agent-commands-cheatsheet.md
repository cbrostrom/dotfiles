# Agent Commands Cheatsheet

Personal reference for all dot commands, agent triggers, brain CLI, and workflows.
Last updated: 2026-06-28

---

## Dot Commands

Quick shorthands wired into `AGENTS.md`. Any agent that has loaded `AGENTS.md` will respond to these.

| Command | What it does |
|---|---|
| `.spec <problem>` | Spawn `problem-solver` — read-only diagnosis + implementation spec + model recommendation |
| `.review` | Spawn `code-reviewer` — review changed/indicated code for bugs, security, reuse, simplification |
| `.add <behavior>` | Spawn `config-writer` — decide where new agent behavior lives, check overlap, create it |
| `.remember` / `.r` | Full session save via `context-bridge` — extract decisions, reasoning, dead ends, next step → vault |
| `.note <text>` / `.n <text>` | Single fact → `brain current "<text>"` immediately |
| `.gotcha <text>` / `.g <text>` | Trap/pitfall → `brain gotcha "<text>"` immediately |
| `.recall` | Surface current state → `brain current` + `brain next` |

---

## Brain CLI

Vault: `~/Vaults/Brain/Brains/<slug>/`  
Binary: `~/.local/bin/brain`

| Command | What it does |
|---|---|
| `brain load` | Surface current state + active next items (session start) |
| `brain current` | Read current.md (what's active, key decisions, context) |
| `brain current <fact>` | Append a fact to current.md |
| `brain next` | Read next.md (pending tasks/next steps) |
| `brain next <action>` | Append a next step to next.md |
| `brain gotcha <trap>` | Append a trap/pitfall to gotchas.md |
| `ob open <path>` | Open a vault file in Obsidian |

---

## Agents

All 16 agents available globally at `~/.cursor/agents/`. Invoked by Cursor when description keywords match, or by name.

### Investigation & Quality

| Agent | Trigger keywords | What it does |
|---|---|---|
| `problem-solver` | `.spec`, "figure out why", "why is X broken", "diagnose this", "spec this out" | Read-only root cause analysis + structured implementation spec. Model: `claude-4.6-sonnet-medium-thinking`. |
| `code-reviewer` | `.review`, "review this", "review my changes", "before merge", "PR review" | Reviews changed code only — bugs, security, reuse, simplification. Read-only. Model: `claude-4.6-sonnet-medium-thinking`. |
| `code-cleaner` | "check code quality", "any slop?", "fix slop", "audit codebase", "duplication" | aislop + fallow audit, complexity estimate, model recommendation, plan of action. Never fixes without permission. |

### Daily Workflow

| Agent | Trigger keywords | What it does |
|---|---|---|
| `standup` | "standup", "daily", "what did I do yesterday" | git commits + Jira in-progress + brain done → 3-bullet standup. Fast. |
| `morning-brief` | "morning brief", "start day", "brief me", "good morning" | Brain priorities + calendar + open PRs in ≤200 words. Run once at workday start. |

### Vault & Memory

| Agent | Trigger keywords | What it does |
|---|---|---|
| `context-bridge` | `.remember`, "save context", "bridge session", "I will continue later" | Rich session save — decisions + reasoning + dead ends + next step → vault snapshot. |
| `vault-librarian` | "vault", "brain", "inbox", "save to vault", "load vault context", "triage inbox" | Vault protocol agent — brain load/save, inbox triage, knowledge routing. |
| `memory-curator` | "curate vault", "clean brain", "memory audit", "tidy vault" | Vault quality guard — stale items, contradictions, duplicates. Proposes only. Also runs weekly via cron. |

### Agent Architecture

| Agent | Trigger keywords | What it does |
|---|---|---|
| `config-writer` | `.add`, "add behavior", "where does this go", "create a rule for", "make a skill that" | Placement decision + creates the right artifact. Knows thin-wrapper architecture. Approval required. |
| `dotfiles-architect` | "how does X work in dotfiles", "explain the setup", "dotfiles architecture" | Read-only architecture reference. Explains settings layers, hooks, skills, modules. |
| `dotfiles-editor` | "update dotfiles", "change config", "edit hook", "fix symlink" | Implements approved dotfiles changes. Plan + approval required before edits. |

### Jira / Delivery

| Agent | Trigger keywords | What it does |
|---|---|---|
| `jira-assistant` | "jira", "ticket", "write ticket", "review ticket KEY-N", "delivery analyst" | Read + review tickets (AC, scope, risks), draft new tickets/comments for copy-paste. Never auto-writes. |

### Shopify

| Agent | Trigger keywords | What it does |
|---|---|---|
| `shopify-generalist` | Shopify platform questions, Liquid, API, metafields, theme behavior | MCP-first verification. Evidence standard. Complexity + model recommendation. |
| `shopify-fiskars-specialist` | Fiskars, stellar-shopify, store-specific work | Multi-store theme specialist. Loads shopify skill + vault routing. Complexity + model recommendation. |

### Release & Docs

| Agent | Trigger keywords | What it does |
|---|---|---|
| `release-notes` | "release notes", "changelog", "what changed since", "draft release" | git range → grouped + rewritten release notes. Learns project templates. Never publishes without instruction. |
| `dot-doctor` | "dot-doctor", "dotfiles health", "check setup", "is my setup broken" | Runs doctor.sh, suppresses cosmetic noise, surfaces real issues with fix commands. |

---

## Shared Skills

Portable skills in `~/.agents/skills/` (also at `~/.cursor/skills`). Load by reference in any agent or manually.

| Skill | Load path | Use |
|---|---|---|
| `problem-solver` | `~/.agents/skills/problem-solver/SKILL.md` | Investigation protocol + spec format |
| `code-reviewer` | `~/.agents/skills/code-reviewer/SKILL.md` | Review criteria + output format |
| `code-cleaner` | `~/.agents/skills/code-cleaner/SKILL.md` | aislop + fallow audit protocol |
| `config-writer` | `~/.agents/skills/config-writer/SKILL.md` | Placement decision framework |
| `shopify` | `~/.agents/skills/shopify/SKILL.md` | MCP-first, evidence standard, vault routing, complexity YAML |
| `context-bridge` | `~/.agents/skills/context-bridge/SKILL.md` | Session save/restore protocol |
| `vault` | `~/.agents/skills/vault/SKILL.md` | Vault path detection, brain CLI, inbox routing |
| `inbox-librarian` | `~/.agents/skills/inbox-librarian/SKILL.md` | Route Inbox/ files to vault |
| `fallow` | `~/.agents/skills/fallow/SKILL.md` | JS/TS codebase intelligence |
| `standup` | `~/.agents/skills/standup/SKILL.md` | Standup generation protocol |
| `morning-brief` | `~/.agents/skills/morning-brief/SKILL.md` | Morning brief protocol |
| `dot-doctor` | `~/.agents/skills/dot-doctor/SKILL.md` | Dotfiles health check protocol |
| `jira-assistant` | `~/.agents/skills/jira-assistant/SKILL.md` | Jira analysis + delivery analyst |
| `memory-curator` | `~/.agents/skills/memory-curator/SKILL.md` | Vault curation protocol |
| `release-notes` | `~/.agents/skills/release-notes/SKILL.md` | Release notes generation protocol |

---

## Background / Cron

| Job | Schedule | What |
|---|---|---|
| `memory-curator` | Weekly (Sunday, configurable) | Vault quality pass — stale items, contradictions, duplicates |

Plist: `~/dotfiles/scripts/vault/com.christian.memory-curator.plist`  
Script: `~/dotfiles/scripts/vault/memory-curator.sh`

---

## Hooks

Cursor hooks at `~/.cursor/hooks.json`. All wrapped by `run-hook.sh` (logs failures, slow runs > 3s).

| Event | Hook | What |
|---|---|---|
| `sessionStart` | `brain-load.sh` | Surface vault state at session start |
| `sessionStart` | `herdr-agent-state.sh` | Load agent state |
| `preToolUse` | `rtk hook cursor` | Token-compressed shell output |
| `afterFileEdit` | `aislop hook cursor` | Code quality regression check |
| `stop` | `vault-save.sh` | Nudge vault save before session ends |
| `preCompact` | `brain-save-inject.sh` | Write brain before context is summarized |

---

## Model Selection Quick Reference

Full map: `~/Vaults/Brain/Development/Cursor Model Selection Map.md`

| Tier | Models | Use when |
|---|---|---|
| Cheap | GPT-5.4 Mini / Haiku | Trivial, single-file, obvious fix |
| Economical | Composer 2.5 / Codex | Low complexity, well-scoped |
| Senior | Sonnet 4.6 / Codex 5.3 | Multi-file, medium complexity |
| Senior + thinking | Sonnet 4.6 medium-thinking | Debugging, spec writing, reasoning-heavy |
| Premium | Opus 4.8 / GPT-5.5 | Architecture, cross-system, hard unknowns |
