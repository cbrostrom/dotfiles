# Compact overflow — dotfiles — 2026-07-08 08:37

- codebase-memory-mcp fully wired: hooks in settings.base.json (CC+Cursor via compat layer), cbm-code-discovery-gate on PreToolUse Grep|Glob, cbm-session-reminder on SessionStart. cbm skill promoted to .agents/skills/. auto_index=true. Cursor hooks audit done — CC compat layer handles effort-classifier + cbm (beforeSubmitPrompt has no additionalContext, compat is load-bearing).
