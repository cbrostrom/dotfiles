# Compact overflow — dotfiles — 2026-07-07 22:17

- **Skill layer collapsed to two layers**: `.claude/skills` deleted (Cursor was loading it as built-in, causing triple-load). All 8 useful skills promoted to `.agents/skills`. `.agents/skills` (35 skills) is now the single shared source across all agents.
- **5 loopkit skills added**: adversarial-verify, context-budget, tool-restraint, kill-dead-code, simplify.
- **Model assignments fixed**: AGENTS.md dispatch (code-reviewer + context-bridge → standard), problem-solver frontmatter hardcode removed, dotfiles skill composer-2.5-fast → standard, budget_tier label mismatches fixed.
- **fallow skill** trimmed from 14.6k to 609 tokens (was auto-generated reference dump).
- **Cursor skill loading**: `~/.cursor/skills` (→ .agents/skills) + `~/.cursor/skills-cursor` (Cursor-managed, 19 skills, auto-syncs — can't delete from it permanently). No .claude/skills layer.
