# kb map + machine cleanup — implementation spec

**Date:** 2026-07-06  
**Implement in:** `~/dotfiles` (primary) + `~/Vaults/AI/tools/kb` (thin wrapper)  
**Executor:** Sonnet in dotfiles repo  
**Status:** spec — not started

---

## Problem

1. Vault has **14 project brains**; machine has **~99 git repos** under `~/Projects` (per `_inventory.md`, Apr 2026).
2. Agents need **in-repo** `CODEBASE.md` for routing; vault needs a **registry** (not 99 stub brains).
3. Folder structure is ad-hoc (`Clients/`, `Shopify/`, `Internal/`, `Private/`, `Workspaces/` — overlapping semantics).
4. AI setup has accumulated bloat (`.cursor` ~1.7 GB, duplicate skill layers, stale hooks).

**Do not conflate:** registry ≠ project brain ≠ CODEBASE.md.

---

## Architecture (three layers)

| Layer | Location | Purpose | Auto? |
|-------|----------|---------|-------|
| **Registry** | `$VAULT_AI/personal/projects-registry.md` | Machine inventory: path, slug, type, stack, flags | Yes — `kb map scan` |
| **CODEBASE.md** | Each repo root | Agent routing map for cwd | Yes — skeleton; human/AI enriches purpose |
| **Project brain** | `$VAULT_AI/projects/<slug>/` | Live state (current, next, gotchas) | No — `kb init` only when active |

### Load protocol change (vault)

Add to `AGENTS.md` optional load:

```
When slug unknown or user asks "what projects": read personal/projects-registry.md
```

Do **not** load registry on every SessionStart — too heavy. Load on demand or via `kb map list`.

---

## Config (dotfiles — single editable file)

**Path:** `~/dotfiles/config/projects-map.conf`

Simple shell-sourceable format (no YAML parser needed):

```bash
# Scan roots — one absolute path per line (comments allowed)
ROOTS=(
  "$HOME/Projects"
  "$HOME/dotfiles"
  # "$HOME/Developer"
)

# Extra single-repo paths outside ROOTS (e.g. worktrees)
EXTRA_REPOS=(
  # "$HOME/worktrees/stellar-shopify-pr1306"
)

# Category inference: first matching pattern wins (path relative to Projects root)
# Format: "pattern|category"
# Categories: work-client, work-internal, work-shopify, private, sandbox, archive
CATEGORY_RULES=(
  "Clients/*|work-client"
  "Shopify/*|work-shopify"
  "Internal/*|work-internal"
  "Private/*|private"
  "Workspaces/*|sandbox"
  "_archive/*|archive"
  "*|unknown"
)

# Target structure (for plan-gen hints only — used by apply.sh)
TARGET_LAYOUT="clients/<client>/<repo>"

# CODEBASE generation
CODEBASE_MAXDEPTH=2
CODEBASE_SKIP_IF_EXISTS=1          # default: don't overwrite
CODEBASE_FORCE=0                   # --force sets this

# Vault output
VAULT_AI="${VAULT_AI:-$HOME/Vaults/AI}"
REGISTRY_PATH="$VAULT_AI/personal/projects-registry.md"

# Symlink farm (existing zellij integration)
SYMLINK_ROOT="$HOME/.zellij-projects"
```

User edits this file only. No code changes to add a new root or category.

---

## Commands

### Entry point: `kb map` (vault CLI delegates to dotfiles)

Add to `~/Vaults/AI/tools/kb`:

```python
elif raw[0] == "map":
    # exec ~/dotfiles/scripts/projects/map.sh with remaining args
    subprocess.run([os.path.expanduser("~/dotfiles/scripts/projects/map.sh"), *raw[1:]], check=False)
```

Shim already exists at `~/dotfiles/scripts/kb` → vault `kb`. One CLI surface.

### Subcommands (implemented in dotfiles)

```
kb map scan [--refresh-inventory]
    → Run inventory (or reuse _inventory.json if <24h old and --refresh not set)
    → Write/update personal/projects-registry.md
    → Print summary: N repos, M with brain, K with CODEBASE, issues count

kb map list [--type=private|work-*] [--brain] [--no-codebase]
    → Filtered table from registry (no rescan)

kb map codebase [path|slug] [--all] [--missing-only] [--force]
    → Generate CODEBASE.md skeleton in repo root
    → Default: skip if CODEBASE.md exists
    → --all: every repo in registry
    → --missing-only: only repos without CODEBASE.md

kb map init <slug>
    → kb init <slug> if no brain exists (promote registry → active project)
    → Does NOT auto-create for all repos

kb map doctor
    → AI setup audit (see Cleaning Phase B below)
    → Read-only report to stdout + optional _ops/ file
```

---

## Implementation files (dotfiles)

| File | Action |
|------|--------|
| `config/projects-map.conf` | **New** — user-editable config |
| `scripts/projects/map.sh` | **New** — main dispatcher |
| `scripts/projects/map-scan.sh` | **New** — registry writer (uses lib.sh + inventory JSON) |
| `scripts/projects/map-codebase.sh` | **New** — CODEBASE skeleton generator |
| `scripts/projects/map-doctor.sh` | **New** — AI bloat audit |
| `scripts/projects/lib.sh` | **Extend** — add `has_brain()`, `has_codebase()`, `infer_category()`, `registry_row()` |
| `scripts/projects/inventory.sh` | **Keep** — map-scan calls it when stale |
| `scripts/projects/README.md` | **Update** — document kb map + config |
| `scripts/projects/symlink.config` | **Keep** — extra paths for zellij farm |

### Reuse, don't rewrite

- `inventory.sh` already produces `_inventory.json` with stack, age, flags, duplicates.
- `apply.sh` + `plan.template.yml` already handle **approved moves** with rollback.
- `audit.sh` + `doctor.sh` already cover dotfiles wiring.
- `map-scan.sh` = transform `_inventory.json` → compact registry markdown.

---

## Registry output format

**Path:** `~/Vaults/AI/personal/projects-registry.md`

```markdown
# Projects registry — superbro
_Updated: 2026-07-06 20:45 · 99 repos · scan: kb map scan_

| slug | path | type | stack | brain | codebase | flags |
|------|------|------|-------|-------|----------|-------|
| stellar-shopify | ~/Projects/Shopify/Fiskars/stellar-shopify | work-shopify | node/shopify | yes | yes | |
| huskr | ~/Projects/Private/huskr | private | tauri/rust | yes | no | |
| akqa-dk-alustre-web | ~/Projects/Shopify/akqa-dk-alustre-web | work-shopify | nextjs | no | no | DUPLICATE |

## Issues (from last scan)
- **Duplicates:** 8 name/remote collisions — see _inventory.md
- **Stale (>365d):** 54 repos
- **Security:** 9 .env.local / key files in tree — rotate/review
```

Keep under ~500 lines. Full detail stays in `~/Projects/_inventory.md`.

---

## CODEBASE skeleton format

Generator writes this; purpose columns use **inference only** (no LLM):

```markdown
# Codebase map — <repo-name>
_Auto-generated by kb map codebase — enrich purpose columns manually._

Read this before searching. Jump directly to the right file.

## Stack
<from detect_stack(): node/shopify, rust/tauri, etc.>

## Root
| File | Purpose |
|------|---------|
| `package.json` | Node project manifest |
| `README.md` | <first non-heading line, truncated 80 chars> |
| `AGENTS.md` | Agent policy (if exists) |

## Key directories
### `src/` (or top-level dirs from find -maxdepth 1 -type d)
| Entry | Purpose |
|-------|---------|
| `src/` | Source tree |
| `modules/` | Install modules |
```

**Inference rules:**
- Root files: list non-hidden files at depth 1; purpose from extension (`*.sh` → shell script) or README first line.
- Dirs: top 8 directories by file count (exclude standard EXCLUDE_DIRS from lib.sh).
- If `AGENTS.md` or `CODEBASE.md` exists, note in header — don't overwrite with `--force` unless explicit.

**After generation:** user or agent enriches purpose columns once per important repo.

---

## Cleaning phase (integrated workflow)

### Why dotfiles, not vault?

| Concern | Best home | Reason |
|---------|-----------|--------|
| Folder structure | `dotfiles/scripts/projects/` | Already built (`inventory`, `apply`, symlinks) |
| AI tool bloat | `dotfiles` (modules, skills, audit) | Installs and symlinks live here |
| Registry + brains | `Vaults/AI` | kb schema, load protocol |
| Machine-specific paths | `dotfiles/config/` | Propagates to LinuxBro/SuperBro with edits |

Vault stores **knowledge**. Dotfiles stores **machine behavior and cleanup tooling**.

### Phase order (critical — do NOT generate CODEBASE before moves)

```
Phase A — Read-only audit (1 session, no moves)
  ./scripts/projects/inventory.sh          # refresh _inventory (Apr data is stale)
  kb map scan --refresh-inventory
  ./scripts/audit.sh
  ./scripts/doctor.sh
  kb map doctor > ~/Vaults/AI/_ops/ai-audit-$(date +%F).md

Phase B — AI setup cleanup (dotfiles repo)
  See checklist below. Low path churn — safe before folder moves.

Phase C — Projects folder restructure (~/Projects)
  cp plan.template.yml plan.yml
  Review with AI: set approved: true per move (batch by category)
  ./scripts/projects/apply.sh --dry-run
  ./scripts/projects/apply.sh --execute   # journal + rollback available
  ./scripts/projects/sync-symlinks.sh

Phase D — kb map rollout (after paths stable)
  kb map scan
  kb map codebase --all --missing-only
  Enrich CODEBASE.md for top 10 active repos (manual or agent session)

Phase E — Vault brain promotion (ongoing)
  kb map init <slug>   # only repos you're actively working
```

**Rationale:** CODEBASE paths and registry rows go stale if you restructure after generating. Your Apr inventory shows duplicates and nested git — fix structure first.

### Phase B — AI setup cleanup checklist

New script: `scripts/projects/map-doctor.sh` (or extend `audit.sh` with `--ai` flag).

Checks (read-only):

| Check | What | Action hint |
|-------|------|-------------|
| Skill duplicates | Same skill in `.agents/`, `.claude/`, dotfiles copy | Keep `.agents/skills/` canonical; symlink rest |
| Orphan symlinks | `~/.claude/skills/*` → broken targets | Remove dead links |
| Cursor cache size | `~/.cursor` > 500MB | Document safe cleanup (not auto-delete) |
| cursor-agent cache | `~/.local/share/cursor-agent` | Same |
| Stale modules | `modules.conf` `!module` but dir exists | Archive or delete |
| Hook orphans | doctor.sh already checks missing hook files | Fix wiring (see 2026-06-25-cleanup.plan.md Phase B) |
| MCP server sprawl | Compare `~/.claude.json` mcpServers vs dotfiles module | Dedupe, move to dotfiles module |
| Disabled skill dirs | `.claude/skills/.disabled-*` | Delete (git history preserves) |
| lean-ctx remnants | grep dotfiles for lean-ctx | Phase C of existing cleanup plan |
| Repomix/graphify caches | find ~ -maxdepth 4 -name 'repomix-out' -o -name 'graphify-out' | Add to gitignore or delete |

Output: grouped report with **severity** (fix now / review / informational).

Do **not** auto-delete `.cursor` caches — report size + manual steps only.

### Phase C — target folder structure

Already defined in `scripts/projects/README.md`:

```
~/Projects/
├── clients/<client>/<repo>/
├── internal/<repo>/
├── personal/<repo>/
├── sandbox/<repo>/
├── _assets/
└── _archive/
```

Current mess: `Shopify/` and `Clients/` overlap (Fiskars in Shopify, others in Clients). `plan-gen.sh` should suggest moves; human approves in `plan.yml`.

**Symlink farm:** `~/.zellij-projects/` stays flat — sessionizer unchanged.

---

## Tradeoffs

| Choice | Pros | Cons |
|--------|------|------|
| Config in dotfiles vs vault | Editable, propagates with dotfiles | Not synced if vault-only on another machine |
| Registry in vault `personal/` | kb knows it; lintable | Regenerated by scan — not hand-edited |
| Reuse inventory.sh vs inline scan | Battle-tested; JSON already rich | Two output formats to maintain |
| CODEBASE skeleton vs full AI write | Zero token cost; deterministic | Purpose columns thin until enriched |
| Scan before folder cleanup | Accurate registry immediately | Paths invalidated after moves — must rescan |
| Scan after folder cleanup | Stable paths | Delayed agent benefit |
| **Recommended:** scan before AND after Phase C | Baseline + final registry | Two scans (cheap) |
| `kb map` in vault vs dotfiles-only | Single CLI (`kb`) | Cross-repo dependency |
| 99 project brains | Full vault context | Violates schema; kb load bloat |

---

## Sonnet implementation checklist

### P0 — Config + scan (2–3h)
- [ ] Create `config/projects-map.conf` with defaults above
- [ ] `map-scan.sh`: read config → call inventory if stale → write registry
- [ ] Extend `lib.sh` with brain/codebase detection
- [ ] Add `kb map` dispatch in vault `tools/kb`
- [ ] Update `scripts/projects/README.md`

### P1 — CODEBASE generator (1–2h)
- [ ] `map-codebase.sh` with inference rules
- [ ] `--missing-only`, `--force`, single path/slug arg
- [ ] Test on dotfiles, huskr, stellar-shopify

### P2 — AI doctor (1–2h)
- [ ] `map-doctor.sh` with checks table above
- [ ] Wire `kb map doctor`

### P3 — Docs + vault (30m)
- [ ] Add registry note to `AGENTS.md` load protocol (optional tier)
- [ ] `kb lint` — ensure `personal/projects-registry.md` allowed (may need schema exception: generated file, no bullet cap)

### P4 — Run cleaning phases (human-gated)
- [ ] Phase A audit — user reviews output
- [ ] Phase B — PR in dotfiles for AI cleanup
- [ ] Phase C — user approves plan.yml moves
- [ ] Phase D — batch CODEBASE generation

---

## Verification

```bash
# After P0
kb map scan
kb map list --no-codebase | head
test -f ~/Vaults/AI/personal/projects-registry.md

# After P1
kb map codebase ~/dotfiles
kb map codebase --missing-only --all 2>&1 | tail -5

# After P2
kb map doctor | grep -c '\[fix\]\|\[review\]'

# Lint
kb lint
```

---

## Out of scope (v1)

- Auto-creating project brains for all repos
- LLM-based CODEBASE purpose inference
- Cross-machine registry merge (SuperBro/LinuxBro) — future: `infra/<host>/` overlay
- Deleting repos or `.cursor` cache automatically
- Replacing `inventory.sh` / `apply.sh`

---

## Related existing work

- `scripts/projects/inventory.sh` + `_inventory.md` (Apr 2026, 99 repos)
- `projects/dotfiles/plans/2026-06-25-cleanup.plan.md` (dotfiles wiring cleanup)
- `codebase` skill — agent reads CODEBASE.md; generator is this tool
- Session 2026-07-06 — architecture decision: registry ≠ brain ≠ CODEBASE
