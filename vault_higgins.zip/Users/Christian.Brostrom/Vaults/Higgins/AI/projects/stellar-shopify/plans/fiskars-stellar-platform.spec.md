---
name: Fiskars Stellar Platform Shell
overview: Thin platform meta-layer over existing sibling git repos — manifests, workspace generation, per-store app install matrix, and AI routing. Theme and apps stay separate repos.
status: proposed
captured: 2026-07-08
repo: stellar-shopify
related:
  - ~/Projects/clients/Fiskars/fiskars-stellar-project.code-workspace
  - ~/Projects/clients/Fiskars/stellar-shopify/tools/shopify-migrator
---

# Fiskars Stellar Platform — Spec

## Goal

When a developer or AI opens the workspace, they instantly know:

1. **What repos exist** and what each owns
2. **Which stores exist** (brand × env → `*.myshopify.com`)
3. **Which custom apps are installed where**, at what version, with what extensions/blocks
4. **How theme ↔ app touchpoints connect** (blocks, metafields, cart transforms, webhooks)

The theme repo (`stellar-shopify`) stays the theme. Apps stay independently deployable. The platform root is the map.

## Current state (2026-07-08)

- `~/Projects/clients/Fiskars/` has 17 git repos as siblings
- `fiskars-stellar-project.code-workspace` lists theme + 15 repos — incomplete (missing `admin-access`, `stellar-shopify-apps`)
- `fiskars-stellar.code-workspace` is theme-only
- Store domains exist in `stores/*/theme/shopify.theme.toml`
- App metadata exists in per-repo `shopify.app.toml`
- `shopify-migrator` has OAuth multi-store pattern (reuse for install audit)
- No machine-readable install matrix
- No platform-level `CODEBASE.md` / `AGENTS.md`

## Recommended architecture: Platform shell, not monorepo

```
~/Projects/clients/Fiskars/              ← platform root (AI opens here)
├── CODEBASE.md                          ← single AI router
├── AGENTS.md                            ← cross-repo rules
├── fiskars-stellar.code-workspace       ← generated from manifest
├── manifests/
│   ├── repos.yml
│   ├── stores.yml
│   ├── apps.yml
│   ├── integrations.yml                 ← hand-curated theme↔app contracts
│   └── installations.matrix.yml         ← generated, not hand-edited
├── scripts/
│   ├── sync-workspace.mjs
│   ├── audit-app-installs.mjs
│   └── clone-all.sh
├── stellar-shopify/                     ← existing git repo
├── stellar-shopify-app-*/               ← existing git repos
├── stellar-shopify-apps/                ← umbrella (stellar-extensions)
└── stellar-consumer-id-orchestrator/
```

### Why not merge into stellar-shopify

Apps have different deploy cadence, Azure backends, Partners app IDs, and CI. Coupling into the theme repo creates the wrong dependency graph and noisy AI context.

### Why not true monorepo migration

High cost (~17 repos), breaks existing pipelines, marginal gain over manifest + workspace.

### Platform root repo decision

**Recommended:** new thin repo `fiskars-stellar-platform` containing only manifests/scripts/workspace. Sibling repos stay siblings. Clean ownership, no nesting git repos.

Alternative: keep as unversioned folder layout with manifests committed to a new meta-repo.

## Manifest files

### 1. `manifests/repos.yml` — what exists (hand-maintained)

```yaml
repos:
  - id: stellar-shopify
    kind: theme
    path: stellar-shopify
    remote: akqa-den/...
    owns: [liquid, schemas, shared, build]
  - id: gift-wrapping
    kind: app
    path: stellar-shopify-app-gift-wrapping
    handle: stellar-gift-wrapping
    surfaces: [cart_transform, admin_embedded]
  - id: ui-extensions
    kind: app
    path: stellar-shopify-apps/stellar-extensions
    handle: stellar-ui-extensions
    surfaces: [checkout_ui, customer_account]
  - id: admin-access
    kind: app
    path: stellar-shopify-app-admin-access
    # currently missing from workspace — add
```

Known repos (2026-07-08):

| Repo | Kind |
|------|------|
| stellar-shopify | theme |
| stellar-shopify-app-admin-access | app |
| stellar-shopify-app-auto-fulfill-child-items | app |
| stellar-shopify-app-base-ui-extensions | app |
| stellar-shopify-app-bloomreach-enhancements | app |
| stellar-shopify-app-discount-information | app |
| stellar-shopify-app-gift-purchase-discount | app |
| stellar-shopify-app-gift-wrapping | app |
| stellar-shopify-app-market-discount | app |
| stellar-shopify-app-order-information | app |
| stellar-shopify-app-print-invoice | app |
| stellar-shopify-app-salesforce-notification | app |
| stellar-shopify-app-salesforce-voucher | app |
| stellar-shopify-app-tracking-web-pixel | app |
| stellar-shopify-app-warranty | app |
| stellar-shopify-app-wishlist | app |
| stellar-shopify-apps | umbrella (stellar-extensions) |
| stellar-consumer-id-orchestrator | service |

### 2. `manifests/stores.yml` — brand × environment (derived)

Scrape from `stellar-shopify/stores/*/theme/shopify.theme.toml`:

```yaml
stores:
  iittala:
    dev: iittala-develop.myshopify.com
    test: iittala-dev.myshopify.com
    live: iittala-webstore.myshopify.com
  wedgwood:
    dev: wedgwood-develop.myshopify.com
    test: wedgwood-dev.myshopify.com
    live: wedgwood-webstore.myshopify.com
  # georg-jensen, moominarabia, royal-copenhagen, royal-doulton, waterford
```

### 3. `manifests/apps.yml` — app metadata (auto-scraped)

Scrape from each repo's `shopify.app*.toml` + `extensions/*/shopify.extension.toml`:

| Field | Source |
|-------|--------|
| client_id, handle, name | shopify.app.toml |
| scopes | shopify.app.toml |
| extensions[] | extension toml files |
| theme_blocks[] | extension targets + block types |
| repo | repos.yml link |

Run on CI when any app repo changes.

### 4. `manifests/installations.matrix.yml` — per-store overview (generated)

```yaml
# generated — do not edit
iittala-live:
  stellar-gift-wrapping: { version: "2.1.0", enabled: true }
  stellar-ui-extensions:   { version: "1.4.2", enabled: true }
```

**Source:** Shopify Admin API per store, or Partners API. Reuse OAuth client-credentials from `shopify-migrator`.

Refresh: weekly cron + `npm run platform:audit` + optional PR on drift.

Include third-party apps tagged `kind: third_party`. Separate by env (dev/test/live) — installs differ.

### 5. `manifests/integrations.yml` — theme↔app contracts (hand-curated)

High ROI for AI working in theme repo without app source:

```yaml
gift-wrapping:
  app: stellar-gift-wrapping
  theme_touchpoints:
    - stores/*/theme/sections/shopping-cart.liquid
    - shared/scripts/utils/cart-*
  metafields: [custom.gift_wrap_message]
  stores: [all]  # or explicit list from matrix

wishlist:
  app: stellar-wishlist
  theme_touchpoints:
    - stores/*/snippets/wishlist-*
  stores: [iittala, wedgwood]  # from matrix
```

Start with highest-coupled apps: gift wrapping, wishlist, UI extensions, tracking pixel, market discount.

## AI loading strategy

| Layer | What | Where |
|-------|------|-------|
| L0 Platform | Router + install matrix + repo map | `Fiskars/CODEBASE.md` |
| L1 Repo | Deep dive per repo | each repo's `CODEBASE.md` |
| L2 Task | 2–3 files | codebase skill / CBM |

- **Cursor workspace root = `Fiskars/`**, not `stellar-shopify/`
- Platform `AGENTS.md`: theme changes → check install matrix; app changes → check store coverage
- codebase-memory-mcp: index from platform root for cross-repo search

## Phased rollout

### Phase 0 — half day (do first)

- [ ] Create `manifests/repos.yml` from directory listing
- [ ] `scripts/sync-workspace.mjs` → regenerate `.code-workspace`
- [ ] Platform `CODEBASE.md` — 1-page router
- [ ] `clone-all.sh` for onboarding

### Phase 1 — 1–2 days

- [ ] Scrape `shopify.app.toml` → `apps.yml`
- [ ] Scrape `shopify.theme.toml` → `stores.yml`
- [ ] `npm run platform:sync` at platform root

### Phase 2 — 2–3 days

- [ ] Port OAuth multi-store pattern from shopify-migrator
- [ ] `audit-app-installs.mjs` → `installations.matrix.yml`
- [ ] Optional markdown table output for humans

### Phase 3 — ongoing

- [ ] `integrations.yml` for theme↔app contracts
- [ ] CI: fail if repos.yml repo missing from disk/workspace
- [ ] CI: warn on install matrix drift > 7 days

### Phase 4 — only if needed

- Unified docs site from manifests
- Dependabot across repos via meta-repo
- **Not** merging git repos

## Anti-patterns

1. Submodule all repos into theme — git pain, wrong lifecycle
2. Hand-maintaining install matrix — drifts in a week
3. Opening only `stellar-shopify` in Cursor — AI blind to apps
4. Big-bang monorepo migration — months of CI rework
5. Duplicating app code into theme `shared/` — coupling nightmare

## Reuse from existing codebase

- Multi-store theme: `stores/*`, `shopify.theme.toml`
- Workspace prototype: `fiskars-stellar-project.code-workspace`
- OAuth multi-store: `stellar-shopify/tools/shopify-migrator`
- Theme app blocks: `stores/base/src/schemas/sections/apps.ts`, `@app` block support

## Open decisions

| Decision | Recommendation |
|----------|----------------|
| Platform root = new git repo? | Yes — `fiskars-stellar-platform` thin meta-repo |
| stellar-shopify-apps vs individual repos? | Both in repos.yml; mark canonical deploy target |
| Third-party apps in matrix? | Yes, tagged `kind: third_party` |
| Live vs dev matrix? | Nested under store key per env |
