---
name: Alias to relative migration
overview: Export `snakifyString` from the build package, write a codemod script to convert all `@/` and `@shared/` alias imports in stellar-shopify schema files to relative paths (and package imports for snakifyString), then publish a patch.
todos:
  - id: export-snakify
    content: Export snakifyString from package src/index.ts
    status: pending
  - id: write-codemod
    content: Write scripts/migrate-aliases.ts codemod
    status: pending
  - id: rebuild-publish
    content: Rebuild and publish patch version of the package
    status: pending
  - id: run-codemod
    content: Run codemod against stellar-shopify
    status: pending
  - id: verify
    content: Run shopify-build prepare and verify output
    status: pending
isProject: false
---

# Migrate schema imports from aliases to relative paths

## Context

Schema files across 8 stores (~1,347 files) use tsconfig path aliases (`@/schemas/*`, `@shared/*`) that break when the build package's orchestrator loads them via `jiti` at runtime. Instead of making the package resolve aliases, we fix the consumer codebase to use standard imports.

## 1. Package: export `snakifyString`

In [src/index.ts](src/index.ts), add:

```typescript
export { snakifyString } from './utils/strings.js';
```

Then rebuild and publish a patch (`0.1.x`).

## 2. Write codemod script

Create `scripts/migrate-aliases.ts` (a standalone Node.js script, lives in the build package repo for convenience). It will:

- Accept a `--root` arg pointing to the stellar-shopify repo root
- Glob all `stores/*/src/schemas/**/*.ts` files
- For each file, rewrite imports line-by-line:
  - **`@/schemas/*`** -- convert to a relative path calculated from the file's location within its store's `schemas/` directory. E.g. a file at `settings/foo.ts` importing `@/schemas/types/schemaTypes` becomes `../types/schemaTypes`
  - **`@shared/scripts/utils/snakifyString`** -- replace with `@akqa-denmark/shopify-theme-build` (the package now exports it)
- Write modified files in-place
- Print a summary of changes per store

### Alias resolution mapping

All `@/` aliases resolve relative to the store root (`stores/<name>/src/`), so `@/schemas/X` = `<store>/src/schemas/X`. Since every schema file is already under `<store>/src/schemas/`, the relative path is just `path.relative(dirname(file), schemasDir) + '/X'`.

The 7 distinct import targets:

- `@/schemas/settings` (barrel) -- e.g. from `sections/foo.ts` becomes `../settings`
- `@/schemas/settings/paragraph` -- from `sections/foo.ts` becomes `../settings/paragraph`
- `@/schemas/section-blocks` (barrel) -- from `sections/foo.ts` becomes `../section-blocks`
- `@/schemas/section-blocks/collection-teaser` -- relative
- `@/schemas/section-blocks/teaser-card` -- relative
- `@/schemas/types/schemaTypes` -- relative (type-only but converting for consistency)
- `@shared/scripts/utils/snakifyString` -- replaced with package import

## 3. Run in stellar-shopify

```bash
npx tsx scripts/migrate-aliases.ts --root /path/to/stellar-shopify
```

## 4. Verify

Run `shopify-build prepare` in stellar-shopify to confirm schema generation works without alias resolution.

## 5. Commit and PR in stellar-shopify

Single PR: "chore: replace alias imports with relative paths in schema files"

---

## Risks / edge cases

- **Barrel imports** (`@/schemas/settings`): requires that `settings/index.ts` exists. If any barrel is missing, the relative import also breaks -- but that's a pre-existing issue, not introduced by this change.
- **Other `@/` imports outside schemas**: the codemod only touches `schemas/` files. Vite-resolved aliases in `assets/scripts/` etc. remain unchanged (they're handled by Vite at dev/build time, not by the build package).
