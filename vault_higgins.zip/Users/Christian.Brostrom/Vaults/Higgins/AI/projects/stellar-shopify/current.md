# Brain: stellar-shopify
_Updated: 2026-06-19_

## Current State

`@akqa-denmark/shopify-theme-build` v0.1.1 patch pending publish (exports `snakifyString`).
stellar-shopify migration is done — coworker has completed the codemod + wiring.
Once 0.1.1 is published: run `npm install @akqa-denmark/shopify-theme-build@latest` in stellar-shopify.

## Conventions

