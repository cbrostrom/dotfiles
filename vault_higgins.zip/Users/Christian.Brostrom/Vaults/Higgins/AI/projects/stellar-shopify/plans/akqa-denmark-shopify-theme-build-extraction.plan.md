---
type: specification
status: ready
target: /Users/Christian.Brostrom/Projects/Internal/akqa-denmark-shopify-theme-build
source: /Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify
created: 2026-06-23
---

# @akqa-denmark/shopify-theme-build — Extraction Specification

Complete, self-contained spec for extracting the Shopify theme build pipeline into a standalone NPM package. An executing agent should be able to create the entire package from this document alone.

---

## Target Directory

```
/Users/Christian.Brostrom/Projects/Internal/akqa-denmark-shopify-theme-build
```

---

## Package Requirements

- **Node.js** >= 22.0.0
- **Vite** >= 8.0.0 (Rolldown, `resolve.tsconfigPaths`, native watcher)
- **ESM-only** package (`"type": "module"`)
- **Runtime**: Bun or Node (no runtime-specific APIs)

---

## Final Package Structure

```
akqa-denmark-shopify-theme-build/
├── src/
│   ├── index.ts                   # Public API: defineConfig, resolveConfig, orchestrate, types
│   ├── vite.ts                    # Subpath export: createViteConfig
│   ├── config/
│   │   ├── types.ts               # StoreDefinition, BuildConfig, ResolvedConfig interfaces
│   │   ├── resolve.ts             # Load shopify-build.config.ts via jiti, validate, resolve paths
│   │   └── conventions.ts         # Default paths, schema types, asset naming rules
│   ├── core/
│   │   ├── orchestrator.ts        # Main pipeline: glob → import → process → write
│   │   ├── schema-builder.ts      # TS schema → Liquid {% schema %} injection (sections/blocks)
│   │   ├── config-builder.ts      # TS schema → settings_schema.json (configs)
│   │   ├── locale-extractor.ts    # TS schema → locale translation data (in-memory)
│   │   └── locale-merger.ts       # Merge accumulated locale data → en.default.schema.json
│   ├── plugins/
│   │   └── schema-watcher.ts      # Vite plugin: hooks into server.watcher
│   ├── utils/
│   │   ├── logger.ts              # Chalk-based structured logger
│   │   ├── strings.ts             # snakifyString, formatToName, capitalizeFirstLetter
│   │   ├── objects.ts             # deepSortObjectKeys, removeEmptyObjects
│   │   ├── schema-comment.ts      # Auto-generated file comment header
│   │   └── version.ts             # resolveVersion from git tags
│   └── cli/
│       ├── index.ts               # CLI entry: parse args, dispatch commands
│       ├── prepare.ts             # `shopify-build prepare` implementation
│       └── manifest.ts            # `shopify-build manifest` JSON output
├── package.json
├── tsconfig.json
├── tsup.config.ts
└── README.md
```

---

## Step 1: package.json

```json
{
  "name": "@akqa-denmark/shopify-theme-build",
  "version": "0.1.0",
  "description": "Shopify theme build pipeline — schema generation, locale merging, and Vite config factory",
  "type": "module",
  "engines": {
    "node": ">=22.0.0"
  },
  "exports": {
    ".": {
      "types": "./dist/index.d.ts",
      "import": "./dist/index.js"
    },
    "./vite": {
      "types": "./dist/vite.d.ts",
      "import": "./dist/vite.js"
    }
  },
  "main": "./dist/index.js",
  "types": "./dist/index.d.ts",
  "bin": {
    "shopify-build": "./dist/cli/index.js"
  },
  "files": [
    "dist"
  ],
  "scripts": {
    "build": "tsup",
    "dev": "tsup --watch",
    "type-check": "tsc --noEmit",
    "prepublishOnly": "npm run build"
  },
  "dependencies": {
    "chalk": "^5.4.0",
    "jiti": "^2.4.0"
  },
  "peerDependencies": {
    "vite": "^8.0.0",
    "vite-plugin-shopify": ">=4.0.0",
    "vite-plugin-full-reload": ">=1.0.0",
    "@tailwindcss/vite": ">=4.0.0"
  },
  "peerDependenciesMeta": {
    "@tailwindcss/vite": {
      "optional": true
    }
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "tsup": "^8.0.0",
    "typescript": "^5.7.0",
    "vite": "^8.0.0",
    "vite-plugin-shopify": "^4.0.0",
    "vite-plugin-full-reload": "^1.2.0"
  },
  "keywords": ["shopify", "theme", "vite", "build", "schema"],
  "license": "MIT",
  "author": "AKQA Denmark"
}
```

---

## Step 2: tsconfig.json

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "declaration": true,
    "outDir": "dist",
    "rootDir": "src",
    "types": ["node"]
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
```

---

## Step 3: tsup.config.ts

```typescript
import { defineConfig } from 'tsup';

export default defineConfig({
  entry: {
    index: 'src/index.ts',
    vite: 'src/vite.ts',
    'cli/index': 'src/cli/index.ts',
  },
  format: ['esm'],
  dts: true,
  clean: true,
  target: 'node22',
  splitting: true,
  external: [
    'vite',
    'vite-plugin-shopify',
    'vite-plugin-full-reload',
    '@tailwindcss/vite',
  ],
  banner: {
    js: '#!/usr/bin/env node',
  },
  esbuildOptions(options) {
    // Only add shebang to CLI entry
    if (!options.entryPoints?.toString().includes('cli')) {
      options.banner = {};
    }
  },
});
```

Note: The shebang handling above is simplified. In practice, tsup's `banner` applies to all entries. A better approach is to use a separate tsup entry config for CLI vs library, or use a post-build script to add the shebang only to `dist/cli/index.js`.

---

## Step 4: Source Files

### src/config/types.ts

```typescript
export interface StoreDefinition {
  slug: string;
  name: string;
  foundation?: boolean;
}

export interface BuildConfig {
  stores: StoreDefinition[];
  defaultStore: string;
  storesDirectory?: string;
  sharedDirectory?: string;
  build?: {
    parallel?: boolean;
  };
  vite?: {
    port?: number;
    bundledDev?: boolean;
  };
}

export interface ResolvedConfig {
  stores: StoreDefinition[];
  defaultStore: string;
  storesDirectory: string;
  sharedDirectory: string;
  rootDir: string;
  build: {
    parallel: boolean;
  };
  vite: {
    port: number;
    bundledDev: boolean;
  };
}

export function defineConfig(config: BuildConfig): BuildConfig {
  return config;
}
```

### src/config/conventions.ts

```typescript
/** Default schema subdirectory types (relative to store/src/schemas/) */
export const SCHEMA_TYPES = [
  'settings',
  'configs',
  'sections',
  'blocks',
  'section-blocks',
  'section-groups',
] as const;

export type SchemaType = (typeof SCHEMA_TYPES)[number];

/** Schema types that generate Liquid {% schema %} blocks */
export const LIQUID_SCHEMA_TYPES: SchemaType[] = ['sections', 'blocks'];

/** Schema types that contribute to settings_schema.json */
export const CONFIG_SCHEMA_TYPES: SchemaType[] = ['configs'];

/** Schema types that contribute to locale files */
export const LOCALE_SCHEMA_TYPES: SchemaType[] = [
  'settings',
  'configs',
  'sections',
  'blocks',
  'section-blocks',
];

/** Convention: path from store root to schemas */
export const SCHEMAS_PATH = 'src/schemas';

/** Convention: path from store root to theme */
export const THEME_PATH = 'theme';

/** Convention: path from store root to entrypoints */
export const ENTRYPOINTS_PATH = 'src/assets/scripts/entrypoints';

/** Convention: path from store root to source */
export const SOURCE_PATH = 'src';

/** Shopify CDN asset naming rules */
export const ASSET_NAMING = {
  fonts: '[name].[ext]',
  css: '[name]-[hash].min.css',
  js: '[name]-[hash].min.js',
  other: '[name]-[hash].[ext]',
  entry: '[name]-[hash].js',
} as const;

/** Mapping from schema type to Liquid directory */
export const LIQUID_DIR_MAP: Record<string, string> = {
  sections: 'sections',
  blocks: 'blocks',
};
```

### src/config/resolve.ts

```typescript
import { existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import type { BuildConfig, ResolvedConfig } from './types.js';

const CONFIG_FILE_NAMES = [
  'shopify-build.config.ts',
  'shopify-build.config.js',
  'shopify-build.config.mjs',
];

export async function resolveConfig(cwd?: string): Promise<ResolvedConfig> {
  const rootDir = cwd || process.cwd();
  const configPath = findConfigFile(rootDir);

  if (!configPath) {
    throw new Error(
      `No config file found. Create one of: ${CONFIG_FILE_NAMES.join(', ')}`
    );
  }

  // Load TS/JS config via jiti
  const { createJiti } = await import('jiti');
  const jiti = createJiti(rootDir);
  const rawModule = await jiti.import(configPath);
  const raw: BuildConfig =
    (rawModule as { default?: BuildConfig }).default || (rawModule as BuildConfig);

  // Validate
  if (!raw.stores || raw.stores.length === 0) {
    throw new Error('Config must define at least one store');
  }
  if (!raw.defaultStore) {
    throw new Error('Config must define a defaultStore');
  }
  const defaultExists = raw.stores.some((s) => s.slug === raw.defaultStore);
  if (!defaultExists) {
    throw new Error(
      `defaultStore "${raw.defaultStore}" not found in stores array`
    );
  }

  return {
    stores: raw.stores,
    defaultStore: raw.defaultStore,
    storesDirectory: raw.storesDirectory || 'stores',
    sharedDirectory: raw.sharedDirectory || 'shared',
    rootDir,
    build: {
      parallel: raw.build?.parallel ?? true,
    },
    vite: {
      port: raw.vite?.port ?? 3000,
      bundledDev: raw.vite?.bundledDev ?? false,
    },
  };
}

function findConfigFile(rootDir: string): string | null {
  for (const name of CONFIG_FILE_NAMES) {
    const fullPath = resolve(rootDir, name);
    if (existsSync(fullPath)) return fullPath;
  }
  return null;
}

/**
 * Resolve which store to use.
 * Priority: explicit arg > CURRENT_STORE env > defaultStore from config
 */
export function resolveStore(
  config: ResolvedConfig,
  explicit?: string
): string {
  const store = explicit || process.env.CURRENT_STORE || config.defaultStore;
  const exists = config.stores.some((s) => s.slug === store);
  if (!exists) {
    const valid = config.stores.map((s) => s.slug).join(', ');
    throw new Error(`Store "${store}" not found. Valid: ${valid}`);
  }
  return store;
}

/**
 * Get resolved paths for a specific store
 */
export function getStorePaths(config: ResolvedConfig, store: string) {
  const storeDir = join(config.rootDir, config.storesDirectory, store);
  const themeDir = join(storeDir, 'theme');
  const srcDir = join(storeDir, 'src');
  const schemasDir = join(srcDir, 'schemas');
  const entrypointsDir = join(srcDir, 'assets/scripts/entrypoints');
  const localesDir = join(themeDir, 'locales');
  const configDir = join(themeDir, 'config');

  return { storeDir, themeDir, srcDir, schemasDir, entrypointsDir, localesDir, configDir };
}
```

### src/utils/logger.ts

Port from source. Key aspects:
- `log(type, ...args)` with types: `'info' | 'warn' | 'error' | 'success'`
- Uses chalk for coloring
- Respects `--verbose` flag and `BUILD_VERBOSE` env

### src/utils/strings.ts

Port these functions verbatim from `build/utils/strings.ts`:
- `snakifyString(input: string): string`
- `formatToName(fileName: string, type: string): string`
- `capitalizeFirstLetter(string: string): string`
- `removeTPrefix(obj)` (recursive t: prefix removal)

### src/utils/objects.ts

Port verbatim from `build/utils/objects.ts`:
- `deepSortObjectKeys<T>(value: T): T`
- `removeEmptyObjects(obj: unknown): unknown`

### src/utils/schema-comment.ts

Port verbatim from `build/utils/schema-comment.ts`:
- `createSchemaFileContent(data: unknown): string`
- `addSchemaCommentHeader(jsonContent: string): string`

### src/utils/version.ts

Port from `build/utils/resolve-version.ts`:
- `resolveVersion(): string` -- reads RELEASE_TAG env, falls back to `git describe --tags --abbrev=0`

---

## Step 5: Core Pipeline

### src/core/orchestrator.ts

The main pipeline. Replaces `build/core/orchestrator.ts`.

**Key differences from source:**
1. No barrel generation phase
2. No temp directory — locale data accumulates in memory
3. No format cache
4. Uses `fs.globSync` (Node 22) not `glob` package
5. Reads store name from config, not `process.env.CURRENT_STORE`
6. Accepts `ResolvedConfig` as input, not global constants

**Logic flow:**

```typescript
import { globSync } from 'node:fs';
import { join, resolve, basename, parse as pathParse } from 'node:path';
import { statSync } from 'node:fs';
import type { ResolvedConfig } from '../config/types.js';
import { getStorePaths, resolveStore } from '../config/resolve.js';
import { SCHEMA_TYPES, LOCALE_SCHEMA_TYPES, LIQUID_SCHEMA_TYPES, CONFIG_SCHEMA_TYPES } from '../config/conventions.js';
import { buildLiquidSchema } from './schema-builder.js';
import { buildConfigs } from './config-builder.js';
import { extractLocaleData } from './locale-extractor.js';
import { mergeAndWriteLocales } from './locale-merger.js';
import { log } from '../utils/logger.js';

export interface OrchestrateOptions {
  store?: string;
  config: ResolvedConfig;
  skipSchemas?: boolean;
  skipLocales?: boolean;
}

export async function orchestrate(options: OrchestrateOptions): Promise<void> {
  const { config, skipSchemas = false, skipLocales = false } = options;
  const store = resolveStore(config, options.store);
  const paths = getStorePaths(config, store);
  const startTime = Date.now();

  log('info', `Building store: ${store}`);

  // Accumulator for locale data (in-memory, no temp files)
  const localeAccumulator: Record<string, Record<string, unknown>> = {};

  // Process each schema type
  for (const schemaType of SCHEMA_TYPES) {
    const schemaDir = join(paths.schemasDir, schemaType);
    const pattern = join(schemaDir, '**/*.ts');
    
    // Use Node 22 fs.globSync
    let files: string[];
    try {
      files = globSync(pattern)
        .filter((f) => !basename(f).startsWith('index.'))
        .sort();
    } catch {
      continue; // Directory doesn't exist
    }

    if (files.length === 0) continue;

    // Process in parallel batches
    const batchSize = config.build.parallel ? Math.min(16, files.length) : 1;
    
    for (let i = 0; i < files.length; i += batchSize) {
      const batch = files.slice(i, i + batchSize);
      await Promise.all(batch.map(async (file) => {
        const { name } = pathParse(file);
        const module = await import(`${resolve(file)}?t=${Date.now()}`);
        let schema = module.default || module[formatToName(name, schemaType)];
        if (typeof schema === 'function') schema = schema();
        if (!schema) return;

        // Step 3a: Liquid schema injection (sections, blocks)
        if (!skipSchemas && LIQUID_SCHEMA_TYPES.includes(schemaType)) {
          await buildLiquidSchema(file, schema, schemaType, name, paths.themeDir);
        }

        // Step 3a alt: Config schema (settings_schema.json)
        if (!skipSchemas && CONFIG_SCHEMA_TYPES.includes(schemaType)) {
          // Configs are accumulated and written together
          // (handled separately below)
        }

        // Step 3b: Extract locale data (in-memory)
        if (!skipLocales && LOCALE_SCHEMA_TYPES.includes(schemaType)) {
          const localeData = extractLocaleData(schema);
          if (localeData && Object.keys(localeData).length > 0) {
            if (!localeAccumulator[schemaType]) {
              localeAccumulator[schemaType] = {};
            }
            localeAccumulator[schemaType][name] = localeData;
          }
        }
      }));
    }
  }

  // Handle configs (settings_schema.json)
  if (!skipSchemas) {
    await buildConfigs(paths, store, config);
  }

  // Step 4: Merge locale data and write en.default.schema.json
  if (!skipLocales) {
    await mergeAndWriteLocales(localeAccumulator, paths.localesDir);
  }

  const elapsed = Date.now() - startTime;
  log('success', `Build completed in ${elapsed}ms`);
}
```

**Important:** The above is pseudocode showing the structure. The actual implementation should handle:
- mtime-based skipping (compare input mtime vs output mtime)
- Error handling per-file (don't fail the whole build)
- The config builder needs special handling for `theme-info` (version injection)

### src/core/schema-builder.ts

Port from `build/core/schema/build-file.ts`. Key logic:

1. Takes a schema object + Liquid file path
2. Removes metadata keys (`originalLabel`, `defaultLabel`, `fieldType`)
3. Adds translation keys (`t:sections.{name}.settings.{id}.label`)
4. Reads the Liquid file
5. Replaces everything from `{% schema %}` to end with new JSON
6. Writes back

**Critical detail:** The `stringifyCompact` function that keeps short string arrays on one line. Port it exactly.

### src/core/config-builder.ts

Port from `build/core/schema/build-config-file.ts`. Key logic:

1. Processes all files in `schemas/configs/`
2. Each config becomes an entry in `settings_schema.json` (a JSON array)
3. `theme-info` is always first, gets version injected from `resolveVersion()`
4. Gets store display name from config (`config.stores.find(s => s.slug === store).name`) **instead of version.json**

### src/core/locale-extractor.ts

Port from `build/core/json/transform.ts`. The `extractLocaleData` function that pulls `name`, `label`, `info`, `options[].label` from schema objects into a flat locale structure.

### src/core/locale-merger.ts

Port from `build/core/locale/merge.ts` but simplified:
- Takes the in-memory `localeAccumulator` (not files from temp dir)
- Structures by type: `{ global: {...}, theme_settings: {...}, sections: {...}, blocks: {...}, section_blocks: {...} }`
- Deep-sorts keys deterministically
- Writes single file: `{localesDir}/en.default.schema.json` with comment header

---

## Step 6: Vite Integration

### src/vite.ts

```typescript
import { resolve, join } from 'node:path';
import { defineConfig, mergeConfig, type UserConfig } from 'vite';
import { resolveConfig, resolveStore, getStorePaths } from './config/resolve.js';
import { ASSET_NAMING } from './config/conventions.js';
import { createSchemaWatcherPlugin } from './plugins/schema-watcher.js';

export async function createViteConfig(overrides?: UserConfig): Promise<UserConfig> {
  const config = await resolveConfig();
  const store = resolveStore(config);
  const paths = getStorePaths(config, store);

  // Auto-detect optional plugins
  let tailwindPlugin: unknown = null;
  try {
    const tw = await import('@tailwindcss/vite');
    tailwindPlugin = (tw.default || tw)();
  } catch {
    // @tailwindcss/vite not installed, skip
  }

  const shopify = (await import('vite-plugin-shopify')).default;
  const fullReload = (await import('vite-plugin-full-reload')).default;

  const baseConfig = defineConfig({
    base: '',
    cacheDir: resolve(config.rootDir, '.cache/vite', store),

    plugins: [
      shopify({
        themeRoot: paths.themeDir,
        sourceCodeDir: paths.srcDir,
        entrypointsDir: paths.entrypointsDir,
      }),
      createSchemaWatcherPlugin(config, store),
      fullReload(
        [
          `${paths.themeDir}/**/*.{liquid,json}`,
          `${paths.schemasDir}/**/*.ts`,
        ],
        { delay: 100 }
      ),
      ...(tailwindPlugin ? [tailwindPlugin] : []),
    ],

    resolve: {
      tsconfigPaths: true,
    },

    css: {
      devSourcemap: true,
    },

    build: {
      outDir: join(paths.themeDir, 'assets'),
      emptyOutDir: true,
      rolldownOptions: {
        output: {
          assetFileNames: (assetInfo: { name?: string }) => {
            const name = assetInfo.name || '';
            if (/\.(woff2|woff|ttf|otf|eot)$/i.test(name)) return ASSET_NAMING.fonts;
            if (/\.css$/i.test(name)) return ASSET_NAMING.css;
            if (/\.js$/i.test(name)) return ASSET_NAMING.js;
            return ASSET_NAMING.other;
          },
          entryFileNames: ASSET_NAMING.entry,
        },
      },
    },

    server: {
      port: config.vite.port,
      host: '0.0.0.0',
      cors: { origin: true, credentials: true },
      watch: {
        ignored: ['**/node_modules/**', '**/.git/**', '**/.cache/**'],
      },
      hmr: {
        protocol: 'ws',
        host: 'localhost',
        port: config.vite.port,
      },
    },

    ...(config.vite.bundledDev ? { experimental: { bundledDev: true } } : {}),
  });

  return overrides ? mergeConfig(baseConfig, overrides) : baseConfig;
}
```

### src/plugins/schema-watcher.ts

```typescript
import { join } from 'node:path';
import type { Plugin } from 'vite';
import type { ResolvedConfig } from '../config/types.js';
import { getStorePaths } from '../config/resolve.js';
import { orchestrate } from '../core/orchestrator.js';
import { log } from '../utils/logger.js';

export function createSchemaWatcherPlugin(
  config: ResolvedConfig,
  store: string
): Plugin {
  const paths = getStorePaths(config, store);
  let debounceTimer: ReturnType<typeof setTimeout> | null = null;
  const DEBOUNCE_MS = 3000;

  return {
    name: 'shopify-schema-watcher',
    configureServer(server) {
      // Hook into Vite's existing watcher
      server.watcher.add(paths.schemasDir);

      server.watcher.on('change', (file) => {
        if (!file.startsWith(paths.schemasDir)) return;
        if (!file.endsWith('.ts')) return;
        if (file.includes('index.ts')) return;

        if (debounceTimer) clearTimeout(debounceTimer);

        debounceTimer = setTimeout(async () => {
          log('info', `Schema changed: ${file}`);
          try {
            await orchestrate({ store, config });
            log('success', 'Schema rebuild complete');
          } catch (error) {
            log('error', `Schema rebuild failed: ${error}`);
          }
        }, DEBOUNCE_MS);
      });

      log('info', `Schema watcher active for: ${paths.schemasDir}`);
    },
  };
}
```

---

## Step 7: CLI

### src/cli/index.ts

```typescript
#!/usr/bin/env node
import { resolveConfig } from '../config/resolve.js';

const [, , command, ...args] = process.argv;

async function main() {
  switch (command) {
    case 'prepare': {
      const { runPrepare } = await import('./prepare.js');
      await runPrepare(args);
      break;
    }
    case 'manifest': {
      const { runManifest } = await import('./manifest.js');
      await runManifest();
      break;
    }
    default:
      console.error(`Unknown command: ${command}`);
      console.error('Available commands: prepare, manifest');
      process.exit(1);
  }
}

main().catch((err) => {
  console.error(err.message || err);
  process.exit(1);
});
```

### src/cli/prepare.ts

```typescript
import { resolveConfig } from '../config/resolve.js';
import { orchestrate } from '../core/orchestrator.js';

export async function runPrepare(args: string[]) {
  const storeFlag = args.indexOf('--store');
  const store = storeFlag !== -1 ? args[storeFlag + 1] : undefined;

  const config = await resolveConfig();
  await orchestrate({
    store,
    config,
    skipSchemas: args.includes('--skip-schemas'),
    skipLocales: args.includes('--skip-locales'),
  });
}
```

### src/cli/manifest.ts

```typescript
import { resolveConfig } from '../config/resolve.js';

export async function runManifest() {
  const config = await resolveConfig();
  const manifest = {
    stores: config.stores.map((s) => ({
      slug: s.slug,
      name: s.name,
      deployable: !s.foundation,
    })),
  };
  process.stdout.write(JSON.stringify(manifest, null, 2) + '\n');
}
```

---

## Step 8: Main Entry

### src/index.ts

```typescript
export { defineConfig } from './config/types.js';
export { resolveConfig, resolveStore, getStorePaths } from './config/resolve.js';
export { orchestrate } from './core/orchestrator.js';
export type {
  BuildConfig,
  StoreDefinition,
  ResolvedConfig,
} from './config/types.js';
```

---

## Source File Mapping (what to port from where)

| Package file | Source in stellar-shopify | Notes |
|---|---|---|
| `core/schema-builder.ts` | `build/core/schema/build-file.ts` | Remove progress bar deps; add mtime skip |
| `core/config-builder.ts` | `build/core/schema/build-config-file.ts` | Replace version.json read with config lookup |
| `core/locale-extractor.ts` | `build/core/json/transform.ts` | Verbatim port of `extractLocaleData` |
| `core/locale-merger.ts` | `build/core/locale/merge.ts` | Rewrite to accept in-memory data, not read from temp dir |
| `utils/logger.ts` | `build/utils/logger.ts` | Simplify: remove `cli` type, keep core logic |
| `utils/strings.ts` | `build/utils/strings.ts` | Port: snakifyString, formatToName, capitalizeFirstLetter, removeTPrefix |
| `utils/objects.ts` | `build/utils/objects.ts` | Port: deepSortObjectKeys, removeEmptyObjects |
| `utils/schema-comment.ts` | `build/utils/schema-comment.ts` | Verbatim |
| `utils/version.ts` | `build/utils/resolve-version.ts` | Verbatim |
| `plugins/schema-watcher.ts` | `build/plugins/shopify-watchers.ts` | Complete rewrite: use server.watcher |
| `vite.ts` | `vite.config.ts` (root) | Rewrite as factory with config resolution |

---

## Critical Implementation Details

### 1. Schema import with cache busting

Schemas are imported with `?t=${Date.now()}` to bypass Node's module cache:
```typescript
const module = await import(`${resolve(filePath)}?t=${Date.now()}`);
```

### 2. Liquid schema injection format

The `{% schema %}` block in Liquid files uses a custom compact JSON stringifier that keeps short string arrays on single lines. Port `stringifyCompact` from `build/core/schema/build-file.ts` exactly.

### 3. Config builder: theme_name injection

The `theme_name` in `settings_schema.json` now comes from config instead of version.json:
```typescript
const storeConfig = config.stores.find(s => s.slug === store);
themeInfo.theme_name = storeConfig?.name || store;
```

### 4. Locale merger structure

The final `en.default.schema.json` has this structure:
```json
{
  "global": { /* from settings schemas */ },
  "theme_settings": { /* from configs schemas */ },
  "section_blocks": { /* from section-blocks schemas */ },
  "sections": { /* from sections schemas */ },
  "blocks": { /* from blocks schemas */ }
}
```

### 5. mtime-based skip logic

For each schema file, check if the output is newer than all inputs:
```typescript
const inputMtime = statSync(inputFile).mtimeMs;
const outputMtime = statSync(outputFile).mtimeMs;
if (outputMtime > inputMtime) return; // Skip, output is fresh
```

### 6. Node 22 fs.globSync usage

```typescript
import { globSync } from 'node:fs';

// Returns string[] of matching paths
const files = globSync(join(schemasDir, '**/*.ts'));
```

Note: Node 22's `fs.globSync` uses `**` for recursive matching. If not available in all Node 22 builds, fallback to manual recursive readdir.

---

## Verification Checklist

After building the package, test against stellar-shopify:

1. `cd /Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify`
2. Create `shopify-build.config.ts` with store definitions
3. `npm link ../Internal/akqa-denmark-shopify-theme-build`
4. Run: `npx shopify-build prepare --store moominarabia`
5. Compare output:
   - `stores/moominarabia/theme/locales/en.default.schema.json` should be identical
   - `stores/moominarabia/theme/config/settings_schema.json` should be identical
   - `stores/moominarabia/theme/sections/*.liquid` schema blocks should be identical
6. Test `npx shopify-build manifest` outputs correct JSON
7. Test `vite build` with new config produces identical assets

---

## Consumer Example (stellar-shopify after migration)

### shopify-build.config.ts

```typescript
import { defineConfig } from '@akqa-denmark/shopify-theme-build';

export default defineConfig({
  stores: [
    { slug: 'moominarabia', name: 'Moomin Arabia' },
    { slug: 'georg-jensen', name: 'Georg Jensen' },
    { slug: 'royal-doulton', name: 'Royal Doulton' },
    { slug: 'royal-copenhagen', name: 'Royal Copenhagen' },
    { slug: 'wedgwood', name: 'Wedgwood' },
    { slug: 'waterford', name: 'Waterford' },
    { slug: 'iittala', name: 'Iittala' },
    { slug: 'base', name: 'Base', foundation: true },
  ],
  defaultStore: 'moominarabia',
});
```

### vite.config.ts

```typescript
import { createViteConfig } from '@akqa-denmark/shopify-theme-build/vite';

export default createViteConfig();
```

### package.json scripts (relevant subset)

```json
{
  "scripts": {
    "build:prepare": "shopify-build prepare",
    "build:full": "shopify-build prepare && vite build",
    "vite:dev": "vite",
    "vite:build": "vite build"
  }
}
```
