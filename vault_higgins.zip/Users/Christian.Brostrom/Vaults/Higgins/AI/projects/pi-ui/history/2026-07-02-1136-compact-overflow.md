# Compact overflow — pi-ui — 2026-07-02 11:36

- Tauri v2 + SolidJS + Tailwind v4 + Bun desktop app that spawns pi --mode rpc as its AI backend pi-ui
- Core RPC plumbing complete: pi_start/prompt/steer/abort/set_model/send_raw Rust commands; JSONL stdout → pi:event Tauri events pi-ui
- Frontend: ChatView + TextBlock (marked+DOMPurify markdown) + ThinkingBlock + ToolCallChip + InputBar + TitleBar + ConfirmModal all implemented pi-ui
- UX: Enter sends, Shift+Enter newline; model picker centred in title bar (200/300K context only, no fast variants); CWD shown in title bar; isConnecting loading state pi-ui
- extension_ui_request confirm surfaced as modal; select/input/editor auto-answered; pi process killed on restart to avoid orphans pi-ui
