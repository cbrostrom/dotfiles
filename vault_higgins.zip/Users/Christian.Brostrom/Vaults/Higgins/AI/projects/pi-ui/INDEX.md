# Brain index: pi-ui
- current.md (11L) — _Updated: 2026-07-02_
- gotchas.md (11L) — - Tauri sandbox PATH is minimal — must prepend ~/.local/bin:
- next.md (13L) — - Test end-to-end: verify streaming, markdown, tool chips, m
- history/ — 1 session(s), last 2026-07-02-1136-compact-overflow
