# Brain: akqa-den-webhandbook
_Updated: 2026-07-01_

- Active AKQA DEN project — team-facing web handbook for engineering standards, patterns, and conventions
- Purpose: living reference distilled from `stellar-shopify`, `akqa-denmark-shopify-theme-build`, and cross-client learnings
- Source of truth for Shopify patterns will move to `modules/shopify/` — this project consumes/references
- Status: initial content pending — **user to seed real current state on next session**
- Sharing: internal AKQA only
