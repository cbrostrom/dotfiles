# Brain: hopper
_Updated: 2026-07-01_

- Renamed from hopline (2026-07-01). Tauri 2 + SolidJS + TS + SQLite (tauri-plugin-sql). Last commit `d9a6f72` on main.
- Persistent Tabs (Phase 5a–5d) complete: saved tabs, folders (2-level, CRUD), global + space pins, drag-and-drop via `@thisbeyond/solid-dnd` + custom `HoldDragSensor` (innermost-wins).
- Sidebar autohide + multi-monitor + Settings window + App icon mode + Spaces all shipping.
- Quality gate: aislop ≥ 90, fallow 0 issues, tsc 0 errors, `cargo clippy -- -D warnings` clean before commit.
- Cross-project patterns (HoldDragSensor, jiggle_cursor, stable `<For>` keys) distilled into `modules/tauri-solidjs/`.
