# Brain index: hopper
- current.md (8L) — _Updated: 2026-07-01_
- gotchas.md (42L) — _Updated: 2026-06-20_
- next.md (32L) — _Updated: 2026-07-01_
- history/ — 5 session(s), last 2026-07-01-2214-preTrim-current
- archive/ — 1 monthly file(s)
