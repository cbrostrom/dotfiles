# hopline brain closed
_2026-07-01_

Project renamed to **Hopper**. Vault `brains/hopline/` merged into `brains/hopper/` and removed.

Historical session wraps remain in `history/` (dated 2026-06-19, pre-rename).
