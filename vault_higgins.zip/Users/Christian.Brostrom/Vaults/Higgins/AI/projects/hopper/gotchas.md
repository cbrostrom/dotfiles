# Gotchas: hopper
_Updated: 2026-06-20_

## WKWebView / macOS specific

- **`:hover` doesn't activate on window appear** — fixed with `jiggle_cursor` Tauri command
  (1pt OS cursor warp). Call it after sidebar slides in AND after every drag end.
- **`window.prompt()` returns null** — Tauri's WKWebView silently rejects it.
  Use `InlineInput` component everywhere an inline edit is needed.
- **Click fires after pointerup** — even with `e.preventDefault()` on pointerup.
  Fixed in `HoldDragSensor`: register a capture+once click suppressor when drag was active.

## solid-dnd specifics

- **Event bubbling with nested draggables**: `pointerdown` bubbles through ALL ancestor
  draggable elements. The sensor's activator fires for EACH one. Inner fires first (correct).
  Guard: `if (holdTimer !== null) return` in the activator = innermost draggable wins.
- **`stopPropagation()` breaks delegation**: solid-dnd uses event delegation up to
  `DragDropProvider`. Calling `stopPropagation()` on a child prevents the event from
  reaching the provider — no drag starts at all. Never use it for DnD elements.
- **`closestCenter` shifts folders during tab drags**: Fixed with `tabAwareCollision`:
  tabs only sort against other tabs; folders are pure drop targets detected by
  `getBoundingClientRect()` intersection.
- **`DragOverlay` export exists** in 0.7.5 but not needed yet (in-place ghost with ring
  is sufficient).

## SolidJS reactivity

- **`<For>` identity with plain objects**: creates new objects every render → `<For>`
  recreates ALL children on every update. Use stable primitive keys (strings/numbers).
  Pattern: `createMemo` returning `string[]` → `<For each={keys()}>` → look up store
  data reactively inside the loop.
- **`InlineInput` double-commit**: `onKeyDown Enter` → sets state to hide input →
  unmount fires `onBlur` → `onCommit` called twice. Fix: `committed` flag guards both.

## Rust / Tauri

- `warp_cursor` / `get_cursor_pos` are `#[cfg(target_os = "macos")]` only.
  `jiggle_cursor` command is cross-platform safe (no-op on non-mac, cfg-gated inside).
- `menu_on_left_click` is deprecated — use `show_menu_on_left_click(false)`.
- Menu bar height: use `NSScreen.mainScreen.visibleFrame` via objc2 (not a constant).
  Stored as `MENU_BAR_HEIGHT_CENTIDOTS: AtomicI32`.
