# Next: hopper
_Updated: 2026-07-01_

## PIVOT: Omnibox-first command bar app

Project renamed to **Hopper**. Pivoting from sidebar-first to command-bar-first.
Full spec + implementation plan in `~/Vaults/Me/Ideas/Hopline Omnibox Pivot/`.

### Implementation phases (critical path)

- **Phase 0** — Rename hopline → hopper (all files, Cargo, extension, configs)
- **Phase 1** — Add `uiMode` setting: `"omnibox"` | `"sidebar"` | `"both"` (default both). Omnibox mode hides sidebar, sidebar mode hides shortcut.
- **Phase 2** — Change global shortcut from Cmd+T to Option+Space + **Helium-only dynamic registration** (`hopBarScope`). Cmd+T conflicts with Chrome.
- **Phase 3** — Promote hop bar: default to statusbar icon, tray click → hop bar, update onboarding
- **Phase 4** — Enhance search: folder search, context display, active tab boost, `>` command prefix

### Post-MVP
- Phase 5 — Frecency scoring (tab_events table, decay function)
- Phase 6 — Feature-gate sidebar code for smaller omnibox-only binary

### Deprioritized (sidebar-era phases, still valid for sidebar mode)
- Folder colours
- Tab metadata sync
- Keyboard navigation in sidebar
- Spaces management UI
- Export / Import

### Deferred / won't do soon
- Profile support
- Deep folder nesting
- Browser history search (Phase 2+ stretch)
- Multi-browser support
