# Brain: raycast-extensions
_Updated: 2026-06-21_

## Current State

Goal: make Raycast extension development low-friction and easy to query from the
vault.

Best-known starting flow:

- In Raycast, run `Create Extension`
- Choose a template and parent folder
- In the new folder, run `npm install && npm run dev`
- Re-open Raycast and launch the command from Root Search
- Iterate by editing `src/*.tsx` or `src/*.ts`

## Conventions

- Prefer scaffolding via Raycast's built-in creator over hand-rolling setup.
- `package.json` is both npm package metadata and the Raycast manifest.
- Each command name maps to a source file in `src/` (for example
  `name: "create"` -> `src/create.tsx`).
- Use `tsx` for UI commands; `ts` is enough for non-UI or script-style commands.
- Treat the official docs as queryable: append `.md` to pages and use
  `?ask=<question>` for targeted answers.
- Canonical docs index: `https://developers.raycast.com/llms.txt`

## Canonical Sources

- Manual overview: `https://manual.raycast.com/extensions#create-your-own`
- Dev docs home: `https://developers.raycast.com/`
- Getting started: `https://developers.raycast.com/basics/getting-started`
- First extension:
  `https://developers.raycast.com/basics/create-your-first-extension`
- Manifest: `https://developers.raycast.com/information/manifest`
- File structure: `https://developers.raycast.com/information/file-structure`
