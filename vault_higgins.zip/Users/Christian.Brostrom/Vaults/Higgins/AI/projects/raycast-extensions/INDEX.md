# Brain index: raycast-extensions
- current.md (8L) — _Updated: 2026-07-01_
- gotchas.md (17L) — - **Sign-in is required** to use Raycast's `Create Extension
- next.md (11L) — - Create one small local extension first, ideally from the `
- history/ — 1 session(s), last 2026-07-01-2214-preTrim-current
