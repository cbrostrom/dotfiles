# Next: raycast-extensions

- Create one small local extension first, ideally from the `Detail` or `List`
  template.
- Keep the first version narrow: one command, one input path, one clear output.
- Use docs queries instead of browsing when stuck:
  - `https://developers.raycast.com/readme.md?ask=What should I read first to build a simple extension?`
  - `https://developers.raycast.com/information/manifest.md?ask=How do command preferences work?`
  - `https://developers.raycast.com/information/file-structure.md?ask=How does a command name map to files in src?`
- Once a real extension repo exists, create a repo-specific brain for decisions,
  architecture, and publishing notes.
