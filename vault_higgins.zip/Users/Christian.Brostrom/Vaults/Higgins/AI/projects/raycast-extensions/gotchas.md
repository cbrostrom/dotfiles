# Gotchas: raycast-extensions

- **Sign-in is required** to use Raycast's `Create Extension`, `Import Extension`,
  and `Manage Extensions` commands.
- **Prereqs matter**: docs currently call for Raycast 1.26.0+, Node.js 22.14+,
  and npm 7+.
- **`npm run dev` is the main dev loop**: it enables hot reloading, error
  reporting, and local iteration.
- **Mac dev behavior changed**: `npm run dev` opens in Raycast v2 if it is
  running, and falls back to v1 otherwise. Keep `@raycast/api` current.
- **Local dev/imported extensions are not Store-managed**: they stay installed in
  Raycast, but updates are your responsibility.
- **Permissions are mostly OS-level**: when an extension needs protected
  directories or system capabilities, Raycast prompts through normal macOS
  permission flows.
- **The docs are AI-friendly on purpose**: markdown pages (`.md`) and direct
  questions (`?ask=...`) are faster than browsing random pages manually.
