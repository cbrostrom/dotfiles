# Brain: raycast-extensions
_Updated: 2026-07-01_

- Goal: low-friction Raycast extension dev, easily queryable from vault
- Scaffold via `Create Extension` in Raycast → template + parent folder → `npm install && npm run dev`
- `package.json` = both npm metadata AND Raycast manifest. `name: "create"` → `src/create.tsx`. `tsx` for UI, `ts` for scripts.
- Docs are queryable: append `.md` to any page + `?ask=<question>`. Canonical index: `https://developers.raycast.com/llms.txt`
- Full scaffolding flow + doc URLs archived in `history/2026-07-01-2214-preTrim-current.md`
