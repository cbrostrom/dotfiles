# Brain: laesr
_Updated: 2026-07-01_

- Stack: Bun + Hono + Drizzle + SQLite (WAL). Single-process, single-container. No Redis/Bull/Prisma/PostgreSQL.
- v2.2.5 shipped: 503 loader fix, per-feed full-article extraction toggle, YouTube thumbnail/embed fixes, pubDate freeze, same-feed title dedup.
- Two entrypoints: `apps/api/src/index.ts` (dev :4000), `apps/api/server.ts` (prod — serves API + SPA static).
- Infra: SuperBro VPS (6C EPYC, 12GB, no swap). Container mgmt via Dockhand (port 3000, `fnsys/dockhand:latest`), NOT Portainer.
- Full architecture + conventions distilled to `modules/bun-sqlite-hono/`; project-specific gotchas in `gotchas.md`.
