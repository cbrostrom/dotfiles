# Brain index: laesr
- current.md (8L) — _Updated: 2026-07-01_
- gotchas.md (20L) — `--z-*` is NOT recognised by Tailwind v4's `@theme` block. D
- next.md (2L) — —
- history/ — 1 session(s), last 2026-07-01-2214-preTrim-current
