# Gotchas: laesr

## Tailwind v4: z-index is NOT a theme namespace
`--z-*` is NOT recognised by Tailwind v4's `@theme` block. Defining `--z-modal: 100` in `@theme` generates nothing. The `z-modal` utility class will silently not exist.
- Keep z-index tokens in `:root` (e.g. `spacing.css`)
- Reference them with the parenthetical syntax: `z-(--z-navbar-mobile)` (shorthand for `z-[var(--z-navbar-mobile)]`)
- Recognised namespaces: `--color-*`, `--spacing-*`, `--radius-*`, `--shadow-*`, `--font-*`, `--text-*` etc. z-index is NOT one of them.
- Discovered 2026-03-26 when mobile navbar kept disappearing behind article modal despite seemingly correct tokens.

## Dockerfile: use Debian slim, NOT Alpine
Alpine's musl DNS resolver has known issues with IPv6 fallback and `EAI_AGAIN` under load, which breaks external HTTP calls (e.g. to OpenRouter, RSS feeds). Always use `oven/bun:*-slim` (Debian) for the runtime image.
- Build deps: `libcairo2-dev`, `libjpeg62-turbo-dev`, `libpango1.0-dev`, `libgif-dev`, `libpixman-1-dev`
- Runtime deps: `libcairo2`, `libjpeg62-turbo`, `libpango-1.0-0`, `libpangocairo-1.0-0`, `libgif7`, `libpixman-1-0`
- Healthcheck: use `curl`, not `wget` (wget not available in slim)

## Zombie subprocess leak — RESOLVED by stack migration
Old stack (Express/Node, pre-2026-05) accumulated 169 zombie subprocesses from content extraction (likely Playwright/headless browser). This was eliminated by the Bun + Hono migration — the current `contentExtractor.ts` uses only `fetch()` + `cheerio` + `@mozilla/readability`, all in-process. No `Bun.spawn`, `child_process`, or `worker_threads` exist anywhere in the runtime code. Confirmed 2026-06-24 via full codebase grep.

## fallow: invoke via npx (binary not on PATH)
`fallow` is NOT installed globally on this machine — `fallow ... || true` silently returns empty (looks like "no issues") if the binary is missing. Always run `npx --yes fallow <cmd> --format json --quiet 2>/dev/null || true`. Full usage reference: `~/Vaults/Brain/Development/Frameworks/Fallow.md`. For QA after each stream: `npx --yes fallow audit --base main --format json --quiet 2>/dev/null || true`.
