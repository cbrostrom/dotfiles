# Brain: laesr
_Updated: 2026-06-26_

## Current State
Stack migration from Express + Prisma + PostgreSQL + Redis + Node to **Bun + Hono + Drizzle + SQLite** is complete. Single-process, single-container architecture. No Redis, no Bull, no Prisma, no PostgreSQL.

Latest work (2026-06-24): 10 performance fixes (SQLite pragmas, feed burst stagger, job queue cap, body size caps, semaphore fix, SSE dedup, cleanup inline, VACUUM removed) + RSS output endpoints + kiosk view for Helium.

Latest work (2026-06-25 → 2026-06-26): Multiple bug fixes and features shipped in v2.2.5:
- **503 loader fix**: `AuthContext` now tracks `serverError` signal; `ProtectedRoute` shows "Server unavailable" retry screen on 5xx instead of redirecting to login.
- **Per-feed full-article extraction toggle**: `feeds.extract_full_content` column (default `false`). UI toggle in EditFeedDrawer. Articles route gates extraction on feed setting. `contentPrewarm` cron skips feeds with extraction off. Migration `0015_open_black_tom.sql`.
- **YouTube thumbnails**: Fixed `extractImageFromRSSItem` — now reads `media:thumbnail` inside `media:group` (YouTube-specific nesting). Also extracts `media:group.media:description` as article description fallback.
- **YouTube embed**: `ArticleDrawer` shows responsive 16:9 `<iframe>` embed for YouTube articles instead of markdown content. Video ID parsed from article URL at render time (no schema change).
- **pubDate freeze**: `onConflictDoUpdate` no longer includes `pubDate` — first-seen date is preserved. Prevents feeds that re-stamp items on every serve from reshuffling sort order.
- **Same-feed title dedup**: Before upserting, checks `(feedId, titleNormalized)` for existing row. Skips re-insert if found — protects against feeds that rotate article URLs between fetches.
- **Migration test fix**: Three fresh-DB assertions updated to accept either "no drift detected" or "applied N repair statements" (migration 0015 has overlapping DDL; schema-sync self-heals; second run is always clean).

## Infra: SuperBro VPS
- **6 CPU cores** (AMD EPYC), **12GB RAM**, 194GB disk
- No swap configured — OOM kill is possible under sustained load
- Container management: **Dockhand** (NOT Portainer) — port 3000, image `fnsys/dockhand:latest`
- Stack env vars live in Dockhand, not docker-compose files

## Conventions
- English everywhere in code (comments, identifiers, UI strings, commits, docs). Chat replies can be Danish. Brand name `laesr` stays as-is.
- Drizzle + `bun:sqlite` — never reach for raw `sqlite.query()` outside `lib/`
- Drawer over inline popper for create/edit flows
- Dark theme: `bg-gray-900 / bg-gray-800 / text-gray-100 / border-gray-700 / accent bg-blue-600`
- Commit format: `type(scope): subject` — imperative, lowercase, ≤72 chars
- No magic numbers — use DOM measurements or named constants

## Key Architecture Notes
- Two entrypoints: `apps/api/src/index.ts` (dev :4000) and `apps/api/server.ts` (prod — serves API + SPA static)
- Workers use `globalThis` Symbol guards to prevent duplicate startup across Bun `--hot` reloads
- Job queue is SQLite-backed (`lib/jobQueue.ts`) with dedupe on `(dedupe_key, status)` partial unique index
- SSE heartbeat every 25s — requires `idleTimeout: 255` on Bun server (default 10s kills streams)
- Feed dedupe key pattern: `feed_update:${feedId}` (unified across cron, routes, opml)
- Article list endpoints exclude `content` + `aiTopics` columns — use `articleListColumns` from `lib/articleColumns.ts`
- RSS output key: stored as `rss_api_key` setting, generate via `POST /api/settings/rss-key/generate`
- Kiosk view: `/kiosk?key=<rss-api-key>` — auth-gated, auto-refreshes every 5 min
