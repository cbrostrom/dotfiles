# AI Vault Reorganisation Plan

## Context

The `~/Vaults/AI` brain vault is architecturally sound but cluttered: 91 files across 3 coexisting formats (modular folders, flat files, hybrids), 4 hollow stub brains, an empty `knowledge/` tier, a ghost project (`tabflow.md`), an unactioned curator report, no root-level agent contract, and no sharable modular unit for team knowledge (e.g. Shopify).

Goals:
1. Uniform, lint-enforced schema across all brains.
2. Clear tier separation: contract / personal / modules / projects / infra / sessions / ops.
3. Modular sharing story — each `modules/<name>/` extractable via `git subtree` for team consumption.
4. Multi-harness support (PI, Cursor IDE, Cursor-Agent in Zed) via a single `AGENTS.md` contract.
5. Self-maintaining via `brain prune`, `brain compact`, `brain lint`, weekly session promotion.

## Approach

Rename `brains/` → `projects/` and split top level into named tiers. Introduce a modular `modules/` tier as the shareable unit. Consolidate the two empty personal brains (`Christian.Brostrom/`, `Me/`) into `personal/`. Move flat machine brains to `infra/<host>/`. Archive ghost projects. Partition sessions by month. Add `AGENTS.md` + `README.md` + `_schema/` at vault root so all harnesses obey the same contract. Seed `modules/` day one (Shopify, tauri-solidjs, bun-sqlite-hono, agent-harness, obsidian-vault-ops).

Migration is phased and gated — each phase reversible via git, nothing runs without explicit approval.

## Target tree

```
Vaults/AI/
├── AGENTS.md                    NEW — contract for all harnesses
├── README.md                    NEW — human overview
├── _schema/                     NEW — lint schemas (project/module/personal)
├── _ops/
│   ├── curator-reports/
│   │   └── 2026-06-28.md        MOVED from brains/
│   └── migration-2026-07-01.md  NEW — migration log
├── personal/
│   ├── current.md               MERGED from Christian.Brostrom/ + Me/
│   ├── preferences.md           NEW — stack, style, conventions
│   ├── gotchas.md
│   └── history/                 MOVED from Me/history/
├── modules/
│   ├── shopify/                 NEW — team-sharable
│   ├── tauri-solidjs/           NEW — distilled from hopper/
│   ├── bun-sqlite-hono/         NEW — distilled from laesr + huskr
│   ├── agent-harness/           NEW — distilled from Brain.md + dotfiles
│   └── obsidian-vault-ops/      NEW — this system's own docs
├── projects/                    RENAMED from brains/
│   ├── hopper/
│   ├── huskr/                   (move p3-sync-plan.md, pivot-tauri.md → plans/)
│   ├── laesr/
│   ├── dotfiles/                (move cleanup-plan, subagent-ideas, cheatsheet → plans/)
│   ├── raycast-extensions/
│   ├── stellar-shopify/         (move .plan.md → plans/)
│   ├── akqa-den-webhandbook/            KEEP (active AKQA) — seed content
│   └── akqa-denmark-shopify-theme-build/ KEEP (active AKQA) — seed content
├── infra/                       NEW
│   ├── superbro/                MOVED from brains/superbro.md
│   ├── monsterbro/              MOVED from brains/monsterbro.md
│   ├── linuxbro/                MOVED from brains/linuxbro.md
│   ├── homelab/                 MOVED from brains/homelab.md
│   └── cloudcli/                MOVED from brains/cloudcli.md
├── tools/
│   └── kb                       MOVED from ~/dotfiles/scripts/brain, renamed
├── sessions/
│   ├── 2026/06/                 MOVED retroactively — partition by month
│   ├── 2026/07/
│   └── candidates.md            NEW — grep-promoted signal for review
└── archive/                     NEW
    ├── tabflow.md               MOVED from brains/tabflow.md
    ├── dotfiles.md.legacy       MOVED
    └── hopline/                 MOVED from hopper/archive/
```

## Standard schemas

### Project brain
```
projects/<slug>/
├── INDEX.md      auto-generated, ≤ 500 bytes
├── current.md    ≤ 5 bullets (hard cap)
├── next.md       [done:] auto-pruned to history/
├── gotchas.md    append-only
├── history/      YYYY-MM-DD-HHMM.md
├── archive/
└── plans/        ad-hoc planning docs
```

### Module (shareable unit)
```
modules/<name>/
├── MODULE.md     what, owner, license, how to consume, version
├── gotchas.md
├── patterns.md
├── decisions.md  ADR-lite
└── references.md links to source project brains
```

## Naming conventions

- Slugs: `lowercase-kebab` (no CamelCase, dots, spaces)
- Session files: `YYYY-MM-DD-HHMM-<slug>.md`
- History files: `YYYY-MM-DD-HHMM.md` inside `history/`
- Plan files: `YYYY-MM-DD-<slug>.plan.md` inside `plans/`
- Archive: move to `archive/`, no `.legacy`/`.old` suffixes
- Leading underscore (`_schema/`, `_ops/`) = tooling namespace

## Multi-harness contract

Single `AGENTS.md` at vault root. All harnesses obey it via thin adapters:

| Harness | Adapter | Behaviour |
|---|---|---|
| PI | `~/dotfiles/.pi/hooks/kb-load.sh` | Loads personal + modules + project brain |
| Cursor IDE | `~/.cursor/hooks.json` → `kb-load.sh` | Same |
| Cursor-Agent (Zed) | Inherits Cursor config | Same |
| Future harness | Point at `AGENTS.md` | Just works |

Load order: `personal/current.md` → `modules/*/gotchas.md` (all) → `projects/<slug>/{current,next,gotchas}.md`.
Write path: `kb` CLI only (formerly `brain`) — no harness writes files directly. CLI lives at `$VAULT_AI/tools/kb`; dotfiles installs a PATH shim.

## Sharing model

Each `modules/<name>/` is extractable:
```bash
git subtree split --prefix=modules/shopify -b shopify-module
git push git@github.com:akqa-den/shopify-brain.git shopify-module:main
```
Or use git submodule for bidirectional sync. Structure supports both, no rewrite needed later.

## Files to modify / create

- Create: `AGENTS.md`, `README.md`, `_schema/{project,module,personal}.schema.json`, `_ops/migration-2026-07-01.md`
- Rename: `brains/` → `projects/`
- Move: machine brains → `infra/`; ghost files → `archive/`; curator report → `_ops/`; sessions → `sessions/YYYY/MM/`
- Consolidate: `brains/Christian.Brostrom/` + `brains/Me/` → `personal/`
- Delete: stub `current.md` files, `brains/Brain/` (all stubs), `.DS_Store` files
- Relocate + rename CLI: `~/dotfiles/scripts/brain` → `Vaults/AI/tools/kb`. Add `prune`, `compact`, `lint` subcommands. Install `brain` → `kb` symlink for transition.
- Rename `vault`/`brain` skill in `~/.agents/skills/` → `kb` skill (single skill covering the knowledgebase protocol)
- Wire: existing `shopify` skill (`~/.agents/skills/shopify/SKILL.md`) → load from `modules/shopify/`
- Update: `~/.cursor/hooks/*` and dotfiles `brain-load.sh` → `kb-load.sh` for new paths
- `.gitignore`: `.DS_Store`

## Reuse

- `brain` CLI at `~/dotfiles/scripts/brain` — move into vault as `tools/kb`, extend with `prune`/`compact`/`lint`, keep semantics
- `vault` skill at `~/.agents/skills/vault/SKILL.md` — rename to `kb` skill, update paths after migration
- `shopify` skill at `~/.agents/skills/shopify/SKILL.md` — repoint at `modules/shopify/`
- Existing hooks: `~/.cursor/hooks/vault-save.sh`, `brain-load.sh` (→ `kb-load.sh`), TF-IDF `summarizer.py` — keep, update paths + names only
- Existing curator report at `brains/curator-report-2026-06-28.md` — use as Phase 4 checklist
- Source content for modules (do not delete sources; add cross-references):
  - `projects/hopper/gotchas.md` → `modules/tauri-solidjs/`
  - `projects/laesr/gotchas.md` + `projects/huskr/gotchas.md` → `modules/bun-sqlite-hono/`
  - `projects/stellar-shopify/`, `akqa-den-webhandbook/`, `akqa-denmark-shopify-theme-build/` → `modules/shopify/`
  - `brains/Brain.md` + `projects/dotfiles/` → `modules/agent-harness/`

## Steps

### Phase 0 — Prep (~5 min, safe)
- [ ] `git tag pre-audit-2026-07-01` on current state
- [ ] Add `.gitignore` for `.DS_Store`
- [ ] Remove existing `.DS_Store` files
- [ ] Create `_ops/migration-2026-07-01.md` as running log

### Phase 1 — Contract (~15 min, additive only)
- [ ] Write `AGENTS.md` (path map, load protocol, write protocol, slug resolution, do-not-create list)
- [ ] Write `README.md` (human overview + tier explanation)
- [ ] Create `_schema/project.schema.json`, `_schema/module.schema.json`, `_schema/personal.schema.json`
- [ ] Add `kb lint` to CLI (still at `~/dotfiles/scripts/brain` this phase — moves in Phase 3)
- [ ] **Approval gate** — review contract before any moves

### Phase 2 — Tier split (~20 min, moves only, no content change)
- [ ] `mv brains/ projects/`
- [ ] Create `personal/`, `modules/`, `infra/`, `archive/`, `_ops/curator-reports/`
- [ ] Move machine brains: `projects/{superbro,monsterbro,linuxbro,homelab,cloudcli}.md` → `infra/<host>/current.md`
- [ ] Move `projects/tabflow.md` → `archive/`
- [ ] Move `projects/dotfiles.md.legacy` → `archive/dotfiles.md`
- [ ] Move `projects/curator-report-2026-06-28.md` → `_ops/curator-reports/`
- [ ] Retroactively partition `sessions/` — move all existing files into `sessions/YYYY/MM/` based on filename date prefix
- [ ] Update hook paths (`~/.cursor/hooks/*`, dotfiles `brain-load.sh`) for new tree
- [ ] **Approval gate** — verify tree matches spec

### Phase 3 — Personal brain + CLI rename (~45 min, needs input)
- [ ] Merge `projects/Christian.Brostrom/` + `projects/Me/` → `personal/`
- [ ] Draft `personal/preferences.md` from observed patterns (stack, style, hates, commit conventions)
- [ ] User edits and signs off
- [ ] Delete hollow personal folders
- [ ] Move `~/dotfiles/scripts/brain` → `Vaults/AI/tools/kb`; rename entry point
- [ ] Add PATH shim in dotfiles that execs `$VAULT_AI/tools/kb`; keep `brain` as symlink → `kb` for transition
- [ ] Rename `~/.agents/skills/vault/` → `~/.agents/skills/kb/` (single canonical skill)
- [ ] Update `kb` CLI slug resolution: explicit tier > `personal` (when in vault) > plan `repo:` > git basename > cwd
- [ ] **Approval gate** — sign off `personal/preferences.md` + CLI rename

### Phase 4 — Project cleanup (~60 min)
- [ ] Seed real content in `akqa-den-webhandbook/` and `akqa-denmark-shopify-theme-build/` (both active AKQA — user supplies current state/conventions; draft from prior sessions where possible)
- [ ] Delete other stub `current.md` files (or fill with content)
- [ ] Move ad-hoc `.md` files inside project folders → `<project>/plans/`
  - `huskr/p3-sync-plan.md`, `huskr/pivot-tauri.md`, `huskr/context-bridge.md`
  - `dotfiles/cleanup-plan-2026-06-25.md`, `dotfiles/subagent-ideas-2026-06-25.md`, `dotfiles/agent-commands-cheatsheet.md`, `dotfiles/context-bridge.md`
  - `stellar-shopify/alias-to-relative-migration.plan.md`, `stellar-shopify/akqa-denmark-shopify-theme-build-extraction.md`
- [ ] Prune `[done:]` items from every `next.md` to `history/`
- [ ] Trim oversized `current.md` (laesr 25 bullets, hopper 32, raycast-extensions 17, dotfiles 7 → all ≤ 5)
- [ ] Regenerate all `INDEX.md`
- [ ] **Approval gate** — per-project review

### Phase 5 — Module seeding (~90 min, the compounding step)
- [ ] Create `modules/shopify/` — distill from stellar-shopify + akqa-den-webhandbook + akqa-denmark-shopify-theme-build
- [ ] Create `modules/tauri-solidjs/` — HoldDragSensor, jiggle_cursor, stable `<For>` keys (from hopper)
- [ ] Create `modules/bun-sqlite-hono/` — WAL pragmas, migration runner, Drizzle patterns (from laesr + huskr)
- [ ] Create `modules/agent-harness/` — distill `brains/Brain.md` (hook list, kb CLI, slug resolution) + dotfiles brain content, then delete `Brain.md` (canonical home is the module — no `_ops/harness-notes.md`)
- [ ] Create `modules/obsidian-vault-ops/` — this system's own docs
- [ ] Write `MODULE.md` for each (owner, license, consumption, version)
- [ ] Wire `shopify` skill → load from `modules/shopify/`
- [ ] **Approval gate** — each module reviewed individually

### Phase 6 — Automation (~60 min)
- [ ] `kb prune` — move `[done:]` items to `history/` automatically
- [ ] `kb compact` — cap `current.md` at 5 bullets, overflow to `history/`
- [ ] Wire `kb lint` to pre-commit hook
- [ ] Weekly `session-promote` — grep-based scan of `sessions/**/*.md` for gotcha patterns → `sessions/candidates.md`
- [ ] **Approval gate** — user runs each command manually before auto-wiring

### Phase 7 — Team sharing setup (~30 min, private only)
- [ ] Create **private** GitHub repo under AKQA org (e.g. `akqa-den/shopify-kb`) — AKQA content stays private
- [ ] `git subtree split --prefix=modules/shopify` + push to private repo
- [ ] Document pull/push loop in `modules/shopify/MODULE.md` (team-only, no public sharing)
- [ ] **Approval gate** — first extraction test with one teammate before broader rollout

## Resolved decisions (from feedback)

1. **`akqa-den-webhandbook/` and `akqa-denmark-shopify-theme-build/`** — both **active** AKQA projects. Keep in `projects/`, seed real content in Phase 4 (no archive).
2. **`Brain.md`** — **distill to `modules/agent-harness/` then delete original**. The whole point of this reorganisation is to make knowledge modular and shareable; leaving a flat meta-brain at root contradicts the tier model. `modules/agent-harness/` is the canonical home.
3. **`modules/shopify/`** — **private AKQA repo**. All AKQA content is inherently private. Sharing (if any) is team-only via a private GitHub repo. Phase 7 targets a private repo, no open-source path.
4. **Session partitioning** — **retroactive**. Move all existing `sessions/*.md` into `sessions/YYYY/MM/` during Phase 2. Everything brought in line, no mixed layout.
5. **Rename `Christian.Brostrom` → `personal`** — confirmed. Additionally: **rename the `brain` CLI + skill to `kb`** (knowledgebase). Cleaner, tier-agnostic name that matches the new architecture (personal, modules, projects, infra all live under one knowledgebase — "brain" was too project-brain-centric). Symlink `brain` → `kb` for a transition period.
6. **Move CLI into vault** — yes, tied to #5. Move `~/dotfiles/scripts/brain` → `Vaults/AI/tools/kb` so the vault is fully self-describing and portable. Dotfiles installs a shim on PATH that execs `$VAULT_AI/tools/kb`. When a teammate clones a shared module, they can optionally clone the whole vault tooling too.

## Verification

- `kb lint` returns clean across all tiers
- `kb load` in any project surfaces personal + relevant modules + project brain in expected order
- Both `kb` (canonical) and `brain` (transition symlink) resolve to the same CLI at `$VAULT_AI/tools/kb`
- All three harnesses (PI, Cursor IDE, Cursor-Agent in Zed) load identical context for the same slug
- `git subtree split --prefix=modules/shopify` produces a valid standalone branch, pushable to a private AKQA repo
- No orphaned files (every `.md` maps to a tier defined in `AGENTS.md`)
- No stub brains (`current.md` files < 200 bytes) — including seeded content in both active AKQA projects
- No `[done:]` items older than 24h in any `next.md`
- `brains/Brain.md` no longer exists — its content lives in `modules/agent-harness/`
- Session files exist only under `sessions/YYYY/MM/` — no files remain at `sessions/` root (retroactive migration complete)
- Existing hooks fire correctly against new paths (test: end a Cursor session, confirm session summary lands in `sessions/2026/07/`)
