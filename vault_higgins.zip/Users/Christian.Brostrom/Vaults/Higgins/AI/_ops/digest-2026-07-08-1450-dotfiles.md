# kb digest — dotfiles — 2026-07-08 14:50
_Scanned 5 session file(s) from last 7 days_

## Current brain

### current.md
```
# Brain: dotfiles
_Updated: 2026-07-07_

- `kb map` system built (P0–P3): `config/projects-map.conf`, `scripts/projects/map.sh` dispatcher, `map-scan.sh`, `map-codebase.sh`, `map-doctor.sh`. `kb` CLI dispatch extended with `map` subcommand. Registry: `~/Vaults/AI/personal/projects-registry.md`.
- Bash 4+ version guards added to all new `scripts/projects/map-*.sh` scripts (macOS ships bash 3.2 — guards re-exec via Homebrew bash).
- `brain` CLI → transition shim; canonical `kb` CLI now lives at `$VAULT_AI/tools/kb`. All memory = markdown via kb.
- CODEBASE.md + `codebase` skill route task → relevant files. Two-vault: `~/Vaults/Me` (human/Obsidian) vs `~/Vaults/AI` (agent-owned, git).
- Cursor stop hook wired: vault-save.sh → sessions/ + pending.md; brain-load picks up pending.md on next sessionStart via session-brain.mdc (alwaysApply workaround for Cursor sessionStart race bug).
```

### next.md
```
# Next: dotfiles

- **[decide]** Private/ non-git dirs: `Fynder/` (84MB), `tailwind4-astro/`, `aleksdeejay-fetch/`, `Superbro/`, `bitwarden/` — archive or delete.
- Run `kb map codebase --all --missing-only` to generate CODEBASE.md skeletons for remaining 107 repos without one.
- Seed Keychain + enable pinentry-touchid (manual: `rbw unlock` in Terminal → "Save in Keychain" → `rbw config set pinentry pinentry-touchid`).
- Bootstrap MonsterBro (`dotfiles --update` end-to-end on WSL host — `mcp-servers.wsl.list` exists but full bootstrap loop unverified).
- Fix memory-curator.sh paths for Vaults/AI/projects/, then install weekly cron.
- Pull token-diet ultra telegraphic mode concept into core.mdc as opt-in hint.
- Propagate dotfiles to LinuxBro/SuperBro after today's skill layer changes.
- Decide on Plannotator skills once Cursor plan/agent mode flow is understood.
- Audit CLAUDE.md for Cursor bloat: it's auto-loaded by Cursor from workspace root (~700 tokens of CC-specific content per session). Split into lean Cursor-facing stub + CC-only detail, or gate CC sections.
```

### gotchas.md
```
# Gotchas: dotfiles

- **cloudcli auth shim**: synthetic `~/.claude/.credentials.json` with placeholder `accessToken` lets cloudcli show "connected" under enterprise Keychain auth. Breaks if cloudcli ever validates token against API.
- **CLAUDEMD editing**: blocked by auto-mode self-modification guard. Edit source at `~/dotfiles/.claude/CLAUDE.md` (symlink target).
- **kb CLI canonical**: brain shim at ~/.local/bin/brain → $VAULT_AI/tools/kb. No brain skill, no MCP.
- **Plan files**: $VAULT_AI/projects/<slug>/plans/YYYY-MM-DD-<topic>.plan.md — never .planning/ in repo
- Cursor sessionStart additional_context silently dropped (race condition, confirmed Cursor bug, no ETA). Workaround: brain-load.sh writes ~/.cursor/rules/session-brain.mdc (alwaysApply:true). One-session lag expected. See: forum.cursor.com/t/157141
- codebase-memory-mcp: Cursor is primary harness — configured in ~/.cursor/mcp.json (auto_index=true, limit=50000). Claude Code gets it via .claude/mcp-servers.developer.list as a secondary overlay. When describing setup, lead with Cursor, not CC.

- **Cleanup 2026-07-08 decisions**: plannotator removed (D1), engram removed (D2), herdr kept as per-host standby (D3), vivald
```

## Session candidates

### gotcha (1 found)

- (2026-07-08-dotfiles-session.md) - `kb gotcha "codebase-memory-mcp: Cursor is primary harness — configured in ~/.cursor/mcp.json (auto_index=true, limit=50000). Claude Code gets it via .claude/mcp`

## Agent: apply relevant entries

Run the commands below for each item worth keeping:
```bash
kb current "<updated one-liner state>"
kb gotcha "<non-obvious trap>"
kb next "<open action item>"
kb prune dotfiles   # auto-moves [done:] to history
kb compact dotfiles # auto-caps current.md at 5 bullets
```
