# kb digest — stellar-shopify-pr1306 — 2026-07-02 12:05
_Scanned 1 session file(s) from last 7 days_

## Current brain

### current.md
```
# Brain: stellar-shopify-pr1306
_Updated: 2026-07-02_

## Current State

## Conventions
```

### next.md
```
# Next: stellar-shopify-pr1306
```

### gotchas.md
```
# Gotchas: stellar-shopify-pr1306
```

## Session candidates

### gotcha (1 found)

- (2026-07-02-stellar-shopify-pr1306-session.md) **Goal:** Thursday, Jul 2, 2026, 12:04 PM (UTC+2) Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridg

## Agent: apply relevant entries

Run the commands below for each item worth keeping:
```bash
kb current "<updated one-liner state>"
kb gotcha "<non-obvious trap>"
kb next "<open action item>"
kb prune stellar-shopify-pr1306   # auto-moves [done:] to history
kb compact stellar-shopify-pr1306 # auto-caps current.md at 5 bullets
```
