# kb digest — Christian.Brostrom — 2026-07-02 09:33
_Scanned 1 session file(s) from last 7 days_

## Current brain

### current.md
```
# Brain: Christian.Brostrom
_Updated: 2026-07-02_

## Current State

## Conventions
```

### next.md
```
# Next: Christian.Brostrom
```

### gotchas.md
```
# Gotchas: Christian.Brostrom
```

## Session candidates

### gotcha (2 found)

- (2026-07-02-Christian.Brostrom-session.md) **Goal:** Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridge tools, call pi__* MCP names, not pi ca

- (2026-07-02-Christian.Brostrom-session.md) - Tools: call available Cursor SDK/MCP tools; never print tool cards as assistant text.

## Agent: apply relevant entries

Run the commands below for each item worth keeping:
```bash
kb current "<updated one-liner state>"
kb gotcha "<non-obvious trap>"
kb next "<open action item>"
kb prune Christian.Brostrom   # auto-moves [done:] to history
kb compact Christian.Brostrom # auto-caps current.md at 5 bullets
```
