# kb digest — stellar-shopify — 2026-07-02 09:45
_Scanned 2 session file(s) from last 7 days_

## Current brain

### current.md
```
# Brain: stellar-shopify
_Updated: 2026-06-19_

## Current State

`@akqa-denmark/shopify-theme-build` v0.1.1 patch pending publish (exports `snakifyString`).
stellar-shopify migration is done — coworker has completed the codemod + wiring.
Once 0.1.1 is published: run `npm install @akqa-denmark/shopify-theme-build@latest` in stellar-shopify.

## Conventions
```

### next.md
```
# Next: stellar-shopify

## Fix schema alias imports (repo: stellar-shopify) — DONE by coworker, pending package bump

> stellar-shopify migration is complete and verified. Only blocker: bump to @akqa-denmark/shopify-theme-build@0.1.1 once published.

## Fix schema alias imports (repo: stellar-shopify) — archive

**Context**: `@akqa-denmark/shopify-theme-build` v0.1.x is extracted and published.
When `shopify-build prepare` runs, the orchestrator loads schema files via `jiti`
but Node can't resolve `@/` and `@shared/` tsconfig aliases at runtime.

**Fix**: migrate all schema files from alias imports to relative imports.
Do NOT patch the package — fix the consumer (stellar-shopify).

### Steps

1. **In `akqa-denmark-shopify-theme-build` repo** (do first):
   - Add `export { snakifyString } from './utils/strings.js';` to `src/index.ts`
   - Rebuild and publish a new patch (`npm run release`)

2. **Write codemod** `scripts/migrate-aliases.ts` in the build package repo:
   - Globs `stores/*/src/schemas/**/*.ts` given a `--root` arg
   - `@/schemas/*` → relative path (all schema files live under `<store>/src/schemas/`)
   - `@shared/scripts/utils/snakifyString` → `@akqa-denmark/shopify-
```

### gotchas.md
```
# Gotchas: stellar-shopify
```

## Session candidates

### gotcha (2 found)

- (2026-07-01-stellar-shopify-session.md) **Goal:** Wednesday, Jul 1, 2026, 2:11 PM (UTC+2) Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridg

- (2026-07-02-stellar-shopify-session.md) **Goal:** Thursday, Jul 2, 2026, 9:43 AM (UTC+2) Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridge

## Agent: apply relevant entries

Run the commands below for each item worth keeping:
```bash
kb current "<updated one-liner state>"
kb gotcha "<non-obvious trap>"
kb next "<open action item>"
kb prune stellar-shopify   # auto-moves [done:] to history
kb compact stellar-shopify # auto-caps current.md at 5 bullets
```
