# kb digest — stellar-shopify-release — 2026-07-02 12:43
_Scanned 1 session file(s) from last 7 days_

## Current brain

### current.md
```
# Brain: stellar-shopify-release
_Updated: 2026-07-02_

## Current State

## Conventions
```

### next.md
```
# Next: stellar-shopify-release
```

### gotchas.md
```
# Gotchas: stellar-shopify-release
```

## Session candidates

### gotcha (2 found)

- (2026-07-02-stellar-shopify-release-session.md) **Goal:** Thursday, Jul 2, 2026, 12:41 PM (UTC+2) Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridg

- (2026-07-02-stellar-shopify-release-session.md) - Tools: call available Cursor SDK/MCP tools; never print tool cards as assistant text.

## Agent: apply relevant entries

Run the commands below for each item worth keeping:
```bash
kb current "<updated one-liner state>"
kb gotcha "<non-obvious trap>"
kb next "<open action item>"
kb prune stellar-shopify-release   # auto-moves [done:] to history
kb compact stellar-shopify-release # auto-caps current.md at 5 bullets
```
