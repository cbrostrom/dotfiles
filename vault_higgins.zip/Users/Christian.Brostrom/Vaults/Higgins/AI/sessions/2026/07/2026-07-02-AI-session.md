# Session log: AI — 2026-07-02
transcript: /Users/Christian.Brostrom/.cursor/projects/Users-Christian-Brostrom-Vaults-AI/agent-transcripts/agent-9d9e2064-ae2c-40cb-9ad2-a028cd87a9cd/agent-9d9e2064-ae2c-40cb-9ad2-a028cd87a9cd.jsonl

- 0010  stop

## Summary
_TextRank (vendored, pure Python)_

**Goal:** Thursday, Jul 2, 2026, 5:25 PM (UTC+2) Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridge tools, call pi__* MCP names, not pi card/history names. Do not claim pi-side or WebSearch

**Key points:**
- Cursor SDK tool boundary:
- Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable.
- So "attribution" to the user likely refers to the "Cursor SDK tool boundary:" text block that gets injected into every prompt by pi-cursor-sdk.
- "Cursor SDK tool boundary:",
- "Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable.",
- The "attribution" that the user finds annoying is the "Cursor SDK tool boundary:" block that gets injected into EVERY prompt sent to the Cursor SDK.
- Cursor SDK tool boundary:
- Cursor SDK tool boundary:

**Left off:** I need to create a short recap from the transcript provided. Let me analyze the conversation: **Latest coherent task:** You and an assistant debugged performance issues in PI running on top of the Cursor SDK, identified and fixed startup/fan problems, but discovered two unfixable upstream constraint

<!-- summarized -->
