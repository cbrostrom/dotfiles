# Session log: tmp — 2026-07-02
transcript: /Users/Christian.Brostrom/.cursor/projects/private-tmp/agent-transcripts/agent-3d46df35-fa5a-4639-992c-4c86eec2d6eb/agent-3d46df35-fa5a-4639-992c-4c86eec2d6eb.jsonl

- 0928  stop

## Summary
_TextRank (vendored, pure Python)_

**Goal:** Thursday, Jul 2, 2026, 9:28 AM (UTC+2) Cursor SDK tool boundary: Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable. For exposed pi bridge tools, call pi__* MCP names, not pi card/history names. Do not claim pi-side or WebSearch

**Key points:**
- Call only Cursor SDK/MCP tools exposed in this run; pi history names, replay labels, and transcript names are not callable.
- - Cursor host/MCP: read/shell/search/edit/write and other host tools when Cursor exposes them; configured MCP depends on Cursor settings.
- Pi tool catalog omitted: Cursor can call only Cursor SDK tools exposed in this run.
- - Additional docs: /Users/Christian.Brostrom/Library/Application Support/fnm/node-versions/v22.22.3/installation/lib/node_modules/@earendil-works/pi-coding-agent/docs
- - Examples: /Users/Christian.Brostrom/Library/Application Support/fnm/node-versions/v22.22.3/installation/lib/node_modules/@earendil-works/pi-coding-agent/examples (extensions, custom tools, SDK)
- Hierarchy: ctx_batch_execute > ctx_execute > ctx_execute_file > ctx_search.
- Read/edit files → ctx_execute_file.
- Tools: call available Cursor SDK/MCP tools; never print tool cards as assistant text.

**Left off:** hello

<!-- summarized -->
