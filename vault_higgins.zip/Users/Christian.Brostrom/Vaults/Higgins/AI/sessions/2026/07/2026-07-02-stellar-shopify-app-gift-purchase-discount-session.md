# Session log: stellar-shopify-app-gift-purchase-discount — 2026-07-02
transcript: /Users/Christian.Brostrom/.cursor/projects/Users-Christian-Brostrom-Projects-Shopify-Fiskars-stellar-shopify-app-gift-purchase-discount/agent-transcripts/935c37e5-b496-49e6-8f29-5580c2828275/935c37e5-b496-49e6-8f29-5580c2828275.jsonl

- 1502  stop

## Summary
_TextRank (vendored, pure Python)_

**Goal:** I got this question in chat - is this app able to do that? do you know if we can export discounts from our custom Discount app to excel or google sheets? that could be a way of getting them into datafeedwatch

**Key points:**
- do you know if we can export discounts from our custom Discount app to excel or google sheets?
- **Short answer: No** — this app does not export discounts to Excel, CSV, or Google Sheets.
- - `discount_app.discount_title`, `discount_value`, `discount_type` (simple fields)
- - `discount_app.all_discounts` (JSON with full discount details per product — percentage, fixed amount, market scope, member-only, etc.)
- The more realistic route is mapping those `discount_app.*` product metafields in DataFeedWatch's Shopify product feed — *if* their integration supports custom product metafields (worth confirming with DFW support).
- **Product-level discount metafields** (`discount_app.all_discounts`) — what's already synced per product
- `/api/discount-feed.csv`
- For DataFeedWatch, a **scheduled CSV/JSON feed endpoint** (Option D) or **mapping existing `discount_app.*` product metafields in DFW** is the better path.

**Files touched:**
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/AGENTS.md`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/CODEBASE.md`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/README.md`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/routes/app.manage-discounts.tsx`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/routes/api.gwp-campaigns.tsx`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/routes/api.campaign-config.tsx`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/utils/getAllProductDiscounts.ts`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/utils/syncAllDiscountsMetafield.ts`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/routes/api.quantity-discounts.tsx`
- `/Users/Christian.Brostrom/Projects/Shopify/Fiskars/stellar-shopify-app-gift-purchase-discount/app/routes/webhooks.discounts.tsx`

**Left off:** **Scope first:** "Export discounts" could mean different things in this app: 1. **Product-level discount metafields** (`discount_app.all_discounts`) — what's already synced per product 2. **Campaign config** (GWP, threshold, quantity, etc.) — lives in shop metafields, different shape 3. **Native Sho

<!-- summarized -->
