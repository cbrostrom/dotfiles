# Session log: dotfiles — 2026-07-07
transcript: /Users/Christian.Brostrom/.cursor/projects/Users-Christian-Brostrom-dotfiles/agent-transcripts/6a605086-e302-4fed-a359-10346c898237/6a605086-e302-4fed-a359-10346c898237.jsonl

- 0804  stop

## Summary
_TextRank (vendored, pure Python)_

**Goal:** Tuesday, Jul 7, 2026, 11:08 PM (UTC+2) next up is dotfiles overall cleanup - sooo much water under the bridge - could we make a solid spec for cleaning out unused stuff and have a lean setup ready for all my machines

**Key points:**
- | **Skills collapse** `.claude/skills/` → `.agents/skills/` | Git shows mass delete/add; `modules/skills/install.sh` still reads `.claude/skills/skills.list` | Install reads `.agents/skills/` directly; `skills.list` retired or becomes a manifest of external npx skills only; `AGENT_SKILLS.md` = source of truth |
- **P0: skills install fix** — `modules/skills/install.sh` update + any stale `scripts/brain` refs
- | Skills collapse `.claude/skills/` → `.agents/skills/` | Install reads `.agents/skills/` directly; `skills.list` = external npx only; `AGENT_SKILLS.md` = truth |
- The install script still reads from the old `.claude/skills/skills.list` location, and I've already spotted stale brain references scattered across `.cursor/rules/core.mdc`, `AGENTS.md`, `scripts/install/symlinks.sh`, and `.agents/skills/dotfiles/SKILL.md`.
- **Skills install fix** — `install.sh` exits early if no `skills.list`, skipping the `~/.cursor/skills → ~/.agents/skills` symlink entirely.
- - `.claude/skills/` is empty (no `skills.list`)
- - `modules/skills/install.sh` exits early if `skills.list` not found (line 14-17) — so currently it just symlinks `~/.cursor/skills` → `~/.agents/skills/` and exits.
- So the `~/.cursor/skills → ~/.agents/skills` symlink isn't actually being created right now since `skills.list` is missing!

**Files touched:**
- `/Users/Christian.Brostrom/dotfiles/CODEBASE.md`
- `/Users/Christian.Brostrom/Vaults/AI/projects/dotfiles/next.md`
- `/Users/Christian.Brostrom/Vaults/AI/projects/dotfiles/current.md`
- `/Users/Christian.Brostrom/dotfiles/modules.conf`
- `/Users/Christian.Brostrom/dotfiles/AGENT_SKILLS.md`
- `/Users/Christian.Brostrom/dotfiles/.local-config.example`
- `/Users/Christian.Brostrom/dotfiles/modules/skills/install.sh`
- `/Users/Christian.Brostrom/dotfiles/scripts/doctor.sh`
- `/Users/Christian.Brostrom/dotfiles/modules/README.md`
- `/Users/Christian.Brostrom/dotfiles/modules/herdr/module.sh`
- `/Users/Christian.Brostrom/dotfiles/modules/engram/module.sh`
- `/Users/Christian.Brostrom/dotfiles/vivaldi/README.md`
- `/Users/Christian.Brostrom/dotfiles/modules/claude-plugins/module.sh`
- `/Users/Christian.Brostrom/dotfiles/AGENTS.md`
- `/Users/Christian.Brostrom/dotfiles/zsh/03-aliases.zsh`

**Commands run:**
- `ls -la /Users/Christian.Brostrom/dotfiles | head -60`
- `./bootstrap.sh --list 2>/dev/null | head -80`
- `ls -la /Users/Christian.Brostrom/dotfiles/.attic 2>/dev/null; ls /Users/Christian.Brostrom/dotfiles/functions 2>/dev/null; ls /Users/Christian.Brostrom/dotfiles`
- `du -sh /Users/Christian.Brostrom/dotfiles/*/ 2>/dev/null | sort -hr | head -20`
- `ls -la /Users/Christian.Brostrom/dotfiles/Fynder 2>/dev/null || echo "no Fynder"; ls -d /Users/Christian.Brostrom/dotfiles/*/ 2>/dev/null | xargs -I{} basename `
- `ls /Users/Christian.Brostrom/dotfiles/vivaldi/; rg -l "vivaldi" /Users/Christian.Brostrom/dotfiles --glob '!*.git' 2>/dev/null | head -10`
- `cat > /Users/Christian.Brostrom/Vaults/AI/projects/dotfiles/spec-cleanup.md << 'EOF' # Dotfiles Cleanup Spec _Created: 2026-07-07_ ## North star One repo, three`
- `cd /Users/Christian.Brostrom/dotfiles && git status && git diff --stat HEAD`
- `cd /Users/Christian.Brostrom/dotfiles && git diff HEAD`
- `cd /Users/Christian.Brostrom/dotfiles && git add .agents/skills/context-bridge/SKILL.md && git commit -m "fix(skills): update context-bridge vault paths brains/`

**Left off:** From the spec: | # | Question | My read | Risk if wrong | |---|----------|---------|---------------| | **D1** | Plannotator — keep Mac-only or remove entirely? | Keep Mac-only. Server overlay already disables it. No action needed. | Low — it's already correctly gated. | | **D2** | Engram MCP — enabl

<!-- summarized -->
