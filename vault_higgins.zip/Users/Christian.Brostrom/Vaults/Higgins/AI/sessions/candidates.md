# Session Promotion Candidates
_Generated: 2026-07-01 22:22_

Grep-based scan of `sessions/**/*.md` for gotcha patterns.
Review each candidate; promote to `modules/<name>/gotchas.md` or `personal/gotchas.md` via `kb gotcha`.

## sessions/2026/06/2026-06-30-Brain-session.md

```
32:- `/Users/Christian.Brostrom/Vaults/Brain/Brains/dotfiles/gotchas.md`
```

## sessions/2026/06/2026-06-30-huskr-session.md

```
13:- Actually, the cleanest approach is to just write the migration manually—I'll create the SQL file with the ALTER TABLE statements to add the sync columns, update the journal entry for migration 31, and skip the snapshot generation entirely since the chain is already broken anyway.
```

## sessions/2026/07/2026-07-01-hopline-session.md

```
68:**Left off:** Updated in the vault: **`implementation-plan.md`** — Phase 2 expanded: - `hopBarScope`: `helium_only` (default) | `always` | `off` - Dynamic register/unregister via `NSWorkspace` when Helium (`net.imput.helium`) gains/loses focus - Dismiss hop bar when switching away from Helium - Tray click always 
```

## sessions/2026/07/2026-07-01-hopper-session.md

```
11:- If you want, I can help capture current state into the brain (what’s done, what’s next, gotchas) from the diff — or we can jump straight into whatever you’re working on.
13:- | `brains/hopline/` | Full history — current state (persistent tabs, DnD, etc.), gotchas, pivot plan in `next.md` (already says “hopper (formerly hopline)”) |
21:- `/Users/Christian.Brostrom/Vaults/AI/brains/hopper/gotchas.md`
25:- `/Users/Christian.Brostrom/Vaults/AI/brains/hopline/gotchas.md`
41:**Left off:** Done. **`brains/hopline/`** is fully merged into **`brains/hopper/`** and removed. **Transferred** - `current.md` — full sidebar-era state + migration note - `gotchas.md` — WKWebView, solid-dnd, SolidJS, Rust traps - `next.md` — omnibox pivot phases (Phase 0–6) - `history/` — 4 session wraps (2026-0
```

