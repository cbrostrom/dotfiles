---
created: 2026-06-14
updated: 2026-06-14
area: dev
type: brain
tags: [machine, monsterbro, windows, wsl, gaming, dotfiles]
status: active
host: monsterbro
---

# Brain: monsterbro

Windows 11 gaming rig with WSL for dev work.

## Current State

- WSL Ubuntu bootstrap underway
- `mcp-servers.wsl.list` exists in dotfiles
- Marked optional in `dotfiles --update` skill (gaming rig — sometimes off)
- Snapshot in `.claude/devices/monsterbro.json`

## Open Decisions

- Bootstrap unverified end-to-end — full `dotfiles --update` loop on WSL not yet validated
- ASCII IME switch disabled (recent change)

## Gotchas

- `DOTFILES_NONINTERACTIVE=1` required for `dotfiles --update` to avoid hanging at workflow picker
- WSL workflow loads `mcp-servers.wsl.list` (NOT server or developer)
- Machine sometimes off — `dotfiles` skill treats it as optional, skip cleanly when unreachable

## Next Steps

- Validate full bootstrap: `dotfiles --update` end-to-end on MonsterBro WSL
- Confirm MCPs load correctly from `mcp-servers.wsl.list`
- Test cross-machine sync (vault + engram) from WSL side

## WSL setup specifics

- Vault path on WSL: `/mnt/c/Users/christian/Obsidian/Christian` (will need update to `Brain` after rebootstrap)
- Tailscale required for MCP access (CGNAT 100.64.0.0/10)

## Cross-references

- Dotfiles brain (Mac side): [[Brains/dotfiles]]
- Vault sparring (path change implications): [[Plans/Active/2026-06-14-vault-second-brain-sparring]]
