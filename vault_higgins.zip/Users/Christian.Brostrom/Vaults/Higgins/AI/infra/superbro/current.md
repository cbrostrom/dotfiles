---
created: 2026-06-14
updated: 2026-06-14
area: dev
type: brain
tags: [machine, homelab, superbro, docker, couchdb, mcp, graphiti, dockhand]
status: active
host: superbro
---

# Brain: superbro

Self-hosted server — main MCP + sync host.

## Current State

- Running: CouchDB (LiveSync target), Graphiti MCP (:8000), mcp-dockhand, Engram remote
- Reachable via Tailscale CGNAT (100.64.0.0/10) — all MCPs Tailscale-fronted
- Workflow: `DOTFILES_WORKFLOWS=server` → loads `mcp-servers.server.list`

## Open Decisions

- (none recorded — populate as needed)

## Gotchas

- All self-hosted MCPs require Tailnet enrollment — non-Tailscale clients blocked at network layer
- LiveSync DB on CouchDB — backup separately (CouchDB doesn't snapshot via tar of vault)

## Next Steps

- (none recorded)

## Services running

| Service | Port / Endpoint | Purpose |
|---|---|---|
| CouchDB | (configured per LiveSync setup) | Obsidian LiveSync target |
| Graphiti MCP | `:8000` | Relational/temporal knowledge graph |
| mcp-dockhand | MCP | Stack management for superbro |
| Engram | MCP | Remote memory |

## Cross-references

- LiveSync config: [[Development/Homelab & VPS/LiveSync Setup Guide]]
- Docker compose: [[Development/Homelab & VPS/couchdb-livesync-compose]]
- Dotfiles brain: [[Brains/dotfiles]]
- Homelab overview: [[Brains/homelab]]
