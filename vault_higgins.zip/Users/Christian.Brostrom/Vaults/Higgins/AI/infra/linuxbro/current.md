---
created: 2026-06-14
updated: 2026-06-14
area: dev
type: brain
tags: [machine, homelab, linuxbro, docker, plex, sonarr, radarr, media]
status: active
host: linuxbro
---

# Brain: linuxbro

Self-hosted media + utility server.

## Current State

- Running: Plex, Sonarr, Radarr (media stack), plus utility containers
- Workflow: `DOTFILES_WORKFLOWS=server` → loads `mcp-servers.server.list`
- MCP access: `mcp-dockhand-linuxbro`, `docker-linuxbro` over Tailscale

## Open Decisions

- (none recorded — populate as needed)

## Gotchas

- Hostname must use lowercase `linuxbro.json` in `.claude/devices/` — never `LinuxBro.json` (case duplication breaks `git pull --rebase`)
- Pre-commit hook stash issue resolved via `GIT_REFLOG_ACTION` guard
- Latest audit: [[Development/Homelab & VPS/linuxbro-audit-2026-05-12]]

## Next Steps

- (none recorded)

## Services running

| Service | Purpose |
|---|---|
| Plex | Media server |
| Sonarr | TV automation |
| Radarr | Movie automation |
| (others) | Utility containers — see `.docker` query |

## Cross-references

- Audit (2026-05-12): [[Development/Homelab & VPS/linuxbro-audit-2026-05-12]]
- Dotfiles brain: [[Brains/dotfiles]]
- Homelab overview: [[Brains/homelab]]
