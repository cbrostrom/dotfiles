---
created: 2026-06-14
updated: 2026-06-14
area: dev
type: brain
tags: [homelab, network, tailscale, caddy, dns, docker, infrastructure]
status: active
---
()
# Brain: homelab

Cross-machine homelab + network overview. Connects [[Brains/superbro]], [[Brains/linuxbro]], [[Brains/monsterbro]], [[Brains/dotfiles]].

## Current State

- **Network:** Tailscale CGNAT (100.64.0.0/10) as primary trust layer for all self-hosted MCPs
- **Mac:** pf anchor `caddy.local` wired into `/etc/pf.conf` — portless HTTPS for local services (`ai.local`, etc)
- **Superbro:** main MCP host (CouchDB, Graphiti, Dockhand, Engram remote)
- **Linuxbro:** media stack (Plex, Sonarr, Radarr)
- **Monsterbro:** WSL bootstrap in progress
- **DNS / hostnames:** local `*.local` via Caddy on Mac; Tailscale hostnames for remote machines

## Open Decisions

- Domain consolidation strategy in progress — see [[Development/Homelab & VPS/Domain Consolidation Strategy]]
- Sync mechanism (LiveSync vs Syncthing vs hybrid) deferred per [[Plans/Active/2026-06-14-vault-second-brain-sparring]]

## Gotchas

- **pfctl rule order:** `rdr-anchor` must precede `anchor` in `/etc/pf.conf` — macOS updates reset this; re-run `sudo scripts/system/pf-caddy.sh`
- **Tailscale-only MCPs:** any non-Tailnet client blocked at network layer — confirm enrollment before debugging connectivity
- **Hostname case:** device snapshots use `hostname -s` lowercase — `linuxbro.json` NOT `LinuxBro.json`

## Next Steps

- Validate MonsterBro WSL end-to-end (bootstrap loop)
- Decide vault sync mechanism (parked)
- Run periodic homelab audits (last: linuxbro 2026-05-12)

## Topology

```
              Tailscale CGNAT (100.64.0.0/10)
   ┌─────────────────┬──────────────────┬──────────────────┐
   Mac              Superbro          Linuxbro          Monsterbro
   ├ pf-caddy       ├ CouchDB         ├ Plex            ├ WSL Ubuntu
   ├ ai.local       ├ Graphiti :8000  ├ Sonarr          ├ MCP wsl list
   ├ rbw + pinentry ├ Dockhand MCP    ├ Radarr          ├ (gaming rig)
   ├ dotfiles src   ├ Engram remote   ├ Dockhand MCP    
   └ Claude Code    └ MCP server list  └ docker MCP      
```

## Workflows per host

| Host | `DOTFILES_WORKFLOWS` | MCP list loaded |
|---|---|---|
| Mac | `developer` (default) / `work` | full set / atlassian via project-mcp |
| Superbro | `server` | `mcp-servers.server.list` |
| Linuxbro | `server` | `mcp-servers.server.list` |
| Monsterbro | `wsl` | `mcp-servers.wsl.list` |

## Cross-references

- [[Brains/superbro]] · [[Brains/linuxbro]] · [[Brains/monsterbro]] · [[Brains/dotfiles]]
- [[Development/Homelab & VPS/Domain Consolidation Strategy]]
- [[Development/Homelab & VPS/LiveSync Setup Guide]]
- [[Development/Homelab & VPS/linuxbro-audit-2026-05-12]]
