---
created: 2026-06-15
updated: 2026-06-15
area: dev
type: brain
tags: [cloudcli, claude-code, auth, pm2]
status: active
---

# Brain: cloudcli

cloudcli = `@cloudcli-ai/cloudcli` (siteboon/claudecodeui, 11.9k stars). UI wrapper around Claude Code CLI. Runs via pm2 at `/opt/homebrew/bin/cloudcli`.

## Current State

- **Running**: pm2 process `cloudcli-ui`, pid varies, `/opt/homebrew/bin/cloudcli`
- **Auth**: synthetic credentials shim in place (see Gotchas)
- **Update**: `cloudcli-update` alias (homebrew prefix required)

## Gotchas

- **Enterprise auth shim**: cloudcli checks `~/.claude/.credentials.json` for OAuth token. Claude Code enterprise (WPP/AKQA) stores auth in macOS Keychain — no file written by default. Fix: synthetic file with placeholder `accessToken` and no `expiresAt`. Works because cloudcli never passes credentials to `claude` subprocess — UI display only.
- **cloudcli-update not npm update -g**: homebrew prefix required or wrong binary gets updated
- **pm2 PATH**: uses fnm multishell path — can change between shells. If recreating pm2 entry, hardcode `/opt/homebrew/bin/cloudcli`

## Auth Shim Details

`~/.claude/.credentials.json`:
```json
{
  "claudeAiOauth": { "accessToken": "cloudcli-bridge" },
  "email": "christian.brostrom@akqa.com"
}
```

Safe because: token only used for UI status display, never passed to claude subprocess (verified in source). Real API calls use claude binary with real Keychain auth.

**Risk**: if cloudcli ever validates token against Anthropic API → breaks. File issue: siteboon/claudecodeui.

## Next Steps

- File GitHub issue: siteboon/claudecodeui — add macOS Keychain support for enterprise auth
