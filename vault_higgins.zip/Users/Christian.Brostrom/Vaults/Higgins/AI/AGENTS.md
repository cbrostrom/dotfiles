# AGENTS.md — AI Vault Contract

Single source of truth for every agent (PI, Cursor IDE, Cursor-Agent in Zed, or any future harness) reading or writing this vault.

## Vault location

- macOS: `~/Vaults/AI`
- WSL: `/mnt/c/Users/christian/Obsidian/AI` (TBD — confirmed on MonsterBro bootstrap)

Environment variable: `VAULT_AI`.

## Tier map

| Tier | Path | Purpose |
|---|---|---|
| 0 — Contract | `AGENTS.md`, `README.md`, `_schema/` | This file, human overview, lint schemas |
| 1 — Personal | `personal/` | Christian's preferences, style, cross-cutting gotchas. Loaded every session. |
| 2 — Modules | `modules/<name>/` | Reusable knowledge units. Each folder is a self-contained, extractable unit (git subtree / submodule). |
| 3 — Projects | `projects/<slug>/` | Live project state. Not shared. |
| 4 — Infrastructure | `infra/<host>/` | Machine/host state (superbro, monsterbro, linuxbro, homelab, cloudcli). |
| 5 — Sessions | `sessions/YYYY/MM/` | Raw TF-IDF captures. Auto-partitioned. Never hand-edited. |
| 6 — Ops | `_ops/` | Curator reports, audit outputs, migration logs. |
| 7 — Tools | `tools/` | `kb` CLI (canonical location, moved from `~/dotfiles/scripts/brain`). |
| — Archive | `archive/` | Retired projects/modules. |

## Load protocol (every session)

Agents load context in this order at `SessionStart`:

1. `personal/current.md` + `personal/preferences.md` + `personal/gotchas.md`
2. `modules/*/gotchas.md` (all modules — cross-cutting knowledge)
3. `projects/<slug>/{current,next,gotchas}.md` (resolved slug — see below)
4. Relevant `infra/<host>/current.md` if current host matches

The `kb-load.sh` hook implements this. All harnesses invoke it identically.

## Write protocol

**Only `kb` writes to this vault.** No harness edits vault files directly.

| Command | Effect |
|---|---|
| `kb load [slug]` | Emit context for the agent |
| `kb save <text> [slug]` | Append to `<tier>/<slug>/history/YYYY-MM-DD-HHMM.md` |
| `kb wrap <summary> [topic]` | One-shot save + set new focus |
| `kb prune [slug]` | Move `[done:]` items from `next.md` → `history/` |
| `kb compact [slug]` | Cap `current.md` at 5 bullets, overflow → `history/` |
| `kb lint` | Validate the whole tree against `_schema/` |

`brain` is retained as a transition symlink to `kb`.

## Slug resolution

Ordered precedence:

1. Explicit `--tier <tier> --slug <slug>` args
2. `personal` — when cwd is inside `$VAULT_AI` and no other tier resolves
3. Active plan `repo:` field
4. `git rev-parse --show-toplevel` basename
5. `$PWD` basename

Slug format: `lowercase-kebab` only. No CamelCase, no dots, no spaces.

## Project brain schema

Every `projects/<slug>/` MUST contain only:

```
INDEX.md      auto-generated, ≤ 500 bytes
current.md    ≤ 5 bullets (hard cap; enforced by `kb lint`)
next.md       [done:] items auto-pruned to history/
gotchas.md    append-only
history/      YYYY-MM-DD-HHMM.md
archive/      periodic rollups
plans/        ad-hoc planning docs (was scattered pre-migration)
```

Any other path inside a project folder is a lint violation.

## Module schema

Every `modules/<name>/` MUST contain:

```
MODULE.md     what, owner, license, how to consume, version
gotchas.md    non-obvious facts
patterns.md   proven patterns
decisions.md  ADR-lite
references.md links to source project brains
```

## Do-not-create list

Never create these:

- Top-level `.md` files (except `AGENTS.md`, `README.md`, `PLAN.md`)
- `.legacy`, `.old`, `.bak` suffixes — move to `archive/` instead
- Stub brains (empty `current.md` files with only a header) — either seed content or don't create the folder
- Ad-hoc `.md` at the root of a project brain — put in `<project>/plans/`
- New `.DS_Store` (gitignored)
- Flat brains (e.g. `<slug>.md` at any tier root) — always use folder schema

## Naming conventions

| Kind | Rule |
|---|---|
| Slugs | `lowercase-kebab` |
| Session files | `sessions/YYYY/MM/YYYY-MM-DD-HHMM-<slug>.md` |
| History files | `history/YYYY-MM-DD-HHMM.md` |
| Plan files | `plans/YYYY-MM-DD-<slug>.plan.md` |
| Leading underscore | `_schema/`, `_ops/` = tooling namespace, never user-facing |

## Harness adapters

| Harness | Adapter | Notes |
|---|---|---|
| PI | `~/dotfiles/.pi/hooks/kb-load.sh` | SessionStart hook |
| Cursor IDE | `~/.cursor/hooks.json` → `kb-load.sh` | SessionStart hook |
| Cursor-Agent (Zed) | Inherits Cursor config | No extra config |
| Future harness | Read this file, call `kb load` | Just works |

## Sharing model

Each `modules/<name>/` is extractable to its own repo:

```bash
git subtree split --prefix=modules/shopify -b shopify-module
git push git@github.com:akqa-den/shopify-kb.git shopify-module:main
```

All AKQA content is **private by default**. Only push to private org repos.
