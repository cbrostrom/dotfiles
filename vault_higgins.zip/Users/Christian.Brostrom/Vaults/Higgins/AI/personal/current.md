# Personal: Christian Brostrom
_Updated: 2026-07-01_

- Executing AI vault reorganisation per `PLAN.md` — cluttered `brains/` → tiered `personal/modules/projects/infra/`
- Rename `brain` CLI → `kb`; relocate to `$VAULT_AI/tools/kb` (in-vault, self-describing)
- Active projects: hopper (Tauri browser sidebar), huskr (Tauri todos + Bun sidecar), laesr (Bun+Hono RSS), akqa-* (Shopify)
- Personal preferences now live in `personal/preferences.md` — load every session
- Modules seeded: shopify, tauri-solidjs, bun-sqlite-hono, agent-harness, obsidian-vault-ops
- context-mode installed in Pi; vault auto-indexed at session start + after kb writes; `ctx_search` replaces file dumps for vault knowledge lookups
