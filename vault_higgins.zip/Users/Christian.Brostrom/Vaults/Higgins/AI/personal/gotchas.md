# Personal Gotchas (cross-cutting)

- **WSL vault path unverified** (`/mnt/c/Users/christian/Obsidian/AI`) — confirm on MonsterBro bootstrap.
- **pfctl rule order**: `rdr-anchor` must precede `anchor` in `/etc/pf.conf`. macOS updates reset → re-run `sudo scripts/system/pf-caddy.sh`.
- **`~/.claude.json` mcpServers** bypasses dotfiles overlay. Manual `claude mcp add` writes here. Audit periodically.
- **Zed ACP zombies**: `Zed → acp → node → claude SDK` chain leaks sessions on task complete. Kill manually if accumulating.
- **pm2 after node upgrade**: delete + recreate entry with current `$(which node)`, then `npm rebuild better-sqlite3 --prefix <pkg>`.
- **pinentry-touchid setup**: needs `pinentry-touchid -fix` once to redirect fallback symlink to `pinentry-mac`.
- **cloudcli-update**: must use `npm update -g --prefix /opt/homebrew` — homebrew prefix required or wrong binary updates.
- **git worktree prune** only works from inside owning repo.
- **zsh `**` expansion**: shell expands `**` before Python receives it. Use single quotes.
- **Parallel agents** are token-multiplicative and usually same quality as sequential for solo workflow. Use only for 10+ file migrations or adversarial review.
- **Bun does not run on iOS.** Tauri iOS clients need sync-only mode or a Rust port.
- **`workspace_roots[0]` from stdin JSON** — `$PWD` in Cursor hooks gives `.cursor/`, not project slug.
