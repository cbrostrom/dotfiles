## Context Bridge — Me/vault — 2026-06-30 15:54

### What we were doing
Redesigning the vault memory system: implementing zero-token session capture (recall-inspired), then renaming and splitting the single vault into two — `~/Vaults/Me` (human/Obsidian) and `~/Vaults/AI` (AI-owned git repo).

### Decisions made
- **`~/Vaults/Brain` → `~/Vaults/Me`** — Obsidian remains the human viewer; vault stays plain markdown git repo
- **`~/Vaults/AI`** — new separate git repo for AI brain: `brains/`, `knowledge/`, `sessions/`. Git-native, portable across machines via GitHub personal account
- **Tier 2 knowledge model** — project state (brains/) + cross-project reusable facts (knowledge/) + session logs (sessions/). Not full personal KB — avoids "who owns what" confusion with Obsidian
- **Zero-token session capture** — `vault-save.sh` (stop hook) now always writes timestamped session marker to `~/Vaults/AI/sessions/` regardless of project. Dumps raw Cursor stop event JSON to `/tmp/cursor-stop-event.json`
- **TF-IDF summarizer** — `summarizer.py` (recall's algorithm, verbatim) + `parse_cursor_transcript.py` (Cursor JSONL adapter) + `session-summarize` CLI. Runs in background on every stop via hook — overwrites summary section each time so final transcript always wins
- **WSL paths left unchanged** — decision deferred until MonsterBro setup
- **Obsidian stays for human notes** — kept as optional viewer; not designing around it. Mobile capture TBD

### Files touched
- `~/Vaults/Brain/` → `~/Vaults/Me/` (renamed)
- `~/Vaults/AI/` created (brains/, knowledge/, sessions/, git init)
- `~/Vaults/Me/AGENTS.md` — rewritten for two-vault architecture
- `~/.cursor/hooks/vault-save.sh` — slug fix (workspace_roots[0]), sessions/ path, TF-IDF auto-run
- `~/dotfiles/.claude/hooks/brain-load.sh` — Vaults/AI/brains path
- `~/dotfiles/.claude/hooks/brain-save-inject.sh` — Vaults/AI/brains path
- `~/dotfiles/.claude/hooks/brain-optimise-cheap.sh` — Vaults/AI/brains path
- `~/dotfiles/scripts/brain` — Vaults/AI path, brains/ (lowercase)
- `~/dotfiles/scripts/session-check` — Vaults/AI/sessions path
- `~/dotfiles/scripts/session-summarize` — Vaults/AI/sessions path
- `~/.cursor/hooks/summarizer.py` — recall's TF-IDF + TextRank (verbatim)
- `~/.cursor/hooks/parse_cursor_transcript.py` — Cursor JSONL adapter
- `~/dotfiles/.cursor/rules/core.mdc` — path update
- 10 skill files + shared-rules — bulk path update

### Open questions
- WSL equivalent path for `~/Vaults/AI` and `~/Vaults/Me` (MonsterBro setup)
- Mobile capture into Inbox — no solution yet
- Should `~/Vaults/Me/Brains/` (legacy copy) be removed once AI vault confirmed working?

### Dead ends (don't repeat)
- `$PWD` in vault-save.sh hook gives `.cursor` not the project slug — user hooks run from `~/.cursor/`. Must use `workspace_roots[0]` from stdin JSON
- Recall's `summarizer.py` returns empty via GitHub blob API — use raw URL with `refs/heads/master`

### Exact next step
Push `~/Vaults/AI` to GitHub personal account, then add clone/pull to `dotfiles --update` bootstrap for AKQA Mac, MonsterBro, SuperBro, LinuxBro.

### Context to reload
- Brain: `brain load` in `~/Vaults/Me/` (slug = Me)
- Key files: `~/Vaults/Me/AGENTS.md`, `~/Vaults/AI/brains/Me/context-bridge.md`
- Plan: `~/.cursor/plans/ai_brain_git_repo_61646cfb.plan.md`
