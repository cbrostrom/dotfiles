# Brain index: personal
- current.md (9L) — _Updated: 2026-07-01_
- gotchas.md (14L) — - **WSL vault path unverified** (`/mnt/c/Users/christian/Obs
- history/ — 2 session(s), last 2026-06-30-1554
