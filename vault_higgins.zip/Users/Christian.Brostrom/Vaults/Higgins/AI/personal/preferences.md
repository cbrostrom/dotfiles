# Christian's Preferences
_Updated: 2026-07-01 — draft synthesised from observed patterns across brains. **User to edit + sign off.**_

## Stack defaults

- **Native apps**: Tauri 2 + SolidJS + TypeScript + Tailwind + SQLite (`tauri-plugin-sql` or Bun sidecar)
- **Backend / APIs**: Bun + Hono + Drizzle + SQLite (WAL). Single-process, single-container. No Redis, no Bull, no Prisma, no PostgreSQL unless forced.
- **Shopify**: theme builds (Liquid + Tailwind), stellar-shopify pattern library
- **Scripts / CLIs**: Python 3 stdlib preferred, no `uv`/`poetry` for one-file utilities
- **Package manager**: `bun` for JS/TS, `homebrew` for system, `fnm` for node, `pipx` for global Python tools

## Code style

- **English everywhere** in code (identifiers, comments, UI strings, commits, docs). Chat replies can be Danish.
- **No magic numbers** — use DOM measurements or named constants
- **Fragments over sentences** in brain / doc files. One line per fact.
- **Dark theme defaults**: `bg-gray-900 / bg-gray-800 / text-gray-100 / border-gray-700 / accent bg-blue-600`
- **Token-efficient markdown**: `**bold label**: value`, `- bullet`, `key: value`, `[done: YYYY-MM-DD]`

## Commit conventions

- **Format**: `type(scope): subject` — imperative, lowercase, ≤ 72 chars
- **Types**: feat, fix, refactor, chore, docs, test, perf, style
- **No emoji** in commits unless explicitly requested
- **No AI signature lines** ("Generated with…", "Co-Authored-By: Claude…") — user disables these

## Agent behaviour I want

- **Skip narration comments** in code — no `// increment counter` fluff
- **Batch tool calls** when independent (parallel > sequential)
- **Subagents only for**: 10+ file migrations, adversarial review, browser automation, long-running probes. Sequential is usually same quality for solo work.
- **Read before edit** — always
- **Verification before completion** — run the command, don't claim green
- **Ask before commits** — never auto-commit
- **No git config changes**, no force push to main
- **`brain/kb save` and `kb wrap`** are the write path. Never edit vault files directly.

## Things I hate

- **Supabase** for self-hosted sync (20+ Docker services — anti-simplicity). Decided against for huskr 2026-06-28.
- **Verbose PR descriptions** with headings for one-line changes
- **Stub brains** — empty `## Current State` headers with nothing under them
- **`.legacy` / `.old` suffixes** — move to `archive/` instead
- **`.unwrap()` in Rust production code** without justification
- **Auto-generated comments** narrating what code does

## Tooling I rely on

- **PI** (primary), **Cursor IDE** (secondary), **Cursor-Agent in Zed** (backup) — all must read `~/Vaults/AI/AGENTS.md`
- **kb** CLI (`~/Vaults/AI/tools/kb`, symlinked as `brain` for transition)
- **Homebrew** for system, **fnm** for node, **rbw** + **pinentry-touchid** for secrets
- **Dockhand** (not Portainer) on SuperBro VPS
- **Traefik** with `responseforwarding.flushinterval=0ms` for WS
- **Obsidian** as a viewer for `~/Vaults/Me` (human notes) — never for `~/Vaults/AI` (agent-owned)

## Cross-cutting gotchas

- WSL vault path unverified (`/mnt/c/Users/christian/Obsidian/AI`) — confirm on MonsterBro bootstrap
- pfctl `rdr-anchor` must precede `anchor` in `/etc/pf.conf` (macOS updates reset)
- Zed ACP zombies: `Zed → acp → node → claude SDK` chain leaks — kill manually if accumulating
- `~/.claude.json mcpServers` bypasses dotfiles overlay — audit periodically
- Bun does not run on iOS — plan sync-only or Rust port for iOS clients
