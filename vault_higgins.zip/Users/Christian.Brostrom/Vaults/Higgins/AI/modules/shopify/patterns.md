# Shopify Patterns

Reusable, proven patterns for AKQA DEN Shopify work.

## Theme architecture

- **Sections + blocks over templates** — every reusable UI piece is a section with typed blocks. Templates are thin shells.
- **`snippets/` for atomic UI**, `sections/` for compositional units, `blocks/` for block-scoped fragments (Shopify 2024+ theme blocks).
- **One section = one purpose.** Splitting > monolithic sections with 20 settings.

## Build tooling

- **`@akqa-denmark/shopify-theme-build`** is the canonical build. Codemod runs migration between versions.
- Pin the version in `package.json` — never `^` or `~` in CI.

## Metafield strategy

- **Namespace by feature**, not by team: `custom.product_specs`, `custom.hero_config`. Avoid `akqa.*` (too generic).
- **JSON schema for complex metafields** — document the shape in a Markdown file next to the section that consumes it.
- Metafield definitions live in `config/metafields.json` mirror (source-of-truth) + created via `shopify api` in CI.

## Section composition

- **Preset ≠ default.** `default` = installed state, `presets` = section picker entries.
- Group multiple presets when a section has distinct use cases (hero / product-highlight / etc.).
- Blocks: expose `type`, `name`, `settings` in schema; render via `{% for block in section.blocks %}{% render block %}{% endfor %}`.

## CLI workflow

- `shopify theme dev` for local (auto-reload)
- `shopify theme push --nodelete` for iterative staging pushes
- `shopify theme push --live --allow-live` gated behind manual approval in CI
- `shopify theme pull` to sync merchant changes back

## Style conventions

- Tailwind + Liquid interpolation via `@apply` in `assets/tailwind.css`
- Dark theme: `bg-gray-900 / text-gray-100` defaults if brand allows
- Never inline `<style>` in section files — always via `{% stylesheet %}` block

_Contribute proven patterns; strip experiments to `decisions.md` if they didn't survive._
