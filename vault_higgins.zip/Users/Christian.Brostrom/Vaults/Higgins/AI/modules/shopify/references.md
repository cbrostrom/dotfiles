# Shopify — References

Source project brains that contribute to this module:

- `projects/stellar-shopify/` — pattern library, `@akqa-denmark/shopify-theme-build` codemod origin
- `projects/akqa-den-webhandbook/` — team-facing web handbook (consumes this module)
- `projects/akqa-denmark-shopify-theme-build/` — live client theme build (consumes this module)
- `projects/stellar-shopify/plans/alias-to-relative-migration.plan.md` — migration record
- `projects/stellar-shopify/plans/akqa-denmark-shopify-theme-build-extraction.plan.md` — extraction record

## External

- Shopify Dev Docs: `https://shopify.dev/`
- Theme reference: `https://shopify.dev/docs/themes`
- Storefront API: `https://shopify.dev/docs/api/storefront`

## Skill consumers

- `~/.agents/skills/shopify/SKILL.md` — loads this module for all Shopify-related agent sessions
