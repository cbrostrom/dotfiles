---
name: shopify
owner: Christian Brostrom / AKQA DEN
license: proprietary — internal AKQA only, private repo
consumption: git subtree (private repo) or symlink from vault
version: 2026-07
---

# Module: shopify

Cross-client Shopify platform knowledge for AKQA DEN. Distilled from `stellar-shopify`, `akqa-den-webhandbook`, `akqa-denmark-shopify-theme-build`, and prior client work.

## What lives here

| File | Purpose |
|---|---|
| `MODULE.md` | This file — metadata + consumption instructions |
| `gotchas.md` | Non-obvious Shopify traps (theme, Liquid, CLI, metafields) |
| `patterns.md` | Proven patterns (theme architecture, sections, blocks, metafields) |
| `decisions.md` | ADR-lite: date, context, choice, alternatives rejected |
| `references.md` | Cross-references to source project brains |

## Consumption

### Solo (from Christian's own vault)

Nothing to do — the `shopify` skill (`~/.agents/skills/shopify/SKILL.md`) loads this module directly.

### Team (AKQA DEN teammates)

**Private repo only.** All AKQA content is inherently private.

```bash
git clone git@github.com:akqa-den/shopify-kb.git ~/Vaults/AI-shopify-kb
ln -s ~/Vaults/AI-shopify-kb ~/Vaults/AI/modules/shopify
```

Or as a subtree from Christian's vault:

```bash
git subtree split --prefix=modules/shopify -b shopify-module
git push git@github.com:akqa-den/shopify-kb.git shopify-module:main
```

## Versioning

`version: YYYY-MM` — semver-lite by month. Bump on any material change.

## Owner responsibilities

- Distill new patterns from active project brains (`projects/*-shopify*`, `projects/akqa-*`)
- Prune stale patterns quarterly
- Never merge PRs from outside AKQA
