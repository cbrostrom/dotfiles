# Shopify Decisions (ADR-lite)

Format: `## YYYY-MM-DD — <decision>`. Include context, choice, alternatives rejected.

## 2026-06-19 — Adopt `@akqa-denmark/shopify-theme-build` as canonical

**Context:** stellar-shopify migration needed a shared codemod + build layer across AKQA DEN Shopify projects. Each client re-implementing meant drift and duplicated bugs.

**Choice:** Publish `@akqa-denmark/shopify-theme-build` as internal npm package. Adopt in stellar-shopify first, then akqa-denmark-shopify-theme-build, then future clients.

**Alternatives rejected:**
- Fork Shopify's default theme build per client (drift compounds).
- Use `shopify/theme-tools` directly (missing AKQA-specific transforms).

**Status:** v0.1.1 shipped with `snakifyString` export. Codemod complete on stellar-shopify.

## 2026-07-01 — Extract Shopify knowledge to `modules/shopify/`

**Context:** Shopify learnings were scattered across `projects/stellar-shopify/`, `projects/akqa-den-webhandbook/`, `projects/akqa-denmark-shopify-theme-build/`. No shareable unit.

**Choice:** Distill into `modules/shopify/`. Team-shareable via private git subtree to `akqa-den/shopify-kb`.

**Alternatives rejected:**
- Notion / Confluence (dies in isolation, no AI-readable format).
- Per-project brains only (not reusable across clients).
- Public open-source module (AKQA content is private).

**Status:** Module scaffolded 2026-07-01 as part of vault reorganisation.
