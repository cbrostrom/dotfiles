# Shopify Gotchas

Distilled from AKQA DEN client work. Seeded 2026-07-01 — expand as new traps surface.

## Theme / Liquid

- **`@akqa-denmark/shopify-theme-build`** — internal build tool. Codemod-driven migration for stellar-shopify. Pin version explicitly; do not float `latest` in CI.
- **`snakifyString`** helper is exported from theme-build ≥ 0.1.1. Older versions require inline copy.
- **Section schema `preset` + `default`** — `default` is what merchant sees on install; `presets` are what appears in the theme editor's section picker. Confusing them yields "why can't I add my section" bugs.

## Metafields

- **Metafield definitions must be created before referencing** in theme code — no lazy definition.
- **JSON metafields** can be structured but the storefront API returns them as strings; parse in Liquid via `metafield.value | parse_json` (Storefront 2024-01+).

## CLI / dev flow

- `shopify theme dev` binds a port; leaks on crashes. `lsof -i :9292 | tail -1 | awk '{print $2}' | xargs kill -9` to recover.
- **Theme uploads via CI**: use `shopify theme push --json` for machine-parseable output. `--allow-live` is required for live theme; guard behind manual approval.

## Cross-client

- **English-only in code** (identifiers, comments, UI strings, commits). Danish only in customer-facing copy.
- **Never commit `.env`, `.shopify/`** — gitignore both.
- **Tailwind config** varies per client; extract common bits to a shared preset before duplicating.

_Add findings as they surface — one line per fact._
