---
name: agent-harness
owner: Christian Brostrom
license: MIT (personal)
consumption: reference from dotfiles / any harness
version: 2026-07
---

# Module: agent-harness

Christian's multi-harness AI setup. Covers PI, Cursor IDE, Cursor-Agent in Zed, dotfiles hooks, the `kb` CLI, skills routing, and the AI vault contract.

This is the canonical home for meta-brain content — replaced the flat `brains/Brain.md`.

## Files

| File | Purpose |
|---|---|
| `gotchas.md` | Non-obvious harness traps (skill triggers, hook order, slug resolution edge cases) |
| `patterns.md` | Hook layout, skill routing, kb CLI usage, session capture pipeline |
| `decisions.md` | ADR-lite (why kb over brain, why dotfiles overlay, why 4 tiers) |
| `references.md` | Dotfiles paths, hook files, skill locations |
