# Agent Harness Patterns

## PI Setup (primary daily-driver)

_Last updated: 2026-07-02_

### Identity

- **Binary:** `pi` shim at `~/.local/bin/pi` → `~/dotfiles/scripts/pi` → resolves correct node via fnm
- **Config root:** `~/.pi/agent/`
- **Theme:** `gruvbox-dark-hard`
- **Default model:** `cursor/opus-4-7@300k` (provider: cursor)
- **Thinking level:** `medium`
- **Steering mode:** `one-at-a-time`
- **Double-Esc action:** `tree` (session tree navigation)

### Installed packages (`~/.pi/agent/settings.json` → `packages`)

| Package | Role |
|---|---|
| `@juanibiapina/pi-extension-settings` | Extension settings UI (`/extension-settings`) — must load first |
| `@juanibiapina/pi-powerbar` | Powerline status bar (git branch, tokens, context %) |
| `pi-cursor-sdk` | Cursor SDK bridge (run Cursor agents from PI) |
| `pi-mcp-adapter` | MCP server adapter (wires Cursor MCPs into PI) |
| `pi-stats-ext` | Token/cost stats in footer |
| `pi-spark` | Quick ideation / spark prompts |
| `pi-subagentura` | Subagentura subagent framework |
| `pi-yaml-hooks` | Declarative YAML hooks (`~/.pi/agent/hook/hooks.yaml`) |
| `@gotgenes/pi-subagents` | Subagent dispatch — in-process, live widget, parallel queue, session transcripts |
| `pi-ask-user` | Decision handshake skill (`ask-user`) |
| `pi-web-access` | Web fetch + library research skill |
| `@devkade/pi-plan` | Plan mode extension |
| `pi-simplify` | Response simplification |
| `pi-add-dir` | Add directories to session context |
| `pi-prompt-template-model` | Custom slash-command prompt templates |
| `pi-claude-cli` | Claude Code CLI bridge |
| `@plannotator/pi-extension` | Plannotator annotated review UI |
| `pi-slopchop` | AI slop / quality gate |
| `@tmustier/pi-usage-extension` | Usage stats |
| `@tmustier/pi-raw-paste` | Raw paste support |
| `pi-btw` | Background tasks / BTW queue |
| `pi-interactive-shell` | Interactive shell overlay (TUI agents, long processes) |
| `git:github.com/davebcn87/pi-autoresearch` | Autonomous experiment loop (optimize any measurable target) |
| `@tmustier/pi-ralph-wiggum` | Long-running iterative dev loops with pacing + checkpoints |
| `@victor-software-house/pi-curated-themes` | Extended theme collection (incl. gruvbox-dark-hard) |
| `pi-rtk` | Tool output filter (60–90% token reduction on build/test/git/search output) |
| `pi-intercom` | Cross-session messaging bridge (live status broadcast) |
| `pi-smart-fetch` | Browser-like web fetch with Defuddle extraction (`web_fetch`, `batch_web_fetch`) |
| `git:github.com/v2nic/pi-caveman` | Caveman mode: ultra-compressed ~75% token reduction (`/caveman`) |
| `@narumitw/pi-caffeinate` | Keep macOS awake during long agent runs |
| `@narumitw/pi-chrome-devtools` | Chrome DevTools bridge (inspect, navigate, screenshot) |
| `git:github.com/tomsej/pi-ext` *(filtered)* | **leader-key** (`Ctrl+X` palette), **tool-pills** (compact colored output), **permissions** (`/mode`) |
| `@narumitw/pi-wait-what` | Repeat last agent response / show what it was doing |

### Custom extensions (`~/.pi/agent/extensions/` ← `dotfiles/.config/pi/agent/extensions/`)

| File | Purpose |
|---|---|
| `rtk.ts` | Bash command rewriter → `rtk ls`, `rtk git`, etc. (PI-side RTK rewriting) |
| `kb-project.ts` | Powerbar segment: `◈ <slug>  <abbreviated-path>` next to git branch |
| `whimsical.ts` | Whimsical loading messages during long runs |

### PI YAML hooks (`~/.pi/agent/hook/hooks.yaml` ← dotfiles)

| Hook ID | Event | Action |
|---|---|---|
| `session-ready` | `session.created` | Notify: "PI ready. Type \`kb load\`" |
| `idle-kb-tidy` | `session.idle` | Silent `kb prune + compact`; nudge to `.remember` |
| `new-session-digest` | `session.deleted` (reason=new) | Full `kb digest` before slate wipes |
| `session-end-tidy` | `session.deleted` (other) | `kb prune + compact` |
| `aislop-after-edit` | `file.changed` (code files) | `aislop hook pi` quality gate |
| `guard-destructive` | `tool.before.bash` | Block force-push, `rm -rf /`, `npm publish`, etc. |

### RTK config (`~/.pi/agent/rtk-config.json` ← dotfiles)

```json
{
  "enabled": true,
  "logSavings": true,
  "showUpdateEvery": 10,
  "techniques": {
    "ansiStripping": true,
    "truncation": { "enabled": true, "maxChars": 10000 },
    "sourceCodeFiltering": { "enabled": false, "level": "minimal" },
    "smartTruncation": { "enabled": true, "maxLines": 200 },
    "testOutputAggregation": true,
    "buildOutputFiltering": true,
    "gitCompaction": true,
    "searchResultGrouping": true,
    "linterAggregation": true
  }
}
```

`sourceCodeFiltering` off by default — can mangle file reads before edits. Toggle on-demand with `/rtk-toggle-sourceCodeFiltering` for large read-only codebase exploration.

### Smart-fetch defaults (in `settings.json`)

| Setting | Value | Rationale |
|---|---|---|
| `maxChars` | 30 000 | Reduced from 50k — RTK already compresses; enough for full docs |
| `timeoutMs` | 20 000 | +5s over default — handles heavier/slow doc pages |
| `browser` | `chrome_145` | Best bot-bypass profile |
| `os` | `macos` | Match actual machine (avoids mismatch signals on some sites) |
| `removeImages` | `true` | Dev workflow — image refs in markdown are noise |
| `includeReplies` | `extractors` | Comments on GitHub issues, Reddit, HN when extractors support it |
| `batchConcurrency` | 6 | Reduced from 8 — polite for most doc sites |
| `tempDir` | `/tmp/smart-fetch-pi` | Fixed path, easy to find downloads |

Tools registered: `web_fetch`, `batch_web_fetch`.

### Intercom config (`~/.pi/agent/intercom/config.json` ← dotfiles)

```json
{ "brokerCommand": "bun", "brokerArgs": [], "confirmSend": false, "enabled": true, "replyHint": true }
```

Bun as broker (faster than npx tsx). Sessions publish live status: `idle` → `thinking` → `tool:<name>` → `idle`.

### Powerbar segments (configure via `/extension-settings`)

| Segment | Shows |
|---|---|
| `kb-project` | `◈ <slug>  <repo-root-path>` — active project |
| `git-branch` | `⎇ <branch>` |
| `tokens` | `↑<in> ↓<out> $<cost>` |
| `context-usage` | Context window % progress bar |
| `model` | Current model name |
| `provider` | Provider name |

### Subagent model overrides (all currently: `cursor/sonnet-4-6@200k`)

`context-builder`, `planner`, `researcher`, `reviewer`, `scout`, `worker` — override individually via `/extension-settings` or `settings.json → subagents.agentOverrides`.

### Useful PI commands

```
/reload                  — hot-reload extensions, skills, themes
/extension-settings      — toggle/configure powerbar segments, RTK, etc.
/rtk-stats               — token savings since session start
/rtk-on /rtk-off         — enable/disable RTK
/rtk-toggle-sourceCodeFiltering  — toggle code read filtering
kb load                  — inject vault context (personal + modules + project)
.remember                — full kb digest: scan sessions, propose updates
```

---

## Recommendations — Extensions to consider

Well-regarded PI extensions not yet in the stack. "Look here maybe" list:

> Already installed but worth exploring deeper: `tomsej/pi-ext` ships `leader-key` (Ctrl+X palette), `tool-pills` (compact colored output), and `permissions` (`/mode`). The extensions below are not in `settings.json`.

| Package | What it does | Why interesting |
|---|---|---|
| `npm:pi-git-checkpoint` | Auto git stash checkpoint before each turn | Safety net — roll back any turn's side effects |
| `npm:pi-path-guard` | Block writes to protected paths (`.env`, `node_modules`, secrets) | Defense-in-depth for sensitive files |
| `npm:pi-mermaid` | Render Mermaid diagrams inline in terminal | Good for architecture / flow visualisation |
| `npm:@juanibiapina/pi-powerbar-clock` | Clock segment for powerbar | QoL for long sessions |
| `npm:pi-sub-core` | Hourly/weekly subscription usage tracking | Useful if on a PI subscription plan |
| `npm:pi-worktree` | Git worktree manager (create, list, switch) | Pairs with `ce-worktree` skill for parallel feature work |
| `npm:pi-smart-grep` | Token-optimised grep results (groups by file, counts) | Complements RTK's search grouping |
| `git:github.com/tomsej/pi-ext` → `extensions/review` | Semantic git review with tiered persona agents | Better than a bare `/review` prompt (already have pi-ext; just enable this sub-extension) |
| `git:github.com/tomsej/pi-ext` → `extensions/session-snap` | Archive session snapshots to disk with labels | Good for long investigations you want to revisit |
| `git:github.com/tomsej/pi-ext` → `extensions/handoff` | Structured context transfer to a fresh session | Heavier than `context-bridge` skill but more automated |

---

## Tier map (see `AGENTS.md` at vault root)

- `personal/` — Christian's cross-cutting brain, loaded every session
- `modules/<name>/` — reusable, shareable knowledge units
- `projects/<slug>/` — per-project state
- `infra/<host>/` — machine/host state
- `sessions/YYYY/MM/` — auto TF-IDF captures
- `_ops/` — curator reports, migration logs
- `tools/kb` — canonical CLI

## Hook layout (as of 2026-07)

### Cursor (`~/.cursor/hooks.json`)

| Event | Hook | Purpose |
|---|---|---|
| SessionStart | `brain-load.sh` (→ `kb-load.sh`) | Inject personal + modules + project brain |
| Stop | `vault-save.sh` | Write session marker + trigger TF-IDF summariser |

### Claude (`~/dotfiles/.claude/hooks/`)

| Event | Hook | Purpose |
|---|---|---|
| SessionStart | `brain-load.sh` | Load project brain |
| UserPromptSubmit | `effort-classifier.sh` | Classify effort tier |
| UserPromptSubmit | `fast-mode-guard.sh` | Guard against slow tools in fast mode |
| UserPromptSubmit | `brain-save-inject.sh` | Nudge to save when signal detected |
| PreToolUse:Bash | `git-push-guard.sh` | Block force-push to main |
| PreCompact | `brain-save-inject.sh` | Save before context compaction |
| statusline | `statusline.sh` | Render effort/mode/context in status bar |

## kb CLI usage

```bash
kb                          # dashboard
kb load [slug]              # AI context dump (auto-inits)
kb current "<fact>"         # append to current.md
kb next "<action>"          # append to next.md
kb gotcha "<trap>"          # append to gotchas.md
kb done <substr>            # mark next item done
kb save "<summary>"         # write history/YYYY-MM-DD-HHMM.md
kb wrap "<summary>" [topic] # save + set new focus
kb prune [slug]             # move [done:] → history/ (planned)
kb compact [slug]           # cap current.md at 5 bullets (planned)
kb lint                     # validate tree against _schema/
```

## Session capture pipeline (TF-IDF, zero-token)

```
Cursor stop → vault-save.sh → sessions/YYYY/MM/YYYY-MM-DD-<slug>-session.md
                            → summarizer.py (background, overwrites summary section)
```

- Zero-cost: no LLM in the loop.
- Overwrite pattern: final (fullest) transcript always wins.
- Promotion to modules/personal is manual (via curator or `session-promote` grep-based scan).

## Skill routing

Skills live in `~/.agents/skills/<name>/SKILL.md` (shared across agents), some in `~/.claude/skills/` (Claude-specific), `~/.cursor/skills-cursor/` (Cursor-specific).

- `kb` skill → this file (was `vault`)
- `shopify` skill → loads `modules/shopify/`
- `codebase` skill → routes task to relevant repo files, generates `CODEBASE.md` via find if missing

## Slug resolution (kb CLI)

1. `--tier <t> --slug <s>` args
2. `$KB_SLUG` env
3. `personal` — when cwd inside `$VAULT_AI`
4. Active plan `repo:` field
5. `git rev-parse --show-toplevel` basename
6. `$PWD` basename
