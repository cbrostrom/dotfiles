# Agent Harness Gotchas

## Slug resolution

- **Brain/kb slug ≠ `$PWD`.** Cursor hooks run from `~/.cursor/`, not the project root. Use `workspace_roots[0]` from stdin JSON.
- **`git rev-parse --show-toplevel` basename** is a decent fallback but breaks for worktrees and monorepos with slug ambiguity — prefer explicit `--tier --slug`.
- **`personal` slug is implicit** when cwd is inside `$VAULT_AI` — set via kb CLI's new resolution order.

## Hooks

- **Cursor hooks live at `~/.cursor/hooks/`** (per-user) — dotfiles overlay symlinks these to `~/dotfiles/.cursor/hooks/`.
- **`~/.claude.json` mcpServers bypasses the dotfiles overlay.** Manual `claude mcp add` writes here. Audit periodically.
- **Session stop fires per agent turn**, not per conversation. `session-summarize` uses overwrite pattern so the final (fullest) transcript always wins.
- **Self-Modification HARD BLOCK** in auto mode blocks writes to `settings*.json` and `.claude/skills/`. Give user exact commands, continue with unblocked tasks.

## Skills

- **Dot-commands beat skills for simple triggers.** Zero token overhead, no skill load. Rule of thumb: <2 lines of instruction = dot-command, more = skill.
- **Skill triggers are keyword-based** — bad naming = never fires. Include synonyms in the `description:` field.
- **Skill files must have frontmatter** (`name`, `description`, `group`) or the loader silently ignores them.

## Session capture (TF-IDF pipeline)

- **`summarizer.py`** is recall's TF-IDF + TextRank, vendored verbatim at `~/.cursor/hooks/`. Do not "improve" — algorithm choice matters.
- **`parse_cursor_transcript.py`** — Cursor JSONL adapter. Extracts `role` + `message.content`, `Shell` tool calls, skips `thinking` blocks.
- **Recall's `summarizer.py` returns empty via GitHub blob API** — must fetch via raw URL with `refs/heads/master`.

## Vault architecture

- **Two vaults, not one.** `~/Vaults/Me` (human, Obsidian) vs `~/Vaults/AI` (agent-owned, git repo). Don't cross-link.
- **No brain loaded = no vault map.** Bad hook wiring creates rogue folders. Rule: all uncategorized content → `Inbox/` in `~/Vaults/Me`. Never create new top-level folders in either vault.
- **WSL path unverified** (`/mnt/c/Users/christian/Obsidian/AI`) — confirm on MonsterBro bootstrap.

## PI-specific

- **`pi-powerbar` `register-segment` must fire inside `session_start`**, not at extension top-level. Standalone `~/.pi/agent/extensions/*.ts` can load before npm packages set up their event listeners — the emit fires into nothing. Guard with a `registered` flag inside `session_start`.
- **`/reload` ≠ full restart for segment catalog.** New segment registrations only appear in `/extension-settings` after a full PI quit + restart (session_start must fire fresh).
- **PI YAML hook stdout ≠ `additional_context`.** Hook `bash:` actions run but their stdout is NOT injected into the model. Run `kb load` manually or type `.remember`.
- **`pi install npm:X`** writes to `settings.json` and `npm/node_modules/`. The `settings.json` entry persists across restarts; `node_modules/` is managed by PI's internal npm. Do not `npm install` into the agent dir manually.
- **RTK `sourceCodeFiltering` breaks file edits.** It strips content that the model needs to match for `StrReplace`/edit tools. Keep off by default; toggle on for read-only codebase exploration only.
- **PI `tool.before.bash` guard uses exit code 2** to hard-block. Exit 0/1 = allow. Any other non-2 non-0 = allow with warning.
- **fnm project-node switches** break the `pi` binary if invoked directly. Always use the shim at `~/.local/bin/pi` which resolves the correct node via fnm before exec.
- **Intercom broker** (Bun) must be running for cross-session messaging. Bridge activates automatically on PI start when `pi-intercom` is installed and config exists. `/subagents-doctor` shows bridge status.

## Multi-agent

- **Parallel subagents are token-multiplicative.** Same quality as sequential for solo workflows. Use only for 10+ file migrations, adversarial review, browser automation.
- **Zed ACP zombies**: `Zed → acp → node → claude SDK` leaks sessions on task complete. Kill manually if accumulating.
