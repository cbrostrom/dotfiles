# Agent Harness Decisions

## 2026-07-01 — Rename `brain` CLI + skill → `kb`

**Context:** "brain" was project-brain-centric. New tier model covers `personal/`, `modules/`, `projects/`, `infra/` — one knowledgebase, not one brain-per-project.

**Choice:** Rename to `kb` (knowledgebase). Move CLI into vault at `$VAULT_AI/tools/kb`. Keep `brain` as transition symlink. Rename `vault` skill → `kb` skill.

**Alternatives rejected:**
- Keep `brain` — misleading name, doesn't fit the tier map.
- `mem` — too generic, conflicts with `.mem` conventions.
- `notes` — implies human notes, this is agent-owned.

## 2026-07-01 — Two-vault architecture (Me vs AI)

**Context:** Original single vault mixed Obsidian human notes with agent-owned brains. Ownership was ambiguous, causing conflicts.

**Choice:** `~/Vaults/Me` (Obsidian, human) + `~/Vaults/AI` (git, agent-owned).

**Alternatives rejected:**
- Single vault with tier folders — Obsidian's live-index kept touching agent files.
- Everything in Obsidian — plain-text portability suffers; no agent-native git workflow.

## 2026-06-15 — Vault = sole memory; kill Engram auto-hooks

**Context:** Engram's auto-hooks (sync-start/stop, on-prompt, on-stop) duplicated vault writes, added token cost, produced conflicts.

**Choice:** Kill all 4 Engram auto-hooks. Vault-file writes only, via `kb` CLI.

**Alternatives rejected:**
- Keep Engram, disable individual hooks — surface area of what could re-enable was large.
- Both vault + Engram — dual writes, drift risk.

## 2026-06-30 — TF-IDF session capture (recall's algorithm, verbatim)

**Context:** Needed lossy but zero-cost session capture. LLM-based summarising every stop would burn tokens.

**Choice:** Vendor `recall`'s TF-IDF + TextRank verbatim at `~/.cursor/hooks/summarizer.py`. Overwrite pattern per session.

**Alternatives rejected:**
- LLM summariser — cost prohibitive at every-stop cadence.
- Full transcript archive only — no queryable signal.
- Custom summariser — reinvention risk; recall's algorithm is proven.

## 2026-07-01 — PI as primary coding agent harness

**Context:** Multiple harnesses available (PI, Cursor IDE agent, Claude Code, Codex). Need a primary daily-driver with consistent vault integration.

**Choice:** PI as primary. Cursor IDE agent as secondary (same vault via `brain-load.sh`). Claude Code used for long autonomous tasks. Codex CLI for isolated experiments.

**Rationale:** PI has the richest extension/hook ecosystem, powerbar visibility, subagent framework, intercom, and TUI overlays. Cursor IDE agent integrates better with the editor flow but lacks PI's extension depth.

**PI stack decisions:**
- `sourceCodeFiltering` off — too aggressive for edit workflows
- RTK command rewriting on — `rtk ls/git/tree` saves real tokens in heavy shell sessions
- Bun as intercom broker over `npx tsx` — faster startup, already installed
- Custom `kb-project` powerbar segment — project slug + path always visible
- `pi-yaml-hooks` for declarative hooks vs imperative extension hooks — less code to maintain

## 2026-07-01 — Modules as shareable unit

**Context:** No path to share cross-client knowledge (e.g. Shopify) with the AKQA team without exposing personal/project brains.

**Choice:** `modules/<name>/` with `MODULE.md` — each folder extractable via `git subtree split`.

**Alternatives rejected:**
- Full-vault sharing — exposes personal + client-confidential content.
- Notion/Confluence for shared knowledge — dies in isolation, not AI-readable.
- Copy-paste per teammate — drift + versioning nightmare.
