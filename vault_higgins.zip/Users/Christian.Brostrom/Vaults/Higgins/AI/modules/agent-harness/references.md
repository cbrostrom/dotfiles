# Agent Harness — References

## Vault

- `$VAULT_AI/AGENTS.md` — machine contract
- `$VAULT_AI/README.md` — human overview
- `$VAULT_AI/tools/kb` — canonical CLI
- `$VAULT_AI/_schema/*.schema.json` — lint schemas

## Dotfiles

- `~/dotfiles/scripts/brain` — transition shim → `$VAULT_AI/tools/kb`
- `~/dotfiles/scripts/kb` — symlink → `brain`
- `~/dotfiles/.claude/hooks/brain-load.sh` — Claude SessionStart
- `~/dotfiles/.claude/hooks/brain-save-inject.sh` — Claude UserPromptSubmit + PreCompact
- `~/dotfiles/.claude/hooks/brain-optimise-cheap.sh` — periodic cleanup
- `~/dotfiles/.cursor/hooks/brain-load.sh` — Cursor SessionStart (target rename: `kb-load.sh`)
- `~/dotfiles/.cursor/hooks/vault-save.sh` — Cursor Stop hook

## Cursor hooks (symlinked)

- `~/.cursor/hooks/brain-load.sh` → dotfiles
- `~/.cursor/hooks/vault-save.sh` → dotfiles
- `~/.cursor/hooks/summarizer.py` — TF-IDF (vendored from recall)
- `~/.cursor/hooks/parse_cursor_transcript.py` — Cursor JSONL adapter

## Skills

- `~/.agents/skills/kb/SKILL.md` — knowledgebase protocol (was `vault/`)
- `~/.agents/skills/shopify/SKILL.md` — Shopify skill, loads `modules/shopify/`
- `~/.agents/skills/codebase/SKILL.md` — codebase router
- `~/.claude/skills/*` — Claude-specific
- `~/.cursor/skills-cursor/*` — Cursor-specific

## PI agent config

- `~/.pi/agent/settings.json` — packages, model, theme, steering mode
- `~/.pi/agent/settings-extensions.json` — powerbar placement/style, extension toggles
- `~/.pi/agent/hook/hooks.yaml` → `~/dotfiles/.config/pi/agent/hook/hooks.yaml`
- `~/.pi/agent/extensions/kb-project.ts` → `~/dotfiles/.config/pi/agent/extensions/kb-project.ts`
- `~/.pi/agent/extensions/rtk.ts` → `~/dotfiles/.config/pi/agent/extensions/rtk.ts`
- `~/.pi/agent/rtk-config.json` → `~/dotfiles/.config/pi/agent/rtk-config.json`
- `~/.pi/agent/intercom/config.json` → `~/dotfiles/.config/pi/agent/intercom/config.json`
- `~/.pi/agent/npm/node_modules/` — installed packages (managed by `pi install`)

## PI skills (from packages)

- `pi-subagents` → skill: `pi-subagents` (subagent dispatch)
- `pi-ask-user` → skill: `ask-user`
- `pi-web-access` → skill: `librarian`
- `pi-prompt-template-model` → skill: `prompt-template-authoring`
- `pi-interactive-shell` → skill: `pi-interactive-shell`
- `pi-intercom` → skill: `pi-intercom`
- `@tmustier/pi-ralph-wiggum` → skill: `pi-ralph-wiggum`
- `git:davebcn87/pi-autoresearch` → skills: `autoresearch-create`, `autoresearch-finalize`, `autoresearch-hooks`

## Vault-side historical

- `projects/dotfiles/gotchas.md` — dotfiles-specific traps
- `projects/dotfiles/history/*` — session history
- Original `brains/Brain.md` (deleted 2026-07-01) → distilled here
