# Vault Ops Decisions

## 2026-07-01 — Reorganise from `brains/` to tiered layout

**Context:** Original vault had 91 files across 3 coexisting formats (modular folders, flat files, hybrid), 4 hollow stubs, empty `knowledge/` tier, ghost projects, no root-level contract, no shareable unit.

**Choice:** Rename `brains/ → projects/`. Introduce `personal/`, `modules/`, `infra/`, `_ops/`. Add `AGENTS.md` contract at vault root. Enforce schema via `kb lint`.

**Alternatives rejected:**
- Fix in place — no way to separate concerns without renaming.
- Delete and rebuild — loses history.
- Adopt someone else's PKM (Logseq, Roam) — losses git-native workflow, portability.

## 2026-07-01 — `modules/` as canonical shareable unit

**Context:** Team knowledge (Shopify patterns) was scattered across per-client project brains. No path to share.

**Choice:** `modules/<name>/` folders with `MODULE.md`, extractable via `git subtree split`. Private-by-default for AKQA content.

**Alternatives rejected:**
- Share entire vault — mixes personal + client-confidential.
- Copy-paste into a wiki — drift immediately.
- Notion/Confluence — dies in isolation from source of truth.

## 2026-07-01 — Retroactive session partitioning (`sessions/YYYY/MM/`)

**Context:** Flat `sessions/` dir would balloon; mixed layout after only-forward partitioning would be inconsistent.

**Choice:** Move all existing session files retroactively into `sessions/YYYY/MM/`. Everything in line.

**Alternatives rejected:**
- Forward-only — mixed layout is confusing; violates "boring predictable" convention.

## 2026-07-01 — `kb lint` schema enforcement

**Context:** Schema drift is the root cause of the original clutter. Convention-only enforcement failed.

**Choice:** JSON schemas in `_schema/` + `kb lint` command + pre-commit hook.

**Alternatives rejected:**
- Docs-only enforcement — proven to fail (this vault).
- Full test suite — overkill for a markdown vault.
