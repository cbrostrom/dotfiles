# Vault Ops Gotchas

- **Do not create top-level `.md`** other than `AGENTS.md`, `README.md`, `PLAN.md`. `kb lint` flags them.
- **`.legacy` / `.old` / `.bak` suffixes are forbidden.** Move to `archive/`.
- **Stub brains break the system.** Empty `current.md` files with only a header get loaded and waste tokens. `kb lint` enforces min 200B.
- **`current.md` ≤ 5 bullets — hard cap.** Overflow triggers `kb compact` (planned) or manual trim to `history/`.
- **`[done:]` items rot in `next.md`** if not pruned. `kb prune` moves them to `history/`. Wire to weekly cron.
- **Slug format**: `lowercase-kebab` only. `Christian.Brostrom` and `CamelCase` are lint errors — hence rename to `personal`.
- **Session files must land in `sessions/YYYY/MM/`.** The stop hook writes them; if flat files appear at `sessions/` root, hook is misconfigured.
- **Every project folder must have exactly**: `INDEX.md current.md next.md gotchas.md` + optional dirs `history/ archive/ plans/`. Anything else = orphan lint error.
- **Every module folder must have**: `MODULE.md gotchas.md patterns.md decisions.md references.md`. Missing files = lint error.
- **The `kb` CLI lives at `$VAULT_AI/tools/kb`** — moved from `~/dotfiles/scripts/brain`. `brain` is a shim that execs `kb`. Never edit the shim.
- **Session partitioning is retroactive-only during migration.** Ongoing sessions land partitioned via hook.
