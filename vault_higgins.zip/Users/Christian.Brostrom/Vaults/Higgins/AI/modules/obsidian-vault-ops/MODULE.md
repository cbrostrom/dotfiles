---
name: obsidian-vault-ops
owner: Christian Brostrom
license: MIT (personal)
consumption: reference from this vault; not intended for external consumption
version: 2026-07
---

# Module: obsidian-vault-ops

Documentation of this vault's own operations — the meta-module. How the tier model works, how `kb` maintains it, how sessions promote upward, how modules extract.

**Self-referential:** this module documents the system it's inside.
