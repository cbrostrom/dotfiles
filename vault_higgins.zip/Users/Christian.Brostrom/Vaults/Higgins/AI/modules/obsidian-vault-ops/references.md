# Vault Ops — References

## In-vault

- `AGENTS.md` — machine contract
- `README.md` — human overview
- `PLAN.md` — reorganisation plan (this migration)
- `_schema/*.schema.json` — lint schemas
- `_ops/migration-2026-07-01.md` — migration log
- `_ops/curator-reports/2026-06-28.md` — pre-migration curator scan

## Related modules

- `modules/agent-harness/` — hooks, skills, kb CLI, harness-specific setup

## Skills

- `~/.agents/skills/kb/SKILL.md` — knowledgebase protocol
