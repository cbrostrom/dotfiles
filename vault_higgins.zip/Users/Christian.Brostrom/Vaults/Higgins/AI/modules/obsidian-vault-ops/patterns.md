# Vault Ops Patterns

## Tier model

```
personal/  → cross-cutting, loaded every session
modules/   → shareable, extractable via git subtree
projects/  → per-project state
infra/     → per-machine state
sessions/  → auto TF-IDF captures (YYYY/MM/)
_ops/      → curator reports, migration logs
tools/     → kb CLI
archive/   → retired items
```

## Load order (every session)

1. `personal/current.md` + `personal/preferences.md` + `personal/gotchas.md`
2. `modules/*/gotchas.md` (all)
3. `projects/<slug>/{current,next,gotchas}.md`
4. Relevant `infra/<host>/current.md` if host matches

## Write protocol

- **Only `kb` writes.** No harness edits vault files directly.
- **Append semantics** — `current`, `next`, `gotcha` all append; never overwrite.
- **`kb save` / `kb wrap`** — timestamped snapshot to `history/`.
- **`[done: YYYY-MM-DD]`** marks completion inline; `kb prune` moves to `history/`.

## Sharing modules

```bash
git subtree split --prefix=modules/shopify -b shopify-module
git push git@github.com:akqa-den/shopify-kb.git shopify-module:main
```

Teammates consume via clone + symlink or subtree pull.

## Session promotion (flywheel)

1. Session ends → hook writes TF-IDF summary to `sessions/YYYY/MM/`
2. Weekly `session-promote` (planned) — grep for gotcha patterns → `sessions/candidates.md`
3. User reviews candidates → `kb gotcha` / manual edit into `modules/<name>/gotchas.md` or `personal/gotchas.md`
4. Next session loads denser context → cheaper session

## Maintenance rituals

- **Weekly**: `session-promote` review, `kb prune` per active project
- **Monthly**: `kb compact` per project, `memory-curator` scan → `_ops/curator-reports/`
- **Quarterly**: module review — prune stale patterns, bump `version` in `MODULE.md`

## Schema enforcement

`kb lint` walks the tree and reports:
- Missing required files
- Stub brains
- Oversized `current.md`
- Stale `[done:]` items
- Orphan files in project roots
- Missing module files
- Top-level `.md` violations

Wire to pre-commit hook.
