---
name: bun-sqlite-hono
owner: Christian Brostrom
license: MIT (personal)
consumption: symlink or subtree
version: 2026-07
---

# Module: bun-sqlite-hono

Reusable Bun + Hono + Drizzle + SQLite (WAL) patterns. Single-process, single-container backend architecture. Distilled from `laesr` (RSS reader) and `huskr` (todos + sync).

## Files

| File | Purpose |
|---|---|
| `gotchas.md` | Non-obvious Bun/SQLite/sync traps |
| `patterns.md` | Migration runner, WAL pragmas, job queue, SSE, WebSocket |
| `decisions.md` | ADR-lite (why not Redis, why not Supabase, etc.) |
| `references.md` | Source project brains |
