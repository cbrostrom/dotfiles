# Bun + SQLite + Hono — References

## Source project brains

- `projects/laesr/` — RSS reader, 10 perf fixes, kiosk view, YouTube fixes, pubDate freeze, feed dedup
- `projects/laesr/history/2026-07-01-2214-preTrim-current.md` — full pre-distillation state
- `projects/huskr/` — todos + Tauri sidecar + LWW sync engine + SQLCipher
- `projects/huskr/gotchas.md` — sync/crypto/proxy gotchas

## Related modules

- `modules/tauri-solidjs/` — frontend patterns; sidecar spawn lifecycle overlaps

## External

- Bun docs: `https://bun.sh/docs`
- Hono docs: `https://hono.dev/`
- Drizzle docs: `https://orm.drizzle.team/`
- SQLite WAL: `https://sqlite.org/wal.html`
