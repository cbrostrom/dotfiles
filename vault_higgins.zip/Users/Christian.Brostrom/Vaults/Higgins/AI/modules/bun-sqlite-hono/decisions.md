# Bun + SQLite + Hono Decisions

## 2026 — Bun + Hono + Drizzle + SQLite over Node + Express + Prisma + PostgreSQL + Redis

**Context:** laesr started as Express + Prisma + PostgreSQL + Redis + Node. Complexity was drowning single-user throughput needs.

**Choice:** Single-process, single-container Bun + Hono + Drizzle + SQLite (WAL). No Redis, no Bull, no Prisma, no PostgreSQL.

**Alternatives rejected:**
- Keep Node + Express — Bun startup + fetch API cleaner.
- Fastify — Hono has better types, smaller footprint.
- Prisma — Drizzle is faster, closer to SQL, no `prisma generate` step.
- PostgreSQL — SQLite handles the actual load; PG was cargo-culted.

**Status:** Migration complete for laesr. huskr uses same stack from day one.

## 2026-06-28 — Reject Supabase for huskr sync

**Context:** Considered Supabase as sync layer for huskr's local-first architecture.

**Choice:** Stay on Bun + SQLite + custom WS broadcast. Revisit PowerSync post-P1 if delta sync gets painful.

**Alternatives rejected:**
- Self-hosted Supabase — 20+ Docker services, opposite of Vaultwarden simplicity.
- Supabase Realtime — redundant with existing WS layer.
- PowerSync now — premature; existing sync works for current scale.
- ElectricSQL — same problem as Supabase, more moving parts.

**Status:** Sync engine P3 complete on custom stack.

## 2026 — Dockhand over Portainer

**Context:** SuperBro VPS needed a container UI.

**Choice:** Dockhand (`fnsys/dockhand:latest`, port 3000).

**Alternatives rejected:**
- Portainer — bloated, opinionated, licensing dance.
- Raw `docker compose` — fine but no ops-friendly UI for stack env editing.

**Status:** Stable, env vars managed via Dockhand UI (not committed compose files).
