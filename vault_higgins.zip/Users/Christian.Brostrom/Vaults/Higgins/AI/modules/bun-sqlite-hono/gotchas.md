# Bun + SQLite + Hono Gotchas

## Bun runtime

- **Bun does not run on iOS.** Any Tauri iOS client using a Bun sidecar needs sync-only mode OR a Rust port of the hot path with `sqlx`.
- **Bun `--hot` reloads duplicate workers.** Use `globalThis` Symbol guards to prevent double startup of long-lived workers/timers.
- **`bun:sqlite`** is a wrapper around SQLite3 — no async; blocks the thread. Fine for embedded, terrible for high-concurrency shared DBs (use PostgreSQL there).

## SQLite / WAL

- **WAL pragmas at startup** — always:
  ```sql
  PRAGMA journal_mode=WAL;
  PRAGMA synchronous=NORMAL;
  PRAGMA busy_timeout=5000;
  PRAGMA foreign_keys=ON;
  ```
- **VACUUM is dangerous during operation** — locks DB, breaks WAL. Skip in prod; use `PRAGMA wal_checkpoint(TRUNCATE)` for maintenance instead.
- **`tauri-plugin-sql` does not support multi-statement SQL** via `execute()`. Split migration files or use `sqlite.exec()` from a Bun sidecar.

## Migrations

- **Custom migration runner** — Drizzle's default doesn't handle multi-statement bundles well. Write a `sidecar-migrate.ts` that reads all `*.sql` files and calls `sqlite.exec()`.
- **Schema drift detection**: emit "no drift detected" or "applied N repair statements" so CI can green either way. Second run must always be clean.
- **`onConflictDoUpdate` must never include `pubDate`** (or any first-seen date). Preserves original insertion time.

## Job queue

- **Job queue is SQLite-backed** (`lib/jobQueue.ts`) with dedupe on `(dedupe_key, status)` partial unique index.
- **Feed dedupe key pattern**: `feed_update:${feedId}` — unify across cron, routes, opml.

## HTTP / SSE / WebSocket

- **SSE heartbeat every 25s** requires `idleTimeout: 255` on Bun server (default 10s kills streams).
- **WebSocket cookie auth** must survive reverse proxies; Traefik `responseforwarding.flushinterval=0ms` is load-bearing for INSTANT sync.
- **Article list endpoints exclude `content` + `aiTopics`** — extract to `articleListColumns` in `lib/articleColumns.ts` and reuse.

## Sync / crypto

- **`ENCRYPTION_KEY` (64-char hex)** required even in "notes archived" mode when Butler stores encrypted LLM keys.
- **SQLCipher passphrase loss is destructive** — Local mode = factory reset, Connected mode = server resync. Onboarding must warn loudly.
- **Per-launch sidecar token is not persisted.** Users pasting the token into Claude Desktop will break on Huskr restart. Either auto-update Claude's config or surface the change in Settings.
- **Supabase is NOT the right sync layer** for local-first apps (decided 2026-06-28). 20+ Docker services, Realtime is redundant with WS broadcast layer, still needs custom server for AI. Stay Bun + SQLite. PowerSync worth revisiting if delta sync gets hard.

## Container / infra

- **SuperBro VPS** (6C EPYC, 12GB RAM, 194GB disk) — no swap; OOM kill under sustained load.
- **Container mgmt = Dockhand** (port 3000, `fnsys/dockhand:latest`), NOT Portainer. Stack env vars live in Dockhand, not in `docker-compose.yml`.
