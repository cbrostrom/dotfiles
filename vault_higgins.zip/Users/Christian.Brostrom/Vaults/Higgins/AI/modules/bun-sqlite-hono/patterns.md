# Bun + SQLite + Hono Patterns

## Startup pragmas

```typescript
db.exec(`
  PRAGMA journal_mode=WAL;
  PRAGMA synchronous=NORMAL;
  PRAGMA busy_timeout=5000;
  PRAGMA foreign_keys=ON;
  PRAGMA temp_store=MEMORY;
`);
```

## Migration runner

```typescript
// sidecar-migrate.ts
import { readdirSync, readFileSync } from "node:fs";
import { Database } from "bun:sqlite";

const db = new Database("app.db");
const files = readdirSync("./migrations").filter((f) => f.endsWith(".sql")).sort();
for (const f of files) {
  const sql = readFileSync(`./migrations/${f}`, "utf8");
  db.exec(sql);
  console.log(`applied ${f}`);
}
```

## Job queue (SQLite-backed)

- Table `jobs(id, type, payload, status, dedupe_key, created_at, ...)`
- Partial unique index: `CREATE UNIQUE INDEX jobs_dedupe ON jobs(dedupe_key) WHERE status IN ('queued','running')`
- Worker polls `SELECT ... WHERE status='queued' ORDER BY created_at LIMIT 1`, sets `status='running'`, executes, sets `status='done' or 'failed'`.
- `globalThis` symbol guard prevents duplicate worker startup under `bun --hot`.

## Two entrypoints (dev vs prod)

```
apps/api/src/index.ts     dev :4000, hot reload
apps/api/server.ts        prod, serves API + SPA static
```

## Auth context (frontend)

- `AuthContext` tracks `serverError` signal.
- `ProtectedRoute` shows "Server unavailable" retry screen on 5xx instead of redirecting to login.

## Feed extraction (RSS-specific but pattern reusable)

- Per-source config: `feeds.extract_full_content` boolean column (default `false`).
- Route gates behavior on setting; `contentPrewarm` cron skips off-feeds.
- `media:thumbnail` inside `media:group` for YouTube (nested — easy miss).

## Kiosk / public endpoints

- `/kiosk?key=<rss-api-key>` — key-gated, auto-refresh every 5 min.
- API key stored in settings table (e.g. `rss_api_key`), generated via `POST /api/settings/rss-key/generate`.

## LWW sync engine

- `synced_at` + `sync_origin` columns on synced tables.
- `sync_config` table for endpoint + credentials.
- Bidirectional Last-Writer-Wins between local sidecar and remote server.
