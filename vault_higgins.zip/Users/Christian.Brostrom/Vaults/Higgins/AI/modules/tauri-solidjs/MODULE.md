---
name: tauri-solidjs
owner: Christian Brostrom
license: MIT (personal)
consumption: symlink or subtree
version: 2026-07
---

# Module: tauri-solidjs

Reusable Tauri 2 + SolidJS + TypeScript patterns. Distilled from `hopper` (browser sidebar) and `huskr` (todo app + Bun sidecar).

## Files

| File | Purpose |
|---|---|
| `gotchas.md` | Non-obvious Tauri/SolidJS/WKWebView traps |
| `patterns.md` | Proven patterns (drag-and-drop, reactivity, IPC) |
| `decisions.md` | ADR-lite |
| `references.md` | Source project brains |

## Consumption

```bash
# Symlink into another vault
ln -s ~/Vaults/AI-shared/tauri-solidjs ~/Vaults/AI/modules/tauri-solidjs
```

Or split as subtree if extracted to its own repo.
