# Tauri + SolidJS Gotchas

- **`<For>` stable keys required.** Use `createMemo` returning stable string primitives (e.g. `"t-{id}"`, `"f-{id}"`) — object refs from stores re-render everything on any store change.
- **WKWebView loses hover state after drag.** Fix: expose a Rust `jiggle_cursor` Tauri command; call from drag-end handler. Nudges cursor 1px to re-fire hover.
- **`HoldDragSensor` innermost-wins**: outer `createDraggable` overwrites inner drag when event bubbles. Guard with `if (holdTimer !== null) return` inside the outer sensor so the inner (later-registered) wins.
- **Folder-child draggables NOT in SortableProvider.** Use plain `createDraggable("it-{id}")` for tabs inside folders; SortableProvider re-projects positions and breaks nested drag.
- **`tabAwareCollision`**: implement a custom collision detector so tabs sort only against tabs and folders don't shift during tab drags.
- **`InlineInput` double-commit**: guard with a `committed` boolean signal or blur+enter both fire commit.
- **Ghost styling for dragged element**: `opacity-90 ring-2 ring-accent/60 shadow-xl z-50 rounded-md` — this exact stack looks native on macOS.
- **Sidebar autohide + multi-monitor**: cursor position must be checked against the currently-active monitor's bounds (Tauri's `Monitor::size()`), not primary monitor. Option key to lock cursor to current monitor.
- **`tauri-plugin-sql`** doesn't support multi-statement SQL via `execute()`. Use `sqlite.exec()` from a Bun sidecar OR split migrations into single-statement files.
- **No `.unwrap()` in Rust production code.** Use `.expect("<reason>")` or `?` — panics on Tauri commands crash the whole webview.
