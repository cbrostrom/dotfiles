# Tauri + SolidJS Patterns

## Reactivity

- **Stable `<For>` keys via `createMemo`** returning array of string primitives. Never pass array of objects — SolidJS uses identity, store mutations swap objects.
- **`createStore` over `createSignal` for nested state** — mutations via `produce()` keep referential stability of unrelated branches.
- **Signals over stores for scalars.** Stores add cost for single values.

## Drag-and-drop (`@thisbeyond/solid-dnd`)

- Custom `HoldDragSensor` — press-and-hold before drag activates; prevents accidental drags on scroll/click.
- Innermost-wins guard: outer sensor short-circuits when inner `holdTimer` is active.
- Custom collision detector for asymmetric sort rules (tabs vs folders).
- `handleDragEnd` calls `jiggle_cursor` Tauri command to restore hover state.

## Tauri IPC

- **Commands**: `#[tauri::command]` — always return `Result<T, String>` for JS-serializable errors.
- **Events**: `app.emit("event-name", payload)` — subscribe with `listen<T>("event-name", cb)` in JS.
- **Managed state**: `.manage(Mutex<T>::new(t))` in `setup`, access with `state: State<Mutex<T>>`.
- **Sidecar processes**: spawn via `Command::new_sidecar()`, read stdout for `READY` marker, store port+token in managed state, expose via a `get_sidecar_config` command.

## Windows / tray

- **Standalone Settings window**: `WebviewWindowBuilder::new(app, "settings", WebviewUrl::App("/settings".into()))` from a `open_settings` command.
- **Tray icon modes**: dock / status bar / both / neither — user preference, requires calling `app.set_activation_policy(ActivationPolicy::Accessory)` for status-bar-only.
- **Multi-monitor cursor tracking**: `app.monitor_from_point()` returns the current monitor; use its bounds to compute autohide edges.

## Build / quality gates

- `aislop ≥ 90`, `fallow 0 issues`, `tsc 0 errors`, `cargo clippy -- -D warnings` clean before commit.
