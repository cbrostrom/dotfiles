# Tauri + SolidJS Decisions

## 2026-06 — Choose SolidJS over React for Tauri apps

**Context:** Both hopper and huskr needed a reactive frontend framework in Tauri.

**Choice:** SolidJS. Fine-grained reactivity, no VDOM diffing, tiny bundle.

**Alternatives rejected:**
- React — VDOM cost visible in Tauri sidebars; hooks re-run mental model wrong for stores.
- Svelte — nice, but SolidJS's JSX matches existing muscle memory.

## 2026-06 — `HoldDragSensor` over default sensors

**Context:** Default `PointerSensor` triggers drags on scroll intent inside tab lists.

**Choice:** Custom press-and-hold sensor with innermost-wins guard.

**Alternatives rejected:**
- `TouchSensor` with delay — desktop-first app, wrong primitive.
- Long-press via CSS-only — no callback to gate the drag lifecycle.

## 2026-06 — `jiggle_cursor` Rust command for WKWebView hover

**Context:** WKWebView on macOS keeps stale hover after drag-end. No pure JS fix works.

**Choice:** Rust Tauri command that moves the cursor 1px and back via `CGEventCreateMouseEvent`.

**Alternatives rejected:**
- CSS `pointer-events: none` toggle — flickers, doesn't reliably clear hover.
- Force mousemove event via JS — WKWebView ignores synthetic events for hover.
