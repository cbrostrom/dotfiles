# Tauri + SolidJS — References

## Source project brains

- `projects/hopper/` — browser sidebar, drag-and-drop, WKWebView fixes, multi-monitor
- `projects/hopper/history/2026-07-01-2214-preTrim-current.md` — full pre-distillation state
- `projects/huskr/` — todo app, Tauri sidecar spawn/lifecycle, IPC patterns

## External

- Tauri 2 docs: `https://v2.tauri.app/`
- SolidJS docs: `https://www.solidjs.com/docs`
- `@thisbeyond/solid-dnd`: `https://solid-dnd.com/`
- Tauri plugin-sql: `https://v2.tauri.app/plugin/sql/`
